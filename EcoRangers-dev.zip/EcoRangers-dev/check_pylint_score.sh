#!/bin/sh

# Run pylint and capture the output
PYLINT_OUTPUT=$(pylint "$@" 2>&1)

# Print the pylint output for debugging
echo "$PYLINT_OUTPUT"

# Extract the pylint score
PYLINT_SCORE=$(echo "$PYLINT_OUTPUT" | grep "Your code has been rated at" | awk '{print $7}' | cut -d'/' -f1)

# Print the extracted score for debugging
echo "Extracted pylint score: $PYLINT_SCORE"

# Define the minimum acceptable score
MIN_SCORE=8.0

# Compare the pylint score with the minimum score
if (( $(echo "$PYLINT_SCORE < $MIN_SCORE" | bc -l) )); then
  echo "pylint score is below the minimum threshold of $MIN_SCORE. Current score: $PYLINT_SCORE"
  exit 1
fi

# Print success message
echo "pylint score is above the minimum threshold of $MIN_SCORE. Current score: $PYLINT_SCORE"