# Databricks notebook source

import brickflow
from brickflow import Project, PypiTaskLibrary, JarTaskLibrary, ctx
import products.electricity_data_product.workflows as workflows

if ctx.env == "prod":
    branch = "main"
else:
    branch = ctx.env


def main() -> None:
    with Project(
        "electricity_data_product",
        git_reference="git_branch/" + branch,
        git_repo="https://github.com/nike-data-engineering/EcoRangers",
        provider="github",
        libraries=[
            PypiTaskLibrary(package="pandas"),
            PypiTaskLibrary(package="boxsdk"),
            PypiTaskLibrary(package="spark-expectations"),
            PypiTaskLibrary(package="data-common-utilities"),
            PypiTaskLibrary(package="cerberus-python-client"),
            PypiTaskLibrary(package="prettytable"),
            PypiTaskLibrary(package="snowflake-connector-python"),
            PypiTaskLibrary(package="delta-spark"),
            PypiTaskLibrary(package="asyncssh"),
            JarTaskLibrary(
                "dbfs:/kafka-jars/databricks-shaded-strimzi-kafka-oauth-client-1.1.jar"
            ),
        ],
        enable_plugins=False,
    ) as f:
        f.add_pkg(workflows)


if __name__ == "__main__":
    main()
