import os
from brickflow import (
    ctx,
    Cluster,
    Workflow,
    WorkflowPermissions,
    Group,
    PypiTaskLibrary,
    JarTaskLibrary,
    TaskSettings,
    Trigger,
)
from . import (
    run_ingest_curated_to_integrated,
    SparkUtils,
    LoggerUtils,
    QueryUtils,
)

from brickflow.bundles.model import (
    JobsTriggerTableUpdate,
    JobsTriggerFileArrival,
    JobsTriggerTable,
    JobsHealthRules,
)

JOB_ID = ctx.get_parameter(key="brickflow_job_id", debug="987987987987987")
ENV = ctx.env

# Extracting script location and changing directory to parent
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
PROJECT_NAME = "electricity_data_product"
WF_NAME = "extrapolation_electricity_integrated_to_bcl"
DATABASE = ""
if ENV == "local":
    ENV = "dev"
    DATABASE = "development.global_sustainability_dev"
if ENV == "dev":
    DATABASE = "development.global_sustainability_dev"
elif ENV == "qa":
    DATABASE = "non_published_domain.global_sustainability_qa"
elif ENV == "prod":
    DATABASE = "non_published_domain.global_sustainability_prod"

BATCH_ID_TRACKER_TABLE = DATABASE + "." + "sdf_batch_load_tracker"
root_dir = os.path.dirname(script_dir)


def create_job_cluster(name: str):
    aws_config = {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK",
        "instance_profile_arn": "arn:aws:iam::572801069962:instance-profile/sole/group/ecorangers",
        "spot_bid_price_percent": 100,
        "ebs_volume_type": "GENERAL_PURPOSE_SSD",
        "ebs_volume_count": 3,
        "ebs_volume_size": 100,
    }
    spark_conf = {
        "spark.databricks.delta.schema.autoMerge.enabled": "true",
        "spark.databricks.delta.properties.defaults.enableChangeDataFeed": "true",
        "spark.databricks.delta.changeDataFeed.timestampOutOfRange.enabled": "true",
        "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
        "spark.databricks.service.server.enabled": "false",
        "spark.databricks.delta.preview.enabled": "true",
        "spark.databricks.delta.merge.enableLowShuffle": "true",
        "spark.sql.files.ignoreMissingFiles": "true",
    }
    custom_tags = {
        "nike-environment": ENV,
        "nike-squad": "ecorangers",
        "nike-techsolution": "2f98556ae03985998fc0ee7c3b94260aac32590c",
        "nike-initiative": "sustainability-data-foundation",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    return Cluster(
        name=name,
        spark_version="13.3.x-scala2.12",
        node_type_id="m7gd.large",
        driver_node_type_id="m7gd.large",
        min_workers=1,
        max_workers=2,
        data_security_mode="USER_ISOLATION",
        enable_elastic_disk=True,
        spark_conf=spark_conf,
        policy_id="0009B9D23ECAAA0B",
        custom_tags=custom_tags,
        aws_attributes=aws_config,
        runtime_engine="STANDARD",
    )


wf = Workflow(
    WF_NAME,
    health=[
        JobsHealthRules(metric="RUN_DURATION_SECONDS", op="GREATER_THAN", value=7200.0)
    ],
    default_cluster=create_job_cluster("ecorangers_job_cluster"),
    # schedule_quartz_expression=" 0 15 22 ? * SAT * ",  # 22:15 UTC (03:45 AM IST Every Sunday)
    # timezone="UTC",
    tags={
        "nike-initiative": "sustainability-data-foundation",
        "nike-techsolution": "2f98556ae03985998fc0ee7c3b94260aac32590c",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    },
    permissions=WorkflowPermissions(
        can_manage=[
            Group("App.NikeSole.ecorangers.Developer"),
            Group("App.NikeSole.ecorangers.DataAdmin"),
        ],
        can_view=[Group("App.NikeSole.ecorangers.Analyst")],
    ),
    trigger=Trigger(
        pause_status="UNPAUSED",
        table_update=JobsTriggerTableUpdate(
            table_names=[f"{DATABASE}.see_table_trigger_checkpoint"]
        ),
    ),
    default_task_settings=TaskSettings(max_retries=3),
    libraries=[
        JarTaskLibrary(
            "dbfs:/kafka-jars/databricks-shaded-strimzi-kafka-oauth-client-1.1.jar"
        ),
        PypiTaskLibrary(package="pandas"),
        PypiTaskLibrary(package="boxsdk"),
        PypiTaskLibrary(package="spark-expectations"),
        PypiTaskLibrary(package="snowflake-connector-python"),
        PypiTaskLibrary(package="data-common-utilities"),
        PypiTaskLibrary(package="cerberus-python-client"),
        PypiTaskLibrary(package="prettytable"),
        PypiTaskLibrary(package="delta-spark"),
        PypiTaskLibrary(package="asyncssh"),
    ],
)


@wf.task
# this task does nothing but explains the use of context object
def start():
    logger = LoggerUtils().get_logger_object()
    job_name = str(__name__).split(".")[-2].replace("/", "")
    spark = SparkUtils().get_spark_session(logger, job_name)
    QueryUtils(spark=spark).update_batch_load_tracker(
        project_name=PROJECT_NAME, env=ENV, batch_tracker_table=BATCH_ID_TRACKER_TABLE
    )
    print(f"Starting the workflow with env: {ENV}, job_run_id: {JOB_ID}")


# extrapolation_DATA
@wf.task(depends_on=start, name="extrapolation_integrated_to_integrated_site")
def curatedhist_to_integrated():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="extrapolation_to_integrated_electricity_site_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="extrapolation_electricity_site_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(depends_on=start, name="extrapolation_integrated_to_integrated_detail")
def curatedhist_to_integrated():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="extrapolation_to_integrated_electricity_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="extrapolation_electricity_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on=[
        "extrapolation_integrated_to_integrated_site",
        "extrapolation_integrated_to_integrated_detail",
    ],
    name="extrapolation_integrated_to_integrated_site_and_detail",
)
def curatedhist_to_integrated():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="extrapolation_to_integrated_electricity_site_and_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="extrapolation_electricity_site_and_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
        extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
    )


# merge_list = [
#     "extrapolation_integrated_to_integrated_site_and_detail",
# ]
#
#
# # Merge
# @wf.task(depends_on=merge_list, name="merge")
# def integrated_merge():
#     logger = LoggerUtils().get_logger_object()
#     logger.info("************ Merge scripts completed ************")


# @wf.task(
#     depends_on="extrapolation_integrated_to_integrated_site_and_detail",
#     name="dbx_integrated_to_snowflake_site",
# )
# def trigger_ingest_dbx_integrated_to_bcl():
#     run_ingest_integrated_to_bcl(
#         config_path=root_dir + "/spark/python/config/snowflake/",
#         config_name="electricity_integrated_to_bcl_site_config.toml",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on="extrapolation_integrated_to_integrated_site_and_detail",
#     name="dbx_integrated_to_snowflake_detail",
# )
# def trigger_ingest_dbx_integrated_to_bcl_snf_detail():
#     run_ingest_integrated_to_bcl(
#         config_path=root_dir + "/spark/python/config/snowflake/",
#         config_name="electricity_integrated_to_bcl_detail_config.toml",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on="extrapolation_integrated_to_integrated_site_and_detail",
#     name="dbx_integrated_to_snowflake_site_and_detail",
# )
# def trigger_ingest_dbx_integrated_to_bcl_site_detail():
#     run_ingest_integrated_to_bcl(
#         config_path=root_dir + "/spark/python/config/snowflake/",
#         config_name="electricity_integrated_to_bcl_site_and_detail_config.toml",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


### task added to do table optimisation ###
@wf.task(
    depends_on=["extrapolation_integrated_to_integrated_site_and_detail"],
    name="table_optimisation",
)
def table_optimisation():
    logger = LoggerUtils().get_logger_object()
    job_name = str(__name__).split(".")[-2].replace("/", "")
    spark = SparkUtils().get_spark_session(logger, job_name)
    QueryUtils(spark=spark).run_delta_table_optimisation(
        logger=logger,
        config_path=root_dir + "/spark/python/config/misc",
        config_name="electricity_table_details_vacuum.toml",
        env=ENV,
        bf_context=ctx,
    )


@wf.task(depends_on="table_optimisation", name="end")
# this task does nothing but explains the use of context object
def end():
    logger = LoggerUtils().get_logger_object()
    job_name = str(__name__).split(".")[-2].replace("/", "")
    # run_sla_alerts(config_path=root_dir + "/../common_utilities
    # /spark/python/config", config_name="alerts_config.toml", env = env,
    #  bf_context=ctx, project_name=project_name, wf_name=wf_name,
    #  html_path=root_dir + "/../common_utilities/spark/python/resources/",
    #  html_name = "sla_alerts.html")
    spark = SparkUtils().get_spark_session(logger, job_name)
    QueryUtils(spark=spark).update_batch_load_tracker(
        project_name=PROJECT_NAME,
        env=ENV,
        batch_tracker_table=BATCH_ID_TRACKER_TABLE,
        status="COMPLETED",
    )
    print(f"Ending the workflow with env: {ENV}, job_run_id: {JOB_ID}")


if __name__ == "__main__":
    wf.tasks["start", "end"].execute()
