import os
from brickflow import (
    ctx,
    Cluster,
    Workflow,
    WorkflowPermissions,
    Group,
    PypiTaskLibrary,
    JarTaskLibrary,
    TaskSettings,
)
from . import (
    run_ingest_curated_to_integrated,
    SparkUtils,
    LoggerUtils,
    QueryUtils,
    run_ingest_curated_to_integrated_reject_table,
)

from brickflow.bundles.model import JobsHealthRules

JOB_ID = ctx.get_parameter(key="brickflow_job_id", debug="987987987987987")
JOB_RUN_ID = ctx.get_parameter(key="brickflow_parent_run_id", debug="987987987987987")
ENV = ctx.env

# Extracting script location and changing directory to parent
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
PROJECT_NAME = "electricity_data_product"
WF_NAME = "electricity_integrated_to_bcl"
DATABASE = ""
if ENV == "local":
    ENV = "dev"
    DATABASE = "development.global_sustainability_dev"
if ENV == "dev":
    DATABASE = "development.global_sustainability_dev"
elif ENV == "qa":
    DATABASE = "non_published_domain.global_sustainability_qa"
elif ENV == "prod":
    DATABASE = "non_published_domain.global_sustainability_prod"

BATCH_ID_TRACKER_TABLE = DATABASE + "." + "sdf_batch_load_tracker"
CHECKPOINT_TABLE = DATABASE + "." + "sdf_electricity_table_trigger_checkpoint"
EXTERNAL_MAPPING_TABLE = DATABASE + "." + "sdf_external_table_mapping"
root_dir = os.path.dirname(script_dir)


def create_job_cluster(name: str):
    aws_config = {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK",
        "instance_profile_arn": "arn:aws:iam::572801069962:instance-profile/sole/group/ecorangers",
        "spot_bid_price_percent": 100,
        "ebs_volume_type": "GENERAL_PURPOSE_SSD",
        "ebs_volume_count": 3,
        "ebs_volume_size": 100,
    }
    spark_conf = {
        "spark.databricks.delta.schema.autoMerge.enabled": "true",
        "spark.databricks.delta.properties.defaults.enableChangeDataFeed": "true",
        "spark.databricks.delta.changeDataFeed.timestampOutOfRange.enabled": "true",
        "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
        "spark.databricks.service.server.enabled": "false",
        "spark.databricks.delta.preview.enabled": "true",
        "spark.databricks.delta.merge.enableLowShuffle": "true",
        "spark.sql.files.ignoreMissingFiles": "true",
        "spark.databricks.delta.properties.defaults.columnMapping.mode": "name",
    }
    custom_tags = {
        "nike-environment": ENV,
        "nike-squad": "ecorangers",
        "nike-techsolution": "2f98556ae03985998fc0ee7c3b94260aac32590c",
        "nike-initiative": "sustainability-data-foundation",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    return Cluster(
        name=name,
        spark_version="13.3.x-scala2.12",
        node_type_id="m7gd.large",
        driver_node_type_id="m7gd.large",
        min_workers=1,
        max_workers=3,
        data_security_mode="USER_ISOLATION",
        enable_elastic_disk=True,
        spark_conf=spark_conf,
        policy_id="0009B9D23ECAAA0B",
        custom_tags=custom_tags,
        aws_attributes=aws_config,
        runtime_engine="STANDARD",
    )


wf = Workflow(
    WF_NAME,
    health=[
        JobsHealthRules(metric="RUN_DURATION_SECONDS", op="GREATER_THAN", value=7200.0)
    ],
    default_cluster=create_job_cluster("ecorangers_job_cluster"),
    schedule_quartz_expression=" 0 15 23 ? * SAT * ",  # 23:15 UTC (04:45 AM IST Every Sunday)
    timezone="UTC",
    tags={
        "nike-initiative": "sustainability-data-foundation",
        "nike-techsolution": "2f98556ae03985998fc0ee7c3b94260aac32590c",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
        "AvailabilitySLA": "AvailabilitySLA - 45 2 @ @ 7",
        "Criticality": "Critical",
    },
    permissions=WorkflowPermissions(
        can_manage=[
            Group("App.NikeSole.ecorangers.Developer"),
            Group("App.NikeSole.ecorangers.DataAdmin"),
        ],
        can_view=[Group("App.NikeSole.ecorangers.Analyst")],
    ),
    default_task_settings=TaskSettings(max_retries=3),
    libraries=[
        JarTaskLibrary(
            "dbfs:/kafka-jars/databricks-shaded-strimzi-kafka-oauth-client-1.1.jar"
        ),
        PypiTaskLibrary(package="pandas"),
        PypiTaskLibrary(package="boxsdk"),
        PypiTaskLibrary(package="spark-expectations"),
        PypiTaskLibrary(package="snowflake-connector-python"),
        PypiTaskLibrary(package="data-common-utilities"),
        PypiTaskLibrary(package="cerberus-python-client"),
        PypiTaskLibrary(package="prettytable"),
        PypiTaskLibrary(package="delta-spark"),
        PypiTaskLibrary(package="asyncssh"),
    ],
)


@wf.task
# this task does nothing but explains the use of context object
def start():
    logger = LoggerUtils().get_logger_object()
    job_name = str(__name__).split(".")[-2].replace("/", "")
    spark = SparkUtils().get_spark_session(logger, job_name)
    QueryUtils(spark=spark).update_batch_load_tracker(
        project_name=PROJECT_NAME, env=ENV, batch_tracker_table=BATCH_ID_TRACKER_TABLE
    )
    print(f"Starting the workflow with env: {ENV}, job_run_id: {JOB_ID}")


# @wf.task(depends_on=start, name="external_table_dq_rule_validation")
# def external_table_dq_rule_validation():
#     run_ingest_curated_to_integrated_reject_table(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="curated_to_intgerated_electricity_reject_config.toml",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# LOGEC
@wf.task(
    depends_on="start",
    name="logec_curatedhist_to_integrated_site",
)
def curatedhist_to_integrated_logec_site():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_logec_electricity_site_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_logec_electricity_site_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on="start",
    name="logec_curatedhist_to_integrated_detail",
)
def curatedhist_to_integrated_logec_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_logec_electricity_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_logec_electricity_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on=[
        "logec_curatedhist_to_integrated_site",
        "logec_curatedhist_to_integrated_detail",
    ],
    name="logec_curatedhist_to_integrated_site_and_detail",
)
def curatedhist_to_integrated_logec_site_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_logec_electricity_site_and_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_logec_electricity_site_and_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
        extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
    )


##ENGIE
@wf.task(
    depends_on="logec_curatedhist_to_integrated_site_and_detail",
    name="engie_curatedhist_to_integrated_site",
)
def curatedhist_to_integrated():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_engie_electricity_site_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_engie_electricity_site_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on="logec_curatedhist_to_integrated_site_and_detail",
    name="engie_curatedhist_to_integrated_detail",
)
def curatedhist_to_integrated_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_engie_electricity_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_engie_electricity_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on=[
        "engie_curatedhist_to_integrated_site",
        "engie_curatedhist_to_integrated_detail",
    ],
    name="engie_curatedhist_to_integrated_site_and_detail",
)
def curatedhist_to_integrated_site_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_engie_electricity_site_and_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_engie_electricity_site_and_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
        extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
    )


# #extrapolation_DATA
# @wf.task(depends_on="external_table_dq_rule_validation", name="extrapolation_integrated_to_integrated_site")
# def curatedhist_to_integrated():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="extrapolation_to_integrated_electricity_site_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="extrapolation_electricity_site_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )
#
#
# @wf.task(depends_on="external_table_dq_rule_validation", name="extrapolation_integrated_to_integrated_detail")
# def curatedhist_to_integrated():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="extrapolation_to_integrated_electricity_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="extrapolation_electricity_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )
#
#
# @wf.task(
#     depends_on=[
#         "extrapolation_integrated_to_integrated_site",
#         "extrapolation_integrated_to_integrated_detail",
#     ],
#     name="extrapolation_to_integrated_site_and_detail",
# )
# def curatedhist_to_integrated():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="extrapolation_to_integrated_electricity_site_and_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="extrapolation_electricity_site_and_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


##ENoS
@wf.task(
    depends_on="engie_curatedhist_to_integrated_site_and_detail",
    name="enos_curatedhist_to_integrated_site",
)
def curatedhist_to_integrated_site():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_enos_electricity_site_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_enos_electricity_site_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on="engie_curatedhist_to_integrated_site_and_detail",
    name="enos_curatedhist_to_integrated_detail",
)
def curatedhist_to_integrated_enos_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_enos_electricity_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_enos_electricity_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
        extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
    )


@wf.task(
    depends_on=[
        "enos_curatedhist_to_integrated_site",
        "enos_curatedhist_to_integrated_detail",
    ],
    name="enos_curatedhist_to_integrated_site_and_detail",
)
def curatedhist_to_integrated_site_and_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_enos_electricity_site_and_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_enos_electricity_site_and_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
        extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
    )


##GPS HQ
# @wf.task(
#     depends_on="enos_curatedhist_to_integrated_site_and_detail",
#     name="gps_hq_curatedhist_to_integrated_site",
# )
# def curatedhist_to_integrated_gps_site():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="curated_to_integrated_gps_hq_electricity_site_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_gps_hq_electricity_site_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on="enos_curatedhist_to_integrated_site_and_detail",
#     name="gps_hq_curatedhist_to_integrated_detail",
# )
# def curatedhist_to_integrated_gps_detail():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="curated_to_integrated_gps_hq_electricity_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_gps_hq_electricity_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on=[
#         "gps_hq_curatedhist_to_integrated_site",
#         "gps_hq_curatedhist_to_integrated_detail",
#     ],
#     name="gps_hq_curatedhist_to_integrated_site_and_detail",
# )
# def curatedhist_to_integrated_gps_site_detail():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="curated_to_integrated_gps_hq_electricity_site_and_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_gps_hq_electricity_site_and_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#         extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
#     )


##GPS HQ
@wf.task(
    depends_on="enos_curatedhist_to_integrated_site_and_detail",
    name="gps_hq_airtable_curatedhist_to_integrated_site",
)
def curatedhist_to_integrated_gps_airtable_site():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_gps_hq_airtable_electricity_site_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_gps_hq_airtable_electricity_site_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on="enos_curatedhist_to_integrated_site_and_detail",
    name="gps_hq_airtable_curatedhist_to_integrated_detail",
)
def curatedhist_to_integrated_gps_airtable_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_gps_hq_airtable_electricity_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_gps_hq_airtable_electricity_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on=[
        "gps_hq_airtable_curatedhist_to_integrated_site",
        "gps_hq_airtable_curatedhist_to_integrated_detail",
    ],
    name="gps_hq_airtable_curatedhist_to_integrated_site_and_detail",
)
def curatedhist_to_integrated_gps_airtable_site_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_gps_hq_airtable_electricity_site_and_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_gps_hq_airtable_electricity_site_and_detail_integrated_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
        extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
    )


##Usage & Metrics
# @wf.task(
#     depends_on="logec_curatedhist_to_integrated_site_and_detail",
#     name="usage_metrics_curatedhist_to_integrated_site",
# )
# def curatedhist_to_integrated_ww_site():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="curated_to_integrated_usage_metrics_electricity_site_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_usage_metrics_electricity_site_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on="logec_curatedhist_to_integrated_site_and_detail",
#     name="usage_metrics_curatedhist_to_integrated_detail",
# )
# def curatedhist_to_integrated_ww_detail():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="curated_to_integrated_usage_metrics_electricity_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_usage_metrics_electricity_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on=[
#         "usage_metrics_curatedhist_to_integrated_site",
#         "usage_metrics_curatedhist_to_integrated_detail",
#     ],
#     name="usage_metrics_curatedhist_to_integrated_site_and_detail",
# )
# def curatedhist_to_integrated_ww_site_detail():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="curated_to_integrated_usage_metrics_electricity_site_and_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_usage_metrics_electricity_site_and_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#         extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
#     )


## Mace MyEnergy
@wf.task(
    depends_on="gps_hq_airtable_curatedhist_to_integrated_site_and_detail",
    name="usage_metrics_myenergy_curatedhist_to_integrated_site",
)
def curatedhist_to_integrated_myenergy_site():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_mace_myenergy_electricity_site_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_electricity_and_usage_metrics_myenergy_site_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on="gps_hq_airtable_curatedhist_to_integrated_site_and_detail",
    name="usage_metrics_myenergy_curatedhist_to_integrated_detail",
)
def curatedhist_to_integrated_myenrgy_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_mace_myenergy_electricty_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_electricity_and_usage_metrics_myenergy_detail_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


@wf.task(
    depends_on=[
        "usage_metrics_myenergy_curatedhist_to_integrated_site",
        "usage_metrics_myenergy_curatedhist_to_integrated_detail",
    ],
    name="usage_metrics_myenergy_curatedhist_to_integrated_site_and_detail",
)
def curatedhist_to_integrated_site_myenergy_detail():
    run_ingest_curated_to_integrated(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_integrated_usage_metrics_electricity_myenergy_site_and_detail_config.toml",
        sql_file_path=root_dir + "/databricks_sql/",
        sql_file_name="sdf_electricity_and_usage_metrics_myenergy_site_and_detail_merge.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
        extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
    )


# @wf.task(
#     depends_on="usage_metrics_myenergy_curatedhist_to_integrated_site_and_detail",
#     name="enablon_to_integrated_site",
# )
# def enablon_to_integrated_myenergy_site():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="enablon_to_integrated_electricity_site_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_enablon_electricity_site_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on="usage_metrics_myenergy_curatedhist_to_integrated_site_and_detail",
#     name="enablon_to_integrated_detail",
# )
# def enablon_to_integrated_detail():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="enablon_to_integrated_electricity_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_enablon_electricity_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#     )


# @wf.task(
#     depends_on=[
#         "enablon_to_integrated_site",
#         "enablon_to_integrated_detail",
#     ],
#     name="enablon_to_integrated_site_and_detail",
# )
# def enablon_to_integrated_site_and_detail():
#     run_ingest_curated_to_integrated(
#         config_path=root_dir + "/spark/python/config/integrated",
#         config_name="enablon_to_integrated_electricity_site_and_detail_config.toml",
#         sql_file_path=root_dir + "/databricks_sql/",
#         sql_file_name="sdf_enablon_electricity_site_and_detail_integrated_merge.sql",
#         env=ENV,
#         bf_context=ctx,
#         root_dir=root_dir,
#         extrapltion_sql_file_name="actual_over_extrapolation_alert.sql",
#     )


# merge_list = [
#     "engie_curatedhist_to_integrated_site_and_detail",
#     "enos_curatedhist_to_integrated_site_and_detail",
#     "gps_hq_curatedhist_to_integrated_site_and_detail",
#     "logec_curatedhist_to_integrated_site_and_detail",
#     "usage_metrics_curatedhist_to_integrated_site_and_detail",
#     "usage_metrics_myenergy_curatedhist_to_integrated_site_and_detail",
#     "gps_hq_airtable_curatedhist_to_integrated_site_and_detail",
#     # "extrapolation_to_integrated_site_and_detail",
# ]

merge_list = [
    "engie_curatedhist_to_integrated_site_and_detail",
    "enos_curatedhist_to_integrated_site_and_detail",
    # "gps_hq_curatedhist_to_integrated_site_and_detail",
    "logec_curatedhist_to_integrated_site_and_detail",
    # "usage_metrics_curatedhist_to_integrated_site_and_detail",
    "usage_metrics_myenergy_curatedhist_to_integrated_site_and_detail",
    "gps_hq_airtable_curatedhist_to_integrated_site_and_detail",
    # "enablon_to_integrated_site_and_detail",
    # "extrapolation_to_integrated_site_and_detail",
]


# Merge
@wf.task(
    depends_on="usage_metrics_myenergy_curatedhist_to_integrated_site_and_detail",
    name="merge",
)
def integrated_merge():
    logger = LoggerUtils().get_logger_object()
    logger.info("************ Merge scripts completed ************")


# if ENV == "prod":

#     @wf.task(depends_on="merge", name="dbx_integrated_to_snowflake_site")
#     def trigger_ingest_dbx_integrated_to_bcl():
#         run_ingest_integrated_to_bcl(
#             config_path=root_dir + "/spark/python/config/snowflake/",
#             config_name="electricity_integrated_to_bcl_site_config.toml",
#             env=ENV,
#             bf_context=ctx,
#             root_dir=root_dir,
#         )

#     @wf.task(depends_on="merge", name="dbx_integrated_to_snowflake_detail")
#     def trigger_ingest_dbx_integrated_to_bcl_snf_detail():
#         run_ingest_integrated_to_bcl(
#             config_path=root_dir + "/spark/python/config/snowflake/",
#             config_name="electricity_integrated_to_bcl_detail_config.toml",
#             env=ENV,
#             bf_context=ctx,
#             root_dir=root_dir,
#         )

#     @wf.task(depends_on="merge", name="dbx_integrated_to_snowflake_site_and_detail")
#     def trigger_ingest_dbx_integrated_to_bcl_site_detail():
#         run_ingest_integrated_to_bcl(
#             config_path=root_dir + "/spark/python/config/snowflake/",
#             config_name="electricity_integrated_to_bcl_site_and_detail_config.toml",
#             env=ENV,
#             bf_context=ctx,
#             root_dir=root_dir,
#         )


### task added to do table optimisation ###
@wf.task(
    depends_on=(
        "merge"
        # if ENV != "prod"
        # else [
        #     "dbx_integrated_to_snowflake_site",
        #     "dbx_integrated_to_snowflake_detail",
        #     "dbx_integrated_to_snowflake_site_and_detail",
        # ]
    ),
    name="table_optimisation",
)
def table_optimisation():
    logger = LoggerUtils().get_logger_object()
    job_name = str(__name__).split(".")[-2].replace("/", "")
    spark = SparkUtils().get_spark_session(logger, job_name)
    QueryUtils(spark=spark).run_delta_table_optimisation(
        logger=logger,
        config_path=root_dir + "/spark/python/config/misc",
        config_name="electricity_table_details_vacuum.toml",
        env=ENV,
        bf_context=ctx,
    )


@wf.task(depends_on="table_optimisation", name="electricity_checkpoint_table_update")
# this task does nothing but explains the use of context object
def checkpoint_table_update():
    logger = LoggerUtils().get_logger_object()
    job_name = str(__name__).split(".")[-2].replace("/", "")
    # run_sla_alerts(config_path=root_dir + "/../common_utilities
    # /spark/python/config", config_name="alerts_config.toml", env = env,
    #  bf_context=ctx, project_name=project_name, wf_name=wf_name,
    #  html_path=root_dir + "/../common_utilities/spark/python/resources/",
    #  html_name = "sla_alerts.html")
    spark = SparkUtils().get_spark_session(logger, job_name)
    QueryUtils(spark=spark).update_checkpoint_table(
        job_run_id=JOB_RUN_ID, checkpoint_table=CHECKPOINT_TABLE
    )
    print(f"Ending the workflow with env: {ENV}, job_run_id: {JOB_ID}")


# @wf.task(
#     depends_on="electricity_checkpoint_table_update",
#     name="dbx_drop_external_temp_tables",
# )
# # this task does drop for external tables which are created temporary
# def external_table_drop():
#     logger = LoggerUtils().get_logger_object()
#     job_name = str(__name__).split(".")[-2].replace("/", "")
#     spark = SparkUtils().get_spark_session(logger, job_name)
#     df = spark.sql(f"SELECT table_mapping_nm FROM {EXTERNAL_MAPPING_TABLE}")
#     tables_to_drop = [row.table_mapping_nm for row in df.collect()]
#     for table in tables_to_drop:
#         drop_table_query = f"DROP TABLE IF EXISTS {table}"
#         try:
#             spark.sql(drop_table_query)
#             logger.info(f"Table {table} dropped successfully")
#         except Exception as err:
#             logger.error(f"Error occurred while dropping : {table}: {err}")


@wf.task(depends_on="electricity_checkpoint_table_update", name="end")
# this task does nothing but explains the use of context object
def end():
    logger = LoggerUtils().get_logger_object()
    job_name = str(__name__).split(".")[-2].replace("/", "")
    # run_sla_alerts(config_path=root_dir + "/../common_utilities
    # /spark/python/config", config_name="alerts_config.toml", env = env,
    #  bf_context=ctx, project_name=project_name, wf_name=wf_name,
    #  html_path=root_dir + "/../common_utilities/spark/python/resources/",
    #  html_name = "sla_alerts.html")
    spark = SparkUtils().get_spark_session(logger, job_name)
    QueryUtils(spark=spark).update_batch_load_tracker(
        project_name=PROJECT_NAME,
        env=ENV,
        batch_tracker_table=BATCH_ID_TRACKER_TABLE,
        status="COMPLETED",
    )
    print(f"Ending the workflow with env: {ENV}, job_run_id: {JOB_ID}")


if __name__ == "__main__":
    wf.tasks["start", "end"].execute()
