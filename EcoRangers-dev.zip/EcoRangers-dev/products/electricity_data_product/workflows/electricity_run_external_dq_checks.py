import os
from brickflow import (
    ctx,
    Cluster,
    Workflow,
    WorkflowPermissions,
    Group,
    PypiTaskLibrary,
    JarTaskLibrary,
    TaskSettings,
)

from . import (
    run_ingest_curated_to_integrated_reject_table,
)

from brickflow.bundles.model import JobsHealthRules

JOB_ID = ctx.get_parameter(key="brickflow_job_id", debug="987987987987987")
JOB_RUN_ID = ctx.get_parameter(key="brickflow_parent_run_id", debug="987987987987987")
ENV = ctx.env

# Extracting script location and changing directory to parent
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
PROJECT_NAME = "electricity_data_product"
WF_NAME = "electricity_run_external_dq_checks"
DATABASE = ""
if ENV == "local":
    ENV = "dev"
    DATABASE = "development.global_sustainability_dev"
if ENV == "dev":
    DATABASE = "development.global_sustainability_dev"
elif ENV == "qa":
    DATABASE = "non_published_domain.global_sustainability_qa"
elif ENV == "prod":
    DATABASE = "non_published_domain.global_sustainability_prod"

BATCH_ID_TRACKER_TABLE = DATABASE + "." + "sdf_batch_load_tracker"
CHECKPOINT_TABLE = DATABASE + "." + "sdf_electricity_table_trigger_checkpoint"
EXTERNAL_MAPPING_TABLE = DATABASE + "." + "sdf_external_table_mapping"
root_dir = os.path.dirname(script_dir)


def create_job_cluster(name: str):
    aws_config = {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK",
        "instance_profile_arn": "arn:aws:iam::572801069962:instance-profile/sole/group/ecorangers",
        "spot_bid_price_percent": 100,
        "ebs_volume_type": "GENERAL_PURPOSE_SSD",
        "ebs_volume_count": 3,
        "ebs_volume_size": 100,
    }
    spark_conf = {
        "spark.databricks.delta.schema.autoMerge.enabled": "true",
        "spark.databricks.delta.properties.defaults.enableChangeDataFeed": "true",
        "spark.databricks.delta.changeDataFeed.timestampOutOfRange.enabled": "true",
        "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
        "spark.databricks.service.server.enabled": "false",
        "spark.databricks.delta.preview.enabled": "true",
        "spark.databricks.delta.merge.enableLowShuffle": "true",
        "spark.sql.files.ignoreMissingFiles": "true",
        "spark.databricks.delta.properties.defaults.columnMapping.mode": "name",
    }
    custom_tags = {
        "nike-environment": ENV,
        "nike-squad": "ecorangers",
        "nike-techsolution": "2f98556ae03985998fc0ee7c3b94260aac32590c",
        "nike-initiative": "sustainability-data-foundation",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    return Cluster(
        name=name,
        spark_version="13.3.x-scala2.12",
        node_type_id="m7gd.large",
        driver_node_type_id="m7gd.large",
        min_workers=1,
        max_workers=3,
        data_security_mode="USER_ISOLATION",
        enable_elastic_disk=True,
        spark_conf=spark_conf,
        policy_id="0009B9D23ECAAA0B",
        custom_tags=custom_tags,
        aws_attributes=aws_config,
        runtime_engine="STANDARD",
    )


wf = Workflow(
    WF_NAME,
    health=[
        JobsHealthRules(metric="RUN_DURATION_SECONDS", op="GREATER_THAN", value=7200.0)
    ],
    default_cluster=create_job_cluster("ecorangers_job_cluster"),
    # schedule_quartz_expression=" 0 15 15 ? * SAT * ",  # 15:15 UTC (08:45 PM IST Every Friday)
    schedule_quartz_expression="0 30 10 * * ?",  # 10:30 UTC (04:00 PM IST Every day)
    timezone="UTC",
    tags={
        "nike-initiative": "sustainability-data-foundation",
        "nike-techsolution": "2f98556ae03985998fc0ee7c3b94260aac32590c",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    },
    permissions=WorkflowPermissions(
        can_manage=[
            Group("App.NikeSole.ecorangers.Developer"),
            Group("App.NikeSole.ecorangers.DataAdmin"),
        ],
        can_view=[Group("App.NikeSole.ecorangers.Analyst")],
    ),
    default_task_settings=TaskSettings(max_retries=3),
    libraries=[
        JarTaskLibrary(
            "dbfs:/kafka-jars/databricks-shaded-strimzi-kafka-oauth-client-1.1.jar"
        ),
        PypiTaskLibrary(package="pandas"),
        PypiTaskLibrary(package="boxsdk"),
        PypiTaskLibrary(package="spark-expectations"),
        PypiTaskLibrary(package="snowflake-connector-python"),
        PypiTaskLibrary(package="data-common-utilities"),
        PypiTaskLibrary(package="cerberus-python-client"),
        PypiTaskLibrary(package="prettytable"),
        PypiTaskLibrary(package="delta-spark"),
        PypiTaskLibrary(package="asyncssh"),
    ],
)


@wf.task(name="external_table_dq_rule_validation")
def external_table_dq_rule_validation():
    run_ingest_curated_to_integrated_reject_table(
        config_path=root_dir + "/spark/python/config/integrated",
        config_name="curated_to_intgerated_electricity_reject_config.toml",
        env=ENV,
        bf_context=ctx,
        root_dir=root_dir,
    )


if __name__ == "__main__":
    wf.tasks["external_table_dq_rule_validation"].execute()
