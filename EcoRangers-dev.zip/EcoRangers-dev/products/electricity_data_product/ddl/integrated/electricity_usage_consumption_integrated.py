env = "dev"
catalog = "development" if env.lower() == "dev" else "non_published_domain"
db_name = f"{catalog}.global_sustainability_{env}"
sole_group = "Sole.ServicePrincipal.ecorangers.Developer"
view_catalog = "published_domain" if env.lower() == "prod" else "development"
view_database = f"global_sustainability_{env}"

# table DDL
# spark.sql(f"""drop table if exists {db_name}.electricity_usage_consumption_integrated""")

spark.sql(
    f"""
CREATE TABLE {db_name}.ELECTRICITY_USAGE_CONSUMPTION_INTEGRATED (
  electricity_location_nbr STRING,
  electricity_location_nm STRING,
  reporting_period_dt DATE,
  SERVICE_TYPE_CD STRING,
  BILLING_MONTH_START_DT DATE,
  BILLING_MONTH_END_DT DATE,
  BILLING_MONTH_DATE_RANGE_TXT STRING,
  REPORTING_FISCAL_YEAR_NBR DECIMAL(38,0),
  REPORTING_CALENDAR_YEAR_NBR DECIMAL(38,0),
  REPORTING_MONTH_LONG_NM STRING,
  REPORTING_MONTH_OF_YEAR_NBR DECIMAL(38,0),
  REPORTING_QUARTER_NBR DECIMAL(38,0),
  REPORTING_WEEK_OF_YEAR_NBR DECIMAL(38,0),
  building_id STRING,
  DATA_FREQUENCY_CD INT,
  SERVICE_USAGE_QTY DOUBLE,
  SERVICE_USAGE_QTY_UOM STRING,
  SERVICE_COST INT,
  SERVICE_COST_UOM STRING,
  extrapolation_ind STRING,
  scope_nbr STRING,
  data_source_nm STRING,
  electricity_consumption_uuid STRING,
  user_nm STRING,
  load_dt DATE,
  load_month_nbr INT,
  load_year_nbr INT,
  created_at_tmst TIMESTAMP,
  batch_load_tmst TIMESTAMP,
  job_nm STRING,
  job_run_id STRING,
  hash_col INT,
  updated_at_tmst TIMESTAMP,
  lease_custom_key STRING)
USING delta
PARTITIONED BY (load_year_nbr, load_month_nbr)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4')
"""
)

if catalog == "development":
    spark.sql(
        f"ALTER TABLE {db_name}.electricity_usage_consumption_integrated OWNER TO `{sole_group}`"
    )

# view ddl
spark.sql(
    f"""
CREATE VIEW {db_name}.electricity_usage_consumption_integrated_v 
AS SELECT
    SUBSTR(REGEXP_REPLACE(ELECTRICITY_CONSUMPTION_UUID,'[^a-zA-Z0-9]',''),1,10) AS ELECTRICITY_CONSUMPTION_UUID,
    ELECTRICITY_LOCATION_NBR,
    ELECTRICITY_LOCATION_NM,
    REPORTING_PERIOD_DT,
    SERVICE_TYPE_CD,
    BILLING_MONTH_START_DT,
    BILLING_MONTH_END_DT,
    BILLING_MONTH_DATE_RANGE_TXT,
    REPORTING_FISCAL_YEAR_NBR,
    REPORTING_CALENDAR_YEAR_NBR,
    REPORTING_MONTH_LONG_NM,
    REPORTING_MONTH_OF_YEAR_NBR,
    REPORTING_QUARTER_NBR,
    REPORTING_WEEK_OF_YEAR_NBR,
    BUILDING_ID,
    DATA_FREQUENCY_CD,
    SERVICE_USAGE_QTY,
    SERVICE_USAGE_QTY_UOM,
    SERVICE_COST,
    SERVICE_COST_UOM,
    EXTRAPOLATION_IND,
    SCOPE_NBR,
    BATCH_LOAD_TMST AS BATCH_LOAD_TIMESTAMP
FROM
    {db_name}.ELECTRICITY_USAGE_CONSUMPTION_INTEGRATED
"""
)
