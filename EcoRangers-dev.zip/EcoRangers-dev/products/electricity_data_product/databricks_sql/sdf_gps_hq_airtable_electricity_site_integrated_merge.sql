WITH
  TAXONOMY_TABLE AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_mapping_tbl}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  GPS_SITE_METRICS AS (
    SELECT
      *,
      ---electricity_location_nbr----
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'TMT'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'HQ (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'HQ (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'Greater China Headquarters'
        WHEN curated_tbl.headquarter_cd LIKE '%Converse%' THEN 'Others' -- DATA render from engie source
        ELSE NULL
      END AS electricity_location_nbr,
      -----electricity_location_nm-----
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'Nike HQ - North America (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'Nike HQ - Europe (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'Greater China Headquarters'
        WHEN curated_tbl.headquarter_cd LIKE '%Converse%' THEN 'Others' -- DATA render from engie source
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'Tokyo Midtown Tower'
        ELSE NULL
      END AS electricity_location_nm
      ---electricity_location_nm----
    FROM
      {curated_table_name} curated_tbl
  ),
  SITE_INTEGRATION AS (
    SELECT DISTINCT
      electricity_location_nm,
      electricity_location_nbr,
      entity_lease_nbr AS lease_nbr,
      NULL AS building_id,
      CASE
        WHEN enablon_tbl.entity_division_nm LIKE '%Retail%' THEN 'Retail'
        ELSE 'Non Retail'
      END AS business_group_txt,
      COALESCE(
        enablon_tbl.entity_brand_nm,
        CASE
          WHEN headquarter_cd LIKE '%Converse%' THEN 'Converse'
          ELSE 'Nike'
        END
      ) AS brand_nm,
      CASE
        WHEN enablon_tbl.entity_division_nm LIKE '%Fleet%' THEN 'Transportation'
        WHEN enablon_tbl.entity_division_nm LIKE '%Headquarters%' THEN 'Headquarters'
        ELSE 'Other Facilities'
      END AS nike_department_type_txt,
      taxonomy.region AS BUSINESS_ENTITY_GEO_REGION_CD,
      NULL AS ELECTRICITY_LOCATION_USE_CD,
      COALESCE(
        enablon_tbl.entity_business_function_nm,
        CASE
          WHEN headquarter_cd LIKE '%Converse%' THEN 'WD+C (C)'
          ELSE 'WD+C (N)'
        END
      ) AS business_function_nm,
      enablon_tbl.entity_division_nm AS enablon_tbl_entity_division_nm,
      taxonomy.region AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN entity_continent_nm = 'America' THEN 'North America'
        ELSE entity_continent_nm
      END AS continent_nm,
      enablon_tbl.entity_address_txt AS ADDRESS_LINE_1_TXT,
      INITCAP(enablon_tbl.entity_city_nm) AS city_nm,
      NULL AS state_cd,
      enablon_tbl.entity_zip_cd AS postal_cd,
      COALESCE(
        CASE
          WHEN enablon_tbl.entity_country_nm LIKE 'United States of America' THEN CONCAT(entity_zip_cd, '-', INITCAP(entity_city_nm))
        END,
        INITCAP(enablon_tbl.entity_country_nm),
        INITCAP(enablon_tbl.entity_geographical_reference_txt)
      ) AS geographical_axis_nm,
      taxonomy.CTRY_CD AS COUNTRY_CD,
      CAST(
        COALESCE(
          enablon_tbl.entity_area_in_sqft,
          combined_area_ft2
        ) AS DECIMAL(31, 5)
      ) AS location_area,
      enablon_tbl.entity_status_nm AS LOCATION_STATUS_CD,
      CAST(
        enablon_tbl.entity_geographical_latitude_deg AS STRING
      ) AS latitude_deg,
      CAST(
        enablon_tbl.entity_geographical_longitude_deg AS STRING
      ) AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      reporting_period_dt,
      CASE
        WHEN enablon_tbl.entity_area_in_sqft IS NOT NULL THEN 'sustainability_impact_areas'
        WHEN combined_area_ft2 IS NOT NULL THEN 'gps_airtable_usage_metrics'
      END AS location_area_data_source_nm,
      CASE
        WHEN enablon_tbl.entity_area_in_sqft IS NOT NULL THEN 'ENABLON'
        WHEN combined_area_ft2 IS NOT NULL THEN 'GPSAIRTABLE'
      END AS location_area_data_source_cd,
      entity_reference_nm AS enablon_location_nm
    FROM
      GPS_SITE_METRICS curated_tbl
      LEFT JOIN {enablon_tbl} enablon_tbl ON curated_tbl.electricity_location_nm = enablon_tbl.entity_reference_nm
      AND curated_tbl.reporting_period_dt = enablon_tbl.source_reporting_dt
      LEFT JOIN TAXONOMY_TABLE taxonomy ON (
        CASE
          WHEN enablon_tbl.entity_country_nm = 'United States of America' THEN 'USA'
          WHEN enablon_tbl.entity_country_nm = 'South Korea' THEN 'Korea'
          ELSE enablon_tbl.entity_country_nm
        END
      ) = taxonomy.CTRY_NM
    WHERE
      (
        Electricity_usage_qty IS NOT NULL
        OR electricity_landlord_usage_qty IS NOT NULL
        OR solar_generation_usage_qty IS NOT NULL
      )
      -- and enablon_tbl.entity_reference_nm is null
      QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          curated_tbl.electricity_location_nbr,
          curated_tbl.electricity_location_nm,
          curated_tbl.reporting_period_dt
        ORDER BY
          combined_area_ft2 DESC
      ) = 1
  )
SELECT DISTINCT
  ELECTRIC_SITE.electricity_location_nbr,
  ELECTRIC_SITE.electricity_location_nm,
  COALESCE(ELECTRIC_SITE.lease_nbr, ELE_SITE.lease_nbr) AS lease_nbr,
  ELECTRIC_SITE.reporting_period_dt,
  CAST(ELECTRIC_SITE.building_id AS STRING) AS building_id,
  INITCAP(ELECTRIC_SITE.business_group_txt) AS business_group_txt,
  INITCAP(ELECTRIC_SITE.brand_nm) AS brand_nm,
  ELECTRIC_SITE.nike_department_type_txt,
  COALESCE(
    ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD,
    ELE_SITE.BUSINESS_ENTITY_GEO_REGION_CD
  ) AS BUSINESS_ENTITY_GEO_REGION_CD,
  CAST(
    ELECTRIC_SITE.ELECTRICITY_LOCATION_USE_CD AS STRING
  ) AS ELECTRICITY_LOCATION_USE_CD,
  ELECTRIC_SITE.business_function_nm,
  COALESCE(
    ELECTRIC_SITE.enablon_tbl_entity_division_nm,
    CASE
      WHEN ELECTRIC_SITE.nike_department_type_txt = 'Headquarters'
      AND ELECTRIC_SITE.brand_nm = 'Nike' THEN 'Headquarters (N)'
      WHEN ELECTRIC_SITE.nike_department_type_txt = 'Headquarters'
      AND ELECTRIC_SITE.brand_nm = 'Converse' THEN 'Headquarters (C)'
      WHEN ELECTRIC_SITE.nike_department_type_txt = 'Transportation'
      AND ELECTRIC_SITE.brand_nm = 'Nike' THEN 'Fleet Vehicles (N)'
      WHEN ELECTRIC_SITE.nike_department_type_txt = 'Transportation'
      AND ELECTRIC_SITE.brand_nm = 'Converse' THEN 'Fleet Vehicles (C)'
    END,
    ELE_SITE.enablon_tbl_entity_division_nm
  ) AS division_nm,
  -- ELECTRIC_SITE.division_nm,
  COALESCE(
    ELECTRIC_SITE.LOCATION_GEO_REGION_CD,
    ELE_SITE.LOCATION_GEO_REGION_CD
  ) AS LOCATION_GEO_REGION_CD,
  COALESCE(ELECTRIC_SITE.continent_nm, ELE_SITE.continent_nm) AS continent_nm,
  COALESCE(
    ELECTRIC_SITE.ADDRESS_LINE_1_TXT,
    ELE_SITE.ADDRESS_LINE_1_TXT
  ) AS ADDRESS_LINE_1_TXT,
  COALESCE(ELECTRIC_SITE.city_nm, ELE_SITE.city_nm) AS city_nm,
  CAST(ELECTRIC_SITE.STATE_CD AS STRING) AS STATE_CD,
  COALESCE(ELECTRIC_SITE.POSTAL_CD, ELE_SITE.POSTAL_CD) AS POSTAL_CD,
  COALESCE(
    ELECTRIC_SITE.geographical_axis_nm,
    ELE_SITE.geographical_axis_nm
  ) AS geographical_axis_nm,
  COALESCE(ELECTRIC_SITE.COUNTRY_CD, ELE_SITE.COUNTRY_CD) AS COUNTRY_CD,
  COALESCE(
    ELECTRIC_SITE.LOCATION_STATUS_CD,
    ELE_SITE.LOCATION_STATUS_CD
  ) AS LOCATION_STATUS_CD,
  COALESCE(ELECTRIC_SITE.latitude_deg, ELE_SITE.latitude_deg) AS latitude_deg,
  COALESCE(
    ELECTRIC_SITE.longitude_deg,
    ELE_SITE.longitude_deg
  ) AS longitude_deg,
  CAST(
    ELECTRIC_SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS STRING
  ) AS ADDITIONAL_LOCATION_FEATURE_DESC,
  ELECTRIC_SITE.LOCATION_AREA,
  CASE
    WHEN ELECTRIC_SITE.location_area IS NOT NULL THEN 'Square foot'
  END AS LOCATION_AREA_UOM,
  ELECTRIC_SITE.LOCATION_AREA_DATA_SOURCE_NM,
  ELECTRIC_SITE.LOCATION_AREA_DATA_SOURCE_CD,
  'gps_airtable_usage_metrics' AS cost_usage_data_source_nm,
  'GPSAIRTABLE' AS cost_usage_data_source_cd
FROM
  SITE_INTEGRATION ELECTRIC_SITE
  LEFT JOIN (
    SELECT
      *
    FROM
      SITE_INTEGRATION
    WHERE
      enablon_location_nm IS NOT NULL qualify ROW_NUMBER() OVER (
        PARTITION BY
          electricity_location_nbr,
          electricity_location_nm
        ORDER BY
          reporting_period_dt DESC
      ) = 1
  ) ELE_SITE ON ELECTRIC_SITE.electricity_location_nbr = ELE_SITE.electricity_location_nbr
  AND ELECTRIC_SITE.electricity_location_nm = ELE_SITE.electricity_location_nm
  AND ELECTRIC_SITE.reporting_period_dt > ADD_MONTHS(CURRENT_DATE(), -3)
  /* Remove 'Others' category corresponding to Converse headquarter data which is already coming from engie data source, Removing EHQ data as it is already coming from MACE data source.*/
WHERE
  ELECTRIC_SITE.electricity_location_nbr NOT IN ('Others', 'HQ (EHQ)')
  AND ELECTRIC_SITE.electricity_location_nm NOT IN ('Others', 'Nike HQ - Europe (EHQ)')
  AND ELECTRIC_SITE.electricity_location_nbr IS NOT NULL
  AND ELECTRIC_SITE.electricity_location_nm IS NOT NULL;
