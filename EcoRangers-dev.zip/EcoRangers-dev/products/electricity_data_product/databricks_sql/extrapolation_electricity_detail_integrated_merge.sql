SELECT
  --electricity_consumption_uuid,
  electricity_location_nbr,
  electricity_location_nm,
  reporting_period_dt,
  service_type_cd,
  billing_month_start_dt,
  billing_month_end_dt,
  billing_month_date_range_txt,
  CAST(reporting_fiscal_year_nbr AS INT) AS reporting_fiscal_year_nbr,
  CAST(reporting_fiscal_quarter_nbr AS INT) AS reporting_fiscal_quarter_nbr,
  CAST(reporting_fiscal_month_of_year_nbr AS INT) AS reporting_fiscal_month_of_year_nbr,
  CAST(reporting_calendar_year_nbr AS DECIMAL(38, 0)) AS reporting_calendar_year_nbr,
  reporting_month_long_nm,
  CAST(reporting_month_of_year_nbr AS DECIMAL(38, 0)) AS reporting_month_of_year_nbr,
  CAST(reporting_quarter_nbr AS DECIMAL(38, 0)) AS reporting_quarter_nbr,
  CAST(reporting_week_of_year_nbr AS DECIMAL(38, 0)) AS reporting_week_of_year_nbr,
  building_id,
  data_frequency_cd,
  service_usage_qty,
  service_usage_qty_uom,
  service_cost,
  service_cost_uom,
  extrapolation_ind,
  -- 'see_usage_metrics' AS data_source_nm,
  'see_usage_metrics' AS cost_usage_data_source_nm,
  'SEE' AS cost_usage_data_source_cd,
  scope_nbr
FROM
  {extrapolation_electricity_integrated_table_name}
WHERE
  UPPER(extrapolation_ind) = 'TRUE'
