WITH
  CURATED_VIEW AS (
    SELECT DISTINCT
      account_id,
      location_nbr,
      location_nm_latest,
      location_nbr_latest,
      cdd_nbr,
      total_kwh,
      delivery_kw_charges_cost,
      universal_usage_uom,
      days_in_billing_period_days,
      CASE
        WHEN property_nm = 'Stockholm Showroom - WESWE - GPS'
        AND start_dt BETWEEN DATE '2019-12-31' AND DATE  '2020-12-31'
        AND currency_cd = 'USD' THEN total_cost * 0.876827827
        WHEN property_nm = 'Stockholm Showroom - WESWE - GPS'
        AND start_dt BETWEEN DATE '2021-01-01' AND DATE  '2021-12-31'
        AND currency_cd = 'USD' THEN total_cost * 0.845982465
        WHEN property_nm IN (
          'Nike Europe - 999 - Warsaw Annopol Factory Store',
          'Nike Europe - 662 - Krakow Factory Store'
        )
        AND currency_cd = 'PLN' THEN total_cost * 0.21865354
        ELSE total_cost
      END AS total_cost,
      CASE
        WHEN property_nm = 'Stockholm Showroom - WESWE - GPS'
        AND (
          start_dt BETWEEN DATE '2019-12-31' AND DATE  '2021-12-31'
        ) THEN 'EUR'
        WHEN property_nm IN (
          'Nike Europe - 999 - Warsaw Annopol Factory Store',
          'Nike Europe - 662 - Krakow Factory Store'
        )
        AND currency_cd = 'PLN' THEN 'EUR'
        ELSE currency_cd
      END AS currency_cd,
      start_dt,
      end_date,
      mos_nbr,
      supply_kw_charges_cost,
      supply_cost,
      delivery_cost_per_kwh,
      billing_kvar_cost,
      account_cd,
      client_node_id,
      delivery_kwh_charges_cost,
      universal_unit_uom,
      supply_cost_per_kwh,
      mid_peak_kwh,
      on_peak_kwh,
      service_zip_cd,
      invoice_id,
      property_state_nm,
      universal_usage_kbtu,
      property_address_nm,
      off_peak_kwh,
      supply_kwh_cost_per_kwh,
      kva_uom,
      demand_kw,
      percent_renewable_pct,
      property_city_nm,
      delivery_misc_charges_cost,
      service_address_nm,
      account_active_ind,
      calendarized_usage_qty,
      vendor_id,
      hdd_nbr,
      delivery_taxes_cost,
      supply_kwh_charges_cost,
      kva_cost,
      service_city_nm,
      vendor_cd,
      supply_taxes_cost,
      delivery_taxes_per_kwh,
      property_cd,
      property_zip_cd,
      property_nm,
      delivery_invoice_nbr,
      service_state_nm,
      delivery_kw_cost_per_kw,
      total_usage_uom,
      energy_unit,
      delivery_cost,
      total_cost_per_kwh,
      delivery_customer_charges_cost,
      vendor_name,
      property_country_nm,
      account_type_desc,
      end_date,
      yrs_nbr,
      supply_taxes_per_kwh,
      delivery_kwh_cost_per_kwh,
      kvar_cost,
      square_footage_sqft,
      is_property_ind,
      load_dt,
      load_month_nbr,
      load_year_nbr,
      created_at_tmst,
      user_nm,
      batch_load_tmst,
      job_nm,
      job_run_id
    FROM
      {curated_table_name}
    WHERE
      partition_row = 1
  ),
  AGG_REC AS (
    SELECT DISTINCT
      COALESCE(
        curated_obj.location_nm_latest,
        curated_obj.property_nm
      ) AS electricity_location_nm,
      COALESCE(
        curated_obj.location_nbr_latest,
        curated_obj.location_nbr
      ) AS electricity_location_nbr,
      TO_DATE(
        CONCAT(
          curated_obj.yrs_nbr,
          '-',
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electricity' AS SERVICE_TYPE_CD,
      TO_DATE(
        COALESCE(
          curated_obj.start_dt,
          CONCAT(
            curated_obj.yrs_nbr,
            '-',
            LPAD(curated_obj.mos_nbr, 2, '0')
          ),
          'yyyy-MM'
        )
      ) AS BILLING_MONTH_START_DT,
      TO_DATE(
        COALESCE(
          curated_obj.end_date,
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_obj.yrs_nbr,
                  '-',
                  LPAD(curated_obj.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'yyyy-MM-dd'
        )
      ) AS BILLING_MONTH_END_DT,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_obj.yrs_nbr,
                  '-',
                  LPAD(curated_obj.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT,
      calendar_obj.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      calendar_obj.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      calendar_obj.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      CAST(
        COALESCE(calendar_obj.YEAR_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(calendar_obj.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      CAST(
        COALESCE(calendar_obj.MONTH_OF_YEAR_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_MONTH_OF_YEAR_NBR,
      CAST(
        COALESCE(calendar_obj.QUARTER_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_QUARTER_NBR,
      CAST(
        COALESCE(calendar_obj.WEEK_OF_YEAR_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_WEEK_OF_YEAR_NBR,
      NULL AS building_id,
      12 AS DATA_FREQUENCY_CD,
      INITCAP(curated_obj.energy_unit) AS SERVICE_USAGE_QTY_UOM,
      curated_obj.total_usage_uom AS SERVICE_USAGE_QTY,
      curated_obj.total_cost AS SERVICE_COST,
      curated_obj.invoice_id AS invoice_id,
      CASE
        WHEN curated_obj.currency_cd = 'GPB' THEN 'GBP'
        ELSE curated_obj.currency_cd
      END AS SERVICE_COST_UOM,
      'FALSE' AS extrapolation_ind
    FROM
      CURATED_VIEW curated_obj
      LEFT JOIN {calendar_table_name} calendar_obj ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_obj.yrs_nbr,
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = calendar_obj.calendar_dt
  ),
  DETAILS_AGG AS (
    SELECT
      electricity_location_nm,
      electricity_location_nbr,
      reporting_period_dt,
      SERVICE_TYPE_CD,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      BILLING_MONTH_DATE_RANGE_TXT,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      building_id,
      DATA_FREQUENCY_CD,
      SERVICE_USAGE_QTY_UOM,
      CASE
        WHEN COUNT(invoice_id) OVER (
          PARTITION BY
            electricity_location_nm,
            electricity_location_nbr,
            reporting_period_dt,
            'Electricity'
        ) > 1 THEN ROUND(
          CAST(
            SUM(SERVICE_USAGE_QTY) OVER (
              PARTITION BY
                electricity_location_nm,
                electricity_location_nbr,
                reporting_period_dt,
                'Electricity'
            ) AS DECIMAL(38, 2)
          ),
          2
        )
        ELSE ROUND(
          CAST(
            MIN(SERVICE_USAGE_QTY) OVER (
              PARTITION BY
                electricity_location_nm,
                electricity_location_nbr,
                reporting_period_dt,
                'Electricity'
            ) AS DECIMAL(38, 2)
          ),
          2
        )
      END AS SERVICE_USAGE_QTY,
      CASE
        WHEN COUNT(invoice_id) OVER (
          PARTITION BY
            electricity_location_nm,
            electricity_location_nbr,
            reporting_period_dt,
            'Electricity'
        ) > 1 THEN ROUND(
          CAST(
            SUM(SERVICE_COST) OVER (
              PARTITION BY
                electricity_location_nm,
                electricity_location_nbr,
                reporting_period_dt,
                'Electricity'
            ) AS DECIMAL(38, 2)
          ),
          2
        )
        ELSE ROUND(
          CAST(
            MIN(SERVICE_COST) OVER (
              PARTITION BY
                electricity_location_nm,
                electricity_location_nbr,
                reporting_period_dt,
                'Electricity'
            ) AS DECIMAL(38, 2)
          ),
          2
        )
      END AS SERVICE_COST,
      SERVICE_COST_UOM,
      extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      'electricity_usage_metrics' AS cost_usage_data_source_nm,
      'ACCWW' AS cost_usage_data_source_cd,
      ROW_NUMBER() OVER (
        PARTITION BY
          electricity_location_nm,
          electricity_location_nbr,
          reporting_period_dt,
          'Electricity'
        ORDER BY
          electricity_location_nm,
          electricity_location_nbr,
          reporting_period_dt,
          'Electricity'
      ) AS row_num
    FROM
      AGG_REC
    WHERE
      reporting_period_dt < '2024-01-01'
  )
SELECT
  *
FROM
  DETAILS_AGG
WHERE
  row_num = 1;
