WITH
  impact_tbl AS (
    SELECT
      *,
      CASE
        WHEN entity_country_nm = 'United States of America' THEN 'USA'
        WHEN entity_country_nm = 'South Korea' THEN 'Korea'
        WHEN entity_country_nm = 'Viet Nam' THEN 'Vietnam'
        WHEN entity_country_nm = 'Turkey' THEN 'Türkiye'
        ELSE entity_country_nm
      END AS entity_country_nm_trimmed,
      CASE
        WHEN entity_country_nm = 'United States of America' THEN COALESCE(
          CONCAT(entity_zip_cd, '-', INITCAP(entity_city_nm)),
          INITCAP(entity_country_nm)
        )
        ELSE entity_country_nm
      END AS for_geogrphical_axis,
      CASE
        WHEN entity_geography_nm LIKE '%Factory%' THEN 'NFS'
        WHEN entity_geography_nm LIKE '%EHQ%' THEN 'Freestyle office'
        WHEN entity_geography_nm LIKE '%Distribution Center%' THEN 'DISTRIBUTION  CENTER'
        WHEN entity_geography_nm LIKE "HQ"
        OR entity_geography_nm = "GCHQ"
        OR entity_geography_nm = "WHQ" THEN 'OFFICE'
        WHEN entity_geography_nm LIKE '%Retail inline%' THEN 'NSO'
        WHEN entity_geography_nm LIKE '%Air Zoom Alpha AIR MI%' THEN 'MANUFACTURING'
        WHEN entity_geography_nm LIKE "%Warehouse%"
        OR entity_geography_nm LIKE "%Vietnam%"
        OR entity_geography_nm LIKE "%Viet nam%" THEN 'WAREHOUSE'
        WHEN entity_geography_nm = 'Other Facilities' THEN 'OTHER'
      END AS entity_geography_nm_validated,
      source_reporting_dt AS reporting_period_dt
    FROM
      {enablon_5_impact_areas}
    WHERE
      entity_scope_nm IN ('SCOPE 2', 'SCOPE 1&2')
      AND reporting_period_fiscal_year_nbr = 2025
      AND extrapolated_ind = 'FALSE'
  ),
  taxonomy_tbl AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_table}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  lookup_tbl AS (
    SELECT
      *
    FROM
      {enablon_lookup_table}
    WHERE
      (
        enablon_data_ingestion_method_nm = 'manually entered in enablon'
        AND entity_comparison_txt = 'exists in enablon but not in source'
        OR service_type_comparison_txt = 'more service types in enablon	more service types in enablon'
      )
      OR (
        enablon_data_ingestion_method_nm = 'manually entered in enablon'
        AND entity_comparison_txt = 'exists in source and enablon'
        OR service_type_comparison_txt = 'more service types in enablon	more service types in enablon'
      )
  ),
  site_tbl AS (
    SELECT DISTINCT
      electricity_location_nbr AS location_nbr,
      electricity_location_nm AS location_nm
    FROM
      {site_elec_table}
    WHERE
      cost_usage_data_source_cd NOT IN ('ENABLON', 'SEE')
    UNION
    SELECT DISTINCT
      fuel_location_nbr AS location_nbr,
      fuel_location_nm AS location_nm
    FROM
      {site_fuel_table}
    WHERE
      cost_usage_data_source_cd NOT IN ('ENABLON', 'SEE')
  ),
  calendar_tbl AS (
    SELECT
      *
    FROM
      {calendar_table}
  )
SELECT DISTINCT
  COALESCE(e.location_nbr, a.entity_reference_cd) AS electricity_location_nbr,
  a.entity_reference_nm AS electricity_location_nm,
  a.entity_lease_nbr AS lease_nbr,
  'null' AS building_id,
  CASE
    WHEN a.entity_division_nm LIKE 'Retail%' THEN 'Retail'
    ELSE 'Non Retail'
  END AS business_group_txt,
  a.entity_division_nm AS division_nm,
  INITCAP(a.entity_brand_nm) AS brand_nm,
  CASE
    WHEN a.entity_division_nm = 'Retail Inline (N)'
    OR a.entity_division_nm = 'Retail Inline (H)'
    OR a.entity_division_nm = 'Retail Inline (C)' THEN 'Retail Inline'
    WHEN a.entity_division_nm = 'Retail Factory (C)'
    OR a.entity_division_nm = 'Retail Factory (H)'
    OR a.entity_division_nm = 'Retail Factory (N)' THEN 'Retail Factory'
    WHEN a.entity_division_nm = 'Distribution Centers (N)'
    OR a.entity_division_nm = 'Distribution Centers (C)' THEN 'Distribution Center'
    WHEN a.entity_division_nm = 'Headquarters (N)'
    OR a.entity_division_nm = 'Headquarters (C)'
    OR a.entity_division_nm = 'Headquarters (H)' THEN 'Headquarters'
    WHEN a.entity_division_nm = 'Air MI - Facilities' THEN 'Air MI'
    WHEN a.entity_division_nm = 'Owned/Operated' THEN 'Owned/Operated'
    WHEN a.entity_division_nm = 'Fleet Vehicle'
    OR a.entity_division_nm = 'Inbound Transportation (C)'
    OR a.entity_division_nm = 'Inbound Transportation (N)' THEN 'Transportation'
    WHEN a.entity_division_nm = 'Flight Ops' THEN 'Flight Ops'
    WHEN a.entity_division_nm = 'Mixed' THEN 'Mixed'
    ELSE 'Other Facilities'
  END AS nike_department_type_txt,
  b.Region AS business_entity_geo_region_cd,
  b.Region AS location_geo_region_cd,
  'null' AS electricity_location_use_cd,
  a.entity_business_function_nm AS business_function_nm,
  CASE
    WHEN a.entity_continent_nm = 'America' THEN 'North America'
    ELSE a.entity_continent_nm
  END AS continent_nm,
  a.entity_address_txt AS address_line_1_txt,
  INITCAP(a.entity_city_nm) AS city_nm,
  'null' AS state_cd,
  a.entity_zip_cd AS postal_cd,
  -- below code is for testing
  for_geogrphical_axis AS geographical_axis_nm,
  b.CTRY_CD AS country_cd,
  CAST(a.entity_area_in_sqft AS DECIMAL(31, 5)) AS location_area,
  CASE
    WHEN location_area IS NULL THEN NULL
    ELSE 'Square foot'
  END AS location_area_uom,
  a.entity_status_nm AS location_status_cd,
  a.entity_geographical_latitude_deg AS location_latitude_deg,
  a.entity_geographical_longitude_deg AS location_longitude_deg,
  a.entity_characteristic_txt AS additional_location_feature_desc,
  a.reporting_period_dt,
  -- CASE
  --   WHEN entity_country_nm = 'United States of America' THEN 'USA'
  --   WHEN entity_country_nm = 'South Korea' THEN 'Korea'
  --   ELSE entity_country_nm
  -- END AS LOCATION_GEO_REGION_CD,
  -- Sustainability Impact Areas (knwldge repo -- )
  'sustainability_impact_areas' AS LOCATION_AREA_DATA_SOURCE_NM,
  'ENABLON' AS LOCATION_AREA_DATA_SOURCE_cd,
  'sustainability_impact_areas' AS cost_usage_data_source_nm,
  'ENABLON' AS cost_usage_data_source_cd
FROM
  impact_tbl a
  INNER JOIN lookup_tbl c ON a.entity_reference_cd = c.enablon_entity_reference_cd
  LEFT JOIN site_tbl e ON a.entity_reference_nm = e.location_nm
  LEFT JOIN taxonomy_tbl b ON entity_country_nm_trimmed = b.CTRY_NM
WHERE
  -- filter to exclude fuel locations that are present in scope 1&2 filter
  a.entity_consumption_group_nm NOT IN ("Biomass", "Electricity+Biomass", "Site Area")
