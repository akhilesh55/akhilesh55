WITH
  five_impact_areas_table AS (
    SELECT
      *
    FROM
      (
        SELECT
          *,
          ROW_NUMBER() OVER (
            PARTITION BY
              entity_reference_cd,
              entity_reference_nm,
              source_reporting_dt
            ORDER BY
              source_reporting_dt DESC
          ) AS row_num
        FROM
          {enablon_5_impact_areas}
        WHERE
          entity_impact_area_nm = 'CARBON'
          AND entity_scope_nm IN ('SCOPE 2', 'SCOPE 1', 'SCOPE 1&2')
      )
    WHERE
      row_num = 1
  ),
  TAXONOMY_TABLE AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_mapping_tbl}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  CURATED_VIEW AS (
    SELECT
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm,
      curated_tbl.client_site_ref_id,
      YEAR(TO_DATE(start_dt, 'dd/MM/yyyy')) AS yrs_nbr,
      MONTH(TO_DATE(start_dt, 'dd/MM/yyyy')) AS mos_nbr,
      DAY(TO_DATE(start_dt, 'dd/MM/yyyy')) AS dayy,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.concept_nm,
      curated_tbl.street_txt,
      curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt,
      curated_tbl.end_dt,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh,
      curated_tbl.invoiced_cost,
      curated_tbl.invoiced_usage_qty,
      curated_tbl.currency_cd
    FROM
      {curated_table_name} curated_tbl MINUS
    SELECT
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm,
      curated_tbl.client_site_ref_id,
      YEAR(TO_DATE(start_dt, 'dd/MM/yyyy')) AS yrs_nbr,
      MONTH(TO_DATE(start_dt, 'dd/MM/yyyy')) AS mos_nbr,
      DAY(TO_DATE(start_dt, 'dd/MM/yyyy')) AS dayy,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.concept_nm,
      curated_tbl.street_txt,
      curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt,
      curated_tbl.end_dt,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh,
      curated_tbl.invoiced_cost,
      curated_tbl.invoiced_usage_qty,
      curated_tbl.currency_cd
    FROM
      {curated_table_name_rejects} curated_tbl
  ),
  AGG_REC AS (
    SELECT DISTINCT
      curated_obj.site_nm AS electricity_location_nm,
      curated_obj.client_site_ref_id AS electricity_location_nbr,
      enablon_obj.entity_lease_nbr AS lease_nbr,
      TO_DATE(
        CONCAT(
          curated_obj.yrs_nbr,
          '-',
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      NULL AS building_id,
      CASE
        WHEN curated_obj.concept_nm LIKE '%Nike Offices%'
        OR curated_obj.concept_nm LIKE '%Converse - Nike Offices%' THEN 'Non Retail'
        ELSE 'Retail'
      END AS business_group_txt,
      CASE
        WHEN curated_obj.concept_nm LIKE '%CFS%'
        OR curated_obj.concept_nm LIKE '%Converse - Nike Office%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
      -- First priority: Check for specific 'Headquarters' values
        WHEN enablon_obj.entity_division_nm IN ('Headquarters (N)', 'Headquarters (C)') THEN 'Main HQ'
        -- Second priority: Clean and use entity division name if it results in a non-null value
        WHEN TRIM(
          REGEXP_REPLACE(enablon_obj.entity_division_nm, r'\s*\(.*\)', '')
        ) IS NOT NULL THEN TRIM(
          REGEXP_REPLACE(enablon_obj.entity_division_nm, r'\s*\(.*\)', '')
        )
        -- Third priority: Match 'NSO' case-insensitively
        WHEN curated_obj.concept_nm ILIKE 'NSO' THEN 'Retail Inline'
        -- Fourth priority: Match specific values exactly
        WHEN curated_obj.concept_nm IN ('NVS', 'NFS', 'CFS') THEN 'Retail Factory'
        -- Fifth priority: Match concept names containing 'nike office' case-insensitively
        WHEN curated_obj.concept_nm ILIKE '%nike office%' THEN 'Local Office'
      END AS nike_department_type_txt,
      'EMEA' AS BUSINESS_ENTITY_GEO_REGION_CD,
      CASE
        WHEN curated_obj.concept_nm IN ('NSO', 'NFS') THEN curated_obj.concept_nm
        WHEN curated_obj.concept_nm IN ('NVS', 'CFS') THEN 'FACTORY'
        WHEN curated_obj.concept_nm ILIKE '%office%' THEN 'OFFICE'
      END AS ELECTRICITY_LOCATION_USE_CD,
      enablon_obj.entity_business_function_nm AS business_function_nm,
      enablon_obj.entity_division_nm AS division_nm,
      'EMEA' AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        enablon_obj.entity_address_txt,
        curated_obj.street_txt
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(enablon_obj.entity_city_nm, curated_obj.city_nm) AS city_nm,
      -- COALESCE(
      --   enablon_obj.entity_state_nm,
      --   curated_obj.subleague_nm
      -- ) AS state_cd,
      NULL AS state_cd,
      COALESCE(enablon_obj.entity_zip_cd, curated_obj.zip_cd) AS postal_cd,
      COALESCE(
        enablon_obj.entity_geographical_reference_txt,
        taxonomy_obj.CTRY_NM,
        curated_obj.city_nm
      ) AS geographical_axis_nm,
      taxonomy_obj.CTRY_CD AS country_cd,
      CAST(
        COALESCE(
          enablon_obj.entity_area_in_sqft,
          curated_obj.site_size_in_sqft
        ) AS DECIMAL(31, 5)
      ) AS LOCATION_AREA,
      CASE
        WHEN enablon_obj.entity_area_in_sqft IS NOT NULL THEN 'Square foot'
        WHEN curated_obj.site_size_in_sqft IS NOT NULL THEN 'Square meter'
        ELSE NULL
      END AS LOCATION_AREA_UOM,
      COALESCE(
        enablon_obj.entity_status_nm,
        curated_obj.site_status_Ind_cd
      ) AS LOCATION_STATUS_CD,
      CAST(
        COALESCE(
          enablon_obj.ENTITY_GEOGRAPHICAL_LATITUDE_DEG,
          curated_obj.location_latitude_deg
        ) AS STRING
      ) AS latitude_deg,
      CAST(
        COALESCE(
          enablon_obj.ENTITY_GEOGRAPHICAL_LONGITUDE_DEG,
          curated_obj.location_longitude_deg
        ) AS STRING
      ) AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      CASE
        WHEN enablon_obj.entity_area_in_sqft IS NOT NULL THEN 'sustainability_impact_areas'
        WHEN curated_obj.site_size_in_sqft IS NOT NULL THEN 'electricity_usage_and_cost_metrics'
        ELSE NULL
      END AS location_area_data_source_nm,
      CASE
        WHEN enablon_obj.entity_area_in_sqft IS NOT NULL THEN 'ENABLON'
        WHEN curated_obj.site_size_in_sqft IS NOT NULL THEN 'MACE'
        ELSE NULL
      END AS location_area_data_source_cd,
      ROW_NUMBER() OVER (
        PARTITION BY
          curated_obj.site_nm,
          curated_obj.client_site_ref_id,
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          )
        ORDER BY
          curated_obj.site_nm,
          curated_obj.client_site_ref_id,
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          curated_obj.location_latitude_deg DESC,
          curated_obj.location_longitude_deg DESC
      ) AS row_num
    FROM
      CURATED_VIEW curated_obj
      LEFT JOIN five_impact_areas_table enablon_obj ON enablon_obj.source_reporting_dt = TO_DATE(
        CONCAT(
          curated_obj.yrs_nbr,
          '-',
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      )
      AND enablon_obj.entity_reference_nm = curated_obj.site_nm
      OR enablon_obj.entity_reference_cd = curated_obj.client_site_ref_id
      LEFT JOIN TAXONOMY_TABLE taxonomy_obj ON COALESCE(
        enablon_obj.entity_country_nm,
        curated_obj.country_nm
      ) = taxonomy_obj.CTRY_NM
  ),
  DERIVED_AGG AS (
    SELECT
      electricity_location_nm,
      electricity_location_nbr,
      lease_nbr,
      reporting_period_dt,
      building_id,
      business_group_txt,
      brand_nm,
      nike_department_type_txt,
      BUSINESS_ENTITY_GEO_REGION_CD,
      ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN nike_department_type_txt IN ('Retail Inline', 'Retail Factory')
        AND brand_nm = 'Nike' THEN 'DTC (N)'
        WHEN nike_department_type_txt IN ('Retail Inline', 'Retail Factory')
        AND brand_nm = 'Converse' THEN 'DTC (C)'
        WHEN nike_department_type_txt = 'Main HQ'
        AND brand_nm = 'Nike' THEN 'WD+C (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = 'Nike' THEN 'WD+C (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = 'Converse' THEN 'WD+C (C)'
        ELSE 'DTC (N)'
      END AS business_function_nm,
      CASE
        WHEN nike_department_type_txt = 'Retail Inline'
        AND brand_nm = 'Nike' THEN 'Retail Inline (N)'
        WHEN nike_department_type_txt = 'Retail Factory'
        AND brand_nm = 'Nike' THEN 'Retail Factory (N)'
        WHEN nike_department_type_txt = 'Retail Inline'
        AND brand_nm = 'Converse' THEN 'Retail Inline (C)'
        WHEN nike_department_type_txt = 'Retail Factory'
        AND brand_nm = 'Converse' THEN 'Retail Factory (C)'
        WHEN nike_department_type_txt = 'Main HQ'
        AND brand_nm = 'Nike' THEN 'Headquarters (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = 'Converse' THEN 'Other Facilities (C)'
        ELSE 'Other Facilities (N)'
      END AS division_nm,
      LOCATION_GEO_REGION_CD,
      continent_nm,
      ADDRESS_LINE_1_TXT,
      INITCAP(city_nm),
      state_cd,
      postal_cd,
      geographical_axis_nm,
      country_cd,
      LOCATION_AREA,
      LOCATION_AREA_UOM,
      LOCATION_STATUS_CD,
      latitude_deg,
      longitude_deg,
      ADDITIONAL_LOCATION_FEATURE_DESC,
      location_area_data_source_nm,
      location_area_data_source_cd,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      'MACE' AS cost_usage_data_source_cd,
      row_num
    FROM
      AGG_REC
  )
  /* FILTERING THE RECORDS for 2024 and above to match with mace */
SELECT
  *
EXCEPT
(row_num)
FROM
  DERIVED_AGG
WHERE
  reporting_period_dt >= '2024-01-01'
  AND row_num = 1
