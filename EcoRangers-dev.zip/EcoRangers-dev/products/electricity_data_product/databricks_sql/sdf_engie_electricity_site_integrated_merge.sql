WITH
  EMISSION_AND_USAGE AS (
    SELECT
      U_METRICS_PART.location_nm AS location_nm,
      U_METRICS_PART.location_nbr AS location_nbr,
      U_METRICS_PART.location_address_1_nm AS location_address_1_nm,
      U_METRICS_PART.location_address_2_nm AS location_address_2_nm,
      U_METRICS_PART.location_city_nm AS location_city_nm,
      U_METRICS_PART.location_state_or_province_nm AS location_state_or_province_nm,
      U_METRICS_PART.location_postal_cd AS location_postal_cd,
      U_METRICS_PART.location_country_nm AS location_country_nm,
      U_METRICS_PART.location_status_desc AS location_status_desc,
      U_METRICS_PART.location_size_sqft AS location_size_sqft,
      U_METRICS_PART.misc_information_desc AS misc_information_desc,
      U_METRICS_PART.vendor_nm AS vendor_nm,
      U_METRICS_PART.vendor_address_1_nm AS vendor_address_1_nm,
      U_METRICS_PART.vendor_address_2_nm AS vendor_address_2_nm,
      U_METRICS_PART.vendor_city_nm AS vendor_city_nm,
      U_METRICS_PART.vendor_state_or_province_nm AS vendor_state_or_province_nm,
      U_METRICS_PART.vendor_postal_cd AS vendor_postal_cd,
      U_METRICS_PART.vendor_country_nm AS vendor_country_nm,
      U_METRICS_PART.account_nbr AS account_nbr,
      U_METRICS_PART.summary_account_nbr AS summary_account_nbr,
      U_METRICS_PART.account_address_1_nm AS account_address_1_nm,
      U_METRICS_PART.account_address_2_nm AS account_address_2_nm,
      U_METRICS_PART.account_city_nm AS account_city_nm,
      U_METRICS_PART.account_state_or_province_nm AS account_state_or_province_nm,
      U_METRICS_PART.account_postal_cd AS account_postal_cd,
      U_METRICS_PART.account_country_nm AS account_country_nm,
      U_METRICS_PART.clean_account_number_desc AS clean_account_number_desc,
      U_METRICS_PART.supplier_only_account_ind AS supplier_only_account_ind,
      U_METRICS_PART.audit_only_ind AS audit_only_ind,
      U_METRICS_PART.customer_gl_nbr AS customer_gl_nbr,
      U_METRICS_PART.gl_desc AS gl_desc,
      U_METRICS_PART.gl_allocation_pct AS gl_allocation_pct,
      U_METRICS_PART.meter_number_desc AS meter_number_desc,
      U_METRICS_PART.service_point_location_nm AS service_point_location_nm,
      U_METRICS_PART.rate_schedule_desc AS rate_schedule_desc,
      U_METRICS_PART.month_dt AS reporting_period_dt,
      U_METRICS_PART.begin_dt AS begin_dt,
      U_METRICS_PART.end_dt AS end_dt,
      U_METRICS_PART.service_days AS service_days,
      U_METRICS_PART.cost AS COST,
      U_METRICS_PART.service_type_nm AS service_type_nm,
      U_METRICS_PART.uom AS uom,
      U_METRICS_PART.usage_qty AS usage_qty,
      U_METRICS_PART.billed_qty AS billed_qty,
      U_METRICS_PART.cost_per_unit_uom AS cost_per_unit_uom,
      U_METRICS_PART.cost_per_day AS cost_per_day,
      U_METRICS_PART.cost_per_sqft AS cost_per_sqft,
      U_METRICS_PART.usage_per_day AS usage_per_day,
      U_METRICS_PART.usage_per_sqft AS usage_per_sqft,
      U_METRICS_PART.kbtus_qty AS kbtus_qty,
      U_METRICS_PART.kbtus_per_sqft AS kbtus_per_sqft,
      U_METRICS_PART.max_demand_qty AS max_demand_qty,
      U_METRICS_PART.load_factor_qty AS load_factor_qty,
      U_METRICS_PART.power_factor_qty AS power_factor_qty,
      U_METRICS_PART.cost_per_billed_qty AS cost_per_billed_qty,
      U_METRICS_PART.bill_estimated_ind AS bill_estimated_ind,
      U_METRICS_PART.open_exceptions_ind AS open_exceptions_ind,
      U_METRICS_PART.bill_image_desc AS bill_image_desc,
      U_METRICS_PART.department_nm AS department_nm,
      U_METRICS_PART.lease_number_desc AS lease_number_desc,
      U_METRICS_PART.audit_status_dt AS audit_status_dt,
      U_METRICS_PART.contract_expiration_dt AS contract_expiration_dt,
      U_METRICS_PART.contract_nm AS contract_nm,
      U_METRICS_PART.contract_status_desc AS contract_status_desc,
      U_METRICS_PART.floor_nbr AS floor_nbr,
      U_METRICS_PART.alternate_nm AS alternate_nm,
      U_METRICS_PART.baseline_note_desc AS baseline_note_desc,
      U_METRICS_PART.better_buildings_challenge_ind AS better_buildings_challenge_ind,
      U_METRICS_PART.district_inline_desc AS district_inline_desc,
      U_METRICS_PART.district_outlet_desc AS district_outlet_desc,
      U_METRICS_PART.footprint_sqft AS footprint_sqft,
      U_METRICS_PART.in_line_outlet_desc AS in_line_outlet_desc,
      U_METRICS_PART.ems_desc AS ems_desc,
      U_METRICS_PART.ems_install_dt AS ems_install_dt,
      U_METRICS_PART.global_sustainability_energy_plus_carbon_target_group_desc AS global_sustainability_energy_plus_carbon_target_group_desc,
      U_METRICS_PART.location_opened_dt AS location_opened_dt,
      U_METRICS_PART.site_cd_siterra_desc AS site_cd_siterra_desc,
      U_METRICS_PART.total_bldg_sqft AS total_bldg_sqft,
      U_METRICS_PART.wd_and_c_geo AS wd_and_c_geo,
      U_METRICS_PART.whq_campus_nm AS whq_campus_nm,
      U_METRICS_PART.leed_desc AS leed_desc,
      U_METRICS_PART.location_crc_nbr AS location_crc_nbr,
      U_METRICS_PART.new_building_nm AS new_building_nm,
      U_METRICS_PART.ownership_desc AS ownership_desc,
      U_METRICS_PART.principle_building_activity_desc AS principle_building_activity_desc,
      U_METRICS_PART.seated_occupancy_qty AS seated_occupancy_qty,
      U_METRICS_PART.sub_concept_desc AS sub_concept_desc,
      U_METRICS_PART.brand_nm AS brand_nm
    FROM
      {curated_table_name} U_METRICS_PART
    WHERE
      (
        U_METRICS_PART.DEPARTMENT_NM IN (
          'Retail Factory',
          'Retail Inline',
          'Retail Other',
          'WHQ',
          'HQ',
          'Other Offices and Building Construction',
          'DC',
          'Distribution Centers',
          'Flex Space',
          'Sales Offices'
        )
        OR U_METRICS_PART.DEPARTMENT_NM ILIKE '%Air MI%'
        OR U_METRICS_PART.DEPARTMENT_NM IS NULL
      )
      AND U_METRICS_PART.SERVICE_TYPE_NM IN ('Electric')
      AND U_METRICS_PART.LOCATION_NM NOT ILIKE '!0%' QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          U_METRICS_PART.location_nbr,
          U_METRICS_PART.location_nm,
          U_METRICS_PART.month_dt
        ORDER BY
          U_METRICS_PART.month_dt DESC,
          U_METRICS_PART.site_cd_siterra_desc DESC
      ) = 1 MINUS
    SELECT
      *
    EXCEPT
    (
      time_from_report,
      user_nm,
      batch_load_tmst,
      job_nm,
      job_run_id
    )
    FROM
      {emission_and_usage_metrics_reject_view}
  ),
  ENABLON_5_IMPACT_AREA AS (
    SELECT
      F_IMPACT.SUSTAINABILITY_IMPACT_AREA_UUID AS SUSTAINABILITY_IMPACT_AREA_UUID,
      F_IMPACT.ENTITY_REFERENCE_ID AS ENTITY_REFERENCE_ID,
      F_IMPACT.SOURCE_REPORTING_DT AS SOURCE_REPORTING_DT,
      F_IMPACT.INDICATOR_ID AS INDICATOR_ID,
      F_IMPACT.GHG_EMISSIONS_UUID AS GHG_EMISSIONS_UUID,
      F_IMPACT.ENTITY_REFERENCE_CD AS ENTITY_REFERENCE_CD,
      F_IMPACT.ENTITY_REFERENCE_NM AS ENTITY_REFERENCE_NM,
      F_IMPACT.ENTITY_LEVEL_NBR AS ENTITY_LEVEL_NBR,
      F_IMPACT.ENTITY_ID AS ENTITY_ID,
      F_IMPACT.ENTITY_CD AS ENTITY_CD,
      F_IMPACT.ENTITY_NM AS ENTITY_NM,
      F_IMPACT.ENTITY_ORGANIZATION_ID AS ENTITY_ORGANIZATION_ID,
      F_IMPACT.ENTITY_ORGANIZATION_CD AS ENTITY_ORGANIZATION_CD,
      F_IMPACT.ENTITY_ORGANIZATION_NM AS ENTITY_ORGANIZATION_NM,
      F_IMPACT.ENTITY_BRAND_ID AS ENTITY_BRAND_ID,
      F_IMPACT.ENTITY_BRAND_CD AS ENTITY_BRAND_CD,
      F_IMPACT.ENTITY_BRAND_NM AS ENTITY_BRAND_NM,
      F_IMPACT.ENTITY_BUSINESS_FUNCTION_ID AS ENTITY_BUSINESS_FUNCTION_ID,
      F_IMPACT.ENTITY_BUSINESS_FUNCTION_CD AS ENTITY_BUSINESS_FUNCTION_CD,
      F_IMPACT.ENTITY_BUSINESS_FUNCTION_NM AS ENTITY_BUSINESS_FUNCTION_NM,
      F_IMPACT.ENTITY_DIVISION_ID AS ENTITY_DIVISION_ID,
      F_IMPACT.ENTITY_DIVISION_CD AS ENTITY_DIVISION_CD,
      F_IMPACT.ENTITY_DIVISION_NM AS ENTITY_DIVISION_NM,
      F_IMPACT.ENTITY_GEOGRAPHY_ID AS ENTITY_GEOGRAPHY_ID,
      F_IMPACT.ENTITY_GEOGRAPHY_CD AS ENTITY_GEOGRAPHY_CD,
      F_IMPACT.ENTITY_GEOGRAPHY_NM AS ENTITY_GEOGRAPHY_NM,
      F_IMPACT.ENTITY_CONTINENT_NM AS ENTITY_CONTINENT_NM,
      F_IMPACT.ENTITY_LEASE_NBR AS ENTITY_LEASE_NBR,
      F_IMPACT.ENTITY_ADDRESS_TXT AS ENTITY_ADDRESS_TXT,
      F_IMPACT.ENTITY_CITY_NM AS ENTITY_CITY_NM,
      F_IMPACT.ENTITY_STATE_NM AS ENTITY_STATE_NM,
      F_IMPACT.ENTITY_STATE_REGION_NM AS ENTITY_STATE_REGION_NM,
      F_IMPACT.ENTITY_COUNTRY_NM AS ENTITY_COUNTRY_NM,
      F_IMPACT.ENTITY_ZIP_CD AS ENTITY_ZIP_CD,
      F_IMPACT.ENTITY_GEOGRAPHICAL_REFERENCE_TXT AS ENTITY_GEOGRAPHICAL_REFERENCE_TXT,
      F_IMPACT.ENTITY_GEOGRAPHICAL_LATITUDE_DEG AS ENTITY_GEOGRAPHICAL_LATITUDE_DEG,
      F_IMPACT.ENTITY_GEOGRAPHICAL_LONGITUDE_DEG AS ENTITY_GEOGRAPHICAL_LONGITUDE_DEG,
      F_IMPACT.ENTITY_AREA_IN_SQFT AS ENTITY_AREA_IN_SQFT,
      F_IMPACT.ENTITY_CHARACTERISTIC_TXT AS ENTITY_CHARACTERISTIC_TXT,
      F_IMPACT.ENTITY_STATUS_NM AS ENTITY_STATUS_NM,
      F_IMPACT.ENTITY_IMPACT_AREA_NM AS ENTITY_IMPACT_AREA_NM,
      F_IMPACT.ENTITY_SECONDARY_IMPACT_AREA_NM AS ENTITY_SECONDARY_IMPACT_AREA_NM,
      F_IMPACT.ENTITY_SCOPE_NM AS ENTITY_SCOPE_NM,
      F_IMPACT.ENTITY_PROTOCOL_NM AS ENTITY_PROTOCOL_NM,
      F_IMPACT.ENTITY_GREENHOUSE_GAS_NM AS ENTITY_GREENHOUSE_GAS_NM,
      F_IMPACT.ENTITY_CONSUMPTION_GROUP_NM AS ENTITY_CONSUMPTION_GROUP_NM,
      F_IMPACT.ENTITY_EMISSION_FACTOR_CD AS ENTITY_EMISSION_FACTOR_CD,
      F_IMPACT.ENTITY_EMISSION_FACTOR_NM AS ENTITY_EMISSION_FACTOR_NM,
      F_IMPACT.ENTITY_EMISSION_FACTOR_EFFECTIVE_DT AS ENTITY_EMISSION_FACTOR_EFFECTIVE_DT,
      F_IMPACT.ENTITY_EMISSION_FACTOR_UOM AS ENTITY_EMISSION_FACTOR_UOM,
      F_IMPACT.INDICATOR_REFERENTIAL_ID AS INDICATOR_REFERENTIAL_ID,
      F_IMPACT.INDICATOR_REFERENTIAL_CD AS INDICATOR_REFERENTIAL_CD,
      F_IMPACT.INDICATOR_REFERENTIAL_NM AS INDICATOR_REFERENTIAL_NM,
      F_IMPACT.INDICATOR_BUSINESS_FUNCTION_ID AS INDICATOR_BUSINESS_FUNCTION_ID,
      F_IMPACT.INDICATOR_BUSINESS_FUNCTION_CD AS INDICATOR_BUSINESS_FUNCTION_CD,
      F_IMPACT.INDICATOR_BUSINESS_FUNCTION_NM AS INDICATOR_BUSINESS_FUNCTION_NM,
      F_IMPACT.IMPACT_AREA_QUESTIONNAIRE_ID AS IMPACT_AREA_QUESTIONNAIRE_ID,
      F_IMPACT.IMPACT_AREA_QUESTIONNAIRE_CD AS IMPACT_AREA_QUESTIONNAIRE_CD,
      F_IMPACT.IMPACT_AREA_QUESTIONNAIRE_NM AS IMPACT_AREA_QUESTIONNAIRE_NM,
      F_IMPACT.INDICATOR_CD AS INDICATOR_CD,
      F_IMPACT.INDICATOR_NM AS INDICATOR_NM,
      F_IMPACT.INDICATOR_CATEGORY_CD AS INDICATOR_CATEGORY_CD,
      F_IMPACT.INDICATOR_ACTIVE_IND AS INDICATOR_ACTIVE_IND,
      F_IMPACT.INDICATOR_CAMPAIGN_ID AS INDICATOR_CAMPAIGN_ID,
      F_IMPACT.INDICATOR_CAMPAIGN_NM AS INDICATOR_CAMPAIGN_NM,
      F_IMPACT.INDICATOR_CAMPAIGN_STATUS_NM AS INDICATOR_CAMPAIGN_STATUS_NM,
      F_IMPACT.INDICATOR_TYPE_CD AS INDICATOR_TYPE_CD,
      F_IMPACT.INDICATOR_TYPE_NM AS INDICATOR_TYPE_NM,
      F_IMPACT.INDICATOR_NUMERATOR_TXT AS INDICATOR_NUMERATOR_TXT,
      F_IMPACT.INDICATOR_DENOMINATOR_TXT AS INDICATOR_DENOMINATOR_TXT,
      F_IMPACT.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
      F_IMPACT.DATA_FREQUENCY_NM AS DATA_FREQUENCY_NM,
      F_IMPACT.REPORTING_PERIOD_FISCAL_YEAR_NBR AS REPORTING_PERIOD_FISCAL_YEAR_NBR,
      F_IMPACT.REPORTING_PERIOD_FISCAL_QUARTER_NBR AS REPORTING_PERIOD_FISCAL_QUARTER_NBR,
      F_IMPACT.REPORTING_PERIOD_YEAR_NBR AS REPORTING_PERIOD_YEAR_NBR,
      F_IMPACT.REPORTING_PERIOD_QUARTER_NBR AS REPORTING_PERIOD_QUARTER_NBR,
      F_IMPACT.REPORTING_PERIOD_MONTH_NBR AS REPORTING_PERIOD_MONTH_NBR,
      F_IMPACT.REPORTING_PERIOD_MONTH_NM AS REPORTING_PERIOD_MONTH_NM,
      F_IMPACT.SOURCE_VALUE_NBR AS SOURCE_VALUE_NBR,
      F_IMPACT.RESULT_VALUE_NBR AS RESULT_VALUE_NBR,
      F_IMPACT.RESULT_VALUE_TXT AS RESULT_VALUE_TXT,
      F_IMPACT.CATEGORY_BASE_UOM_ID AS CATEGORY_BASE_UOM_ID,
      F_IMPACT.CATEGORY_BASE_UOM_CD AS CATEGORY_BASE_UOM_CD,
      F_IMPACT.CATEGORY_BASE_UOM_NM AS CATEGORY_BASE_UOM_NM,
      F_IMPACT.FAMILY_BASE_UOM_CD AS FAMILY_BASE_UOM_CD,
      F_IMPACT.FAMILY_BASE_UOM_NM AS FAMILY_BASE_UOM_NM,
      F_IMPACT.FAMILY_BASE_QTY_UOM_CD AS FAMILY_BASE_QTY_UOM_CD,
      F_IMPACT.FAMILY_BASE_QTY_UOM_NM AS FAMILY_BASE_QTY_UOM_NM,
      F_IMPACT.CONVERTED_VALUE_NBR AS CONVERTED_VALUE_NBR,
      F_IMPACT.CONVERTED_UOM_CD AS CONVERTED_UOM_CD,
      F_IMPACT.CONVERTED_UOM_NM AS CONVERTED_UOM_NM,
      F_IMPACT.CALCULATED_SUM_IND AS CALCULATED_SUM_IND,
      F_IMPACT.EXTRAPOLATED_IND AS EXTRAPOLATED_IND,
      F_IMPACT.DATA_COMMENT_TXT AS DATA_COMMENT_TXT,
      F_IMPACT.ETL_TMST_UTC AS ETL_TMST_UTC
    FROM
      {ENABLON_5_IMPACT_AREA_V} F_IMPACT
    WHERE
      ENTITY_IMPACT_AREA_NM = 'CARBON'
      -- AND ENTITY_SCOPE_NM IN ("SCOPE 2", "SCOPE 1&2")
      -- AND INDICATOR_CD IN (
      --   'DTC-E-5',
      --   'FS-E-11',
      --   'IHM-E-11',
      --   'LOG-E-60',
      --   'WDC-E-10'
      -- ) 
      QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          --  F_IMPACT.ENTITY_REFERENCE_CD,
          F_IMPACT.ENTITY_REFERENCE_NM,
          F_IMPACT.SOURCE_REPORTING_DT
        ORDER BY
          F_IMPACT.SOURCE_REPORTING_DT DESC,
          CASE
            WHEN F_IMPACT.INDICATOR_CATEGORY_CD = 'ENERGY' THEN 1
            ELSE 2
          END,
          CASE
            WHEN F_IMPACT.ENTITY_STATUS_NM ILIKE 'Open' THEN 1
            ELSE 2
          END
      ) = 1
  ),
  SITE_INTEGRATION AS (
    SELECT
      COALESCE(
        CAST(EAU.LOCATION_NBR AS STRING),
        AIRMI.LOCATION_NUMBER,
        EFIA.ENTITY_REFERENCE_CD
      ) AS electricity_location_nbr,
      EAU.LOCATION_NM AS electricity_location_nm,
      -- COALESCE(EFIA.ENTITY_LEASE_NBR, EAU.LEASE_NUMBER_DESC) AS lease_nbr,
      COALESCE(
        EFIA.ENTITY_LEASE_NBR,
        FIRST_VALUE(EFIA.ENTITY_LEASE_NBR) OVER (
          PARTITION BY
            EAU.LOCATION_NM
          ORDER BY
            EFIA.SOURCE_REPORTING_DT DESC ROWS BETWEEN UNBOUNDED PRECEDING
            AND UNBOUNDED FOLLOWING
        ),
        EAU.LEASE_NUMBER_DESC
      ) AS lease_nbr,
      EAU.SITE_CD_SITERRA_DESC AS building_id,
      CASE
        WHEN (
          EAU.DEPARTMENT_NM ILIKE 'Retail%'
          OR TRIM(
            REGEXP_REPLACE(EFIA.entity_division_nm, r'\s*\(.*\)', '')
          ) ILIKE 'Retail%'
        ) THEN 'Retail'
        ELSE 'Non Retail'
      END AS business_group_txt,
      COALESCE(EAU.BRAND_NM, EFIA.ENTITY_BRAND_NM) AS brand_nm,
      CASE
        WHEN EAU.DEPARTMENT_NM IN (
          'Other Offices and Building Construction',
          'Flex Space',
          'Sales Offices'
        ) THEN 'Other Facilities'
        WHEN (
          EAU.DEPARTMENT_NM ILIKE 'HQ'
          OR EFIA.entity_division_nm ILIKE '%Headquarters%'
        ) THEN 'WHQ'
        WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%' THEN 'Air Mi'
        WHEN EAU.DEPARTMENT_NM IS NULL
        AND EAU.location_nm ILIKE '%store%' THEN 'Retail Inline'
        WHEN EAU.DEPARTMENT_NM IS NULL
        AND EAU.location_nm ILIKE '%clearance%' THEN 'Retail Factory'
        WHEN (
          EAU.DEPARTMENT_NM IS NULL
          AND TRIM(
            REGEXP_REPLACE(EFIA.entity_division_nm, r'\s*\(.*\)', '')
          ) IS NOT NULL
        ) THEN TRIM(
          REGEXP_REPLACE(EFIA.entity_division_nm, r'\s*\(.*\)', '')
        )
        WHEN EAU.DEPARTMENT_NM IS NULL THEN 'Retail Other'
        ELSE EAU.DEPARTMENT_NM
      END AS nike_department_type_txt,
      COALESCE(EAU.whq_campus_nm, EAU.wd_and_c_geo, 'NA') AS BUSINESS_ENTITY_GEO_REGION_CD,
      NULL AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN EFIA.ENTITY_BUSINESS_FUNCTION_NM IS NOT NULL THEN EFIA.ENTITY_BUSINESS_FUNCTION_NM
        WHEN (
          EAU.DEPARTMENT_NM IN ('Retail Factory', 'Retail Inline', 'Retail Other')
          OR (
            EAU.DEPARTMENT_NM IS NULL
            AND EAU.location_nm ILIKE '%store%'
          )
        )
        AND EAU.BRAND_NM = 'Nike' THEN 'DTC (N)'
        WHEN (
          EAU.DEPARTMENT_NM IN ('Retail Factory', 'Retail Inline', 'Retail Other')
          OR (
            EAU.DEPARTMENT_NM IS NULL
            AND EAU.location_nm ILIKE '%store%'
          )
        )
        AND EAU.BRAND_NM = 'Converse' THEN 'DTC (C)'
        WHEN (
          EAU.DEPARTMENT_NM IN (
            'Other Offices and Building Construction',
            'Flex Space',
            'Sales Offices'
          )
          OR EAU.DEPARTMENT_NM ILIKE '%HQ%'
        )
        AND EAU.BRAND_NM = 'Nike' THEN 'WD+C (N)'
        WHEN (
          EAU.DEPARTMENT_NM IN (
            'Other Offices and Building Construction',
            'Flex Space',
            'Sales Offices'
          )
          OR EAU.DEPARTMENT_NM ILIKE '%HQ%'
        )
        AND EAU.BRAND_NM = 'Converse' THEN 'WD+C (C)'
        WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%'
        AND EAU.BRAND_NM = 'Nike' THEN 'Air MI (Nike)'
        ELSE NULL
      END AS business_function_nm,
      CASE
        WHEN EFIA.entity_continent_nm IS NOT NULL THEN EFIA.entity_continent_nm
        WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'NA'
        ELSE 'NA'
      END AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN EFIA.entity_continent_nm IS NOT NULL THEN EFIA.entity_continent_nm
        WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
        ELSE 'North America'
      END AS continent_nm,
      COALESCE(
        EFIA.entity_address_txt,
        EAU.location_address_1_nm
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(EFIA.entity_city_nm, EAU.location_city_nm) AS city_nm,
      COALESCE(
        EAU.location_state_or_province_nm
        -- EFIA.entity_state_nm
      ) AS STATE_CD,
      COALESCE(EFIA.entity_zip_cd, EAU.location_postal_cd) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(EFIA.entity_zip_cd, EAU.location_postal_cd),
        INITCAP(
          COALESCE(EFIA.entity_city_nm, EAU.location_city_nm)
        )
      ) AS geographical_axis_nm,
      COALESCE(EFIA.entity_country_nm, EAU.location_country_nm) AS COUNTRY_CD,
      COALESCE(EFIA.ENTITY_AREA_IN_SQFT, EAU.location_size_sqft) AS LOCATION_AREA,
      CASE
        WHEN (
          EFIA.ENTITY_AREA_IN_SQFT IS NOT NULL
          OR EAU.location_size_sqft IS NOT NULL
        ) THEN 'Square foot'
        ELSE NULL
      END AS LOCATION_AREA_UOM,
      -- CASE
      --   WHEN EFIA.entity_status_nm IS NOT NULL THEN EFIA.entity_status_nm
      --   WHEN EAU.location_status_desc = 'Active' THEN 'Open'
      --   WHEN EAU.location_status_desc = 'Inactive' THEN 'Close'
      --   ELSE EAU.location_status_desc
      -- END AS LOCATION_STATUS_CD,
      COALESCE(
        FIRST_VALUE(EFIA.entity_status_nm) OVER (
          PARTITION BY
            EAU.LOCATION_NM
          ORDER BY
            EFIA.SOURCE_REPORTING_DT DESC ROWS BETWEEN UNBOUNDED PRECEDING
            AND UNBOUNDED FOLLOWING
        ),
        CASE
          WHEN EAU.location_status_desc = 'Active' THEN 'Open'
          WHEN EAU.location_status_desc = 'Inactive' THEN 'Close'
          ELSE EAU.location_status_desc
        END
      ) AS LOCATION_STATUS_CD,
      EFIA.entity_geographical_latitude_deg AS latitude_deg,
      EFIA.entity_geographical_longitude_deg AS longitude_deg,
      CASE
        WHEN EAU.EMS_DESC = 'EMS Sites' THEN 'EMS'
        ELSE EAU.EMS_DESC
      END AS ADDITIONAL_LOCATION_FEATURE_DESC,
      CASE
        WHEN EFIA.ENTITY_AREA_IN_SQFT IS NOT NULL THEN 'sustainability_impact_areas'
        WHEN (
          EFIA.ENTITY_AREA_IN_SQFT IS NULL
          AND EAU.location_size_sqft IS NOT NULL
        ) THEN 'emission_and_usage_metrics'
        ELSE NULL
      END AS LOCATION_AREA_DATA_SOURCE_NM,
      CASE
        WHEN EFIA.ENTITY_AREA_IN_SQFT IS NOT NULL THEN 'ENABLON'
        WHEN (
          EFIA.ENTITY_AREA_IN_SQFT IS NULL
          AND EAU.location_size_sqft IS NOT NULL
        ) THEN 'ENGI'
        ELSE NULL
      END AS LOCATION_AREA_DATA_SOURCE_CD,
      EAU.reporting_period_dt AS reporting_period_dt
    FROM
      EMISSION_AND_USAGE EAU
      LEFT JOIN ENABLON_5_IMPACT_AREA EFIA ON EAU.location_nm = EFIA.entity_reference_nm
      AND EAU.reporting_period_dt = EFIA.source_reporting_dt
      LEFT JOIN (
        SELECT
          LOCATION_NAME,
          BUILDING_ID,
          LOCATION_NUMBER
        FROM
          air_mi_mapping_table_name
        WHERE
          OPERATION_ACTION IN ('XOVERWRITE', 'XMERGE')
      ) AIRMI ON EAU.LOCATION_NM = AIRMI.LOCATION_NAME
    WHERE
      (
        EAU.DEPARTMENT_NM IN (
          'Retail Factory',
          'Retail Inline',
          'Retail Other',
          'Other Offices and Building Construction',
          'Flex Space',
          'Sales Offices',
          'WHQ',
          'HQ'
        )
        OR EAU.DEPARTMENT_NM IS NULL
        OR EAU.DEPARTMENT_NM ILIKE '%Air MI%'
      )
    UNION ALL
    SELECT
      COALESCE(
        LOGEC.electricity_location_nbr,
        SUBSTRING(DC_UMD.LOCATION_KEY, 4),
        CAST(EAU.LOCATION_NBR AS STRING)
      ) AS electricity_location_nbr,
      COALESCE(
        LOGEC.electricity_location_nm,
        DC_UMD.NODE_NAME,
        DC_UMD.LOCATION_NAME,
        EAU.LOCATION_NM
      ) AS electricity_location_nm,
      COALESCE(LOGEC.lease_nbr, EAU.LEASE_NUMBER_DESC) AS lease_nbr,
      COALESCE(LOGEC.building_id, EAU.SITE_CD_SITERRA_DESC) AS building_id,
      'Non Retail' AS business_group_txt,
      COALESCE(
        EAU.BRAND_NM
        -- , EFIA.ENTITY_BRAND_NM
      ) AS brand_nm,
      'Distribution Center' AS nike_department_type_txt,
      COALESCE(EAU.whq_campus_nm, EAU.wd_and_c_geo, 'NA') AS BUSINESS_ENTITY_GEO_REGION_CD,
      'DISTRIBUTION CENTER' AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN EAU.BRAND_NM ILIKE '%Nike%' THEN 'Logistics (N)'
        WHEN EAU.BRAND_NM ILIKE '%Converse%' THEN 'Logistics (C)'
        ELSE EAU.DEPARTMENT_NM
      END AS business_function_nm,
      CASE
        WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'NA'
        ELSE 'NA'
      END AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
        ELSE 'North America'
      END AS continent_nm,
      COALESCE(
        LOGEC.ADDRESS_LINE_1_TXT,
        EAU.location_address_1_nm
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(LOGEC.city_nm, EAU.location_city_nm) AS city_nm,
      COALESCE(LOGEC.STATE_CD, EAU.location_state_or_province_nm) AS STATE_CD,
      COALESCE(LOGEC.POSTAL_CD, EAU.location_postal_cd) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(LOGEC.POSTAL_CD, EAU.location_postal_cd),
        INITCAP(COALESCE(LOGEC.city_nm, EAU.location_city_nm))
      ) AS geographical_axis_nm,
      COALESCE(LOGEC.COUNTRY_CD, EAU.location_country_nm) AS COUNTRY_CD,
      COALESCE(LOGEC.LOCATION_AREA, EAU.location_size_sqft) AS LOCATION_AREA,
      CASE
        WHEN LOGEC.LOCATION_AREA IS NOT NULL THEN 'Square meter'
        WHEN (
          LOGEC.LOCATION_AREA IS NULL
          AND EAU.location_size_sqft IS NOT NULL
        ) THEN 'Square foot'
        ELSE NULL
      END AS LOCATION_AREA_UOM,
      CASE
        WHEN EAU.location_status_desc = 'Active' THEN 'Open'
        WHEN EAU.location_status_desc = 'Inactive' THEN 'Close'
        ELSE EAU.location_status_desc
      END AS LOCATION_STATUS_CD,
      COALESCE(
        LOGEC.latitude_deg
        -- ,EFIA.entity_geographical_latitude_deg
      ) AS latitude_deg,
      COALESCE(
        LOGEC.longitude_deg
        -- ,EFIA.entity_geographical_longitude_deg
      ) AS longitude_deg,
      CASE
        WHEN EAU.EMS_DESC = 'EMS Sites' THEN 'EMS'
        ELSE EAU.EMS_DESC
      END AS ADDITIONAL_LOCATION_FEATURE_DESC,
      CASE
        WHEN LOGEC.LOCATION_AREA IS NOT NULL THEN 'logec'
        WHEN (
          LOGEC.LOCATION_AREA IS NULL
          AND EAU.location_size_sqft IS NOT NULL
        ) THEN 'emission_and_usage_metrics'
        ELSE NULL
      END AS LOCATION_AREA_DATA_SOURCE_NM,
      CASE
        WHEN LOGEC.LOCATION_AREA IS NOT NULL THEN 'LOGEC'
        WHEN (
          LOGEC.LOCATION_AREA IS NULL
          AND EAU.location_size_sqft IS NOT NULL
        ) THEN 'ENGI'
        ELSE NULL
      END AS LOCATION_AREA_DATA_SOURCE_CD,
      EAU.reporting_period_dt AS reporting_period_dt
    FROM
      EMISSION_AND_USAGE EAU
      -- LEFT JOIN ENABLON_5_IMPACT_AREA EFIA ON EAU.location_nm = EFIA.entity_reference_nm
      -- AND EAU.reporting_period_dt = EFIA.source_reporting_dt
      LEFT JOIN DC_SITE_DETAIL_MAPPING DC_UMD ON EAU.LOCATION_NM = DC_UMD.LOCATION_NM
      AND EAU.LOCATION_NBR = DC_UMD.LOCATION_NBR
      LEFT JOIN {electricity_usage_location_integrated} LOGEC ON COALESCE(DC_UMD.NODE_NAME, DC_UMD.LOCATION_NAME) = LOGEC.electricity_location_nm
      AND SUBSTRING(DC_UMD.LOCATION_KEY, 4) = LOGEC.electricity_location_nbr
      AND EAU.reporting_period_dt = LOGEC.reporting_period_dt
      AND LOGEC.cost_usage_data_source_nm = 'logec'
    WHERE
      EAU.DEPARTMENT_NM IN ('DC', 'Distribution Centers')
      AND NOT (
        EAU.LOCATION_NM ILIKE '%Ontario-Hofer'
        OR EAU.LOCATION_NM ILIKE '%Ontario - Lowell'
      )
  )
SELECT DISTINCT
  CONCAT(
    COALESCE(ELECTRIC_SITE.lease_nbr, 'R0'),
    COALESCE(
      RIGHT(
        CAST(ELECTRIC_SITE.electricity_location_nbr AS STRING),
        3
      ),
      '999999999'
    )
  ) AS lease_custom_key,
  ELECTRIC_SITE.electricity_location_nbr AS electricity_location_nbr,
  ELECTRIC_SITE.electricity_location_nm AS electricity_location_nm,
  ELECTRIC_SITE.lease_nbr AS lease_nbr,
  ELECTRIC_SITE.building_id AS building_id,
  INITCAP(
    REGEXP_REPLACE(ELECTRIC_SITE.business_group_txt, '-', ' ')
  ) AS business_group_txt,
  INITCAP(ELECTRIC_SITE.brand_nm) AS brand_nm,
  CASE
    WHEN ELECTRIC_SITE.nike_department_type_txt ILIKE '%air mi%' THEN 'Air MI'
    ELSE ELECTRIC_SITE.nike_department_type_txt
  END AS nike_department_type_txt,
  CASE
    WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE '%America%' THEN 'NA'
    WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
    WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
    ELSE ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD
  END AS BUSINESS_ENTITY_GEO_REGION_CD,
  ELECTRIC_SITE.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
  ELECTRIC_SITE.business_function_nm AS business_function_nm,
  CASE
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Inline'
    AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Retail Inline (N)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Other'
    AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Retail Other (N)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Factory'
    AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Retail Factory (N)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Inline'
    AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Retail Inline (C)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Other'
    AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Retail Other (C)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Factory'
    AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Retail Factory (C)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'WHQ'
    AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Headquarters (N)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT ILIKE '%HQ%'
    AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Headquarters (C)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Other Facilities'
    AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Other Facilities (N)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Other Facilities'
    AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Other Facilities (C)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Air Mi' THEN 'Air MI - Facilities'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Distribution Center'
    AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Distribution Centers (N)'
    WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Distribution Center'
    AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Distribution Centers (C)'
    ELSE NULL
  END AS division_nm,
  CASE
    WHEN ELECTRIC_SITE.LOCATION_GEO_REGION_CD ILIKE '%America%' THEN 'NA'
    WHEN ELECTRIC_SITE.LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
    ELSE ELECTRIC_SITE.LOCATION_GEO_REGION_CD
  END AS LOCATION_GEO_REGION_CD,
  CASE
    WHEN ELECTRIC_SITE.continent_nm ILIKE 'EMEA' THEN 'Europe'
    WHEN ELECTRIC_SITE.continent_nm ILIKE 'APLA' THEN 'Asia'
    WHEN ELECTRIC_SITE.continent_nm ILIKE '%America%' THEN 'North America'
    WHEN ELECTRIC_SITE.continent_nm ILIKE 'Greater China' THEN 'Asia'
    ELSE ELECTRIC_SITE.continent_nm
  END AS continent_nm,
  ELECTRIC_SITE.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
  INITCAP(ELECTRIC_SITE.city_nm) AS city_nm,
  ELECTRIC_SITE.STATE_CD AS STATE_CD,
  ELECTRIC_SITE.POSTAL_CD AS POSTAL_CD,
  ELECTRIC_SITE.geographical_axis_nm AS geographical_axis_nm,
  CASE
    WHEN ELECTRIC_SITE.COUNTRY_CD ILIKE 'Canada' THEN 'CA'
    WHEN ELECTRIC_SITE.COUNTRY_CD ILIKE '%United States%' THEN 'US'
    ELSE UPPER(ELECTRIC_SITE.COUNTRY_CD)
  END AS COUNTRY_CD,
  CAST(ELECTRIC_SITE.LOCATION_AREA AS DECIMAL(31, 5)) AS LOCATION_AREA,
  LOCATION_AREA_UOM,
  ELECTRIC_SITE.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
  CAST(ELECTRIC_SITE.latitude_deg AS STRING) AS latitude_deg,
  CAST(ELECTRIC_SITE.longitude_deg AS STRING) AS longitude_deg,
  ELECTRIC_SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
  LOCATION_AREA_DATA_SOURCE_NM,
  LOCATION_AREA_DATA_SOURCE_CD,
  'emission_and_usage_metrics' AS cost_usage_data_source_nm,
  'ENGI' AS cost_usage_data_source_cd,
  REPORTING_PERIOD_DT
FROM
  SITE_INTEGRATION ELECTRIC_SITE
WHERE
  NOT (
    (
      ELECTRIC_SITE.electricity_location_nbr = '104238'
      AND ELECTRIC_SITE.electricity_location_nm ilike 'Jay Street Lot'
    )
  );
