WITH
  AIR_TABLE_METRICS AS (
    SELECT
      generation_or_consumption_country_nm,
      site_common_nm,
      site_official_nm,
      location_nbr,
      nike_business_function_cd,
      sourcing_method_desc,
      tech_type_desc,
      source_method_type
    FROM
      {curated_air_table} air_table
    WHERE
      air_table.nike_business_function_cd ilike 'Air MI'
  ),
  ELECTRICITY_USAGE_METRICS AS (
    SELECT
      METRICS.START_DT,
      METRICS.END_DT,
      METRICS.location_nbr,
      METRICS.location_nm,
      METRICS.lease_nbr,
      METRICS.brand_nm,
      METRICS.department_nm,
      METRICS.SERVICE_TYPE,
      METRICS.UoM,
      METRICS.site_production_in_kwh,
      METRICS.grid_meter_production_in_kwh,
      METRICS.energy_meter_production_in_kwh,
      METRICS.inverter_production_in_kwh,
      METRICS.grid_inject_production_in_kwh,
      METRICS.self_consumed_production_in_kwh,
      METRICS.self_consumed_pct,
      METRICS.building_id,
      METRICS.load_dt,
      METRICS.load_month_nbr,
      METRICS.load_year_nbr,
      METRICS.created_at_tmst,
      METRICS.user_nm,
      METRICS.batch_load_tmst,
      METRICS.job_nm,
      METRICS.job_run_id
    FROM
      {curated_table_name} METRICS
  ),
  DETAIL_INTEGRATION AS (
    SELECT
      curated.location_nbr AS electricity_location_nbr,
      -- 'curated.location_nbr' as electricity_location_nbr,      -- Correted the curated.location_nbr to building_tbl.building_code_main to get the actual site number
      -- building_tbl.BUILDING_CODE_MAIN AS electricity_location_nbr,
      curated.location_nm AS electricity_location_nm,
      TO_DATE(curated.START_DT, 'MM/dd/yyyy') AS reporting_period_dt,
      -- curated.SERVICE_TYPE as SERVICE_TYPE_CD, -- Updated service type logic to get the correct service type based on purchased and owned
      CASE
        WHEN curated.SERVICE_TYPE ilike '%Solar Generation'
        AND airtable.sourcing_method_desc ilike '%Purchased%'
        AND tech_type_desc ilike '%solar%' THEN 'Purchased Onsite Solar Generation'
        WHEN curated.SERVICE_TYPE ilike '%Solar Consumption'
        AND airtable.sourcing_method_desc ilike '%Purchased%'
        AND tech_type_desc ilike '%solar%' THEN 'Purchased Onsite Solar Consumption'
        WHEN curated.SERVICE_TYPE ilike '%Solar Generation'
        AND airtable.sourcing_method_desc ilike '%Owned%'
        AND tech_type_desc ilike '%solar%' THEN 'Owned Onsite Solar Generation'
        WHEN curated.SERVICE_TYPE ilike '%Solar Consumption'
        AND airtable.sourcing_method_desc ilike '%Owned%'
        AND tech_type_desc ilike '%solar%' THEN 'Owned Onsite Solar Consumption'
        ELSE NULL
      END AS SERVICE_TYPE_CD,
      TO_DATE(curated.START_DT, 'MM/dd/yyyy') AS BILLING_MONTH_START_DT,
      TO_DATE(curated.END_DT, 'MM/dd/yyyy') AS BILLING_MONTH_END_DT,
      CONCAT(
        DATE_FORMAT(curated.START_DT, 'MM/dd/yyyy'),
        '-',
        DATE_FORMAT(curated.END_DT, 'MM/dd/yyyy')
      ) AS BILLING_MONTH_DATE_RANGE_TXT,
      CAST(cd.FISCAL_YEAR_NBR AS INT) AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
      cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
      cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
      cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
      cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
      building_id AS building_id,
      -- 'building_tbl.tririga_building_id' AS building_id,
      NULL AS SAF_pct,
      NULL AS SAF_density,
      NULL AS Net_heat_of_combustion_UOM,
      12 AS DATA_FREQUENCY_CD,
      CASE
        WHEN curated.SERVICE_TYPE ilike '%Solar Generation' THEN curated.site_production_in_kwh
        WHEN curated.SERVICE_TYPE ilike '%Solar Consumption' THEN curated.self_consumed_production_in_kwh
        ELSE NULL
      END AS SERVICE_USAGE_QTY,
      uom AS SERVICE_USAGE_QTY_UOM,
      0 AS SERVICE_COST,
      'VND' AS SERVICE_COST_UOM,
      'FALSE' AS extrapolation_ind
    FROM
      ELECTRICITY_USAGE_METRICS curated
      -- LEFT JOIN BUILDING_COMBINE building_tbl ON curated.building_id = building_tbl.BUILDING_CODE_MAIN
      LEFT JOIN {calendar_table_name} AS cd ON CAST(curated.START_DT AS STRING) = CAST(cd.calendar_dt AS STRING)
      LEFT JOIN AIR_TABLE_METRICS airtable -- Added airtable join to get the sourcing method and tech type
      -- ON curated.building_id = airtable.location_nbr
      -- WHERE
      --   (
      --     building_tbl.COMBINE_PART IS NULL
      --     OR building_tbl.COMBINE_PART = 1
      --   )
  ),
  DETAILS_UUID AS (
    SELECT
      ELECTRIC_DETAIL_U.electricity_location_nbr,
      ELECTRIC_DETAIL_U.electricity_location_nm,
      ELECTRIC_DETAIL_U.reporting_period_dt,
      ELECTRIC_DETAIL_U.SERVICE_TYPE_CD,
      ELECTRIC_DETAIL_U.BILLING_MONTH_START_DT,
      ELECTRIC_DETAIL_U.BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL_U.BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRIC_DETAIL_U.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL_U.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL_U.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_QUARTER_NBR,
      ELECTRIC_DETAIL_U.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL_U.building_id,
      ELECTRIC_DETAIL_U.DATA_FREQUENCY_CD,
      ELECTRIC_DETAIL_U.SERVICE_USAGE_QTY,
      ELECTRIC_DETAIL_U.SERVICE_USAGE_QTY_UOM,
      ELECTRIC_DETAIL_U.SERVICE_COST,
      ELECTRIC_DETAIL_U.SERVICE_COST_UOM,
      ELECTRIC_DETAIL_U.extrapolation_ind
    FROM
      DETAIL_INTEGRATION ELECTRIC_DETAIL_U
  ),
  DETAILS_FINAL AS (
    SELECT
      ELECTRIC_DETAIL_A.electricity_location_nbr,
      ELECTRIC_DETAIL_A.electricity_location_nm,
      ELECTRIC_DETAIL_A.reporting_period_dt,
      ELECTRIC_DETAIL_A.SERVICE_TYPE_CD,
      ELECTRIC_DETAIL_A.BILLING_MONTH_START_DT,
      ELECTRIC_DETAIL_A.BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL_A.BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.building_id,
      ELECTRIC_DETAIL_A.DATA_FREQUENCY_CD,
      SUM(ELECTRIC_DETAIL_A.SERVICE_USAGE_QTY) AS SERVICE_USAGE_QTY,
      ELECTRIC_DETAIL_A.SERVICE_USAGE_QTY_UOM,
      ELECTRIC_DETAIL_A.SERVICE_COST AS SERVICE_COST,
      ELECTRIC_DETAIL_A.SERVICE_COST_UOM,
      ELECTRIC_DETAIL_A.extrapolation_ind
    FROM
      DETAILS_UUID ELECTRIC_DETAIL_A
    GROUP BY
      ELECTRIC_DETAIL_A.electricity_location_nbr,
      ELECTRIC_DETAIL_A.electricity_location_nm,
      ELECTRIC_DETAIL_A.reporting_period_dt,
      ELECTRIC_DETAIL_A.SERVICE_TYPE_CD,
      ELECTRIC_DETAIL_A.BILLING_MONTH_START_DT,
      ELECTRIC_DETAIL_A.BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL_A.BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.building_id,
      ELECTRIC_DETAIL_A.DATA_FREQUENCY_CD,
      ELECTRIC_DETAIL_A.SERVICE_USAGE_QTY_UOM,
      ELECTRIC_DETAIL_A.SERVICE_COST,
      ELECTRIC_DETAIL_A.SERVICE_COST_UOM,
      ELECTRIC_DETAIL_A.extrapolation_ind
  )
SELECT
  ELECTRIC_DETAIL.electricity_location_nbr AS electricity_location_nbr,
  ELECTRIC_DETAIL.electricity_location_nm AS electricity_location_nm,
  ELECTRIC_DETAIL.reporting_period_dt AS reporting_period_dt,
  ELECTRIC_DETAIL.SERVICE_TYPE_CD AS SERVICE_TYPE_CD,
  ELECTRIC_DETAIL.BILLING_MONTH_START_DT AS BILLING_MONTH_START_DT,
  ELECTRIC_DETAIL.BILLING_MONTH_END_DT AS BILLING_MONTH_END_DT,
  ELECTRIC_DETAIL.BILLING_MONTH_DATE_RANGE_TXT AS BILLING_MONTH_DATE_RANGE_TXT,
  ELECTRIC_DETAIL.REPORTING_FISCAL_YEAR_NBR,
  ELECTRIC_DETAIL.REPORTING_FISCAL_QUARTER_NBR,
  ELECTRIC_DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  CAST(
    ELECTRIC_DETAIL.REPORTING_CALENDAR_YEAR_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_CALENDAR_YEAR_NBR,
  ELECTRIC_DETAIL.REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
  CAST(
    ELECTRIC_DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_MONTH_OF_YEAR_NBR,
  CAST(
    ELECTRIC_DETAIL.REPORTING_QUARTER_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_QUARTER_NBR,
  CAST(
    ELECTRIC_DETAIL.REPORTING_WEEK_OF_YEAR_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_WEEK_OF_YEAR_NBR,
  ELECTRIC_DETAIL.building_id AS building_id,
  ELECTRIC_DETAIL.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
  CAST(
    ELECTRIC_DETAIL.SERVICE_USAGE_QTY AS DECIMAL(38, 2)
  ) AS SERVICE_USAGE_QTY,
  INITCAP(ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM) AS SERVICE_USAGE_QTY_UOM,
  CAST(ELECTRIC_DETAIL.SERVICE_COST AS DECIMAL(38, 2)) AS SERVICE_COST,
  ELECTRIC_DETAIL.SERVICE_COST_UOM AS SERVICE_COST_UOM,
  ELECTRIC_DETAIL.extrapolation_ind AS extrapolation_ind,
  'SCOPE 2' AS scope_nbr,
  'enos' AS cost_usage_data_source_nm,
  'ENVISION' AS cost_usage_data_source_cd
FROM
  DETAILS_FINAL ELECTRIC_DETAIL
