WITH
  TAXONOMY_TABLE AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_mapping_tbl}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  AIR_TABLE_METRICS AS (
    SELECT
      generation_or_consumption_country_nm,
      site_common_nm,
      site_official_nm,
      location_nbr,
      nike_business_function_cd,
      sourcing_method_desc,
      tech_type_desc,
      source_method_type
    FROM
      {curated_air_table} air_table
    WHERE
      air_table.nike_business_function_cd ilike 'Air MI'
  ),
  ELECTRICITY_USAGE_METRICS AS (
    SELECT
      METRICS.START_DT,
      METRICS.START_DT AS reporting_period_dt,
      METRICS.END_DT,
      METRICS.location_nbr,
      METRICS.location_nm,
      METRICS.lease_nbr,
      METRICS.brand_nm,
      METRICS.department_nm,
      METRICS.SERVICE_TYPE,
      METRICS.UoM,
      METRICS.site_production_in_kwh,
      METRICS.grid_meter_production_in_kwh,
      METRICS.energy_meter_production_in_kwh,
      METRICS.inverter_production_in_kwh,
      METRICS.grid_inject_production_in_kwh,
      METRICS.self_consumed_production_in_kwh,
      METRICS.self_consumed_pct,
      METRICS.building_id,
      METRICS.load_dt,
      METRICS.load_month_nbr,
      METRICS.load_year_nbr,
      METRICS.created_at_tmst,
      METRICS.user_nm,
      METRICS.batch_load_tmst,
      METRICS.job_nm,
      METRICS.job_run_id
    FROM
      {curated_table_name} METRICS
  ),
  SITE_INTEGRATION AS (
    SELECT DISTINCT
      -- building_tbl.BUILDING_CODE_MAIN AS electricity_location_nbr, -- Corrected the curated.location_nbr to building_tbl.building_code_main to get the actual site number
      curated.location_nbr AS electricity_location_nbr,
      curated.location_nm AS electricity_location_nm,
      reporting_period_dt,
      COALESCE(enablon.entity_lease_nbr, curated.lease_nbr) AS lease_nbr,
      curated.building_id,
      CASE
        WHEN enablon.entity_division_nm LIKE '%Retail%' THEN 'Retail'
        ELSE 'Non Retail'
      END AS business_group_txt,
      COALESCE(curated.brand_nm, enablon.entity_brand_nm) AS brand_nm,
      curated.department_nm AS nike_department_type_txt,
      taxonomy.REGION AS LOCATION_GEO_REGION_CD,
      enablon.entity_continent_nm AS BUSINESS_ENTITY_GEO_REGION_CD,
      CAST(NULL AS STRING) AS ELECTRICITY_LOCATION_USE_CD,
      -- CASE
      --   WHEN DEPARTMENT_NM ilike '%air mi%'
      --   AND Brand_nm = 'Nike' THEN 'Air MI (Nike)'
      --   ELSE NULL
      -- END AS business_function_nm,
      -- COALESCE(entity_division_nm,(CASE WHEN DEPARTMENT_NM ilike '%air mi%'  AND Brand_nm = 'Nike' THEN 'Air MI (Nike)' end)) as business_function_nm,
      COALESCE(
        entity_business_function_nm,
        CASE
          WHEN DEPARTMENT_NM ilike '%air mi%'
          AND Brand_nm = 'Nike' THEN 'Air MI (Nike)'
        END
      ) AS business_function_nm,
      COALESCE(
        entity_division_nm,
        CONCAT(department_nm, ' - Facilities')
      ) AS division_nm,
      enablon.entity_continent_nm AS CONTINENT_NM,
      enablon.entity_address_txt AS ADDRESS_LINE_1_TXT,
      enablon.entity_city_nm AS city_nm,
      CAST(NULL AS STRING) AS STATE_CD,
      entity_zip_cd AS POSTAL_CD,
      COALESCE(
        entity_geographical_reference_txt,
        CASE
          WHEN entity_country_nm = 'Viet Nam' THEN 'Vietnam'
          ELSE entity_country_nm
        END
      ) AS geographical_axis_nm,
      CTRY_CD AS COUNTRY_CD,
      entity_area_in_sqft AS LOCATION_AREA,
      CASE
        WHEN entity_area_in_sqft IS NOT NULL THEN 'Square foot'
      END AS LOCATION_AREA_UOM,
      enablon.entity_status_nm AS LOCATION_STATUS_CD,
      CAST(
        enablon.entity_geographical_latitude_deg AS STRING
      ) AS latitude_deg,
      CAST(
        enablon.entity_geographical_longitude_deg AS STRING
      ) AS longitude_deg,
      CAST(NULL AS STRING) AS ADDITIONAL_LOCATION_FEATURE_DESC,
      entity_reference_nm AS enablon_location_nm
    FROM
      ELECTRICITY_USAGE_METRICS curated
      -- LEFT JOIN BUILDING_COMBINE building_tbl ON curated.building_id = building_tbl.BUILDING_CODE_MAIN
      -- AND curated.START_DT = building_tbl.reporting_period_dt
      LEFT JOIN {enablon} enablon ON curated.location_nm = enablon.entity_reference_nm
      AND curated.reporting_period_dt = enablon.source_reporting_dt
      LEFT JOIN TAXONOMY_TABLE taxonomy ON (
        CASE
          WHEN enablon.entity_country_nm = 'Viet Nam' THEN 'Vietnam'
          ELSE enablon.entity_country_nm
        END
      ) = taxonomy.CTRY_NM
      LEFT JOIN AIR_TABLE_METRICS airtable ON curated.building_id = airtable.location_nbr
      -- WHERE
      -- (
      --   building_tbl.COMBINE_PART IS NULL
      --   OR building_tbl.COMBINE_PART = 1
      -- )
      -- where enablon.entity_reference_nm is not null
  )
SELECT DISTINCT
  ELECTRICITY_SITE.electricity_location_nbr AS electricity_location_nbr,
  ELECTRICITY_SITE.electricity_location_nm AS electricity_location_nm,
  COALESCE(ELECTRICITY_SITE.lease_nbr, ELE_SITE.lease_nbr) AS lease_nbr,
  ELECTRICITY_SITE.reporting_period_dt,
  ELECTRICITY_SITE.building_id AS building_id,
  ELECTRICITY_SITE.business_group_txt,
  ELECTRICITY_SITE.brand_nm AS brand_nm,
  ELECTRICITY_SITE.nike_department_type_txt,
  CASE
    WHEN COALESCE(
      ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD,
      ELE_SITE.BUSINESS_ENTITY_GEO_REGION_CD
    ) ilike '%asia%' THEN 'APLA'
    ELSE COALESCE(
      ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD,
      ELE_SITE.BUSINESS_ENTITY_GEO_REGION_CD
    )
  END AS BUSINESS_ENTITY_GEO_REGION_CD,
  ELECTRICITY_SITE.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
  ELECTRICITY_SITE.business_function_nm AS business_function_nm,
  ELECTRICITY_SITE.division_nm AS division_nm,
  COALESCE(
    ELECTRICITY_SITE.LOCATION_GEO_REGION_CD,
    ELE_SITE.LOCATION_GEO_REGION_CD
  ) AS LOCATION_GEO_REGION_CD,
  COALESCE(
    ELECTRICITY_SITE.continent_nm,
    ELE_SITE.continent_nm
  ) AS continent_nm,
  COALESCE(
    ELECTRICITY_SITE.ADDRESS_LINE_1_TXT,
    ELE_SITE.ADDRESS_LINE_1_TXT
  ) AS ADDRESS_LINE_1_TXT,
  ELECTRICITY_SITE.city_nm AS city_nm,
  ELECTRICITY_SITE.STATE_CD AS STATE_CD,
  ELECTRICITY_SITE.POSTAL_CD AS POSTAL_CD,
  COALESCE(
    ELECTRICITY_SITE.geographical_axis_nm,
    ELE_SITE.geographical_axis_nm
  ) AS geographical_axis_nm,
  COALESCE(ELECTRICITY_SITE.COUNTRY_CD, ELE_SITE.COUNTRY_CD) AS COUNTRY_CD,
  CAST(
    COALESCE(
      ELECTRICITY_SITE.LOCATION_AREA,
      ELE_SITE.LOCATION_AREA
    ) AS DECIMAL(31, 5)
  ) AS LOCATION_AREA,
  COALESCE(
    ELECTRICITY_SITE.LOCATION_AREA_UOM,
    ELE_SITE.LOCATION_AREA_UOM
  ) AS LOCATION_AREA_UOM,
  COALESCE(
    ELECTRICITY_SITE.LOCATION_STATUS_CD,
    ELE_SITE.LOCATION_STATUS_CD
  ) AS LOCATION_STATUS_CD,
  COALESCE(
    ELECTRICITY_SITE.latitude_deg,
    ELE_SITE.latitude_deg
  ) AS latitude_deg,
  COALESCE(
    ELECTRICITY_SITE.longitude_deg,
    ELE_SITE.longitude_deg
  ) AS longitude_deg,
  ELECTRICITY_SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
  'sustainability_impact_areas' AS LOCATION_AREA_DATA_SOURCE_NM,
  'ENABLON' AS LOCATION_AREA_DATA_SOURCE_CD,
  'enos' AS cost_usage_data_source_nm,
  'ENVISION' AS cost_usage_data_source_cd
FROM
  SITE_INTEGRATION ELECTRICITY_SITE
  LEFT JOIN (
    SELECT
      *
    FROM
      SITE_INTEGRATION
    WHERE
      enablon_location_nm IS NOT NULL qualify ROW_NUMBER() OVER (
        PARTITION BY
          electricity_location_nbr,
          electricity_location_nm
        ORDER BY
          reporting_period_dt DESC
      ) = 1
  ) ELE_SITE ON ELECTRICITY_SITE.electricity_location_nbr = ELE_SITE.electricity_location_nbr
  AND ELECTRICITY_SITE.electricity_location_nm = ELE_SITE.electricity_location_nm
  AND
  -- ELE_SITE.reporting_period_dt > add_months(ELECTRICITY_SITE.reporting_period_dt,-1)
  ELECTRICITY_SITE.reporting_period_dt > ADD_MONTHS(CURRENT_DATE(), -3)
