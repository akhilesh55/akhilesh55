WITH
  impact_table_5 AS (
    SELECT
      *
    FROM
      (
        SELECT
          *,
          ROW_NUMBER() OVER (
            PARTITION BY
              entity_reference_cd,
              entity_reference_nm,
              source_reporting_dt
            ORDER BY
              source_reporting_dt DESC
          ) AS row_num
        FROM
          {enablon_5_impact_areas}
        WHERE
          entity_impact_area_nm = 'CARBON'
          AND entity_scope_nm IN ('SCOPE 2', 'SCOPE 1', 'SCOPE 1&2')
      )
    WHERE
      row_num = 1
  ),
  TAXONOMY_TABLE AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_mapping_tbl}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  CURATED_VIEW AS (
    SELECT
      METRICS.PROPERTY_NM,
      METRICS.location_nm_latest,
      METRICS.location_nbr,
      METRICS.location_nbr_latest,
      METRICS.lease_nbr_latest,
      METRICS.account_id,
      METRICS.cdd_nbr,
      METRICS.total_kwh,
      METRICS.delivery_kw_charges_cost,
      METRICS.universal_usage_uom,
      METRICS.days_in_billing_period_days,
      METRICS.currency_cd,
      METRICS.START_DT,
      METRICS.total_cost,
      METRICS.mos_nbr,
      METRICS.supply_kw_charges_cost,
      METRICS.supply_cost,
      METRICS.delivery_cost_per_kwh,
      METRICS.billing_kvar_cost,
      METRICS.account_cd,
      METRICS.client_node_id,
      METRICS.delivery_kwh_charges_cost,
      METRICS.universal_unit_uom,
      METRICS.supply_cost_per_kwh,
      METRICS.mid_peak_kwh,
      METRICS.on_peak_kwh,
      METRICS.service_zip_cd,
      METRICS.invoice_id,
      METRICS.property_state_nm,
      METRICS.universal_usage_kbtu,
      METRICS.property_address_nm,
      METRICS.off_peak_kwh,
      METRICS.supply_kwh_cost_per_kwh,
      METRICS.kva_uom,
      METRICS.demand_kw,
      METRICS.percent_renewable_pct,
      METRICS.property_city_nm,
      METRICS.delivery_misc_charges_cost,
      METRICS.service_address_nm,
      METRICS.account_active_ind,
      METRICS.calendarized_usage_qty,
      METRICS.vendor_id,
      METRICS.hdd_nbr,
      METRICS.delivery_taxes_cost,
      METRICS.supply_kwh_charges_cost,
      METRICS.kva_cost,
      METRICS.service_city_nm,
      METRICS.vendor_cd,
      METRICS.supply_taxes_cost,
      METRICS.delivery_taxes_per_kwh,
      METRICS.property_cd,
      METRICS.property_zip_cd,
      METRICS.delivery_invoice_nbr,
      METRICS.service_state_nm,
      METRICS.delivery_kw_cost_per_kw,
      METRICS.total_usage_uom,
      METRICS.energy_unit,
      METRICS.delivery_cost,
      METRICS.total_cost_per_kwh,
      METRICS.delivery_customer_charges_cost,
      METRICS.vendor_name,
      METRICS.property_country_nm,
      METRICS.account_type_desc,
      METRICS.end_date,
      METRICS.yrs_nbr,
      METRICS.supply_taxes_per_kwh,
      METRICS.delivery_kwh_cost_per_kwh,
      METRICS.kvar_cost,
      METRICS.square_footage_sqft,
      METRICS.is_property_ind,
      METRICS.load_dt,
      METRICS.load_month_nbr,
      METRICS.load_year_nbr,
      METRICS.created_at_tmst,
      METRICS.user_nm,
      METRICS.batch_load_tmst,
      METRICS.job_nm,
      METRICS.job_run_id
    FROM
      {curated_table_name} METRICS
    WHERE
      METRICS.partition_row = 1
  ),
  AGG_REC AS (
    SELECT DISTINCT
      COALESCE(
        curated_obj.location_nm_latest,
        curated_obj.property_nm
      ) AS electricity_location_nm,
      COALESCE(
        curated_obj.location_nbr_latest,
        curated_obj.location_nbr
      ) AS electricity_location_nbr,
      COALESCE(
        enablon_obj.entity_lease_nbr,
        curated_obj.lease_nbr_latest
      ) AS lease_nbr,
      TO_DATE(
        CONCAT(
          curated_obj.yrs_nbr,
          '-',
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      NULL AS building_id,
      CASE
        WHEN enablon_obj.entity_division_nm LIKE '%Retail%' THEN 'Retail'
        WHEN COALESCE(
          curated_obj.location_nm_latest,
          curated_obj.property_nm
        ) LIKE '%Nike%'
        OR COALESCE(
          curated_obj.location_nm_latest,
          curated_obj.property_nm
        ) LIKE '%CFS%' THEN 'Retail'
        ELSE 'Non Retail'
      END AS business_group_txt,
      CASE
        WHEN COALESCE(
          curated_obj.location_nm_latest,
          curated_obj.property_nm
        ) LIKE '%CFS%'
        OR COALESCE(
          curated_obj.location_nm_latest,
          curated_obj.property_nm
        ) ILIKE '%converse%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN enablon_obj.entity_division_nm IN ('Headquarters (N)', 'Headquarters (C)') THEN 'Main HQ'
        WHEN TRIM(
          REGEXP_REPLACE(enablon_obj.entity_division_nm, r'\s*\(.*\)', '')
        ) IS NOT NULL THEN TRIM(
          REGEXP_REPLACE(enablon_obj.entity_division_nm, r'\s*\(.*\)', '')
        )
        WHEN curated_obj.property_nm LIKE 'CFS%' THEN 'Retail Factory'
        WHEN curated_obj.property_nm LIKE 'EHQ%' THEN 'Retail Factory'
        ELSE 'Local Office'
      END AS nike_department_type_txt,
      'EMEA' AS BUSINESS_ENTITY_GEO_REGION_CD,
      NULL AS ELECTRICITY_LOCATION_USE_CD,
      COALESCE(
        enablon_obj.entity_business_function_nm,
        CASE
          WHEN COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ) LIKE '%Nike%'
          OR COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ) LIKE '%NIKE%' THEN 'DTC (N)'
          WHEN COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ) LIKE 'CFS%' THEN 'DTC (C)'
          WHEN COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ) LIKE 'Converse%'
          OR COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ) LIKE '%CONVERSE%' THEN 'WD+C (C)'
          ELSE 'WD+C (N)'
        END
      ) AS business_function_nm,
      COALESCE(
        enablon_obj.entity_division_nm,
        CASE
          WHEN COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ) LIKE '%CFS%'
          OR COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ) LIKE '%Converse%' THEN CASE
            WHEN COALESCE(
              curated_obj.location_nm_latest,
              curated_obj.property_nm
            ) LIKE 'CFS%' THEN 'Retail Factory (C)'
            WHEN COALESCE(
              curated_obj.location_nm_latest,
              curated_obj.property_nm
            ) LIKE '%Converse%' THEN 'Other Facilities (C)'
          END
          ELSE CASE
            WHEN COALESCE(
              curated_obj.location_nm_latest,
              curated_obj.property_nm
            ) LIKE 'EHQ%' THEN 'Headquarters (N)'
            WHEN COALESCE(
              curated_obj.location_nm_latest,
              curated_obj.property_nm
            ) NOT LIKE '%nike%'
            AND COALESCE(
              curated_obj.location_nm_latest,
              curated_obj.property_nm
            ) NOT LIKE '%CFS%'
            AND COALESCE(
              curated_obj.location_nm_latest,
              curated_obj.property_nm
            ) NOT LIKE '%Converse%' THEN 'Other Facilities (N)'
            ELSE 'Other Facilities (N)'
          END
        END
      ) AS division_nm,
      'EMEA' AS LOCATION_GEO_REGION_CD,
      COALESCE(enablon_obj.entity_continent_nm, 'Europe') AS continent_nm,
      COALESCE(
        enablon_obj.entity_address_txt,
        curated_obj.property_address_nm
      ) AS ADDRESS_LINE_1_TXT,
      enablon_obj.entity_city_nm AS enablon_city_nm,
      curated_obj.property_city_nm AS wwire_city_nm,
      -- COALESCE(
      --   enablon_obj.entity_city_nm,
      --   curated_obj.property_city_nm
      -- ) AS city_nm,
      NULL AS state_cd,
      COALESCE(
        enablon_obj.entity_zip_cd,
        curated_obj.property_zip_cd
      ) AS postal_cd,
      COALESCE(
        enablon_obj.entity_geographical_reference_txt,
        COALESCE(
          enablon_obj.entity_country_nm,
          taxonomy_obj.CTRY_NM,
          curated_obj.property_country_nm
        )
      ) AS geographical_axis_nm,
      COALESCE(
        taxonomy_obj.CTRY_CD,
        curated_obj.property_country_nm
      ) AS country_cd,
      CAST(
        COALESCE(
          enablon_obj.entity_area_in_sqft,
          curated_obj.square_footage_sqft
        ) AS DECIMAL(31, 5)
      ) AS LOCATION_AREA,
      CASE
        WHEN enablon_obj.entity_area_in_sqft IS NOT NULL THEN 'Square foot'
        WHEN curated_obj.square_footage_sqft IS NOT NULL THEN 'Square foot'
        ELSE NULL
      END AS LOCATION_AREA_UOM,
      COALESCE(
        enablon_obj.entity_status_nm,
        CASE
          WHEN curated_obj.is_property_ind = 'true' THEN 'Open'
          ELSE 'Close'
        END
      ) AS LOCATION_STATUS_CD,
      CAST(
        enablon_obj.ENTITY_GEOGRAPHICAL_LATITUDE_DEG AS STRING
      ) AS latitude_deg,
      CAST(
        enablon_obj.ENTITY_GEOGRAPHICAL_LONGITUDE_DEG AS STRING
      ) AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      CASE
        WHEN enablon_obj.entity_area_in_sqft IS NOT NULL THEN 'sustainability_impact_areas'
        WHEN curated_obj.square_footage_sqft IS NOT NULL THEN 'electricity_usage_metrics'
        ELSE NULL
      END AS location_area_data_source_nm,
      CASE
        WHEN enablon_obj.entity_area_in_sqft IS NOT NULL THEN 'ENABLON'
        WHEN curated_obj.square_footage_sqft IS NOT NULL THEN 'ACCWW'
        ELSE NULL
      END AS location_area_data_source_cd,
      ROW_NUMBER() OVER (
        PARTITION BY
          COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ),
          COALESCE(
            curated_obj.location_nbr_latest,
            curated_obj.location_nbr
          ),
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          )
        ORDER BY
          COALESCE(
            curated_obj.location_nm_latest,
            curated_obj.property_nm
          ),
          COALESCE(
            curated_obj.location_nbr_latest,
            curated_obj.location_nbr
          ),
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          )
      ) AS row_num
    FROM
      CURATED_VIEW curated_obj
      LEFT JOIN impact_table_5 enablon_obj ON enablon_obj.source_reporting_dt = TO_DATE(
        CONCAT(
          curated_obj.yrs_nbr,
          '-',
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      )
      AND (
        enablon_obj.entity_reference_nm = COALESCE(
          curated_obj.location_nm_latest,
          curated_obj.property_nm
        )
        OR enablon_obj.entity_reference_cd = COALESCE(
          curated_obj.location_nbr_latest,
          curated_obj.location_nbr
        )
      )
      LEFT JOIN TAXONOMY_TABLE taxonomy_obj ON COALESCE(
        enablon_obj.entity_country_nm,
        curated_obj.property_country_nm
      ) = taxonomy_obj.ctry_cd
  ),
  DERIVED_AGG AS (
    SELECT
      WWIRE.electricity_location_nm,
      WWIRE.electricity_location_nbr,
      lease_nbr,
      reporting_period_dt,
      building_id,
      business_group_txt,
      brand_nm,
      nike_department_type_txt,
      BUSINESS_ENTITY_GEO_REGION_CD,
      ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN nike_department_type_txt IN ('Retail Inline', 'Retail Factory')
        AND brand_nm = 'Nike' THEN 'DTC (N)'
        WHEN nike_department_type_txt IN ('Retail Inline', 'Retail Factory')
        AND brand_nm = 'Converse' THEN 'DTC (C)'
        WHEN nike_department_type_txt = 'Main HQ'
        AND brand_nm = 'Nike' THEN 'WD+C (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = 'Nike' THEN 'WD+C (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = 'Converse' THEN 'WD+C (C)'
        ELSE 'DTC (N)'
      END AS business_function_nm,
      CASE
        WHEN nike_department_type_txt = 'Retail Inline'
        AND brand_nm = 'Nike' THEN 'Retail Inline (N)'
        WHEN nike_department_type_txt = 'Retail Factory'
        AND brand_nm = 'Nike' THEN 'Retail Factory (N)'
        WHEN nike_department_type_txt = 'Retail Inline'
        AND brand_nm = 'Converse' THEN 'Retail Inline (C)'
        WHEN nike_department_type_txt = 'Retail Factory'
        AND brand_nm = 'Converse' THEN 'Retail Factory (C)'
        WHEN nike_department_type_txt = 'Main HQ'
        AND brand_nm = 'Nike' THEN 'Headquarters (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = 'Converse' THEN 'Other Facilities (C)'
        ELSE 'Other Facilities (N)'
      END AS division_nm,
      LOCATION_GEO_REGION_CD,
      continent_nm,
      ADDRESS_LINE_1_TXT,
      REGEXP_REPLACE(
        COALESCE(enablon_city_nm, ELE.city_nm, wwire_city_nm),
        ',$',
        ''
      ) AS city_nm,
      state_cd,
      postal_cd,
      geographical_axis_nm,
      country_cd,
      LOCATION_AREA,
      LOCATION_AREA_UOM,
      LOCATION_STATUS_CD,
      latitude_deg,
      longitude_deg,
      ADDITIONAL_LOCATION_FEATURE_DESC,
      location_area_data_source_nm,
      location_area_data_source_cd,
      'electricity_usage_metrics' AS cost_usage_data_source_nm,
      'ACCWW' AS cost_usage_data_source_cd,
      row_num
    FROM
      AGG_REC WWIRE
      LEFT JOIN (
        SELECT DISTINCT
          ELE.electricity_location_nbr,
          ELE.electricity_location_nm,
          ELE.city_nm
        FROM
          {ele_integrated} ELE
        WHERE
          ELE.cost_usage_data_source_nm = 'electricity_usage_and_cost_metrics'
      ) ELE ON WWIRE.electricity_location_nbr = ELE.electricity_location_nbr
      AND WWIRE.electricity_location_nm = ELE.electricity_location_nm
  )
SELECT
  *
FROM
  DERIVED_AGG
WHERE
  reporting_period_dt < '2024-01-01'
  AND row_num = 1
