WITH
  SITE_TABLE AS (
    SELECT
      SITE_T.ELECTRICITY_CONSUMPTION_UUID,
      SITE_T.ELECTRICITY_LOCATION_NBR,
      SITE_T.ELECTRICITY_LOCATION_NM,
      SITE_T.REPORTING_PERIOD_DT,
      SITE_T.LEASE_NBR,
      SITE_T.BUILDING_ID,
      SITE_T.BUSINESS_GROUP_TXT,
      SITE_T.BRAND_NM,
      SITE_T.NIKE_DEPARTMENT_TYPE_TXT,
      SITE_T.BUSINESS_ENTITY_GEO_REGION_CD,
      SITE_T.ELECTRICITY_LOCATION_USE_CD,
      SITE_T.BUSINESS_FUNCTION_NM,
      SITE_T.DIVISION_NM,
      SITE_T.LOCATION_GEO_REGION_CD,
      SITE_T.CONTINENT_NM,
      SITE_T.ADDRESS_LINE_1_TXT,
      SITE_T.CITY_NM,
      SITE_T.STATE_CD,
      SITE_T.POSTAL_CD,
      SITE_T.GEOGRAPHICAL_AXIS_NM,
      SITE_T.COUNTRY_CD,
      SITE_T.LOCATION_AREA,
      SITE_T.LOCATION_AREA_UOM,
      SITE_T.LOCATION_STATUS_CD,
      SITE_T.LATITUDE_DEG,
      SITE_T.LONGITUDE_DEG,
      SITE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
      SITE_T.cost_usage_data_source_nm,
      SITE_T.cost_usage_data_source_cd,
      SITE_T.LEASE_CUSTOM_KEY,
      SITE_T.location_area_data_source_nm,
      SITE_T.location_area_data_source_cd
    FROM
      {site_table_name} SITE_T
    WHERE
      batch_load_tmst IN (
        SELECT
          MAX(batch_load_tmst)
        FROM
          {site_table_name}
        WHERE
          cost_usage_data_source_nm = 'see_usage_metrics'
      )
  ),
  DETAIL_TABLE AS (
    SELECT
      DETAIL_T.ELECTRICITY_CONSUMPTION_UUID,
      DETAIL_T.ELECTRICITY_LOCATION_NBR,
      DETAIL_T.ELECTRICITY_LOCATION_NM,
      DETAIL_T.REPORTING_PERIOD_DT,
      DETAIL_T.SERVICE_TYPE_CD,
      DETAIL_T.BILLING_MONTH_START_DT,
      DETAIL_T.BILLING_MONTH_END_DT,
      DETAIL_T.BILLING_MONTH_DATE_RANGE_TXT,
      DETAIL_T.REPORTING_FISCAL_YEAR_NBR,
      DETAIL_T.REPORTING_FISCAL_QUARTER_NBR,
      DETAIL_T.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      DETAIL_T.REPORTING_CALENDAR_YEAR_NBR,
      DETAIL_T.REPORTING_MONTH_LONG_NM,
      DETAIL_T.REPORTING_MONTH_OF_YEAR_NBR,
      DETAIL_T.REPORTING_QUARTER_NBR,
      DETAIL_T.REPORTING_WEEK_OF_YEAR_NBR,
      DETAIL_T.BUILDING_ID,
      DETAIL_T.DATA_FREQUENCY_CD,
      DETAIL_T.SERVICE_USAGE_QTY,
      DETAIL_T.SERVICE_USAGE_QTY_UOM,
      DETAIL_T.SERVICE_COST,
      DETAIL_T.SERVICE_COST_UOM,
      DETAIL_T.EXTRAPOLATION_IND,
      DETAIL_T.SCOPE_NBR,
      DETAIL_T.cost_usage_data_source_nm,
      DETAIL_T.cost_usage_data_source_cd,
      DETAIL_T.LEASE_CUSTOM_KEY
    FROM
      {detail_table_name} DETAIL_T
    WHERE
      batch_load_tmst IN (
        SELECT
          MAX(batch_load_tmst)
        FROM
          {detail_table_name}
        WHERE
          cost_usage_data_source_nm = 'see_usage_metrics'
      )
  )
SELECT
  DETAIL.electricity_consumption_uuid AS electricity_consumption_uuid,
  DETAIL.electricity_location_nbr AS electricity_location_nbr,
  DETAIL.electricity_location_nm AS electricity_location_nm,
  DETAIL.reporting_period_dt AS reporting_period_dt,
  DETAIL.SERVICE_TYPE_CD AS SERVICE_TYPE_CD,
  DETAIL.BILLING_MONTH_START_DT AS BILLING_MONTH_START_DT,
  DETAIL.BILLING_MONTH_END_DT AS BILLING_MONTH_END_DT,
  DETAIL.BILLING_MONTH_DATE_RANGE_TXT AS BILLING_MONTH_DATE_RANGE_TXT,
  SITE.lease_nbr AS lease_nbr,
  SITE.building_id AS building_id,
  SITE.business_group_txt AS business_group_txt,
  SITE.brand_nm AS brand_nm,
  SITE.nike_department_type_txt AS nike_department_type_txt,
  SITE.BUSINESS_ENTITY_GEO_REGION_CD AS BUSINESS_ENTITY_GEO_REGION_CD,
  SITE.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
  SITE.business_function_nm AS business_function_nm,
  SITE.division_nm AS division_nm,
  SITE.LOCATION_GEO_REGION_CD AS LOCATION_GEO_REGION_CD,
  SITE.continent_nm AS continent_nm,
  SITE.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
  SITE.city_nm AS city_nm,
  SITE.STATE_CD AS STATE_CD,
  SITE.POSTAL_CD AS POSTAL_CD,
  SITE.geographical_axis_nm AS geographical_axis_nm,
  SITE.COUNTRY_CD AS COUNTRY_CD,
  SITE.LOCATION_AREA AS LOCATION_AREA,
  SITE.LOCATION_AREA_UOM AS LOCATION_AREA_UOM,
  SITE.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
  SITE.location_area_data_source_nm AS location_area_data_source_nm,
  SITE.location_area_data_source_cd AS location_area_data_source_cd,
  SITE.latitude_deg AS latitude_deg,
  SITE.longitude_deg AS longitude_deg,
  SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
  DETAIL.REPORTING_FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
  DETAIL.REPORTING_FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
  DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  DETAIL.REPORTING_CALENDAR_YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
  DETAIL.REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
  DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
  DETAIL.REPORTING_QUARTER_NBR AS REPORTING_QUARTER_NBR,
  DETAIL.REPORTING_WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
  DETAIL.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
  DETAIL.SERVICE_USAGE_QTY AS SERVICE_USAGE_QTY,
  DETAIL.SERVICE_USAGE_QTY_UOM AS SERVICE_USAGE_QTY_UOM,
  DETAIL.SERVICE_COST AS SERVICE_COST,
  DETAIL.SERVICE_COST_UOM AS SERVICE_COST_UOM,
  DETAIL.extrapolation_ind AS extrapolation_ind,
  DETAIL.scope_nbr AS scope_nbr,
  -- 'see_usage_metrics' AS data_source_nm,
  DETAIL.cost_usage_data_source_nm AS cost_usage_data_source_nm,
  DETAIL.cost_usage_data_source_cd AS cost_usage_data_source_cd
FROM
  SITE_TABLE SITE
  LEFT JOIN DETAIL_TABLE DETAIL ON CONCAT_WS(
    '_',
    DETAIL.electricity_consumption_uuid,
    DETAIL.electricity_location_nbr,
    DETAIL.electricity_location_nm,
    DETAIL.reporting_period_dt,
    DETAIL.lease_custom_key
  ) = CONCAT_WS(
    '_',
    SITE.electricity_consumption_uuid,
    SITE.electricity_location_nbr,
    SITE.electricity_location_nm,
    SITE.reporting_period_dt,
    SITE.lease_custom_key
  )
WHERE
  DETAIL.cost_usage_data_source_nm = 'see_usage_metrics'
