WITH
  CURATED_VIEW AS (
    SELECT
      METRICS.site_address_company_nm,
      METRICS.site_nm,
      METRICS.client_site_ref_id,
      METRICS.league_nm,
      METRICS.subleague_nm,
      METRICS.concept_nm,
      METRICS.street_txt,
      YEAR(TO_DATE(start_dt, 'dd/MM/yyyy')) AS yrs_nbr,
      MONTH(TO_DATE(start_dt, 'dd/MM/yyyy')) AS mos_nbr,
      DAY(TO_DATE(start_dt, 'dd/MM/yyyy')) AS dayy,
      METRICS.city_nm,
      METRICS.zip_cd,
      METRICS.subleague_nm,
      METRICS.location_latitude_deg,
      METRICS.location_longitude_deg,
      METRICS.store_nm,
      METRICS.country_nm,
      METRICS.site_size_in_sqft,
      METRICS.start_dt,
      METRICS.end_dt,
      METRICS.site_status_Ind_cd,
      METRICS.utility_type_nm,
      METRICS.energy_unit_in_kwh,
      METRICS.invoiced_cost,
      METRICS.invoiced_usage_qty,
      METRICS.currency_cd
    FROM
      {curated_table_name} METRICS MINUS
    SELECT
      METRICS.site_address_company_nm,
      METRICS.site_nm,
      METRICS.client_site_ref_id,
      METRICS.league_nm,
      METRICS.subleague_nm,
      METRICS.concept_nm,
      METRICS.street_txt,
      YEAR(TO_DATE(start_dt, 'dd/MM/yyyy')) AS yrs_nbr,
      MONTH(TO_DATE(start_dt, 'dd/MM/yyyy')) AS mos_nbr,
      DAY(TO_DATE(start_dt, 'dd/MM/yyyy')) AS dayy,
      METRICS.city_nm,
      METRICS.zip_cd,
      METRICS.subleague_nm,
      METRICS.location_latitude_deg,
      METRICS.location_longitude_deg,
      METRICS.store_nm,
      METRICS.country_nm,
      METRICS.site_size_in_sqft,
      METRICS.start_dt,
      METRICS.end_dt,
      METRICS.site_status_Ind_cd,
      METRICS.utility_type_nm,
      METRICS.energy_unit_in_kwh,
      METRICS.invoiced_cost,
      METRICS.invoiced_usage_qty,
      METRICS.currency_cd
    FROM
      {curated_table_name_rejects} METRICS
  ),
  AGG_REC AS (
    SELECT DISTINCT
      curated_obj.site_nm AS electricity_location_nm,
      curated_obj.client_site_ref_id AS electricity_location_nbr,
      TO_DATE(
        CONCAT(
          curated_obj.yrs_nbr,
          '-',
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electricity' AS SERVICE_TYPE_CD,
      TO_DATE(
        COALESCE(
          curated_obj.start_dt,
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          )
        ),
        'dd/MM/yyyy'
      ) AS BILLING_MONTH_START_DT,
      TO_DATE(
        COALESCE(
          curated_obj.end_dt,
          DATE_FORMAT(
            LAST_DAY(
              ADD_MONTHS(
                TO_DATE(
                  CONCAT(
                    curated_obj.yrs_nbr,
                    '-',
                    LPAD(curated_obj.mos_nbr, 2, '0')
                  ),
                  'yyyy-MM'
                ),
                1
              )
            ),
            'dd/MM/yyyy'
          )
        ),
        'dd/MM/yyyy'
      ) AS BILLING_MONTH_END_DT,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_obj.yrs_nbr,
                  '-',
                  LPAD(curated_obj.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT,
      calendar_obj.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      calendar_obj.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      calendar_obj.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      CAST(
        COALESCE(calendar_obj.YEAR_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(calendar_obj.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      CAST(
        COALESCE(calendar_obj.MONTH_OF_YEAR_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_MONTH_OF_YEAR_NBR,
      CAST(
        COALESCE(calendar_obj.QUARTER_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_QUARTER_NBR,
      CAST(
        COALESCE(calendar_obj.WEEK_OF_YEAR_NBR, 0) AS DECIMAL(38, 0)
      ) AS REPORTING_WEEK_OF_YEAR_NBR,
      NULL AS building_id,
      12 AS DATA_FREQUENCY_CD,
      INITCAP(curated_obj.energy_unit_in_kwh) AS SERVICE_USAGE_QTY_UOM,
      CAST(
        SUM(curated_obj.invoiced_usage_qty) OVER (
          PARTITION BY
            curated_obj.site_nm,
            curated_obj.client_site_ref_id,
            TO_DATE(
              CONCAT(
                curated_obj.yrs_nbr,
                '-',
                LPAD(curated_obj.mos_nbr, 2, '0')
              ),
              'yyyy-MM'
            ),
            'Electricity'
        ) AS DECIMAL(38, 2)
      ) AS SERVICE_USAGE_QTY,
      CAST(
        SUM(curated_obj.invoiced_cost) OVER (
          PARTITION BY
            curated_obj.site_nm,
            curated_obj.client_site_ref_id,
            TO_DATE(
              CONCAT(
                curated_obj.yrs_nbr,
                '-',
                LPAD(curated_obj.mos_nbr, 2, '0')
              ),
              'yyyy-MM'
            ),
            'Electricity'
        ) AS DECIMAL(38, 2)
      ) AS SERVICE_COST,
      CASE
        WHEN curated_obj.currency_cd = 'GPB' THEN 'GBP'
        ELSE curated_obj.currency_cd
      END AS SERVICE_COST_UOM,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      'MACE' AS cost_usage_data_source_cd,
      ROW_NUMBER() OVER (
        PARTITION BY
          curated_obj.site_nm,
          curated_obj.client_site_ref_id,
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'Electricity'
        ORDER BY
          curated_obj.site_nm,
          curated_obj.client_site_ref_id,
          TO_DATE(
            CONCAT(
              curated_obj.yrs_nbr,
              '-',
              LPAD(curated_obj.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'Electricity'
      ) AS row_num
    FROM
      CURATED_VIEW curated_obj
      LEFT JOIN {calendar_table_name} calendar_obj ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_obj.yrs_nbr,
          LPAD(curated_obj.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = calendar_obj.calendar_dt
  )
SELECT
  *
FROM
  AGG_REC
WHERE
  reporting_period_dt >= '2024-01-01'
  AND row_num = 1
