SELECT
  *
EXCEPT
(rn)
FROM
  (
    SELECT
      --electricity_consumption_uuid,
      electricity_location_nbr,
      electricity_location_nm,
      reporting_period_dt,
      lease_nbr,
      building_id,
      business_group_txt,
      brand_nm,
      nike_department_type_txt,
      business_entity_geo_region_cd,
      electricity_location_use_cd,
      business_function_nm,
      division_nm,
      location_geo_region_cd,
      continent_nm,
      address_line_1_txt,
      city_nm,
      state_cd,
      postal_cd,
      geographical_axis_nm,
      country_cd,
      location_area_in_sqft AS location_area,
      'Square foot' AS location_area_uom,
      location_status_cd,
      latitude_deg,
      longitude_deg,
      additional_location_feature_desc,
      -- 'see_usage_metrics' AS data_source_nm,
      'see_usage_metrics' AS location_area_data_source_nm,
      'SEE' AS location_area_data_source_cd,
      'see_usage_metrics' AS cost_usage_data_source_nm,
      'SEE' AS cost_usage_data_source_cd,
      ROW_NUMBER() OVER (
        PARTITION BY
          electricity_location_nbr,
          electricity_location_nm,
          reporting_period_dt
        ORDER BY
          reporting_period_dt DESC,
          BATCH_LOAD_TIMESTAMP DESC
      ) AS rn
    FROM
      {extrapolation_electricity_integrated_table_name}
    WHERE
      UPPER(extrapolation_ind) = 'TRUE'
      AND LOWER(location_status_cd) = 'open'
  )
WHERE
  rn = 1
