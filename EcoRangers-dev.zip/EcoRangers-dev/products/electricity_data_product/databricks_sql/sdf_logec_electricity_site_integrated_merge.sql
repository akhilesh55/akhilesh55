WITH
  EMISSION_AND_USAGE AS (
    SELECT
      U_METRICS_PART.location_nm AS location_nm,
      U_METRICS_PART.location_nbr AS location_nbr,
      U_METRICS_PART.location_address_1_nm AS location_address_1_nm,
      U_METRICS_PART.location_address_2_nm AS location_address_2_nm,
      U_METRICS_PART.location_city_nm AS location_city_nm,
      U_METRICS_PART.location_state_or_province_nm AS location_state_or_province_nm,
      U_METRICS_PART.location_postal_cd AS location_postal_cd,
      U_METRICS_PART.location_country_nm AS location_country_nm,
      U_METRICS_PART.location_status_desc AS location_status_desc,
      U_METRICS_PART.location_size_sqft AS location_size_sqft,
      U_METRICS_PART.misc_information_desc AS misc_information_desc,
      U_METRICS_PART.vendor_nm AS vendor_nm,
      U_METRICS_PART.vendor_address_1_nm AS vendor_address_1_nm,
      U_METRICS_PART.vendor_address_2_nm AS vendor_address_2_nm,
      U_METRICS_PART.vendor_city_nm AS vendor_city_nm,
      U_METRICS_PART.vendor_state_or_province_nm AS vendor_state_or_province_nm,
      U_METRICS_PART.vendor_postal_cd AS vendor_postal_cd,
      U_METRICS_PART.vendor_country_nm AS vendor_country_nm,
      U_METRICS_PART.account_nbr AS account_nbr,
      U_METRICS_PART.summary_account_nbr AS summary_account_nbr,
      U_METRICS_PART.account_address_1_nm AS account_address_1_nm,
      U_METRICS_PART.account_address_2_nm AS account_address_2_nm,
      U_METRICS_PART.account_city_nm AS account_city_nm,
      U_METRICS_PART.account_state_or_province_nm AS account_state_or_province_nm,
      U_METRICS_PART.account_postal_cd AS account_postal_cd,
      U_METRICS_PART.account_country_nm AS account_country_nm,
      U_METRICS_PART.clean_account_number_desc AS clean_account_number_desc,
      U_METRICS_PART.supplier_only_account_ind AS supplier_only_account_ind,
      U_METRICS_PART.audit_only_ind AS audit_only_ind,
      U_METRICS_PART.customer_gl_nbr AS customer_gl_nbr,
      U_METRICS_PART.gl_desc AS gl_desc,
      U_METRICS_PART.gl_allocation_pct AS gl_allocation_pct,
      U_METRICS_PART.meter_number_desc AS meter_number_desc,
      U_METRICS_PART.service_point_location_nm AS service_point_location_nm,
      U_METRICS_PART.rate_schedule_desc AS rate_schedule_desc,
      U_METRICS_PART.month_dt AS reporting_period_dt,
      U_METRICS_PART.begin_dt AS begin_dt,
      U_METRICS_PART.end_dt AS end_dt,
      U_METRICS_PART.service_days AS service_days,
      U_METRICS_PART.cost AS COST,
      U_METRICS_PART.service_type_nm AS service_type_nm,
      U_METRICS_PART.uom AS uom,
      U_METRICS_PART.usage_qty AS usage_qty,
      U_METRICS_PART.billed_qty AS billed_qty,
      U_METRICS_PART.cost_per_unit_uom AS cost_per_unit_uom,
      U_METRICS_PART.cost_per_day AS cost_per_day,
      U_METRICS_PART.cost_per_sqft AS cost_per_sqft,
      U_METRICS_PART.usage_per_day AS usage_per_day,
      U_METRICS_PART.usage_per_sqft AS usage_per_sqft,
      U_METRICS_PART.kbtus_qty AS kbtus_qty,
      U_METRICS_PART.kbtus_per_sqft AS kbtus_per_sqft,
      U_METRICS_PART.max_demand_qty AS max_demand_qty,
      U_METRICS_PART.load_factor_qty AS load_factor_qty,
      U_METRICS_PART.power_factor_qty AS power_factor_qty,
      U_METRICS_PART.cost_per_billed_qty AS cost_per_billed_qty,
      U_METRICS_PART.bill_estimated_ind AS bill_estimated_ind,
      U_METRICS_PART.open_exceptions_ind AS open_exceptions_ind,
      U_METRICS_PART.bill_image_desc AS bill_image_desc,
      U_METRICS_PART.department_nm AS department_nm,
      U_METRICS_PART.lease_number_desc AS lease_number_desc,
      U_METRICS_PART.audit_status_dt AS audit_status_dt,
      U_METRICS_PART.contract_expiration_dt AS contract_expiration_dt,
      U_METRICS_PART.contract_nm AS contract_nm,
      U_METRICS_PART.contract_status_desc AS contract_status_desc,
      U_METRICS_PART.floor_nbr AS floor_nbr,
      U_METRICS_PART.alternate_nm AS alternate_nm,
      U_METRICS_PART.baseline_note_desc AS baseline_note_desc,
      U_METRICS_PART.better_buildings_challenge_ind AS better_buildings_challenge_ind,
      U_METRICS_PART.district_inline_desc AS district_inline_desc,
      U_METRICS_PART.district_outlet_desc AS district_outlet_desc,
      U_METRICS_PART.footprint_sqft AS footprint_sqft,
      U_METRICS_PART.in_line_outlet_desc AS in_line_outlet_desc,
      U_METRICS_PART.ems_desc AS ems_desc,
      U_METRICS_PART.ems_install_dt AS ems_install_dt,
      U_METRICS_PART.global_sustainability_energy_plus_carbon_target_group_desc AS global_sustainability_energy_plus_carbon_target_group_desc,
      U_METRICS_PART.location_opened_dt AS location_opened_dt,
      U_METRICS_PART.site_cd_siterra_desc AS site_cd_siterra_desc,
      U_METRICS_PART.total_bldg_sqft AS total_bldg_sqft,
      U_METRICS_PART.wd_and_c_geo AS wd_and_c_geo,
      U_METRICS_PART.whq_campus_nm AS whq_campus_nm,
      U_METRICS_PART.leed_desc AS leed_desc,
      U_METRICS_PART.location_crc_nbr AS location_crc_nbr,
      U_METRICS_PART.new_building_nm AS new_building_nm,
      U_METRICS_PART.ownership_desc AS ownership_desc,
      U_METRICS_PART.principle_building_activity_desc AS principle_building_activity_desc,
      U_METRICS_PART.seated_occupancy_qty AS seated_occupancy_qty,
      U_METRICS_PART.sub_concept_desc AS sub_concept_desc,
      U_METRICS_PART.brand_nm AS brand_nm
    FROM
      {engie_curated_table_name} U_METRICS_PART
    WHERE
      U_METRICS_PART.DEPARTMENT_NM IN ('DC', 'Distribution Centers')
      AND U_METRICS_PART.SERVICE_TYPE_NM IN ('Natural Gas', 'Fuel Oil', 'Electric')
      AND NOT (
        U_METRICS_PART.LOCATION_NM ILIKE '%Ontario-Hofer'
        OR U_METRICS_PART.LOCATION_NM ILIKE '%Ontario - Lowell'
      )
      AND U_METRICS_PART.LOCATION_NM NOT ILIKE '!0%' QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          U_METRICS_PART.location_nbr,
          U_METRICS_PART.location_nm,
          U_METRICS_PART.month_dt
        ORDER BY
          U_METRICS_PART.month_dt DESC,
          U_METRICS_PART.site_cd_siterra_desc DESC
      ) = 1
  ),
  site_size_sqft AS (
    SELECT
      location_key,
      CAST(
        CONCAT(CAST(YEAR AS INT), '-', CAST(MONTH AS INT)) AS DATE
      ) AS reporting_period_dt,
      -- year,
      -- month,
      -- ROW_NUMBER() OVER (
      --   PARTITION BY
      --     location_key
      --   ORDER BY
      --     CAST(year AS INT) DESC,
      --     CAST(month AS INT) DESC
      -- ) AS max_yr_mn,
      value
    FROM
      {logec_table_name}
    WHERE
      parent = 'LOCATION_SIZE_M2_FC'
      AND VALUE IS NOT NULL
      -- AND value != 0 -- removed condition to exclude zero values
      qualify (
        ROW_NUMBER() OVER (
          PARTITION BY
            location_key,
            CONCAT(CAST(YEAR AS INT), '-', CAST(MONTH AS INT))
          ORDER BY
            CAST(year AS INT) DESC,
            CAST(month AS INT) DESC
        )
      ) = 1
  ),
  TAXONOMY_GEO_CODE_TABLE AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_mapping_tbl}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  existing_query AS (
    SELECT
      -- uuid_string(
      --     '8e884ace-bee4-11e4-8dfc-aa07a5b093db',
      --     md5(concat(ELECTRICITY_LOCATION_NBR, ELECTRICITY_LOCATION_NM,brand_nm))
      -- ) as ELECTRICITY_CONSUMPTION_UUID,
      electricity_location_nbr,
      location_key,
      electricity_location_nm,
      lease_nbr,
      building_id,
      REGEXP_REPLACE(INITCAP(business_group_txt), '-', ' ') AS business_group_txt,
      INITCAP(brand_nm) AS brand_nm,
      nike_department_type_txt,
      CASE
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
        ELSE BUSINESS_ENTITY_GEO_REGION_CD
      END AS BUSINESS_ENTITY_GEO_REGION_CD,
      ELECTRICITY_LOCATION_USE_CD,
      business_function_nm,
      division_nm,
      CASE
        WHEN LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
        ELSE LOCATION_GEO_REGION_CD
      END AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN continent_nm ILIKE 'EMEA' THEN 'Europe'
        WHEN continent_nm ILIKE 'APLA' THEN 'Asia'
        WHEN continent_nm ILIKE 'North America' THEN 'North America'
        WHEN continent_nm ILIKE 'Greater China' THEN 'Asia'
        ELSE continent_nm
      END AS continent_nm,
      COALESCE(ADDRESS_LINE_1_TXT, conv_adresss_1) AS ADDRESS_LINE_1_TXT,
      COALESCE(INITCAP(city_nm), INITCAP(conv_adresss_2)) AS city_nm,
      COALESCE(STATE_CD, conv_adresss_3) AS STATE_CD,
      COALESCE(POSTAL_CD, conv_zip_code) AS POSTAL_CD,
      conv_dc_country,
      -- geographical_axis_nm,
      CASE
        WHEN COUNTRY_CD ILIKE 'Canada' THEN 'CA'
        WHEN COUNTRY_CD ILIKE 'United States' THEN 'US'
        ELSE COUNTRY_CD
      END AS COUNTRY_CD,
      -- LOCATION_AREA_IN_SQFT,
      LOCATION_STATUS_CD,
      latitude_deg,
      longitude_deg,
      ADDITIONAL_LOCATION_FEATURE_DESC,
      reporting_period_dt
    FROM
      (
        SELECT DISTINCT
          SUBSTRING(log_tbl.LOCATION_KEY, 4) AS ELECTRICITY_LOCATION_NBR,
          log_tbl.location_key,
          --log_tbl.LOCATION_NAME as ELECTRICITY_LOCATION_NM,
          COALESCE(node_tbl.NAME, log_tbl.LOCATION_NAME) AS ELECTRICITY_LOCATION_NM,
          conv_dc_mapping.adresss_1 AS conv_adresss_1,
          conv_dc_mapping.adresss_2 AS conv_adresss_2,
          conv_dc_mapping.adresss_3 AS conv_adresss_3,
          conv_dc_mapping.zip_code AS conv_zip_code,
          NULL AS lease_nbr,
          NULL AS building_id,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'Non Retail'
            ELSE 'Retail'
          END AS BUSINESS_GROUP_TXT,
          CASE
            WHEN log_tbl.SCENARIO_NAME = 'CONVERSE' THEN 'CONVERSE'
            WHEN log_tbl.LOCATION_KEY = 'DC_US_ONTARIO'
            AND log_tbl.SCENARIO_NAME = 'NIKE' THEN 'CONVERSE'
            ELSE 'NIKE'
          END AS brand_nm,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'Distribution Center'
            ELSE NULL
          END AS NIKE_DEPARTMENT_TYPE_TXT,
          log_tbl.REGION AS BUSINESS_ENTITY_GEO_REGION_CD,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'DISTRIBUTION CENTER'
            ELSE NULL
          END AS ELECTRICITY_LOCATION_USE_CD,
          CASE
            WHEN log_tbl.LOCATION_KEY = 'DC_US_ONTARIO'
            AND log_tbl.SCENARIO_NAME = 'NIKE' THEN 'Logistics (C)'
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'NIKE' THEN 'Logistics (N)'
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'CONVERSE' THEN 'Logistics (C)'
            ELSE NULL
          END AS business_function_nm,
          CASE
            WHEN log_tbl.LOCATION_KEY = 'DC_US_ONTARIO'
            AND log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'NIKE' THEN 'Distribution Centers (C)'
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'NIKE' THEN 'Distribution Centers (N)'
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'CONVERSE' THEN 'Distribution Centers (C)'
            ELSE NULL
          END AS division_nm,
          log_tbl.REGION AS LOCATION_GEO_REGION_CD,
          ctry_mapping.GEOSHORT_NM AS continent_nm,
          node_tbl.ADDRESS_LINE_1_TEXT AS ADDRESS_LINE_1_TXT,
          node_tbl.CITY_NAME AS city_nm,
          node_tbl.STATE_PROVINCE_CODE AS STATE_CD,
          node_tbl.POSTAL_CODE AS POSTAL_CD,
          conv_dc_mapping.Country AS conv_dc_country,
          -- COALESCE(CONCAT(node_tbl.POSTAL_CODE,'-',node_tbl.CITY_NAME),conv_dc_mapping.Country) as geographical_axis_nm,
          COALESCE(
            node_tbl.ISO_COUNTRY_CODE,
            conv_dc_mapping.Country_cd
          ) AS COUNTRY_CD,
          -- NULL as LOCATION_AREA_IN_SQFT,
          CASE
            WHEN log_tbl.IS_ABS = 'true' THEN 'Open'
            ELSE 'Close'
          END AS LOCATION_STATUS_CD,
          node_tbl.LATITUDE_DECIMAL_DEGREE AS latitude_deg,
          node_tbl.LONGITUDE_DECIMAL_DEGREE AS longitude_deg,
          NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
          TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') AS reporting_period_dt
        FROM
          {logec_table_name} log_tbl
          LEFT JOIN {node_table_name} node_tbl ON SUBSTRING(log_tbl.LOCATION_KEY, 4) = node_tbl.NODE_CODE
          LEFT JOIN TAXONOMY_GEO_CODE_TABLE ctry_mapping ON log_tbl.region = ctry_mapping.REGION
          LEFT JOIN conv_dc_mapping_table conv_dc_mapping ON log_tbl.LOCATION_KEY = conv_dc_mapping.LOCATION_KEY
        WHERE
          log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2',
            'COST_PURCHASED_ELECTRICITY_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'GENERATED_ELECTRICITY_WIND_SCOPE2',
            'OFFSITE_WIND_CONSUMPTION',
            'ONSITE_SOLAR_CONSUMPTION',
            'ONSITE_SOLAR_GENERATION',
            'ONSITE_WIND_CONSUMPTION',
            'ONSITE_WIND_GENERATION',
            'PURCHASED_ELECTRICITY_SCOPE2',
            'REC_AMOUNT_BIOMASS_EMITTED',
            'REC_AMOUNT_GEOTHERMAL',
            'REC_AMOUNT_HYDROPOWER',
            'REC_AMOUNT_SOLAR',
            'REC_AMOUNT_SOLAR_WIND',
            'REC_AMOUNT_WIND',
            'SURPLUS_ONSITE_SOLAR_GENERATION',
            'SURPLUS_ONSITE_WIND_GENERATION'
          )
          AND log_tbl.LOCATION_NAME NOT IN (
            'Converse ELC ACDC',
            'Converse HKDC',
            'Converse Arvato'
          )
        UNION ALL
        SELECT DISTINCT
          SUBSTRING(log_tbl.LOCATION_KEY, 4) AS ELECTRICITY_LOCATION_NBR,
          log_tbl.location_key,
          --log_tbl.LOCATION_NAME as ELECTRICITY_LOCATION_NM,
          COALESCE(node_tbl.NAME, log_tbl.LOCATION_NAME) AS ELECTRICITY_LOCATION_NM,
          conv_dc_mapping.adresss_1 AS conv_adresss_1,
          conv_dc_mapping.adresss_2 AS conv_adresss_2,
          conv_dc_mapping.adresss_3 AS conv_adresss_3,
          conv_dc_mapping.zip_code AS conv_zip_code,
          NULL AS lease_nbr,
          NULL AS building_id,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'Non Retail'
            ELSE 'Retail'
          END AS BUSINESS_GROUP_TXT,
          'CONVERSE' AS brand_nm,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'Distribution Center'
            ELSE NULL
          END AS NIKE_DEPARTMENT_TYPE_TXT,
          log_tbl.REGION AS BUSINESS_ENTITY_GEO_REGION_CD,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'DISTRIBUTION CENTER'
            ELSE NULL
          END AS ELECTRICITY_LOCATION_USE_CD,
          'Logistics (C)' AS business_function_nm,
          'Distribution Centers (C)' AS division_nm,
          log_tbl.REGION AS LOCATION_GEO_REGION_CD,
          ctry_mapping.GEOSHORT_NM AS continent_nm,
          node_tbl.ADDRESS_LINE_1_TEXT AS ADDRESS_LINE_1_TXT,
          node_tbl.CITY_NAME AS city_nm,
          node_tbl.STATE_PROVINCE_CODE AS STATE_CD,
          node_tbl.POSTAL_CODE AS POSTAL_CD,
          conv_dc_mapping.Country AS conv_dc_country,
          -- COALESCE(CONCAT(node_tbl.POSTAL_CODE,'-',node_tbl.CITY_NAME),conv_dc_mapping.Country) as geographical_axis_nm,
          COALESCE(
            node_tbl.ISO_COUNTRY_CODE,
            conv_dc_mapping.Country_cd
          ) AS COUNTRY_CD,
          -- NULL as LOCATION_AREA_IN_SQFT,
          CASE
            WHEN log_tbl.IS_ABS = 'true' THEN 'Open'
            ELSE 'Close'
          END AS LOCATION_STATUS_CD,
          node_tbl.LATITUDE_DECIMAL_DEGREE AS latitude_deg,
          node_tbl.LONGITUDE_DECIMAL_DEGREE AS longitude_deg,
          NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
          TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') AS reporting_period_dt
        FROM
          {logec_table_name} log_tbl
          LEFT JOIN {node_table_name} node_tbl ON SUBSTRING(log_tbl.LOCATION_KEY, 4) = node_tbl.NODE_CODE
          LEFT JOIN TAXONOMY_GEO_CODE_TABLE ctry_mapping ON log_tbl.region = ctry_mapping.REGION
          LEFT JOIN conv_dc_mapping_table conv_dc_mapping ON log_tbl.LOCATION_KEY = conv_dc_mapping.LOCATION_KEY
        WHERE
          log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2',
            'COST_PURCHASED_ELECTRICITY_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'GENERATED_ELECTRICITY_WIND_SCOPE2',
            'OFFSITE_WIND_CONSUMPTION',
            'ONSITE_SOLAR_CONSUMPTION',
            'ONSITE_SOLAR_GENERATION',
            'ONSITE_WIND_CONSUMPTION',
            'ONSITE_WIND_GENERATION',
            'PURCHASED_ELECTRICITY_SCOPE2',
            'REC_AMOUNT_BIOMASS_EMITTED',
            'REC_AMOUNT_GEOTHERMAL',
            'REC_AMOUNT_HYDROPOWER',
            'REC_AMOUNT_SOLAR',
            'REC_AMOUNT_SOLAR_WIND',
            'REC_AMOUNT_WIND',
            'SURPLUS_ONSITE_SOLAR_GENERATION',
            'SURPLUS_ONSITE_WIND_GENERATION'
          )
          AND log_tbl.LOCATION_NAME IN (
            'Converse ELC ACDC',
            'Converse HKDC',
            'Converse Arvato'
          )
      )
  ),
  Logec_DC_Migrated AS (
    SELECT
      electricity_location_nbr,
      electricity_location_nm,
      lease_nbr,
      building_id,
      business_group_txt,
      brand_nm,
      CASE
        WHEN nike_department_type_txt ILIKE '%air mi%' THEN 'Air MI'
        ELSE nike_department_type_txt
      END AS nike_department_type_txt,
      BUSINESS_ENTITY_GEO_REGION_CD,
      ELECTRICITY_LOCATION_USE_CD,
      business_function_nm,
      LOCATION_GEO_REGION_CD,
      continent_nm,
      ADDRESS_LINE_1_TXT,
      city_nm,
      STATE_CD,
      POSTAL_CD,
      conv_dc_country, -- Added to get the correct value for geographical_axis_nm when null occurs in next step
      -- geographical_axis_nm, -- Handle geographical_axis_nm in next step to get the correct value
      COUNTRY_CD,
      value AS LOCATION_AREA,
      division_nm,
      LOCATION_STATUS_CD,
      CAST(latitude_deg AS STRING) AS latitude_deg,
      CAST(longitude_deg AS STRING) AS longitude_deg,
      ADDITIONAL_LOCATION_FEATURE_DESC,
      existing_query.reporting_period_dt
    FROM
      existing_query
      -- INNER JOIN site_size_sqft ON site_size_sqft.location_key = existing_query.location_key
      LEFT JOIN site_size_sqft ON site_size_sqft.location_key = existing_query.location_key
      AND site_size_sqft.reporting_period_dt = existing_query.reporting_period_dt
      -- WHERE
      -- site_size_sqft.max_yr_mn = 1
  )
SELECT DISTINCT
  electricity_location_nbr,
  electricity_location_nm,
  logec_m.reporting_period_dt,
  -- COALESCE(logec_m.lease_nbr, DC_UMD.engie_lease_nbr) AS lease_nbr, -- These commented code to replace UMD data with engie source
  COALESCE(logec_m.lease_nbr, EAU.LEASE_NUMBER_DESC) AS lease_nbr,
  -- COALESCE(logec_m.building_id, DC_UMD.engie_building_id) AS building_id,
  COALESCE(logec_m.building_id, EAU.SITE_CD_SITERRA_DESC) AS building_id,
  business_group_txt,
  logec_m.brand_nm,
  nike_department_type_txt,
  BUSINESS_ENTITY_GEO_REGION_CD,
  ELECTRICITY_LOCATION_USE_CD,
  business_function_nm,
  LOCATION_GEO_REGION_CD,
  continent_nm,
  -- COALESCE(ADDRESS_LINE_1_TXT, DC_UMD.LOCATION_ADDRESS_1_NM) AS ADDRESS_LINE_1_TXT,
  COALESCE(ADDRESS_LINE_1_TXT, EAU.location_address_1_nm) AS ADDRESS_LINE_1_TXT,
  -- COALESCE(city_nm, DC_UMD.LOCATION_CITY_NM) AS city_nm,
  INITCAP(COALESCE(city_nm, EAU.location_city_nm)) AS city_nm,
  -- COALESCE(
  --   NULLIF(STATE_CD, ''),
  --   DC_UMD.LOCATION_STATE_OR_PROVINCE_NM
  -- ) AS STATE_CD,
  COALESCE(STATE_CD, EAU.location_state_or_province_nm) AS STATE_CD,
  -- COALESCE(POSTAL_CD, DC_UMD.LOCATION_POSTAL_CD) AS POSTAL_CD,
  COALESCE(POSTAL_CD, EAU.location_postal_cd) AS POSTAL_CD,
  -- COALESCE(
  --   CONCAT(
  --     COALESCE(POSTAL_CD, DC_UMD.LOCATION_POSTAL_CD),
  --     '-',
  --     COALESCE(city_nm, DC_UMD.LOCATION_CITY_NM)
  --   ),
  --   conv_dc_country
  -- ) AS geographical_axis_nm,
  COALESCE(
    CONCAT(
      COALESCE(POSTAL_CD, EAU.location_postal_cd),
      '-',
      INITCAP(COALESCE(city_nm, EAU.location_city_nm))
    ),
    INITCAP(conv_dc_country)
  ) AS geographical_axis_nm,
  -- COUNTRY_CD,
  COALESCE(COUNTRY_CD, EAU.location_country_nm) AS COUNTRY_CD,
  -- CAST(
  --   COALESCE(LOCATION_AREA, DC_UMD.engie_LOCATION_AREA_IN_SQFT) AS DECIMAL(31, 5)
  -- ) AS LOCATION_AREA,
  CAST(
    COALESCE(LOCATION_AREA, EAU.location_size_sqft) AS DECIMAL(31, 5)
  ) AS LOCATION_AREA,
  CASE
    WHEN LOCATION_AREA IS NOT NULL THEN 'Square meter'
    WHEN (
      LOCATION_AREA IS NULL
      AND EAU.location_size_sqft IS NOT NULL
    ) THEN 'Square foot'
    ELSE NULL
  END AS LOCATION_AREA_UOM,
  division_nm,
  LOCATION_STATUS_CD,
  COALESCE(
    latitude_deg
    -- , DC_UMD.engie_latitude_deg
  ) AS latitude_deg,
  COALESCE(
    longitude_deg
    -- , DC_UMD.engie_longitude_deg
  ) AS longitude_deg,
  CASE
    WHEN EAU.EMS_DESC = 'EMS Sites' THEN 'EMS'
    ELSE ADDITIONAL_LOCATION_FEATURE_DESC
  END AS ADDITIONAL_LOCATION_FEATURE_DESC,
  CASE
    WHEN LOCATION_AREA IS NOT NULL THEN 'logec'
    WHEN (
      LOCATION_AREA IS NULL
      AND EAU.location_size_sqft IS NOT NULL
    ) THEN 'emission_and_usage_metrics'
    ELSE NULL
  END AS LOCATION_AREA_DATA_SOURCE_NM,
  CASE
    WHEN LOCATION_AREA IS NOT NULL THEN 'LOGEC'
    WHEN (
      LOCATION_AREA IS NULL
      AND EAU.location_size_sqft IS NOT NULL
    ) THEN 'ENGI'
    ELSE NULL
  END AS LOCATION_AREA_DATA_SOURCE_CD,
  'logec' AS cost_usage_data_source_nm,
  'LOGEC' AS cost_usage_data_source_cd
FROM
  Logec_DC_Migrated logec_m
  LEFT JOIN DC_SITE_DETAIL_MAPPING DC_UMD ON logec_m.electricity_location_nbr = SUBSTRING(DC_UMD.LOCATION_KEY, 4)
  LEFT JOIN EMISSION_AND_USAGE EAU ON DC_UMD.LOCATION_NM = EAU.LOCATION_NM
  AND DC_UMD.LOCATION_NBR = EAU.LOCATION_NBR
  AND logec_m.reporting_period_dt = EAU.reporting_period_dt
