WITH
  AIR_TABLE_METRICS AS ( -- Story(SDF-3040)- Added this CTE to get the service type from Airtable
    SELECT
      generation_or_consumption_country_nm,
      site_common_nm,
      site_official_nm,
      TRIM(REPLACE(location_nbr, '\n', '')) AS location_nbr,
      nike_business_function_cd,
      sourcing_method_desc,
      tech_type_desc,
      source_method_type
    FROM
      {curated_air_table} air_table
    WHERE
      air_table.nike_business_function_cd ilike 'DCs'
  ),
  UNION_DETAIL AS (
    (
      SELECT
        SUBSTRING(log_tbl.LOCATION_KEY, 4) AS ELECTRICITY_LOCATION_NBR,
        TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') AS reporting_period_dt,
        CASE
          WHEN log_tbl.SCENARIO_NAME = 'CONVERSE'
          OR SUBSTRING(log_tbl.LOCATION_KEY, 4) IN ('HK01', 'CONVERSE_ELC', 'CONVERSE_ARVATO') THEN 'CONVERSE'
          ELSE 'NIKE'
        END AS brand_nm,
        TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') AS BILLING_MONTH_START_DT,
        LAST_DAY(TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM')) AS BILLING_MONTH_END_DT,
        -- CONCAT(   -- Unwated code, BILLING_MONTH_DATE_RANGE_TXT transformation is done in the final select
        --   date_format(
        --     TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM'),
        --     'MM/dd/yyyy'
        --   ),
        --   '-',
        --   date_format(
        --     last_day(TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM')),
        --     'MM/dd/yyyy'
        --   )
        -- ) AS BILLING_MONTH_DATE_RANGE_TXT,
        -- log_tbl.LOCATION_NAME as ELECTRICITY_LOCATION_NM,
        COALESCE(node_tbl.NAME, log_tbl.LOCATION_NAME) AS ELECTRICITY_LOCATION_NM,
        cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
        cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
        cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
        cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
        cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
        cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
        cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
        cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
        NULL AS building_id,
        -- service_tbl.sourcing_method_desc AS SERVICE_TYPE_CD, -- Priority to Airtable more than UMD
        CASE
          WHEN airtable.sourcing_method_desc ILIKE '%Purchased Onsite%'
          AND airtable.tech_type_desc ILIKE 'Solar'
          AND log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2'
          ) THEN 'Purchased Onsite Solar Consumption'
          WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
          AND airtable.tech_type_desc ILIKE 'Solar'
          AND log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2'
          ) THEN 'Owned Onsite Solar Consumption'
          WHEN airtable.sourcing_method_desc ILIKE '%Purchased Onsite%'
          AND airtable.tech_type_desc ILIKE 'Wind'
          AND log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2',
            'GENERATED_ELECTRICITY_WIND_SCOPE2'
          ) THEN 'Purchased Onsite Wind Consumption'
          WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
          AND airtable.tech_type_desc ILIKE 'Wind'
          AND log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2',
            'GENERATED_ELECTRICITY_WIND_SCOPE2'
          ) THEN 'Owned Onsite Wind Consumption'
          -- WHEN airtable.sourcing_method_desc ILIKE 'Offsite Direct-Line PPA'
          -- AND airtable.tech_type_desc ILIKE 'Wind'
          -- AND log_tbl.PARENT IN (
          --   'COST_GENERATED_ELECTRICITY_WIND_SCOPE2',
          --   'GENERATED_ELECTRICITY_WIND_SCOPE2'
          -- ) THEN 'Offsite Wind Direct - Line PPA' 
          -- Green Power Purchase (Retail Supply) for Solar (Cost-based)
          WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
          AND airtable.tech_type_desc ILIKE '%Multiple source%'
          AND log_tbl.PARENT ILIKE 'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2'
          AND (
            airtable.generation_or_consumption_country_nm ILIKE 'Japan'
            OR log_tbl.location_name ILIKE '%Japan%'
          ) THEN 'Green Power Purchase - Retail Supply - Solar'
          WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
          AND airtable.tech_type_desc ILIKE '%Multiple source%'
          AND log_tbl.PARENT ILIKE 'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2'
          AND (
            airtable.generation_or_consumption_country_nm ILIKE 'Japan'
            OR log_tbl.location_name ILIKE '%Japan%'
          ) THEN 'Green Power Purchase - Retail Supply - Solar'
          ELSE service_tbl.SERVICE_TYPE
        END AS SERVICE_TYPE_CD,
        CAST(12 AS INTEGER) AS DATA_FREQUENCY_CD,
        CASE
          WHEN log_tbl.PARENT IN (
            'GENERATED_ELECTRICITY_WIND_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2'
          ) THEN log_tbl.VALUE
          ELSE NULL
        END AS SERVICE_USAGE_QTY,
        CASE
          WHEN log_tbl.PARENT IN (
            'GENERATED_ELECTRICITY_WIND_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2'
          ) THEN log_tbl.UNIT
          ELSE NULL
        END AS SERVICE_USAGE_QTY_UOM,
        CASE
          WHEN log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2'
          ) THEN log_tbl.VALUE
          ELSE NULL
        END AS SERVICE_COST,
        CASE
          WHEN log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2'
          ) THEN log_tbl.CURRENCY
          ELSE NULL
        END AS SERVICE_COST_UOM,
        'FALSE' AS extrapolation_ind,
        CASE
          WHEN log_tbl.PARENT IN (
            'GENERATED_ELECTRICITY_WIND_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2'
          ) THEN 'SCOPE 2'
          ELSE NULL
        END AS scope_nbr
      FROM
        {logec_table_name} log_tbl
        LEFT JOIN {calendar_table_name} cd ON TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') = CAST(cd.calendar_dt AS STRING)
        LEFT JOIN {node_table_name} node_tbl ON SUBSTRING(log_tbl.LOCATION_KEY, 4) = node_tbl.NODE_CODE
        LEFT JOIN {bcl_service_type} service_tbl ON log_tbl.LOCATION_KEY = service_tbl.LOCATION_KEY
        AND log_tbl.LOCATION_NAME = service_tbl.LOCATION_NAME
        AND log_tbl.PARENT = service_tbl.PARENT
        LEFT JOIN AIR_TABLE_METRICS airtable ON log_tbl.LOCATION_KEY = airtable.location_nbr
        AND (
          (
            (
              log_tbl.PARENT ilike '%PHOTOVOLTAIC%'
              OR log_tbl.PARENT ilike '%SOLAR_%'
            )
            AND airtable.tech_type_desc ilike '%solar%'
          )
          OR (
            log_tbl.PARENT ilike '%WIND_%'
            AND airtable.tech_type_desc ilike '%wind%'
          )
          OR (airtable.tech_type_desc ILIKE '%Multiple source%')
          OR (airtable.tech_type_desc ILIKE '%Geothermal%')
        )
      WHERE
        log_tbl.PARENT IN (
          'GENERATED_ELECTRICITY_WIND_SCOPE2',
          'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
          'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
          'COST_GENERATED_ELECTRICITY_WIND_SCOPE2'
        )
        AND TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') < '2023-06-01' /* Story(SDF-3040)- This condition is added to avoid duplication for (GENERATED_ELECTRICITY_WIND_SCOPE2, GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2) with respect to (ONSITE_SOLAR_CONSUMPTION, ONSITE_WIND_CONSUMPTION) from logec. These parents (GENERATED_ELECTRICITY_WIND_SCOPE2, GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2) serve the same purpose until this date ('2023-06-01') and  this date ('2023-06-01') onwards parent (ONSITE_SOLAR_CONSUMPTION, ONSITE_WIND_CONSUMPTION) will serve the purpose. */
    )
    UNION
    (
      WITH
        NON_NULL_DETAIL AS (
          SELECT
            SUBSTRING(log_tbl.LOCATION_KEY, 4) AS ELECTRICITY_LOCATION_NBR,
            TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') AS reporting_period_dt,
            CASE
              WHEN log_tbl.SCENARIO_NAME = 'CONVERSE'
              OR SUBSTRING(log_tbl.LOCATION_KEY, 4) IN ('HK01', 'CONVERSE_ELC', 'CONVERSE_ARVATO') THEN 'CONVERSE'
              ELSE 'NIKE'
            END AS brand_nm,
            TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') AS BILLING_MONTH_START_DT,
            LAST_DAY(TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM')) AS BILLING_MONTH_END_DT,
            -- CONCAT(    -- Unwated code, BILLING_MONTH_DATE_RANGE_TXT transformation is done in the final select
            --   date_format(
            --     TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM'),
            --     'MM/dd/yyyy'
            --   ),
            --   '-',
            --   date_format(
            --     last_day(TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM')),
            --     'MM/dd/yyyy'
            --   )
            -- ) AS BILLING_MONTH_DATE_RANGE_TXT,
            -- log_tbl.LOCATION_NAME as ELECTRICITY_LOCATION_NM,
            COALESCE(node_tbl.NAME, log_tbl.LOCATION_NAME) AS ELECTRICITY_LOCATION_NM,
            cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
            cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
            cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
            cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
            cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
            cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
            cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
            cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
            NULL AS building_id,
            -- COALESCE(service_tbl.sourcing_method_desc,log_tbl.PARENT) AS SERVICE_TYPE_CD,
            CASE
              WHEN airtable.sourcing_method_desc ILIKE 'Purchased Onsite%'
              AND airtable.tech_type_desc ILIKE 'Solar'
              AND log_tbl.PARENT ILIKE 'ONSITE_SOLAR_CONSUMPTION' THEN 'Purchased Onsite Solar Consumption'
              WHEN airtable.sourcing_method_desc ILIKE 'Purchased Onsite%'
              AND airtable.tech_type_desc ILIKE 'Solar'
              AND log_tbl.PARENT ILIKE 'ONSITE_SOLAR_GENERATION' THEN 'Purchased Onsite Solar Generation'
              WHEN airtable.sourcing_method_desc ILIKE 'Purchased Onsite%'
              AND airtable.tech_type_desc ILIKE 'Solar'
              AND log_tbl.PARENT ILIKE 'SURPLUS_ONSITE_SOLAR_GENERATION' THEN 'Purchased Onsite Solar Surplus Generation'
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (project-specific)'
              AND airtable.tech_type_desc ILIKE 'Solar'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_SOLAR' THEN 'Green Power Purchase - Project Specific - Solar'
              -- Solar: Owned Onsite
              WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
              AND airtable.tech_type_desc ILIKE 'Solar'
              AND log_tbl.PARENT ILIKE 'ONSITE_SOLAR_CONSUMPTION' THEN 'Owned Onsite Solar Consumption'
              WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
              AND airtable.tech_type_desc ILIKE 'Solar'
              AND log_tbl.PARENT ILIKE 'ONSITE_SOLAR_GENERATION' THEN 'Owned Onsite Solar Generation'
              WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
              AND airtable.tech_type_desc ILIKE 'Solar'
              AND log_tbl.PARENT ILIKE 'SURPLUS_ONSITE_SOLAR_GENERATION' THEN 'Owned Onsite Solar Surplus Generation'
              -- Wind: Purchased Onsite Installation (Onsite PPA)
              WHEN airtable.sourcing_method_desc ILIKE 'Purchased Onsite%'
              AND airtable.tech_type_desc ILIKE 'Wind'
              AND log_tbl.PARENT ILIKE 'ONSITE_WIND_CONSUMPTION' THEN 'Purchased Onsite Wind Consumption'
              WHEN airtable.sourcing_method_desc ILIKE 'Purchased Onsite%'
              AND airtable.tech_type_desc ILIKE 'Wind'
              AND log_tbl.PARENT ILIKE 'ONSITE_WIND_GENERATION' THEN 'Purchased Onsite Wind Generation'
              WHEN airtable.sourcing_method_desc ILIKE 'Purchased Onsite%'
              AND airtable.tech_type_desc ILIKE 'Wind'
              AND log_tbl.PARENT ILIKE 'SURPLUS_ONSITE_WIND_GENERATION' THEN 'Purchased Onsite Wind Surplus Generation'
              -- Wind: Owned Onsite
              WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
              AND airtable.tech_type_desc ILIKE 'Wind'
              AND log_tbl.PARENT ILIKE 'ONSITE_WIND_CONSUMPTION' THEN 'Owned Onsite Wind Consumption'
              WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
              AND airtable.tech_type_desc ILIKE 'Wind'
              AND log_tbl.PARENT ILIKE 'ONSITE_WIND_GENERATION' THEN 'Owned Onsite Wind Generation'
              WHEN airtable.sourcing_method_desc ILIKE 'Owned Onsite'
              AND airtable.tech_type_desc ILIKE 'Wind'
              AND log_tbl.PARENT ILIKE 'SURPLUS_ONSITE_WIND_GENERATION' THEN 'Owned Onsite Wind Surplus Generation'
              WHEN airtable.sourcing_method_desc ILIKE 'Offsite Direct-Line PPA'
              AND airtable.tech_type_desc ILIKE 'Wind'
              AND log_tbl.PARENT ILIKE 'OFFSITE_WIND_CONSUMPTION' THEN 'Offsite Wind Direct - Line PPA'
              -- Geothermal: Green Power Purchase
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
              AND airtable.tech_type_desc ILIKE 'Geothermal'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_GEOTHERMAL' THEN 'Green Power Purchase - Retail Supply - Geothermal'
              -- Electricity :
              WHEN log_tbl.PARENT IN (
                'COST_PURCHASED_ELECTRICITY_SCOPE2',
                'PURCHASED_ELECTRICITY_SCOPE2'
              ) THEN 'Electricity'
              --REC :
              WHEN log_tbl.PARENT ILIKE 'REC_AMOUNT_BIOMASS_EMITTED'
              AND (
                airtable.generation_or_consumption_country_nm NOT ILIKE 'Japan'
                OR log_tbl.location_name NOT ILIKE '%Japan%'
              ) THEN 'EACs - Biomass'
              WHEN log_tbl.PARENT ILIKE 'REC_AMOUNT_GEOTHERMAL'
              AND (
                airtable.generation_or_consumption_country_nm NOT ILIKE 'Japan'
                OR log_tbl.location_name NOT ILIKE '%Japan%'
              ) THEN 'EACs - Geothermal'
              WHEN log_tbl.PARENT ILIKE 'REC_AMOUNT_HYDROPOWER'
              AND (
                airtable.generation_or_consumption_country_nm NOT ILIKE 'Japan'
                OR log_tbl.location_name NOT ILIKE '%Japan%'
              ) THEN 'EACs - Small Hydroelectric'
              WHEN log_tbl.PARENT ILIKE 'REC_AMOUNT_SOLAR'
              AND (
                airtable.generation_or_consumption_country_nm NOT ILIKE 'Japan'
                OR log_tbl.location_name NOT ILIKE '%Japan%'
              ) THEN 'EACs - Solar'
              WHEN log_tbl.PARENT ILIKE 'REC_AMOUNT_WIND'
              AND (
                airtable.generation_or_consumption_country_nm NOT ILIKE 'Japan'
                OR log_tbl.location_name NOT ILIKE '%Japan%'
              ) THEN 'EACs - Wind'
              -- Green Power Purchase (Retail Supply) for Biomass
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
              AND airtable.tech_type_desc ILIKE '%Multiple source%'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_BIOMASS_EMITTED'
              AND (
                airtable.generation_or_consumption_country_nm ILIKE 'Japan'
                OR log_tbl.location_name ILIKE '%Japan%'
              ) THEN 'Green Power Purchase - Retail Supply - Biomass'
              -- Green Power Purchase (Retail Supply) for Solar
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
              AND airtable.tech_type_desc ILIKE '%Multiple source%'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_SOLAR'
              AND (
                airtable.generation_or_consumption_country_nm ILIKE 'Japan'
                OR log_tbl.location_name ILIKE '%Japan%'
              ) THEN 'Green Power Purchase - Retail Supply - Solar'
              -- Green Power Purchase (Retail Supply) for Wind
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
              AND airtable.tech_type_desc ILIKE '%Multiple source%'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_WIND'
              AND (
                airtable.generation_or_consumption_country_nm ILIKE 'Japan'
                OR log_tbl.location_name ILIKE '%Japan%'
              ) THEN 'Green Power Purchase - Retail Supply - Wind'
              -- Green Power Purchase (Retail Supply) for Geothermal
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
              AND airtable.tech_type_desc ILIKE '%Multiple source%'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_GEOTHERMAL'
              AND (
                airtable.generation_or_consumption_country_nm ILIKE 'Japan'
                OR log_tbl.location_name ILIKE '%Japan%'
              ) THEN 'Green Power Purchase - Retail Supply - Geothermal'
              -- Green Power Purchase (Retail Supply) for Small Hydroelectric
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
              AND airtable.tech_type_desc ILIKE '%Multiple source%'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_HYDROPOWER'
              AND (
                airtable.generation_or_consumption_country_nm ILIKE 'Japan'
                OR log_tbl.location_name ILIKE '%Japan%'
              ) THEN 'Green Power Purchase - Retail Supply - Small Hydroelectric'
              --Green Power Purchase (Retail Supply) for Solar (Cost-based)
              WHEN airtable.sourcing_method_desc ILIKE 'Green Power Purchase (retail supply)'
              AND airtable.tech_type_desc ILIKE '%Multiple source%'
              AND log_tbl.PARENT ILIKE 'REC_AMOUNT_SOLAR_WIND'
              AND (
                airtable.generation_or_consumption_country_nm ILIKE 'Japan'
                OR log_tbl.location_name ILIKE '%Japan%'
              ) THEN 'Green Power Purchase - Retail Supply Mix'
              ELSE NULL
            END AS SERVICE_TYPE_CD,
            CAST(12 AS INTEGER) AS DATA_FREQUENCY_CD,
            CASE
              WHEN log_tbl.PARENT IN (
                'OFFSITE_WIND_CONSUMPTION',
                'ONSITE_SOLAR_CONSUMPTION',
                'ONSITE_SOLAR_GENERATION',
                'ONSITE_WIND_CONSUMPTION',
                'ONSITE_WIND_GENERATION',
                'PURCHASED_ELECTRICITY_SCOPE2',
                'REC_AMOUNT_BIOMASS_EMITTED',
                'REC_AMOUNT_GEOTHERMAL',
                'REC_AMOUNT_HYDROPOWER',
                'REC_AMOUNT_SOLAR',
                'REC_AMOUNT_SOLAR_WIND',
                'REC_AMOUNT_WIND',
                'SURPLUS_ONSITE_SOLAR_GENERATION',
                'SURPLUS_ONSITE_WIND_GENERATION'
              ) THEN log_tbl.VALUE
              ELSE NULL
            END AS SERVICE_USAGE_QTY,
            CASE
              WHEN log_tbl.PARENT IN (
                'OFFSITE_WIND_CONSUMPTION',
                'ONSITE_SOLAR_CONSUMPTION',
                'ONSITE_SOLAR_GENERATION',
                'ONSITE_WIND_CONSUMPTION',
                'ONSITE_WIND_GENERATION',
                'PURCHASED_ELECTRICITY_SCOPE2',
                'REC_AMOUNT_BIOMASS_EMITTED',
                'REC_AMOUNT_GEOTHERMAL',
                'REC_AMOUNT_HYDROPOWER',
                'REC_AMOUNT_SOLAR',
                'REC_AMOUNT_SOLAR_WIND',
                'REC_AMOUNT_WIND',
                'SURPLUS_ONSITE_SOLAR_GENERATION',
                'SURPLUS_ONSITE_WIND_GENERATION'
              ) THEN log_tbl.UNIT
              ELSE NULL
            END AS SERVICE_USAGE_QTY_UOM,
            CASE
              WHEN log_tbl.PARENT IN ('COST_PURCHASED_ELECTRICITY_SCOPE2') THEN log_tbl.VALUE
              ELSE NULL
            END AS SERVICE_COST,
            CASE
              WHEN log_tbl.PARENT IN ('COST_PURCHASED_ELECTRICITY_SCOPE2') THEN log_tbl.CURRENCY
              ELSE NULL
            END AS SERVICE_COST_UOM,
            'FALSE' AS extrapolation_ind,
            CASE
              WHEN log_tbl.PARENT IN (
                'COST_PURCHASED_ELECTRICITY_SCOPE2',
                'OFFSITE_WIND_CONSUMPTION',
                'ONSITE_SOLAR_CONSUMPTION',
                'ONSITE_SOLAR_GENERATION',
                'ONSITE_WIND_CONSUMPTION',
                'ONSITE_WIND_GENERATION',
                'PURCHASED_ELECTRICITY_SCOPE2',
                'REC_AMOUNT_BIOMASS_EMITTED',
                'REC_AMOUNT_GEOTHERMAL',
                'REC_AMOUNT_HYDROPOWER',
                'REC_AMOUNT_SOLAR',
                'REC_AMOUNT_SOLAR_WIND',
                'REC_AMOUNT_WIND',
                'SURPLUS_ONSITE_SOLAR_GENERATION',
                'SURPLUS_ONSITE_WIND_GENERATION'
              ) THEN 'SCOPE 2'
              ELSE NULL
            END AS scope_nbr,
            log_tbl.PARENT AS PARENT
          FROM
            {logec_table_name} log_tbl
            LEFT JOIN {calendar_table_name} cd ON TO_DATE(log_tbl.YEAR_MONTH, 'yyyy-MM') = CAST(cd.calendar_dt AS STRING)
            LEFT JOIN {node_table_name} node_tbl ON SUBSTRING(log_tbl.LOCATION_KEY, 4) = node_tbl.NODE_CODE
            LEFT JOIN AIR_TABLE_METRICS airtable ON log_tbl.LOCATION_KEY = airtable.location_nbr
            AND (
              (
                (
                  log_tbl.PARENT ilike '%PHOTOVOLTAIC%'
                  OR log_tbl.PARENT ilike '%SOLAR%'
                )
                AND airtable.tech_type_desc ilike '%solar%'
              )
              OR (
                log_tbl.PARENT ilike '%WIND_%'
                AND airtable.tech_type_desc ilike '%wind%'
              )
              OR (airtable.tech_type_desc ILIKE '%Multiple source%')
              OR (airtable.tech_type_desc ILIKE '%Geothermal%')
            )
          WHERE
            log_tbl.PARENT IN (
              'COST_PURCHASED_ELECTRICITY_SCOPE2',
              'OFFSITE_WIND_CONSUMPTION',
              'ONSITE_SOLAR_CONSUMPTION',
              'ONSITE_SOLAR_GENERATION',
              'ONSITE_WIND_CONSUMPTION',
              'ONSITE_WIND_GENERATION',
              'PURCHASED_ELECTRICITY_SCOPE2',
              'REC_AMOUNT_BIOMASS_EMITTED',
              'REC_AMOUNT_GEOTHERMAL',
              'REC_AMOUNT_HYDROPOWER',
              'REC_AMOUNT_SOLAR',
              'REC_AMOUNT_SOLAR_WIND',
              'REC_AMOUNT_WIND',
              'SURPLUS_ONSITE_SOLAR_GENERATION',
              'SURPLUS_ONSITE_WIND_GENERATION'
            )
        )
      SELECT
        ELECTRICITY_LOCATION_NBR,
        reporting_period_dt,
        brand_nm,
        BILLING_MONTH_START_DT,
        BILLING_MONTH_END_DT,
        -- BILLING_MONTH_DATE_RANGE_TXT,
        ELECTRICITY_LOCATION_NM,
        REPORTING_FISCAL_YEAR_NBR,
        REPORTING_FISCAL_QUARTER_NBR,
        REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
        REPORTING_CALENDAR_YEAR_NBR,
        REPORTING_MONTH_LONG_NM,
        REPORTING_MONTH_OF_YEAR_NBR,
        REPORTING_QUARTER_NBR,
        REPORTING_WEEK_OF_YEAR_NBR,
        building_id,
        COALESCE(SERVICE_TYPE_CD, service_tbl.SERVICE_TYPE) AS SERVICE_TYPE_CD, -- Added to get the service type from UMD table if not found in airtable
        DATA_FREQUENCY_CD,
        SERVICE_USAGE_QTY,
        SERVICE_USAGE_QTY_UOM,
        SERVICE_COST,
        SERVICE_COST_UOM,
        extrapolation_ind,
        scope_nbr
      FROM
        NON_NULL_DETAIL log_tbl
        LEFT JOIN {bcl_service_type} service_tbl ON log_tbl.ELECTRICITY_LOCATION_NBR = SUBSTRING(service_tbl.LOCATION_KEY, 4)
        AND log_tbl.ELECTRICITY_LOCATION_NM = COALESCE(service_tbl.NAME, service_tbl.LOCATION_NAME)
        AND log_tbl.PARENT = service_tbl.PARENT
      WHERE
        ELECTRICITY_LOCATION_NBR != 'ELC'
        OR (
          ELECTRICITY_LOCATION_NBR = 'ELC'
          AND SERVICE_TYPE_CD IS NOT NULL
        )
    )
  ),
  DETAILS_AGG AS (
    SELECT
      -- uuid_string('8e884ace-bee4-11e4-8dfc-aa07a5b093db', md5(concat(ELECTRICITY_LOCATION_NBR, ELECTRICITY_LOCATION_NM,brand_nm))) as ELECTRICITY_CONSUMPTION_UUID,
      ELECTRICITY_LOCATION_NBR,
      reporting_period_dt,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      -- BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRICITY_LOCATION_NM,
      INITCAP(brand_nm) AS brand_nm,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      building_id,
      SERVICE_TYPE_CD,
      DATA_FREQUENCY_CD,
      COALESCE(MAX(SERVICE_USAGE_QTY), MIN(SERVICE_USAGE_QTY)) AS SERVICE_USAGE_QTY,
      COALESCE(
        MAX(SERVICE_USAGE_QTY_UOM),
        MIN(SERVICE_USAGE_QTY_UOM)
      ) AS SERVICE_USAGE_QTY_UOM,
      CAST(
        COALESCE(MAX(SERVICE_COST), MIN(SERVICE_COST)) AS DECIMAL(38, 2)
      ) AS SERVICE_COST,
      COALESCE(MAX(SERVICE_COST_UOM), MIN(SERVICE_COST_UOM)) AS SERVICE_COST_UOM,
      extrapolation_ind,
      scope_nbr
    FROM
      UNION_DETAIL
    WHERE
      NOT (
        (
          electricity_location_nbr IN (
            SELECT
              SUBSTRING(DC_UMD.LOCATION_KEY, 4) AS location_key
            FROM
              DC_SITE_DETAIL_MAPPING DC_UMD
          )
        )
        AND SERVICE_TYPE_CD ILIKE 'ELECTRICITY'
      )
    GROUP BY
      -- ELECTRICITY_CONSUMPTION_UUID,
      ELECTRICITY_LOCATION_NBR,
      reporting_period_dt,
      brand_nm,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      -- BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRICITY_LOCATION_NM,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      building_id,
      SERVICE_TYPE_CD,
      DATA_FREQUENCY_CD,
      extrapolation_ind,
      scope_nbr
  )
SELECT
  -- ELECTRICITY_DETAIL.ELECTRICITY_CONSUMPTION_UUID,
  ELECTRICITY_DETAIL.ELECTRICITY_LOCATION_NBR AS electricity_location_nbr,
  ELECTRICITY_DETAIL.ELECTRICITY_LOCATION_NM AS electricity_location_nm,
  ELECTRICITY_DETAIL.reporting_period_dt AS reporting_period_dt,
  CASE
    WHEN ELECTRICITY_DETAIL.SERVICE_TYPE_CD ILIKE 'Electric' THEN 'Electricity'
    ELSE ELECTRICITY_DETAIL.SERVICE_TYPE_CD
  END AS SERVICE_TYPE_CD,
  MIN(ELECTRICITY_DETAIL.BILLING_MONTH_START_DT) AS BILLING_MONTH_START_DT,
  MAX(ELECTRICITY_DETAIL.BILLING_MONTH_END_DT) AS BILLING_MONTH_END_DT,
  CONCAT_WS(
    '-',
    DATE_FORMAT(
      MIN(ELECTRICITY_DETAIL.BILLING_MONTH_START_DT),
      'MM/dd/yyyy'
    ),
    DATE_FORMAT(
      MAX(ELECTRICITY_DETAIL.BILLING_MONTH_END_DT),
      'MM/dd/yyyy'
    )
  ) AS BILLING_MONTH_DATE_RANGE_TXT,
  -- ELECTRICITY_DETAIL.brand_nm,
  ELECTRICITY_DETAIL.REPORTING_FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
  ELECTRICITY_DETAIL.REPORTING_FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
  ELECTRICITY_DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  CAST(
    ELECTRICITY_DETAIL.REPORTING_CALENDAR_YEAR_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_CALENDAR_YEAR_NBR,
  ELECTRICITY_DETAIL.REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
  CAST(
    ELECTRICITY_DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_MONTH_OF_YEAR_NBR,
  CAST(
    ELECTRICITY_DETAIL.REPORTING_QUARTER_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_QUARTER_NBR,
  CAST(
    ELECTRICITY_DETAIL.REPORTING_WEEK_OF_YEAR_NBR AS DECIMAL(38, 0)
  ) AS REPORTING_WEEK_OF_YEAR_NBR,
  ELECTRICITY_DETAIL.building_id AS building_id,
  ELECTRICITY_DETAIL.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
  CAST(
    SUM(ELECTRICITY_DETAIL.SERVICE_USAGE_QTY) AS DECIMAL(38, 2)
  ) AS SERVICE_USAGE_QTY,
  INITCAP(
    COALESCE(
      MAX(ELECTRICITY_DETAIL.SERVICE_USAGE_QTY_UOM),
      MIN(ELECTRICITY_DETAIL.SERVICE_USAGE_QTY_UOM)
    )
  ) AS SERVICE_USAGE_QTY_UOM,
  CAST(
    SUM(ELECTRICITY_DETAIL.SERVICE_COST) AS DECIMAL(38, 2)
  ) AS SERVICE_COST,
  ELECTRICITY_DETAIL.SERVICE_COST_UOM,
  ELECTRICITY_DETAIL.extrapolation_ind,
  ELECTRICITY_DETAIL.scope_nbr,
  'logec' AS cost_usage_data_source_nm,
  'LOGEC' AS cost_usage_data_source_cd
FROM
  DETAILS_AGG ELECTRICITY_DETAIL
WHERE
  NOT (
    ELECTRICITY_DETAIL.electricity_location_nbr = '1089'
    AND ELECTRICITY_DETAIL.SERVICE_TYPE_CD IS NULL
  )
GROUP BY
  ELECTRICITY_DETAIL.electricity_location_nbr,
  ELECTRICITY_DETAIL.electricity_location_nm,
  ELECTRICITY_DETAIL.reporting_period_dt,
  ELECTRICITY_DETAIL.SERVICE_TYPE_CD,
  -- ELECTRICITY_DETAIL.brand_nm,
  ELECTRICITY_DETAIL.REPORTING_FISCAL_YEAR_NBR,
  ELECTRICITY_DETAIL.REPORTING_FISCAL_QUARTER_NBR,
  ELECTRICITY_DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  ELECTRICITY_DETAIL.REPORTING_CALENDAR_YEAR_NBR,
  ELECTRICITY_DETAIL.REPORTING_MONTH_LONG_NM,
  ELECTRICITY_DETAIL.REPORTING_MONTH_OF_YEAR_NBR,
  ELECTRICITY_DETAIL.REPORTING_QUARTER_NBR,
  ELECTRICITY_DETAIL.REPORTING_WEEK_OF_YEAR_NBR,
  ELECTRICITY_DETAIL.building_id,
  ELECTRICITY_DETAIL.DATA_FREQUENCY_CD,
  ELECTRICITY_DETAIL.SERVICE_COST_UOM,
  ELECTRICITY_DETAIL.extrapolation_ind,
  ELECTRICITY_DETAIL.scope_nbr
