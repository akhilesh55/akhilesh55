WITH
  BUILDING_COMBINE AS (
    SELECT
      CASE
        WHEN TRIM(
          SPLIT_PART (B_COMBINE.`"Tririga POS Store ID"`, '-', 2)
        ) = '' THEN NULL
        ELSE TRIM(
          SPLIT_PART (B_COMBINE.`"Tririga POS Store ID"`, '-', 2)
        )
      END AS derived_POS_Store_ID_column,
      B_COMBINE.`"Tririga POS Store ID"`,
      RIGHT(B_COMBINE.TRIRIGA_BUILDING_ID, 4) AS derived_BLDG_ID_column,
      B_COMBINE.TRIRIGA_BUILDING_ID,
      B_COMBINE.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
      B_COMBINE.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
      B_COMBINE.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
      B_COMBINE.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
      B_COMBINE.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
      B_COMBINE.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
      B_COMBINE.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
      B_COMBINE.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
      B_COMBINE.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
      B_COMBINE.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
      B_COMBINE.`"Building Type"` AS `"Building Type"`,
      B_COMBINE.`"Location Type"` AS `"Location Type"`,
      B_COMBINE.`"Nike Key City"` AS `"Nike Key City"`,
      B_COMBINE.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
      B_COMBINE.`"Business Group"` AS `"Business Group"`,
      B_COMBINE.`"Campus - Corporate Park"` AS `"Campus - Corporate Park"`,
      B_COMBINE.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
      B_COMBINE.CITY_CODE_MAIN AS CITY_CODE_MAIN,
      B_COMBINE.CONTINENT_CODE AS CONTINENT_CODE,
      B_COMBINE.CONTINENT_NAME AS CONTINENT_NAME,
      B_COMBINE.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
      B_COMBINE.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
      B_COMBINE.LOCATION_REGION AS LOCATION_REGION,
      B_COMBINE.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
      B_COMBINE.`"NIKE GEO"` AS `"NIKE GEO"`,
      B_COMBINE.`"Primary Use"` AS `"Primary Use"`,
      B_COMBINE.REPORT_DATE AS REPORT_DATE,
      B_COMBINE.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
      B_COMBINE.STATE_PROV_MAIN AS STATE_PROV_MAIN,
      B_COMBINE.STATE_CODE_MAIN AS STATE_CODE_MAIN,
      B_COMBINE.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
      B_COMBINE.`"Tririga Brand"` AS `"Tririga Brand"`,
      B_COMBINE.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
      -- B_COMBINE.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
      B_COMBINE.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
      B_COMBINE.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
      B_COMBINE.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
      B_COMBINE.`"Tririga Contract Status"` AS `"Tririga Contract Status"`,
      B_COMBINE.TRIRIGA_GEO AS TRIRIGA_GEO,
      B_COMBINE.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
      B_COMBINE.LATITUDE_MAIN AS LATITUDE_MAIN,
      B_COMBINE.LONGITUDE_MAIN AS LONGITUDE_MAIN,
      B_COMBINE.`"Tririga GIS LAT"` AS `"Tririga GIS LAT"`,
      B_COMBINE.`"Tririga GIS LON"` AS `"Tririga GIS LON"`,
      -- B_COMBINE.`Tririga POS Store ID` AS `Tririga POS Store ID"`,
      B_COMBINE.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
      B_COMBINE.TRIRIGA_ZIP_POSTAL_CODE AS TRIRIGA_ZIP_POSTAL_CODE,
      B_COMBINE.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
      B_COMBINE.WDC_REGION_MAIN AS WDC_REGION_MAIN,
      B_COMBINE.`"Zip Code Main"` AS `"Zip Code Main"`,
      B_COMBINE.ARCHIBUS_USF AS ARCHIBUS_USF,
      B_COMBINE.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
      B_COMBINE.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      B_COMBINE.`"Max. Bldg. Capacity"` AS `"Max. Bldg. Capacity"`,
      B_COMBINE.`"Number of Floors"` AS `"Number of Floors"`,
      ROW_NUMBER() OVER (
        PARTITION BY
          B_COMBINE.BUILDING_CODE_MAIN,
          B_COMBINE.`"Tririga POS Store ID"`
          -- B_COMBINE.BUILDING_USF_MAIN
        ORDER BY
          B_COMBINE.report_date DESC
      ) AS COMBINE_PART
    FROM
      BUILDING_TABLE_NAME B_COMBINE
    WHERE
      B_COMBINE.`"NIKE GEO"` = 'EMEA'
      -- AND B_COMBINE.DISPLAY_LATEST_MAIN='LATEST'
  ),
  ELECTRICITY_USAGE_METRICS AS (
    SELECT
      REGEXP_EXTRACT(METRICS.client_site_ref_id, '\\d+', 0) AS derived_KEY,
      METRICS.site_address_company_nm,
      METRICS.site_nm,
      METRICS.client_site_ref_id,
      METRICS.league_nm,
      METRICS.subleague_nm,
      METRICS.concept_nm,
      METRICS.street_txt,
      YEAR(TO_DATE(start_dt, 'dd/MM/yyyy')) AS yrs_nbr,
      MONTH(TO_DATE(start_dt, 'dd/MM/yyyy')) AS mos_nbr,
      DAY(TO_DATE(start_dt, 'dd/MM/yyyy')) AS dayy,
      METRICS.city_nm,
      METRICS.zip_cd,
      METRICS.subleague_nm,
      METRICS.location_latitude_deg,
      METRICS.location_longitude_deg,
      METRICS.store_nm,
      METRICS.country_nm,
      METRICS.site_size_in_sqft,
      METRICS.start_dt,
      METRICS.end_dt,
      METRICS.site_status_Ind_cd,
      METRICS.utility_type_nm,
      METRICS.energy_unit_in_kwh,
      METRICS.invoiced_cost,
      METRICS.invoiced_usage_qty,
      METRICS.currency_cd
      -- METRICS.load_dt,
      -- METRICS.load_month_nbr,
      -- METRICS.load_year_nbr,
      -- METRICS.created_at_tmst,
      -- METRICS.user_nm
      -- METRICS.job_nm,
      -- METRICS.job_run_id
    FROM
      {curated_table_name} METRICS MINUS
    SELECT
      REGEXP_EXTRACT(METRICS.client_site_ref_id, '\\d+', 0) AS derived_KEY,
      METRICS.site_address_company_nm,
      METRICS.site_nm,
      METRICS.client_site_ref_id,
      METRICS.league_nm,
      METRICS.subleague_nm,
      METRICS.concept_nm,
      METRICS.street_txt,
      YEAR(TO_DATE(start_dt, 'dd/MM/yyyy')) AS yrs_nbr,
      MONTH(TO_DATE(start_dt, 'dd/MM/yyyy')) AS mos_nbr,
      DAY(TO_DATE(start_dt, 'dd/MM/yyyy')) AS dayy,
      METRICS.city_nm,
      METRICS.zip_cd,
      METRICS.subleague_nm,
      METRICS.location_latitude_deg,
      METRICS.location_longitude_deg,
      METRICS.store_nm,
      METRICS.country_nm,
      METRICS.site_size_in_sqft,
      METRICS.start_dt,
      METRICS.end_dt,
      METRICS.site_status_Ind_cd,
      METRICS.utility_type_nm,
      METRICS.energy_unit_in_kwh,
      METRICS.invoiced_cost,
      METRICS.invoiced_usage_qty,
      METRICS.currency_cd
    FROM
      {curated_table_name_rejects} METRICS
  ),
  DETAIL_INTEGRATION AS (
    SELECT DISTINCT
      curated_tbl.client_site_ref_id AS electricity_location_nbr,
      curated_tbl.site_nm AS electricity_location_nm,
      REGEXP_EXTRACT(curated_tbl.client_site_ref_id, '\\d+', 0) AS derived_KEY,
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm,
      curated_tbl.client_site_ref_id,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.concept_nm,
      curated_tbl.street_txt,
      curated_tbl.yrs_nbr,
      curated_tbl.mos_nbr,
      curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.subleague_nm,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt AS BILLING_MONTH_START_DT,
      curated_tbl.end_dt AS BILLING_MONTH_END_DT,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh AS SERVICE_USAGE_QTY_UOM,
      curated_tbl.invoiced_cost AS SERVICE_COST,
      curated_tbl.invoiced_usage_qty AS SERVICE_USAGE_QTY,
      curated_tbl.currency_cd AS SERVICE_COST_UOM,
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm,
      NULL AS lease_nbr,
      12 AS DATA_FREQUENCY_CD,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Nike Offices%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Offices%' THEN 'NON-RETAIL'
        ELSE 'RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Converse-Nike Office%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IN ('NVS', 'CFS') THEN 'Retail Factory'
        WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Local Office'
        WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Local Office'
        WHEN curated_tbl.concept_nm IS NULL
        AND building_tbl.`"Primary Use"` = 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IS NULL
        AND building_tbl.`"Primary Use"` IN ('NVS', 'NFS', 'CFS') THEN 'Retail Factory'
        WHEN building_tbl.`"Primary Use"` LIKE '%EHQ%' THEN 'Main HQ'
        ELSE 'Retail Factory'
      END AS nike_department_type_txt,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.concept_nm IN ("NSO", 'NVS') THEN 'DTC (N)'
        WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'DTC (C)'
        WHEN curated_tbl.concept_nm LIKE 'Converse%'
        OR curated_tbl.concept_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
        ELSE 'DTC (N)'
      END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      CASE
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline (N)'
        WHEN curated_tbl.concept_nm IN ('NVS') THEN 'Retail Factory (N)'
        WHEN curated_tbl.concept_nm IN ('CFS') THEN 'Retail Factory (C)'
        WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Other Facilities (N)'
        WHEN curated_tbl.concept_nm LIKE 'NIKE%'
        AND building_tbl.`"Primary Use"` IN ("NVS", "NFS") THEN 'Retail Factory(N)'
        WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'Retail Factory(C)'
        WHEN curated_tbl.concept_nm LIKE '%EHQ%' THEN 'Headquarters (N)'
        WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Other Facilities (C)'
        ELSE 'Retail Factory (N)'
      END AS division_nm,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.street_txt
      ) AS ADDRESS_LINE_1_TXT,
      curated_tbl.city_nm AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.subleague_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.zip_cd
      ) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(
          building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
          curated_tbl.zip_cd
        ),
        COALESCE(building_tbl.CITY_CODE_MAIN, curated_tbl.city_nm)
      ) AS geographical_axis_nm,
      building_tbl.COUNTRY_CODE_MAIN AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.site_size_in_sqft
      ) AS LOCATION_AREA_IN_SQFT,
      curated_tbl.site_status_Ind_cd AS LOCATION_STATUS_CD,
      building_tbl.LATITUDE_MAIN AS latitude_deg,
      building_tbl.LONGITUDE_MAIN AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      COALESCE(cd.YEAR_NBR, 0) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(cd.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      COALESCE(cd.MONTH_OF_YEAR_NBR, 0) AS REPORTING_MONTH_OF_YEAR_NBR,
      COALESCE(cd.QUARTER_NBR, 0) AS REPORTING_QUARTER_NBR,
      COALESCE(cd.WEEK_OF_YEAR_NBR, 0) AS REPORTING_WEEK_OF_YEAR_NBR,
      TO_DATE(
        CONCAT(
          curated_tbl.yrs_nbr,
          '-',
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electric' AS SERVICE_TYPE_CD,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_tbl.yrs_nbr,
              '-',
              LPAD(curated_tbl.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_tbl.yrs_nbr,
                  '-',
                  LPAD(curated_tbl.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT
    FROM
      ELECTRICITY_USAGE_METRICS curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) = building_tbl.derived_POS_Store_ID_column
      LEFT JOIN {calendar_table_name} AS cd ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_tbl.yrs_nbr,
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = cd.calendar_dt
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      AND LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) IS NOT NULL
      AND curated_tbl.site_nm NOT LIKE '%Converse%'
    UNION ALL
    SELECT DISTINCT
      curated_tbl.client_site_ref_id AS electricity_location_nbr,
      curated_tbl.site_nm AS electricity_location_nm,
      REGEXP_EXTRACT(curated_tbl.client_site_ref_id, '\\d+', 0) AS derived_KEY,
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm,
      curated_tbl.client_site_ref_id,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.concept_nm,
      curated_tbl.street_txt,
      curated_tbl.yrs_nbr,
      curated_tbl.mos_nbr,
      curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.subleague_nm,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt AS BILLING_MONTH_START_DT,
      curated_tbl.end_dt AS BILLING_MONTH_END_DT,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh AS SERVICE_USAGE_QTY_UOM,
      curated_tbl.invoiced_cost AS SERVICE_COST,
      curated_tbl.invoiced_usage_qty AS SERVICE_USAGE_QTY,
      curated_tbl.currency_cd AS SERVICE_COST_UOM,
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm,
      NULL AS lease_nbr,
      12 AS DATA_FREQUENCY_CD,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Nike Offices%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Offices%' THEN 'NON-RETAIL'
        ELSE 'RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Converse-Nike Office%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IN ('NVS', 'CFS') THEN 'Retail Factory'
        WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Local Office'
        WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Local Office'
        WHEN curated_tbl.concept_nm IS NULL
        AND building_tbl.`"Primary Use"` = 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IS NULL
        AND building_tbl.`"Primary Use"` IN ('NVS', 'NFS', 'CFS') THEN 'Retail Factory'
        WHEN building_tbl.`"Primary Use"` LIKE '%EHQ%' THEN 'Main HQ'
        ELSE 'Retail Factory'
      END AS nike_department_type_txt,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.concept_nm IN ("NSO", 'NVS') THEN 'DTC (N)'
        WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'DTC (C)'
        WHEN curated_tbl.concept_nm LIKE 'Converse%'
        OR curated_tbl.concept_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
        ELSE 'DTC (N)'
      END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      CASE
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline (N)'
        WHEN curated_tbl.concept_nm IN ('NVS') THEN 'Retail Factory (N)'
        WHEN curated_tbl.concept_nm IN ('CFS') THEN 'Retail Factory (C)'
        WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Other Facilities (N)'
        WHEN curated_tbl.concept_nm LIKE 'NIKE%'
        AND building_tbl.`"Primary Use"` IN ("NVS", "NFS") THEN 'Retail Factory(N)'
        WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'Retail Factory(C)'
        WHEN curated_tbl.concept_nm LIKE '%EHQ%' THEN 'Headquarters (N)'
        WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Other Facilities (C)'
        ELSE 'Retail Factory (N)'
      END AS division_nm,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.street_txt
      ) AS ADDRESS_LINE_1_TXT,
      curated_tbl.city_nm AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.subleague_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.zip_cd
      ) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(
          building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
          curated_tbl.zip_cd
        ),
        COALESCE(building_tbl.CITY_CODE_MAIN, curated_tbl.city_nm)
      ) AS geographical_axis_nm,
      building_tbl.COUNTRY_CODE_MAIN AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.site_size_in_sqft
      ) AS LOCATION_AREA_IN_SQFT,
      curated_tbl.site_status_Ind_cd AS LOCATION_STATUS_CD,
      building_tbl.LATITUDE_MAIN AS latitude_deg,
      building_tbl.LONGITUDE_MAIN AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      COALESCE(cd.YEAR_NBR, 0) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(cd.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      COALESCE(cd.MONTH_OF_YEAR_NBR, 0) AS REPORTING_MONTH_OF_YEAR_NBR,
      COALESCE(cd.QUARTER_NBR, 0) AS REPORTING_QUARTER_NBR,
      COALESCE(cd.WEEK_OF_YEAR_NBR, 0) AS REPORTING_WEEK_OF_YEAR_NBR,
      TO_DATE(
        CONCAT(
          curated_tbl.yrs_nbr,
          '-',
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electric' AS SERVICE_TYPE_CD,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_tbl.yrs_nbr,
              '-',
              LPAD(curated_tbl.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_tbl.yrs_nbr,
                  '-',
                  LPAD(curated_tbl.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT
    FROM
      ELECTRICITY_USAGE_METRICS curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) = RIGHT(building_tbl.TRIRIGA_BUILDING_ID, 4)
      LEFT JOIN {calendar_table_name} AS cd ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_tbl.yrs_nbr,
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = cd.calendar_dt
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      AND LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) IS NOT NULL
      AND curated_tbl.site_nm LIKE '%Converse%'
    UNION ALL
    SELECT DISTINCT
      curated_tbl.client_site_ref_id AS electricity_location_nbr,
      curated_tbl.site_nm AS electricity_location_nm,
      REGEXP_EXTRACT(curated_tbl.client_site_ref_id, '\\d+', 0) AS derived_KEY,
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm,
      curated_tbl.client_site_ref_id,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.concept_nm,
      curated_tbl.street_txt,
      curated_tbl.yrs_nbr,
      curated_tbl.mos_nbr,
      curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.subleague_nm,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt AS BILLING_MONTH_START_DT,
      curated_tbl.end_dt AS BILLING_MONTH_END_DT,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh AS SERVICE_USAGE_QTY_UOM,
      curated_tbl.invoiced_cost AS SERVICE_COST,
      curated_tbl.invoiced_usage_qty AS SERVICE_USAGE_QTY,
      curated_tbl.currency_cd AS SERVICE_COST_UOM,
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm,
      NULL AS lease_nbr,
      12 AS DATA_FREQUENCY_CD,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Nike Offices%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Offices%' THEN 'NON-RETAIL'
        ELSE 'RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Converse-Nike Office%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IN ('NVS', 'CFS') THEN 'Retail Factory'
        WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Local Office'
        WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Local Office'
        WHEN curated_tbl.concept_nm IS NULL
        AND building_tbl.`"Primary Use"` = 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IS NULL
        AND building_tbl.`"Primary Use"` IN ('NVS', 'NFS', 'CFS') THEN 'Retail Factory'
        WHEN building_tbl.`"Primary Use"` LIKE '%EHQ%' THEN 'Main HQ'
        ELSE 'Retail Factory'
      END AS nike_department_type_txt,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.concept_nm IN ("NSO", 'NVS') THEN 'DTC (N)'
        WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'DTC (C)'
        WHEN curated_tbl.concept_nm LIKE 'Converse%'
        OR curated_tbl.concept_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
        ELSE 'DTC (N)'
      END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      CASE
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline (N)'
        WHEN curated_tbl.concept_nm IN ('NVS') THEN 'Retail Factory (N)'
        WHEN curated_tbl.concept_nm IN ('CFS') THEN 'Retail Factory (C)'
        WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Other Facilities (N)'
        WHEN curated_tbl.concept_nm LIKE 'NIKE%'
        AND building_tbl.`"Primary Use"` IN ("NVS", "NFS") THEN 'Retail Factory(N)'
        WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'Retail Factory(C)'
        WHEN curated_tbl.concept_nm LIKE '%EHQ%' THEN 'Headquarters (N)'
        WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Other Facilities (C)'
        ELSE 'Retail Factory (N)'
      END AS division_nm,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.street_txt
      ) AS ADDRESS_LINE_1_TXT,
      curated_tbl.city_nm AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.subleague_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.zip_cd
      ) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(
          building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
          curated_tbl.zip_cd
        ),
        COALESCE(building_tbl.CITY_CODE_MAIN, curated_tbl.city_nm)
      ) AS geographical_axis_nm,
      building_tbl.COUNTRY_CODE_MAIN AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.site_size_in_sqft
      ) AS LOCATION_AREA_IN_SQFT,
      curated_tbl.site_status_Ind_cd AS LOCATION_STATUS_CD,
      building_tbl.LATITUDE_MAIN AS latitude_deg,
      building_tbl.LONGITUDE_MAIN AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      COALESCE(cd.YEAR_NBR, 0) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(cd.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      COALESCE(cd.MONTH_OF_YEAR_NBR, 0) AS REPORTING_MONTH_OF_YEAR_NBR,
      COALESCE(cd.QUARTER_NBR, 0) AS REPORTING_QUARTER_NBR,
      COALESCE(cd.WEEK_OF_YEAR_NBR, 0) AS REPORTING_WEEK_OF_YEAR_NBR,
      TO_DATE(
        CONCAT(
          curated_tbl.yrs_nbr,
          '-',
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electric' AS SERVICE_TYPE_CD,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_tbl.yrs_nbr,
              '-',
              LPAD(curated_tbl.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_tbl.yrs_nbr,
                  '-',
                  LPAD(curated_tbl.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT
    FROM
      ELECTRICITY_USAGE_METRICS curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON REGEXP_SUBSTR (
        curated_tbl.client_site_ref_id,
        '^[a-zA-Z][a-zA-Z0-9-_]*'
      ) = building_tbl.TRIRIGA_BUILDING_ID
      LEFT JOIN {calendar_table_name} AS cd ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_tbl.yrs_nbr,
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = cd.calendar_dt
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      AND REGEXP_SUBSTR (
        curated_tbl.client_site_ref_id,
        '^[a-zA-Z][a-zA-Z0-9-_]*'
      ) IS NOT NULL
  ),
  FINAL_AGG AS (
    SELECT DISTINCT
      ELECTRIC_DETAIL.electricity_location_nbr AS electricity_location_nbr,
      ELECTRIC_DETAIL.electricity_location_nm AS electricity_location_nm,
      CAST(ELECTRIC_DETAIL.reporting_period_dt AS DATE) AS reporting_period_dt,
      CASE
        WHEN ELECTRIC_DETAIL.SERVICE_TYPE_CD ILIKE 'Electric' THEN 'Electricity'
        ELSE ELECTRIC_DETAIL.SERVICE_TYPE_CD
      END AS SERVICE_TYPE_CD,
      TO_DATE(
        COALESCE(
          ELECTRIC_DETAIL.BILLING_MONTH_START_DT,
          DATE_TRUNC(
            'MONTH',
            TO_DATE(ELECTRIC_DETAIL.reporting_period_dt)
          )
        ),
        'dd/MM/yyyy'
      ) AS BILLING_MONTH_START_DT,
      TO_DATE(
        COALESCE(
          ELECTRIC_DETAIL.BILLING_MONTH_END_DT,
          DATE_FORMAT(
            LAST_DAY(
              ADD_MONTHS(TO_DATE(ELECTRIC_DETAIL.reporting_period_dt), 1)
            ),
            'dd/MM/yyyy'
          )
        ),
        'dd/MM/yyyy'
      ) AS BILLING_MONTH_END_DT,
      CONCAT_WS(
        '-',
        ELECTRIC_DETAIL.BILLING_MONTH_START_DT,
        ELECTRIC_DETAIL.BILLING_MONTH_END_DT
      ) AS BILLING_MONTH_DATE_RANGE_TXT,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_CALENDAR_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
      CAST(
        ELECTRIC_DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_MONTH_OF_YEAR_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_QUARTER_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_QUARTER_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_WEEK_OF_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL.building_id AS building_id,
      ELECTRIC_DETAIL.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
      CAST(
        ELECTRIC_DETAIL.SERVICE_USAGE_QTY AS DECIMAL(38, 2)
      ) AS SERVICE_USAGE_QTY,
      INITCAP(ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM) AS SERVICE_USAGE_QTY_UOM,
      CAST(ELECTRIC_DETAIL.SERVICE_COST AS DECIMAL(38, 2)) AS SERVICE_COST,
      /* Adding this fix for SERVICE_COST_UOM, as highlighted by end users */
      CASE
        WHEN ELECTRIC_DETAIL.SERVICE_COST_UOM = 'GPB' THEN 'GBP'
        ELSE ELECTRIC_DETAIL.SERVICE_COST_UOM
      END AS SERVICE_COST_UOM,
      ELECTRIC_DETAIL.extrapolation_ind AS extrapolation_ind,
      ELECTRIC_DETAIL.scope_nbr AS scope_nbr,
      ELECTRIC_DETAIL.cost_usage_data_source_nm AS cost_usage_data_source_nm
    FROM
      DETAIL_INTEGRATION ELECTRIC_DETAIL
  )
SELECT
  electricity_location_nbr,
  electricity_location_nm,
  reporting_period_dt,
  SERVICE_TYPE_CD,
  BILLING_MONTH_START_DT,
  BILLING_MONTH_END_DT,
  BILLING_MONTH_DATE_RANGE_TXT,
  building_id,
  REPORTING_FISCAL_YEAR_NBR,
  REPORTING_FISCAL_QUARTER_NBR,
  REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  REPORTING_CALENDAR_YEAR_NBR,
  REPORTING_MONTH_LONG_NM,
  REPORTING_MONTH_OF_YEAR_NBR,
  REPORTING_QUARTER_NBR,
  REPORTING_WEEK_OF_YEAR_NBR,
  DATA_FREQUENCY_CD,
  SUM(SERVICE_USAGE_QTY) AS SERVICE_USAGE_QTY,
  SERVICE_USAGE_QTY_UOM,
  CAST(SUM(SERVICE_COST) AS DECIMAL(38, 2)) AS SERVICE_COST,
  SERVICE_COST_UOM,
  extrapolation_ind,
  scope_nbr,
  cost_usage_data_source_nm
FROM
  FINAL_AGG
GROUP BY
  electricity_location_nbr,
  electricity_location_nm,
  reporting_period_dt,
  SERVICE_TYPE_CD,
  BILLING_MONTH_START_DT,
  BILLING_MONTH_END_DT,
  BILLING_MONTH_DATE_RANGE_TXT,
  building_id,
  REPORTING_FISCAL_YEAR_NBR,
  REPORTING_FISCAL_QUARTER_NBR,
  REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  REPORTING_CALENDAR_YEAR_NBR,
  REPORTING_MONTH_LONG_NM,
  REPORTING_MONTH_OF_YEAR_NBR,
  REPORTING_QUARTER_NBR,
  REPORTING_WEEK_OF_YEAR_NBR,
  DATA_FREQUENCY_CD,
  SERVICE_USAGE_QTY_UOM,
  SERVICE_COST_UOM,
  extrapolation_ind,
  scope_nbr,
  cost_usage_data_source_nm;
