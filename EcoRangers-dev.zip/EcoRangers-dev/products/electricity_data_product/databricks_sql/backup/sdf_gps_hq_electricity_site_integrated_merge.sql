WITH
  BUILDING_COMBINE AS (
    SELECT DISTINCT
      DISPLAY_LATEST_MAIN,
      BUILDING_ADDRESS_MAIN,
      CASE
        WHEN CAMPUS_NAME_MAIN = 'WHQ' THEN 'OWNED'
        ELSE BUILDING_STATUS_MAIN
      END AS BUILDING_STATUS_MAIN,
      BUSINESS_GROUP_MAIN,
      CASE
        WHEN CAMPUS_NAME_MAIN IN ('WHQ', 'GCHQ') THEN 'OFFICE'
        WHEN CAMPUS_NAME_MAIN = 'EHQ' THEN 'FREESTYLE OFFICE'
        ELSE 'OTHERS'
      END AS BUILDING_USE_MAIN,
      `"Business Group"` AS Business_Group,
      CAMPUS_NAME_MAIN,
      CITY_CODE_MAIN,
      CONTINENT_NAME,
      COUNTRY_CODE_MAIN,
      COUNTRY_NAME_MAIN,
      LOCATION_REGION,
      `"NIKE GEO"`,
      `"Primary Use"`,
      STATE_CODE_MAIN,
      `"Tririga Brand"`,
      latitude_main,
      longitude_main,
      `"Zip Code Main"` AS ZIP_CODE_MAIN,
      CONCAT(`"Zip Code Main"`, '-', CITY_CODE_MAIN) AS GEOGRAPHICAL_AXIS_NM
    FROM
      building_table_name
    WHERE
      (
        CAMPUS_NAME_MAIN IN ('WHQ', 'Converse')
        AND BUILDING_ADDRESS_MAIN = 'ONE BOWERMAN DRIVE'
        AND `"Business Group"` LIKE '%NON-RETAIL'
        AND display_latest_main LIKE '%LATEST'
        AND `"Zip Code Main"` IS NOT NULL
      )
      OR (
        campus_name_main = 'GCHQ'
        AND BUILDING_ADDRESS_MAIN LIKE '%NO.99 JIANG WAN CHENG RD%'
        AND `"Business Group"` LIKE '%NON-RETAIL'
        AND display_latest_main LIKE '%LATEST'
        AND `"Zip Code Main"` IS NOT NULL
      )
      OR (
        campus_name_main = 'EHQ'
        AND BUILDING_ADDRESS_MAIN LIKE 'COLOSSEUM 1'
        AND `"Business Group"` LIKE '%NON-RETAIL'
        AND display_latest_main LIKE '%LATEST'
        AND `"Tririga Brand"` IS NOT NULL
        AND `"Zip Code Main"` = '1213NL'
      )
      OR (
        CONTEXT = 'WEEKLY'
        AND DISPLAY_LATEST_MAIN = 'LATEST'
        AND BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND CAMPUS_NAME_MAIN = 'ASIA'
        AND COUNTRY_NAME_MAIN = 'JAPAN'
        AND TRIRIGA_CONCEPT = 'HQ'
      ) QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          CAMPUS_NAME_MAIN
        ORDER BY
          LATITUDE_MAIN DESC
      ) = 1
    UNION
    SELECT DISTINCT
      DISPLAY_LATEST_MAIN,
      BUILDING_ADDRESS_MAIN,
      'OWNED' AS BUILDING_STATUS_MAIN,
      BUSINESS_GROUP_MAIN,
      'OFFICE' AS BUILDING_USE_MAIN,
      `"Business Group"` AS Business_Group,
      CASE
        WHEN DISPLAY_LATEST_MAIN = 'PAST' THEN 'Converse - Lovejoy HQ'
        ELSE 'Converse'
      END AS CAMPUS_NAME_MAIN,
      CITY_CODE_MAIN,
      CONTINENT_NAME,
      COUNTRY_CODE_MAIN,
      COUNTRY_NAME_MAIN,
      LOCATION_REGION,
      `"NIKE GEO"`,
      `"Primary Use"`,
      STATE_CODE_MAIN,
      `"Tririga Brand"`,
      LATITUDE_MAIN,
      LONGITUDE_MAIN,
      `"Zip Code Main"` AS ZIP_CODE_MAIN,
      CONCAT(`"Zip Code Main"`, '-', CITY_CODE_MAIN) AS GEOGRAPHICAL_AXIS_NM
    FROM
      building_table_name
    WHERE
      (
        CAMPUS_NAME_MAIN IN ('WHQ')
        AND BUILDING_ADDRESS_MAIN = 'ONE BOWERMAN DRIVE'
        AND `"Business Group"` LIKE '%NON-RETAIL'
        -- AND display_latest_main like '%LATEST'
        AND `"Zip Code Main"` IS NOT NULL
      ) QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          CAMPUS_NAME_MAIN,
          DISPLAY_LATEST_MAIN
        ORDER BY
          LATITUDE_MAIN DESC
      ) < 3
  ),
  SITE_COMBINED AS (
    SELECT DISTINCT
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        /* SDF-3105: Commenting the below lines to not consider the EV consumption dataset from fleet sites, requirement from SDF-WHQ Team */
        -- when curated_tbl.headquarter_cd = 'WHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (WHQ)'
        -- when curated_tbl.headquarter_cd = 'GCHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (GCHQ)'
        -- when curated_tbl.headquarter_cd like '%Converse%' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'Converse HQ Fleet (WHQ)'
        -- when curated_tbl.headquarter_cd = 'EHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (EHQ)'
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'TMT'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'HQ (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'HQ (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'HQ (GCHQ)'
        -- when curated_tbl.headquarter_cd like '%Converse%' then 'HQ (Converse)' -- DATA render from engie source
        ELSE 'Others'
      END AS electricity_location_nbr,
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        /* SDF-3105: Commenting the below lines to not consider the EV consumption dataset from fleet sites, requirement from SDF-WHQ Team */
        -- when curated_tbl.headquarter_cd = 'WHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (WHQ)'
        -- -- Renaming Nike HQ Fleet - Greater China for Transportation to HQ Fleet (GCHQ) as per Pritha's suggestion from Enablon screenshots
        -- when curated_tbl.headquarter_cd = 'GCHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (GCHQ)'
        -- -----
        -- --- Renaming Nike HQ Fleet - Europe (EHQ) for Transportation to HQ Fleet (EHQ) as per Pritha's suggestion from Enablon screenshots
        -- when curated_tbl.headquarter_cd = 'EHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (EHQ)'
        -- ------
        -- when curated_tbl.headquarter_cd like '%Converse%' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'Converse HQ Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'Nike HQ - North America (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'Nike HQ - Europe (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'Nike HQ - Greater China (GCHQ)'
        -- when curated_tbl.headquarter_cd like '%Converse%' then 'Converse HQ - North America (WHQ)' -- DATA render from engie source
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'Tokyo Midtown Tower'
        ELSE 'Others'
      END AS electricity_location_nm,
      /* adding this below line to convert all the Japan headquarters to TMT to avoid duplicate records */
      CASE
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'Tokyo Midtown Tower'
        ELSE HEADQUARTER_CD
      END AS HEADQUARTERS,
      TO_DATE(
        CONCAT(
          '01',
          reporting_month_mos,
          SUBSTRING(reporting_fiscal_year_yrs, -4, 4)
        ),
        'ddMMyyyy'
      ) AS BILLING_MONTH_START_DT,
      COMBINED_SQUARE_FOOTAGE_SQFT AS SITE_SIZE
    FROM
      {curated_table_name} curated_tbl QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          HEADQUARTERS
        ORDER BY
          BILLING_MONTH_START_DT DESC
      ) = 1
  ),
  SITE_INTEGRATION AS (
    SELECT DISTINCT
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        /* SDF-3105: Commenting the below lines to not consider the EV consumption dataset from fleet sites, requirement from SDF-WHQ Team */
        -- when curated_tbl.headquarter_cd = 'WHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (WHQ)'
        -- when curated_tbl.headquarter_cd = 'GCHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (GCHQ)'
        -- when curated_tbl.headquarter_cd like '%Converse%' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'Converse HQ Fleet (WHQ)'
        -- when curated_tbl.headquarter_cd = 'EHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (EHQ)'
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'TMT'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'HQ (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'HQ (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'HQ (GCHQ)'
        WHEN curated_tbl.headquarter_cd LIKE '%Converse%' THEN 'Others' -- DATA render from engie source
        ELSE NULL
      END AS electricity_location_nbr,
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        /* SDF-3105: Commenting the below lines to not consider the EV consumption dataset from fleet sites, requirement from SDF-WHQ Team */
        -- when curated_tbl.headquarter_cd = 'WHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (WHQ)'
        -- -- Renaming Nike HQ Fleet - Greater China for Transportation to HQ Fleet (GCHQ) as per Pritha's suggestion from Enablon screenshots
        -- when curated_tbl.headquarter_cd = 'GCHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (GCHQ)'
        -- ----------
        -- -- Renaming Nike HQ Fleet - Europe (EHQ) for Transportation to HQ Fleet (EHQ) as per Pritha's suggestion from Enablon screenshots
        -- when curated_tbl.headquarter_cd = 'EHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (EHQ)'
        -- ----------
        -- when curated_tbl.headquarter_cd like '%Converse%' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'Converse HQ Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'Nike HQ - North America (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'Nike HQ - Europe (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'Nike HQ - Greater China (GCHQ)'
        WHEN curated_tbl.headquarter_cd LIKE '%Converse%' THEN 'Others' -- DATA render from engie source
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'Tokyo Midtown Tower'
        ELSE NULL
      END AS electricity_location_nm,
      NULL AS lease_nbr,
      NULL AS building_id,
      CASE
        WHEN headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            BUSINESS_GROUP
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE Business_Group
      END AS business_group_txt,
      CASE
        WHEN headquarter_cd IN (
          'WHQ',
          'EHQ',
          'GCHQ',
          'Japan',
          'Tokyo Midtown Tower'
        ) THEN 'Nike'
        WHEN headquarter_cd LIKE '%Converse%' THEN 'Converse'
      END AS brand_nm,
      CASE
      /* SDF-3105: using the electricity_usage_kwh, landlord and solar column to decide on headquarters dept_type_text to avoid unexpected headquarter results */
        WHEN (
          curated_tbl.team_desc IN ('Transportation', 'Security')
        ) THEN 'Transportation'
        WHEN headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'Other Facilities'
        WHEN (curated_tbl.electricity_usage_kwh IS NOT NULL)
        OR (curated_tbl.electricity_landlord_kwh IS NOT NULL)
        OR (curated_tbl.solar_generation_kwh IS NOT NULL) THEN 'Headquarters'
      END AS nike_department_type_txt,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN 'Asia'
        ELSE `"NIKE GEO"`
      END AS BUSINESS_ENTITY_GEO_REGION_CD,
      CASE
        WHEN curated_tbl.headquarter_cd IN (
          'WHQ',
          'Converse',
          'GCHQ',
          'Japan',
          'Tokyo Midtown Tower'
        ) THEN 'OFFICE'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'FREESTYLE OFFICE'
        ELSE building_use_main
      END AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.headquarter_cd LIKE '%Converse%' THEN 'WD+C (C)'
        ELSE 'WD+C (N)'
      END AS business_function_nm,
      /* SDF-3105: Changing the Division name logic to derive from headquarter code and brand_nm columns instead of vehicle_type_desc */
      CASE
        WHEN nike_department_type_txt = 'Headquarters'
        AND brand_nm = 'Nike' THEN 'Headquarters (N)'
        WHEN nike_department_type_txt = 'Headquarters'
        AND brand_nm = 'Converse' THEN 'Headquarters (C)'
        WHEN nike_department_type_txt = 'Transportation'
        AND brand_nm = 'Nike' THEN 'Fleet Vehicles (N)'
        WHEN nike_department_type_txt = 'Transportation'
        AND brand_nm = 'Converse' THEN 'Fleet Vehicles (C)'
        WHEN nike_department_type_txt = 'Other Facilities'
        AND brand_nm = 'Nike' THEN 'Other Facilities (N)'
        WHEN nike_department_type_txt = 'Other Facilities'
        AND brand_nm = 'Converse' THEN 'Other Facilities (C)'
      END AS division_nm,
      CASE
        WHEN headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            `"NIKE GEO"`
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE `"NIKE GEO"`
      END AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            CONTINENT_NAME
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE CONTINENT_NAME
      END AS continent_nm,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            building_address_main
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE building_address_main
      END AS ADDRESS_LINE_1_TXT,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            city_code_main
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE building_tbl.city_code_main
      END AS city_nm,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            STATE_CODE_MAIN
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE building_tbl.STATE_CODE_MAIN
      END AS STATE_CD,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            Zip_Code_Main
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE Zip_Code_Main
      END AS POSTAL_CD,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN (
          SELECT
            GEOGRAPHICAL_AXIS_NM
          FROM
            building_combine
          WHERE
            country_name_main ilike '%japan%'
        )
        ELSE GEOGRAPHICAL_AXIS_NM
      END AS geographical_axis_nm,
      CASE
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN 'JP'
        ELSE building_tbl.COUNTRY_CODE_MAIN
      END AS COUNTRY_CD,
      curated_tbl.combined_square_footage_sqft AS LOCATION_AREA,
      CASE
        WHEN curated_tbl.headquarter_cd IN ('WHQ', 'Converse') THEN 'OWNED'
        WHEN HEADQUARTER_CD IN ('Japan', 'Tokyo Midtown Tower') THEN 'LEASED'
        ELSE building_tbl.BUILDING_STATUS_MAIN
      END AS LOCATION_STATUS_CD,
      latitude_main AS latitude_deg,
      longitude_main AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC
    FROM
      {curated_table_name} curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON curated_tbl.HEADQUARTER_CD = building_tbl.CAMPUS_NAME_MAIN
  ),
  ELECTRICITY_SITE_COMBINED AS (
    SELECT
      A.electricity_location_nbr,
      A.electricity_location_nm,
      lease_nbr,
      building_id,
      business_group_txt,
      brand_nm,
      nike_department_type_txt,
      A.BUSINESS_ENTITY_GEO_REGION_CD,
      ELECTRICITY_LOCATION_USE_CD,
      business_function_nm,
      A.division_nm,
      LOCATION_GEO_REGION_CD,
      continent_nm,
      ADDRESS_LINE_1_TXT,
      city_nm,
      STATE_CD,
      POSTAL_CD,
      geographical_axis_nm,
      COUNTRY_CD,
      B.SITE_SIZE AS LOCATION_AREA,
      CASE
        WHEN LOCATION_STATUS_CD IN ('OWNED', 'LEASED') THEN 'Open'
        ELSE 'Close'
      END AS LOCATION_STATUS_CD,
      latitude_deg,
      longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC
    FROM
      SITE_INTEGRATION A
      LEFT JOIN SITE_COMBINED B ON A.ELECTRICITY_LOCATION_NBR = B.ELECTRICITY_LOCATION_NBR
      AND A.ELECTRICITY_LOCATION_NM = B.ELECTRICITY_LOCATION_NM QUALIFY ROW_NUMBER() OVER (
        PARTITION BY
          A.electricity_location_nbr,
          A.electricity_location_nm
        ORDER BY
          LOCATION_AREA DESC
      ) = 1
  )
SELECT DISTINCT
  ELECTRIC_SITE.electricity_location_nbr AS electricity_location_nbr,
  /* Changes suggested by Pritha, Nike GCHQ for GPS needs to be renamed to Greater China HeadQuarters */
  CASE
    WHEN ELECTRIC_SITE.electricity_location_nm = 'Nike HQ - Greater China (GCHQ)' THEN 'Greater China Headquarters'
    ELSE ELECTRIC_SITE.electricity_location_nm
  END AS electricity_location_nm,
  ELECTRIC_SITE.lease_nbr AS lease_nbr,
  ELECTRIC_SITE.building_id AS building_id,
  REGEXP_REPLACE(
    INITCAP(ELECTRIC_SITE.business_group_txt),
    '-',
    ' '
  ) AS business_group_txt,
  INITCAP(ELECTRIC_SITE.brand_nm) AS brand_nm,
  ELECTRIC_SITE.nike_department_type_txt AS nike_department_type_txt,
  CASE
    WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
    WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
    WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
    WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
    ELSE ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD
  END AS BUSINESS_ENTITY_GEO_REGION_CD,
  ELECTRIC_SITE.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
  ELECTRIC_SITE.business_function_nm AS business_function_nm,
  ELECTRIC_SITE.division_nm AS division_nm,
  CASE
    WHEN ELECTRIC_SITE.LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
    WHEN ELECTRIC_SITE.LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
    ELSE ELECTRIC_SITE.LOCATION_GEO_REGION_CD
  END AS LOCATION_GEO_REGION_CD,
  CASE
    WHEN ELECTRIC_SITE.continent_nm ILIKE 'EMEA' THEN 'Europe'
    WHEN ELECTRIC_SITE.continent_nm ILIKE 'APLA' THEN 'Asia'
    WHEN ELECTRIC_SITE.continent_nm ILIKE 'North America' THEN 'North America'
    WHEN ELECTRIC_SITE.continent_nm ILIKE 'Greater China' THEN 'Asia'
    ELSE ELECTRIC_SITE.continent_nm
  END AS continent_nm,
  ELECTRIC_SITE.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
  INITCAP(ELECTRIC_SITE.city_nm) AS city_nm,
  ELECTRIC_SITE.STATE_CD AS STATE_CD,
  ELECTRIC_SITE.POSTAL_CD AS POSTAL_CD,
  ELECTRIC_SITE.geographical_axis_nm AS geographical_axis_nm,
  CASE
    WHEN ELECTRIC_SITE.COUNTRY_CD ILIKE 'Canada' THEN 'CA'
    WHEN ELECTRIC_SITE.COUNTRY_CD ILIKE 'United States' THEN 'US'
    ELSE ELECTRIC_SITE.COUNTRY_CD
  END AS COUNTRY_CD,
  CAST(ELECTRIC_SITE.LOCATION_AREA AS DECIMAL(31, 5)) AS LOCATION_AREA,
  'Square foot' AS LOCATION_AREA_UOM,
  ELECTRIC_SITE.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
  ELECTRIC_SITE.latitude_deg AS latitude_deg,
  ELECTRIC_SITE.longitude_deg AS longitude_deg,
  ELECTRIC_SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
  'gps_usage_metrics' AS cost_usage_data_source_nm,
  'gps_usage_metrics' AS location_area_data_source_nm
FROM
  ELECTRICITY_SITE_COMBINED ELECTRIC_SITE
  /* Remove 'Others' category corresponding to Converse headquarter data which is already coming from engie data source, Removing EHQ data as it is already coming from MACE data source.*/
WHERE
  ELECTRIC_SITE.electricity_location_nbr NOT IN ('Others', 'HQ (EHQ)')
  AND ELECTRIC_SITE.electricity_location_nm NOT IN ('Others', 'Nike HQ - Europe (EHQ)')
  AND ELECTRIC_SITE.electricity_location_nbr IS NOT NULL
  AND ELECTRIC_SITE.electricity_location_nm IS NOT NULL;
