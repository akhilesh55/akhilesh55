WITH
  BUILDING_COMBINE AS (
    SELECT
      REGEXP_EXTRACT(B_COMBINE.`"Tririga POS Store ID"`, '\\d+', 0) AS derived_POS_Store_ID_column,
      B_COMBINE.`"Tririga POS Store ID"`,
      RIGHT(B_COMBINE.TRIRIGA_BUILDING_ID, 4) AS derived_BLDG_ID_column,
      B_COMBINE.TRIRIGA_BUILDING_ID,
      B_COMBINE.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
      B_COMBINE.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
      B_COMBINE.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
      B_COMBINE.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
      B_COMBINE.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
      B_COMBINE.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
      B_COMBINE.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
      B_COMBINE.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
      B_COMBINE.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
      B_COMBINE.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
      B_COMBINE.`"Building Type"` AS `"Building Type"`,
      B_COMBINE.`"Location Type"` AS `"Location Type"`,
      B_COMBINE.`"Nike Key City"` AS `"Nike Key City"`,
      B_COMBINE.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
      B_COMBINE.`"Business Group"` AS `"Business Group"`,
      B_COMBINE.`"Campus - Corporate Park"` AS `"Campus - Corporate Park"`,
      B_COMBINE.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
      B_COMBINE.CITY_CODE_MAIN AS CITY_CODE_MAIN,
      B_COMBINE.CONTINENT_CODE AS CONTINENT_CODE,
      B_COMBINE.CONTINENT_NAME AS CONTINENT_NAME,
      B_COMBINE.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
      B_COMBINE.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
      B_COMBINE.LOCATION_REGION AS LOCATION_REGION,
      B_COMBINE.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
      B_COMBINE.`"NIKE GEO"` AS `"NIKE GEO"`,
      B_COMBINE.`"Primary Use"` AS `"Primary Use"`,
      B_COMBINE.REPORT_DATE AS REPORT_DATE,
      B_COMBINE.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
      B_COMBINE.STATE_PROV_MAIN AS STATE_PROV_MAIN,
      B_COMBINE.STATE_CODE_MAIN AS STATE_CODE_MAIN,
      B_COMBINE.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
      B_COMBINE.`"Tririga Brand"` AS `"Tririga Brand"`,
      B_COMBINE.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
      -- B_COMBINE.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
      B_COMBINE.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
      B_COMBINE.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
      B_COMBINE.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
      B_COMBINE.`"Tririga Contract Status"` AS `"Tririga Contract Status"`,
      B_COMBINE.TRIRIGA_GEO AS TRIRIGA_GEO,
      B_COMBINE.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
      B_COMBINE.LATITUDE_MAIN AS LATITUDE_MAIN,
      B_COMBINE.LONGITUDE_MAIN AS LONGITUDE_MAIN,
      B_COMBINE.`"Tririga GIS LAT"` AS `"Tririga GIS LAT"`,
      B_COMBINE.`"Tririga GIS LON"` AS `"Tririga GIS LON"`,
      -- B_COMBINE.`Tririga POS Store ID` AS `Tririga POS Store ID"`,
      B_COMBINE.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
      B_COMBINE.TRIRIGA_ZIP_POSTAL_CODE AS TRIRIGA_ZIP_POSTAL_CODE,
      B_COMBINE.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
      B_COMBINE.WDC_REGION_MAIN AS WDC_REGION_MAIN,
      B_COMBINE.`"Zip Code Main"` AS `"Zip Code Main"`,
      B_COMBINE.ARCHIBUS_USF AS ARCHIBUS_USF,
      B_COMBINE.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
      B_COMBINE.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      B_COMBINE.`"Max. Bldg. Capacity"` AS `"Max. Bldg. Capacity"`,
      B_COMBINE.`"Number of Floors"` AS `"Number of Floors"`,
      DENSE_RANK() OVER (
        PARTITION BY
          B_COMBINE.BUILDING_CODE_MAIN
          -- B_COMBINE.BUILDING_USF_MAIN
        ORDER BY
          B_COMBINE.report_date DESC
      ) AS COMBINE_PART
    FROM
      BUILDING_TABLE_NAME B_COMBINE
    WHERE
      B_COMBINE.`"NIKE GEO"` = 'EMEA'
      --AND B_COMBINE.DISPLAY_LATEST_MAIN='LATEST'
  ),
  ELECTRICITY_USAGE_METRICS AS (
    SELECT
      REGEXP_EXTRACT(PROPERTY_NM, '\\d+', 0) AS derived_KEY,
      METRICS.PROPERTY_NM,
      METRICS.location_nm_latest,
      METRICS.location_nbr,
      METRICS.location_nbr_latest,
      METRICS.account_id,
      METRICS.cdd_nbr,
      METRICS.total_kwh,
      METRICS.delivery_kw_charges_cost,
      METRICS.universal_usage_uom,
      METRICS.days_in_billing_period_days,
      METRICS.currency_cd,
      METRICS.START_DT,
      METRICS.total_cost,
      METRICS.mos_nbr,
      METRICS.supply_kw_charges_cost,
      METRICS.supply_cost,
      METRICS.delivery_cost_per_kwh,
      METRICS.billing_kvar_cost,
      METRICS.account_cd,
      METRICS.client_node_id,
      METRICS.delivery_kwh_charges_cost,
      METRICS.universal_unit_uom,
      METRICS.supply_cost_per_kwh,
      METRICS.mid_peak_kwh,
      METRICS.on_peak_kwh,
      METRICS.service_zip_cd,
      METRICS.invoice_id,
      METRICS.property_state_nm,
      METRICS.universal_usage_kbtu,
      METRICS.property_address_nm,
      METRICS.off_peak_kwh,
      METRICS.supply_kwh_cost_per_kwh,
      METRICS.kva_uom,
      METRICS.demand_kw,
      METRICS.percent_renewable_pct,
      METRICS.property_city_nm,
      METRICS.delivery_misc_charges_cost,
      METRICS.service_address_nm,
      METRICS.account_active_ind,
      METRICS.calendarized_usage_qty,
      METRICS.vendor_id,
      METRICS.hdd_nbr,
      METRICS.delivery_taxes_cost,
      METRICS.supply_kwh_charges_cost,
      METRICS.kva_cost,
      METRICS.service_city_nm,
      METRICS.vendor_cd,
      METRICS.supply_taxes_cost,
      METRICS.delivery_taxes_per_kwh,
      METRICS.property_cd,
      METRICS.property_zip_cd,
      -- METRICS.property_nm,
      METRICS.delivery_invoice_nbr,
      METRICS.service_state_nm,
      METRICS.delivery_kw_cost_per_kw,
      METRICS.total_usage_uom,
      METRICS.energy_unit,
      METRICS.delivery_cost,
      METRICS.total_cost_per_kwh,
      METRICS.delivery_customer_charges_cost,
      METRICS.vendor_name,
      METRICS.property_country_nm,
      METRICS.account_type_desc,
      METRICS.end_date,
      METRICS.yrs_nbr,
      METRICS.supply_taxes_per_kwh,
      METRICS.delivery_kwh_cost_per_kwh,
      METRICS.kvar_cost,
      METRICS.square_footage_sqft,
      METRICS.is_property_ind,
      METRICS.load_dt,
      METRICS.load_month_nbr,
      METRICS.load_year_nbr,
      METRICS.created_at_tmst,
      METRICS.user_nm,
      METRICS.batch_load_tmst,
      METRICS.job_nm,
      METRICS.job_run_id
    FROM
      {curated_table_name} METRICS
  ),
  TAXONOMY_GEO_CODE_TABLE AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_mapping_tbl}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  SITE_INTEGRATION AS (
    SELECT
      *
    FROM
      (
        SELECT DISTINCT
          electricity_location_nbr,
          electricity_location_nm,
          lease_nbr,
          building_id,
          business_group_txt,
          brand_nm,
          nike_department_type_txt,
          BUSINESS_ENTITY_GEO_REGION_CD,
          ELECTRICITY_LOCATION_USE_CD,
          business_function_nm,
          division_nm,
          LOCATION_GEO_REGION_CD,
          continent_nm,
          ADDRESS_LINE_1_TXT,
          city_nm,
          STATE_CD,
          POSTAL_CD,
          geographical_axis_nm,
          COUNTRY_CD,
          LOCATION_AREA,
          LOCATION_STATUS_CD,
          latitude_deg,
          longitude_deg,
          ADDITIONAL_LOCATION_FEATURE_DESC,
          cost_usage_data_source_nm,
          location_area_data_source_nm,
          ROW_NUMBER() OVER (
            PARTITION BY
              electricity_location_nbr,
              electricity_location_nm
            ORDER BY
              electricity_location_nbr DESC
          ) AS row_num
        FROM
          (
            SELECT
              --REGEXP_REPLACE(curated_tbl.property_nm, '[^0-9]', '') AS electricity_location_nbr,
              COALESCE(
                curated_tbl.location_nbr_latest,
                curated_tbl.location_nbr
              ) AS electricity_location_nbr,
              COALESCE(
                curated_tbl.location_nm_latest,
                curated_tbl.property_nm
              ) AS electricity_location_nm,
              curated_tbl.total_kwh,
              curated_tbl.universal_usage_uom,
              curated_tbl.days_in_billing_period_days,
              curated_tbl.currency_cd,
              curated_tbl.START_DT,
              curated_tbl.total_cost,
              curated_tbl.mos_nbr,
              curated_tbl.yrs_nbr,
              curated_tbl.account_cd,
              curated_tbl.universal_unit_uom,
              curated_tbl.service_zip_cd,
              curated_tbl.invoice_id,
              curated_tbl.universal_usage_kbtu,
              curated_tbl.property_address_nm,
              curated_tbl.property_city_nm,
              curated_tbl.service_address_nm,
              curated_tbl.account_active_ind,
              curated_tbl.service_city_nm,
              curated_tbl.property_cd,
              curated_tbl.property_zip_cd,
              curated_tbl.total_usage_uom,
              curated_tbl.energy_unit,
              curated_tbl.vendor_name,
              curated_tbl.property_country_nm,
              curated_tbl.account_type_desc,
              curated_tbl.end_date,
              NULL AS lease_nbr,
              building_tbl.TRIRIGA_BUILDING_ID AS building_id,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
                ELSE 'NON-RETAIL'
              END AS business_group_txt,
              CASE
                WHEN curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
                ELSE 'Nike'
              END AS brand_nm,
              CASE
                WHEN building_tbl.`"Primary Use"` = 'NSO' THEN 'Retail Inline'
                WHEN building_tbl.`"Primary Use"` = 'NVS'
                OR building_tbl.`"Primary Use"` = 'NFS' THEN 'Retail Factory'
                WHEN building_tbl.TRIRIGA_CONCEPT IS NULL
                AND building_tbl.`"Primary Use"` IS NULL THEN 'Retail Factory'
                ELSE 'Local Office'
              END AS nike_department_type_txt,
              COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
              COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'DTC (N)'
                WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'DTC (C)'
                WHEN curated_tbl.property_nm LIKE 'Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
                ELSE 'WD+C (N)'
              END AS business_function_nm,
              building_tbl.`"Tririga Brand"`,
              building_tbl.`"Primary Use"`,
              building_tbl.TRIRIGA_BUILDING_ID,
              building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
              CASE
                WHEN building_tbl.`"Primary Use"` = 'NSO' THEN 'Retail Inline (N)'
                WHEN building_tbl.`"Primary Use"` = 'NVS'
                OR building_tbl.`"Primary Use"` = 'NFS' THEN 'Retail Factory (N)'
                WHEN building_tbl.TRIRIGA_CONCEPT IS NULL
                AND building_tbl.`"Primary Use"` IS NULL THEN 'Retail Factory (N)'
                ELSE 'Other Facilities (N)'
              END AS division_nm,
              COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
              COALESCE(building_tbl.CONTINENT_NAME, 'Europe') AS continent_nm,
              COALESCE(
                building_tbl.BUILDING_ADDRESS_MAIN,
                curated_tbl.property_address_nm
              ) AS ADDRESS_LINE_1_TXT,
              COALESCE(
                building_tbl.CITY_CODE_MAIN,
                curated_tbl.property_city_nm
              ) AS city_nm,
              COALESCE(
                building_tbl.STATE_CODE_MAIN,
                curated_tbl.property_state_nm
              ) AS STATE_CD,
              COALESCE(
                building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                curated_tbl.service_zip_cd
              ) AS POSTAL_CD,
              CONCAT_WS(
                '-',
                COALESCE(
                  building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                  curated_tbl.service_zip_cd
                ),
                COALESCE(
                  building_tbl.CITY_CODE_MAIN,
                  curated_tbl.property_city_nm
                )
              ) AS geographical_axis_nm,
              COALESCE(
                building_tbl.COUNTRY_CODE_MAIN,
                curated_tbl.property_country_nm
              ) AS COUNTRY_CD,
              COALESCE(
                building_tbl.BUILDING_USF_MAIN,
                curated_tbl.square_footage_sqft
              ) AS LOCATION_AREA,
              CASE
                WHEN curated_tbl.is_property_ind = 'true' THEN 'Open'
                ELSE 'Close'
              END AS LOCATION_STATUS_CD,
              building_tbl.LATITUDE_MAIN AS latitude_deg,
              building_tbl.LONGITUDE_MAIN AS longitude_deg,
              NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
              'electricity_usage_metrics' AS cost_usage_data_source_nm,
              CASE
                WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'building_combined'
                ELSE 'electricity_usage_metrics'
              END AS location_area_data_source_nm
            FROM
              ELECTRICITY_USAGE_METRICS curated_tbl
              LEFT JOIN BUILDING_COMBINE building_tbl
              -- ON curated_tbl.property_zip_cd = building_tbl.TRIRIGA_ZIP_POSTAL_CODE
              --ON curated_tbl.derived_KEY = building_tbl.derived_POS_Store_ID_column
              ON LPAD(REGEXP_SUBSTR (property_nm, '[0-9]+'), 4, '0') = building_tbl.derived_POS_Store_ID_column
              LEFT JOIN TAXONOMY_GEO_CODE_TABLE ctry_mapping ON curated_tbl.property_country_nm = ctry_mapping.ctry_cd
            WHERE
              (
                building_tbl.COMBINE_PART IS NULL
                OR building_tbl.COMBINE_PART = 1
              )
              AND (curated_tbl.property_nm ILIKE '%nike%')
            UNION ALL
            SELECT
              --REGEXP_REPLACE(curated_tbl.property_nm, '[^0-9]', '') AS electricity_location_nbr,
              COALESCE(
                curated_tbl.location_nbr_latest,
                curated_tbl.location_nbr
              ) AS electricity_location_nbr,
              COALESCE(
                curated_tbl.location_nm_latest,
                curated_tbl.property_nm
              ) AS electricity_location_nm,
              curated_tbl.total_kwh,
              curated_tbl.universal_usage_uom,
              curated_tbl.days_in_billing_period_days,
              curated_tbl.currency_cd,
              curated_tbl.START_DT,
              curated_tbl.total_cost,
              curated_tbl.mos_nbr,
              curated_tbl.yrs_nbr,
              curated_tbl.account_cd,
              curated_tbl.universal_unit_uom,
              curated_tbl.service_zip_cd,
              curated_tbl.invoice_id,
              curated_tbl.universal_usage_kbtu,
              curated_tbl.property_address_nm,
              curated_tbl.property_city_nm,
              curated_tbl.service_address_nm,
              curated_tbl.account_active_ind,
              curated_tbl.service_city_nm,
              curated_tbl.property_cd,
              curated_tbl.property_zip_cd,
              curated_tbl.total_usage_uom,
              curated_tbl.energy_unit,
              curated_tbl.vendor_name,
              curated_tbl.property_country_nm,
              curated_tbl.account_type_desc,
              curated_tbl.end_date,
              NULL AS lease_nbr,
              building_tbl.TRIRIGA_BUILDING_ID AS building_id,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
                ELSE 'NON-RETAIL'
              END AS business_group_txt,
              CASE
                WHEN curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
                ELSE 'Nike'
              END AS brand_nm,
              CASE
                WHEN building_tbl.`"Primary Use"` = 'NSO' THEN 'Retail Inline'
                WHEN building_tbl.`"Primary Use"` = 'NVS'
                OR building_tbl.`"Primary Use"` = 'NFS' THEN 'Retail Factory'
                WHEN building_tbl.TRIRIGA_CONCEPT IS NULL
                AND building_tbl.`"Primary Use"` IS NULL THEN 'Retail Factory'
                ELSE 'Local Office'
              END AS nike_department_type_txt,
              COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
              COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'DTC (N)'
                WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'DTC (C)'
                WHEN curated_tbl.property_nm LIKE 'Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
                ELSE 'WD+C (N)'
              END AS business_function_nm,
              building_tbl.`"Tririga Brand"`,
              building_tbl.`"Primary Use"`,
              building_tbl.TRIRIGA_BUILDING_ID,
              building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
              CASE
                WHEN building_tbl.`"Primary Use"` = 'NSO' THEN 'Retail Inline (N)'
                WHEN building_tbl.`"Primary Use"` = 'NVS'
                OR building_tbl.`"Primary Use"` = 'NFS' THEN 'Retail Factory (N)'
                WHEN building_tbl.TRIRIGA_CONCEPT IS NULL
                AND building_tbl.`"Primary Use"` IS NULL THEN 'Retail Factory (N)'
                ELSE 'Other Facilities (N)'
              END AS division_nm,
              COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
              COALESCE(building_tbl.CONTINENT_NAME, 'Europe') AS continent_nm,
              COALESCE(
                -- 'yiioioi',
                building_tbl.BUILDING_ADDRESS_MAIN,
                curated_tbl.property_address_nm
              ) AS ADDRESS_LINE_1_TXT,
              COALESCE(
                building_tbl.CITY_CODE_MAIN,
                curated_tbl.property_city_nm
              ) AS city_nm,
              COALESCE(
                building_tbl.STATE_CODE_MAIN,
                curated_tbl.property_state_nm
              ) AS STATE_CD,
              COALESCE(
                building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                curated_tbl.service_zip_cd
              ) AS POSTAL_CD,
              CONCAT_WS(
                '-',
                COALESCE(
                  building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                  curated_tbl.service_zip_cd
                ),
                COALESCE(
                  building_tbl.CITY_CODE_MAIN,
                  curated_tbl.property_city_nm
                )
              ) AS geographical_axis_nm,
              COALESCE(
                building_tbl.COUNTRY_CODE_MAIN,
                curated_tbl.property_country_nm
              ) AS COUNTRY_CD,
              COALESCE(
                building_tbl.BUILDING_USF_MAIN,
                curated_tbl.square_footage_sqft
              ) AS LOCATION_AREA,
              CASE
                WHEN curated_tbl.is_property_ind = 'true' THEN 'Open'
                ELSE 'Close'
              END AS LOCATION_STATUS_CD,
              building_tbl.LATITUDE_MAIN AS latitude_deg,
              building_tbl.LONGITUDE_MAIN AS longitude_deg,
              NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
              'electricity_usage_metrics' AS cost_usage_data_source_nm,
              CASE
                WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'building_combined'
                ELSE 'electricity_usage_metrics'
              END AS location_area_data_source_nm
            FROM
              ELECTRICITY_USAGE_METRICS curated_tbl
              LEFT JOIN BUILDING_COMBINE building_tbl ON curated_tbl.location_nbr = building_tbl.derived_POS_Store_ID_column
              LEFT JOIN TAXONOMY_GEO_CODE_TABLE ctry_mapping ON curated_tbl.property_country_nm = ctry_mapping.ctry_cd
            WHERE
              (
                building_tbl.COMBINE_PART IS NULL
                OR building_tbl.COMBINE_PART = 1
              )
              AND (curated_tbl.property_nm ILIKE '%nike%')
              OR building_tbl.derived_POS_Store_ID_column IS NOT NULL
            UNION ALL
            SELECT
              --REGEXP_REPLACE(curated_tbl.property_nm, '[^0-9]', '') AS electricity_location_nbr,
              COALESCE(
                curated_tbl.location_nbr_latest,
                curated_tbl.location_nbr
              ) AS electricity_location_nbr,
              COALESCE(
                curated_tbl.location_nm_latest,
                curated_tbl.property_nm
              ) AS electricity_location_nm,
              curated_tbl.total_kwh,
              curated_tbl.universal_usage_uom,
              curated_tbl.days_in_billing_period_days,
              curated_tbl.currency_cd,
              curated_tbl.START_DT,
              curated_tbl.total_cost,
              curated_tbl.mos_nbr,
              curated_tbl.yrs_nbr,
              curated_tbl.account_cd,
              curated_tbl.universal_unit_uom,
              curated_tbl.service_zip_cd,
              curated_tbl.invoice_id,
              curated_tbl.universal_usage_kbtu,
              curated_tbl.property_address_nm,
              curated_tbl.property_city_nm,
              curated_tbl.service_address_nm,
              curated_tbl.account_active_ind,
              curated_tbl.service_city_nm,
              curated_tbl.property_cd,
              curated_tbl.property_zip_cd,
              curated_tbl.total_usage_uom,
              curated_tbl.energy_unit,
              curated_tbl.vendor_name,
              curated_tbl.property_country_nm,
              curated_tbl.account_type_desc,
              curated_tbl.end_date,
              NULL AS lease_nbr,
              building_tbl.TRIRIGA_BUILDING_ID AS building_id,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
                ELSE 'NON-RETAIL'
              END AS business_group_txt,
              CASE
                WHEN curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
                ELSE 'Nike'
              END AS brand_nm,
              CASE
                WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Factory'
                ELSE 'Local Office'
              END AS nike_department_type_txt,
              COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
              COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'DTC (N)'
                WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'DTC (C)'
                WHEN curated_tbl.property_nm LIKE 'Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
                ELSE 'WD+C (N)'
              END AS business_function_nm,
              building_tbl.`"Tririga Brand"`,
              building_tbl.`"Primary Use"`,
              building_tbl.TRIRIGA_BUILDING_ID,
              building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
              CASE
                WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Factory (C)'
                WHEN curated_tbl.property_nm LIKE '%Converse%' THEN 'Other Facilities (C)'
                ELSE 'Other Facilities (N)'
              END AS division_nm,
              COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
              COALESCE(building_tbl.CONTINENT_NAME, 'Europe') AS continent_nm,
              COALESCE(
                building_tbl.BUILDING_ADDRESS_MAIN,
                curated_tbl.property_address_nm
              ) AS ADDRESS_LINE_1_TXT,
              COALESCE(
                building_tbl.CITY_CODE_MAIN,
                curated_tbl.property_city_nm
              ) AS city_nm,
              COALESCE(
                building_tbl.STATE_CODE_MAIN,
                curated_tbl.property_state_nm
              ) AS STATE_CD,
              COALESCE(
                building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                curated_tbl.service_zip_cd
              ) AS POSTAL_CD,
              CONCAT_WS(
                '-',
                COALESCE(
                  building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                  curated_tbl.service_zip_cd
                ),
                COALESCE(
                  building_tbl.CITY_CODE_MAIN,
                  curated_tbl.property_city_nm
                )
              ) AS geographical_axis_nm,
              COALESCE(
                building_tbl.COUNTRY_CODE_MAIN,
                curated_tbl.property_country_nm
              ) AS COUNTRY_CD,
              COALESCE(
                building_tbl.BUILDING_USF_MAIN,
                curated_tbl.square_footage_sqft
              ) AS LOCATION_AREA,
              CASE
                WHEN curated_tbl.is_property_ind = 'true' THEN 'Open'
                ELSE 'Close'
              END AS LOCATION_STATUS_CD,
              building_tbl.LATITUDE_MAIN AS latitude_deg,
              building_tbl.LONGITUDE_MAIN AS longitude_deg,
              NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
              'electricity_usage_metrics' AS cost_usage_data_source_nm,
              CASE
                WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'building_combined'
                ELSE 'electricity_usage_metrics'
              END AS location_area_data_source_nm
            FROM
              ELECTRICITY_USAGE_METRICS curated_tbl
              LEFT JOIN BUILDING_COMBINE building_tbl
              -- ON curated_tbl.property_zip_cd = building_tbl.TRIRIGA_ZIP_POSTAL_CODE
              ON curated_tbl.location_nbr = building_tbl.derived_BLDG_ID_column
              LEFT JOIN TAXONOMY_GEO_CODE_TABLE ctry_mapping ON curated_tbl.property_country_nm = ctry_mapping.ctry_cd
            WHERE
              (
                building_tbl.COMBINE_PART IS NULL
                OR building_tbl.COMBINE_PART = 1
              )
              AND curated_tbl.property_nm LIKE '%CFS%'
              OR curated_tbl.property_nm LIKE 'Converse%'
            UNION ALL
            SELECT
              COALESCE(
                curated_tbl.location_nbr_latest,
                curated_tbl.location_nbr
              ) AS electricity_location_nbr,
              COALESCE(
                curated_tbl.location_nm_latest,
                curated_tbl.property_nm
              ) AS electricity_location_nm,
              curated_tbl.total_kwh,
              curated_tbl.universal_usage_uom,
              curated_tbl.days_in_billing_period_days,
              curated_tbl.currency_cd,
              curated_tbl.START_DT,
              curated_tbl.total_cost,
              curated_tbl.mos_nbr,
              curated_tbl.yrs_nbr,
              curated_tbl.account_cd,
              curated_tbl.universal_unit_uom,
              curated_tbl.service_zip_cd,
              curated_tbl.invoice_id,
              curated_tbl.universal_usage_kbtu,
              curated_tbl.property_address_nm,
              curated_tbl.property_city_nm,
              curated_tbl.service_address_nm,
              curated_tbl.account_active_ind,
              curated_tbl.service_city_nm,
              curated_tbl.property_cd,
              curated_tbl.property_zip_cd,
              curated_tbl.total_usage_uom,
              curated_tbl.energy_unit,
              curated_tbl.vendor_name,
              curated_tbl.property_country_nm,
              curated_tbl.account_type_desc,
              curated_tbl.end_date,
              NULL AS lease_nbr,
              building_tbl.TRIRIGA_BUILDING_ID AS building_id,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
                ELSE 'NON-RETAIL'
              END AS business_group_txt,
              CASE
                WHEN curated_tbl.property_nm LIKE '%CFS%'
                OR curated_tbl.property_nm LIKE '%Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
                ELSE 'Nike'
              END AS brand_nm,
              CASE
                WHEN curated_tbl.property_nm LIKE '%EHQ%' THEN 'Main HQ'
                ELSE 'Local Office'
              END AS nike_department_type_txt,
              COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
              COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
              CASE
                WHEN curated_tbl.property_nm LIKE '%Nike%'
                OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'DTC (N)'
                WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'DTC (C)'
                WHEN curated_tbl.property_nm LIKE 'Converse%'
                OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
                ELSE 'WD+C (N)'
              END AS business_function_nm,
              building_tbl.`"Tririga Brand"`,
              building_tbl.`"Primary Use"`,
              building_tbl.TRIRIGA_BUILDING_ID,
              building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
              CASE
                WHEN curated_tbl.property_nm LIKE '%EHQ%' THEN 'Headquarters (N)'
                ELSE 'Other Facilities (N)'
              END AS division_nm,
              COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
              COALESCE(building_tbl.CONTINENT_NAME, 'Europe') AS continent_nm,
              COALESCE(
                building_tbl.BUILDING_ADDRESS_MAIN,
                curated_tbl.property_address_nm
              ) AS ADDRESS_LINE_1_TXT,
              COALESCE(
                building_tbl.CITY_CODE_MAIN,
                curated_tbl.property_city_nm
              ) AS city_nm,
              COALESCE(
                building_tbl.STATE_CODE_MAIN,
                curated_tbl.property_state_nm
              ) AS STATE_CD,
              COALESCE(
                building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                curated_tbl.service_zip_cd
              ) AS POSTAL_CD,
              CONCAT_WS(
                '-',
                COALESCE(
                  building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
                  curated_tbl.service_zip_cd
                ),
                COALESCE(
                  building_tbl.CITY_CODE_MAIN,
                  curated_tbl.property_city_nm
                )
              ) AS geographical_axis_nm,
              COALESCE(
                building_tbl.COUNTRY_CODE_MAIN,
                curated_tbl.property_country_nm
              ) AS COUNTRY_CD,
              COALESCE(
                building_tbl.BUILDING_USF_MAIN,
                curated_tbl.square_footage_sqft
              ) AS LOCATION_AREA,
              CASE
                WHEN curated_tbl.is_property_ind = 'true' THEN 'Open'
                ELSE 'Close'
              END AS LOCATION_STATUS_CD,
              building_tbl.LATITUDE_MAIN AS latitude_deg,
              building_tbl.LONGITUDE_MAIN AS longitude_deg,
              NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
              'electricity_usage_metrics' AS cost_usage_data_source_nm,
              CASE
                WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'building_combined'
                ELSE 'electricity_usage_metrics'
              END AS location_area_data_source_nm
            FROM
              ELECTRICITY_USAGE_METRICS curated_tbl
              LEFT JOIN BUILDING_COMBINE building_tbl
              -- ON curated_tbl.property_zip_cd = building_tbl.TRIRIGA_ZIP_POSTAL_CODE
              ON curated_tbl.location_nbr = building_tbl.TRIRIGA_BUILDING_ID
              LEFT JOIN TAXONOMY_GEO_CODE_TABLE ctry_mapping ON curated_tbl.property_country_nm = ctry_mapping.ctry_cd
            WHERE
              (
                building_tbl.COMBINE_PART IS NULL
                OR building_tbl.COMBINE_PART = 1
              )
              AND curated_tbl.property_nm NOT LIKE 'Converse%'
              AND curated_tbl.property_nm NOT LIKE '%CFS%'
              AND curated_tbl.property_nm NOT LIKE '%Nike%'
            ORDER BY
              invoice_id DESC,
              electricity_location_nm ASC,
              yrs_nbr DESC,
              mos_nbr DESC
          )
      ) A
    WHERE
      A.row_num = 1
  )
SELECT
  ELECTRICITY_SITE.electricity_location_nbr AS electricity_location_nbr,
  ELECTRICITY_SITE.electricity_location_nm AS electricity_location_nm,
  ELECTRICITY_SITE.lease_nbr AS lease_nbr,
  ELECTRICITY_SITE.building_id AS building_id,
  -- REGEXP_REPLACE(
  --   INITCAP(ELECTRICITY_SITE.business_group_txt),
  --   '-',
  --   ' '
  -- ) AS business_group_txt,
  INITCAP(
    REGEXP_REPLACE(ELECTRICITY_SITE.business_group_txt, '-', ' ')
  ) AS business_group_txt,
  INITCAP(ELECTRICITY_SITE.brand_nm) AS brand_nm,
  CASE
    WHEN ELECTRICITY_SITE.nike_department_type_txt ILIKE '%air mi%' THEN 'Air MI'
    ELSE ELECTRICITY_SITE.nike_department_type_txt
  END AS nike_department_type_txt,
  CASE
    WHEN ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
    WHEN ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
    WHEN ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
    ELSE ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD
  END AS BUSINESS_ENTITY_GEO_REGION_CD,
  ELECTRICITY_SITE.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
  ELECTRICITY_SITE.business_function_nm AS business_function_nm,
  ELECTRICITY_SITE.division_nm AS division_nm,
  CASE
    WHEN ELECTRICITY_SITE.LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
    WHEN ELECTRICITY_SITE.LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
    ELSE ELECTRICITY_SITE.LOCATION_GEO_REGION_CD
  END AS LOCATION_GEO_REGION_CD,
  CASE
    WHEN ELECTRICITY_SITE.continent_nm ILIKE 'EMEA' THEN 'Europe'
    WHEN ELECTRICITY_SITE.continent_nm ILIKE 'APLA' THEN 'Asia'
    WHEN ELECTRICITY_SITE.continent_nm ILIKE 'North America' THEN 'North America'
    WHEN ELECTRICITY_SITE.continent_nm ILIKE 'Greater China' THEN 'Asia'
    ELSE ELECTRICITY_SITE.continent_nm
  END AS continent_nm,
  ELECTRICITY_SITE.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
  INITCAP(ELECTRICITY_SITE.city_nm) AS city_nm,
  ELECTRICITY_SITE.STATE_CD AS STATE_CD,
  ELECTRICITY_SITE.POSTAL_CD AS POSTAL_CD,
  ELECTRICITY_SITE.geographical_axis_nm AS geographical_axis_nm,
  CASE
    WHEN ELECTRICITY_SITE.COUNTRY_CD ILIKE 'Canada' THEN 'CA'
    WHEN ELECTRICITY_SITE.COUNTRY_CD ILIKE 'United States' THEN 'US'
    ELSE UPPER(ELECTRICITY_SITE.COUNTRY_CD)
  END AS COUNTRY_CD,
  CAST(ELECTRICITY_SITE.LOCATION_AREA AS DECIMAL(31, 5)) AS LOCATION_AREA,
  'square feet' AS LOCATION_AREA_UOM,
  ELECTRICITY_SITE.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
  ELECTRICITY_SITE.latitude_deg AS latitude_deg,
  ELECTRICITY_SITE.longitude_deg AS longitude_deg,
  ELECTRICITY_SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
  'electricity_usage_metrics' AS cost_usage_data_source_nm,
  location_area_data_source_nm
FROM
  SITE_INTEGRATION ELECTRICITY_SITE;
