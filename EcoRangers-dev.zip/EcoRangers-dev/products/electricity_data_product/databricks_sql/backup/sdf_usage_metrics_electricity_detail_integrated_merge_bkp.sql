WITH
  BUILDING_COMBINE AS (
    SELECT
      REGEXP_EXTRACT(B_COMBINE.`"Tririga POS Store ID"`, '\\d+', 0) AS derived_POS_Store_ID_column,
      B_COMBINE.`"Tririga POS Store ID"`,
      RIGHT(B_COMBINE.TRIRIGA_BUILDING_ID, 4) AS derived_BLDG_ID_column,
      B_COMBINE.TRIRIGA_BUILDING_ID,
      B_COMBINE.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
      B_COMBINE.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
      B_COMBINE.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
      B_COMBINE.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
      B_COMBINE.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
      B_COMBINE.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
      B_COMBINE.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
      B_COMBINE.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
      B_COMBINE.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
      B_COMBINE.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
      B_COMBINE.`"Building Type"` AS `"Building Type"`,
      B_COMBINE.`"Location Type"` AS `"Location Type"`,
      B_COMBINE.`"Nike Key City"` AS `"Nike Key City"`,
      B_COMBINE.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
      B_COMBINE.`"Business Group"` AS `"Business Group"`,
      B_COMBINE.`"Campus - Corporate Park"` AS `"Campus - Corporate Park"`,
      B_COMBINE.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
      B_COMBINE.CITY_CODE_MAIN AS CITY_CODE_MAIN,
      B_COMBINE.CONTINENT_CODE AS CONTINENT_CODE,
      B_COMBINE.CONTINENT_NAME AS CONTINENT_NAME,
      B_COMBINE.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
      B_COMBINE.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
      B_COMBINE.LOCATION_REGION AS LOCATION_REGION,
      B_COMBINE.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
      B_COMBINE.`"NIKE GEO"` AS `"NIKE GEO"`,
      B_COMBINE.`"Primary Use"` AS `"Primary Use"`,
      B_COMBINE.REPORT_DATE AS REPORT_DATE,
      B_COMBINE.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
      B_COMBINE.STATE_PROV_MAIN AS STATE_PROV_MAIN,
      B_COMBINE.STATE_CODE_MAIN AS STATE_CODE_MAIN,
      B_COMBINE.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
      B_COMBINE.`"Tririga Brand"` AS `"Tririga Brand"`,
      B_COMBINE.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
      -- B_COMBINE.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
      B_COMBINE.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
      B_COMBINE.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
      B_COMBINE.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
      B_COMBINE.`"Tririga Contract Status"` AS `"Tririga Contract Status"`,
      B_COMBINE.TRIRIGA_GEO AS TRIRIGA_GEO,
      B_COMBINE.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
      B_COMBINE.LATITUDE_MAIN AS LATITUDE_MAIN,
      B_COMBINE.LONGITUDE_MAIN AS LONGITUDE_MAIN,
      B_COMBINE.`"Tririga GIS LAT"` AS `"Tririga GIS LAT"`,
      B_COMBINE.`"Tririga GIS LON"` AS `"Tririga GIS LON"`,
      -- B_COMBINE.`Tririga POS Store ID` AS `Tririga POS Store ID"`,
      B_COMBINE.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
      B_COMBINE.TRIRIGA_ZIP_POSTAL_CODE AS TRIRIGA_ZIP_POSTAL_CODE,
      B_COMBINE.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
      B_COMBINE.WDC_REGION_MAIN AS WDC_REGION_MAIN,
      B_COMBINE.`"Zip Code Main"` AS `"Zip Code Main"`,
      B_COMBINE.ARCHIBUS_USF AS ARCHIBUS_USF,
      B_COMBINE.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
      B_COMBINE.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      B_COMBINE.`"Max. Bldg. Capacity"` AS `"Max. Bldg. Capacity"`,
      B_COMBINE.`"Number of Floors"` AS `"Number of Floors"`,
      DENSE_RANK() OVER (
        PARTITION BY
          B_COMBINE.BUILDING_CODE_MAIN
          -- B_COMBINE.BUILDING_USF_MAIN
        ORDER BY
          B_COMBINE.report_date DESC
      ) AS COMBINE_PART
    FROM
      BUILDING_TABLE_NAME B_COMBINE
    WHERE
      B_COMBINE.`"NIKE GEO"` = 'EMEA'
      -- AND B_COMBINE.DISPLAY_LATEST_MAIN='LATEST'
  ),
  ELECTRICITY_USAGE_METRICS AS (
    SELECT
      REGEXP_EXTRACT(PROPERTY_NM, '\\d+', 0) AS derived_KEY,
      METRICS.PROPERTY_NM,
      METRICS.location_nbr,
      METRICS.location_nm_latest,
      METRICS.location_nbr_latest,
      METRICS.account_id,
      METRICS.cdd_nbr,
      METRICS.total_kwh,
      METRICS.delivery_kw_charges_cost,
      METRICS.universal_usage_uom,
      METRICS.days_in_billing_period_days,
      METRICS.currency_cd,
      METRICS.START_DT,
      METRICS.total_cost,
      METRICS.mos_nbr,
      METRICS.supply_kw_charges_cost,
      METRICS.supply_cost,
      METRICS.delivery_cost_per_kwh,
      METRICS.billing_kvar_cost,
      METRICS.account_cd,
      METRICS.client_node_id,
      METRICS.delivery_kwh_charges_cost,
      METRICS.universal_unit_uom,
      METRICS.supply_cost_per_kwh,
      METRICS.mid_peak_kwh,
      METRICS.on_peak_kwh,
      METRICS.service_zip_cd,
      METRICS.invoice_id,
      METRICS.property_state_nm,
      METRICS.universal_usage_kbtu,
      METRICS.property_address_nm,
      METRICS.off_peak_kwh,
      METRICS.supply_kwh_cost_per_kwh,
      METRICS.kva_uom,
      METRICS.demand_kw,
      METRICS.percent_renewable_pct,
      METRICS.property_city_nm,
      METRICS.delivery_misc_charges_cost,
      METRICS.service_address_nm,
      METRICS.account_active_ind,
      METRICS.calendarized_usage_qty,
      METRICS.vendor_id,
      METRICS.hdd_nbr,
      METRICS.delivery_taxes_cost,
      METRICS.supply_kwh_charges_cost,
      METRICS.kva_cost,
      METRICS.service_city_nm,
      METRICS.vendor_cd,
      METRICS.supply_taxes_cost,
      METRICS.delivery_taxes_per_kwh,
      METRICS.property_cd,
      METRICS.property_zip_cd,
      -- METRICS.property_nm,
      METRICS.delivery_invoice_nbr,
      METRICS.service_state_nm,
      METRICS.delivery_kw_cost_per_kw,
      METRICS.total_usage_uom,
      METRICS.energy_unit,
      METRICS.delivery_cost,
      METRICS.total_cost_per_kwh,
      METRICS.delivery_customer_charges_cost,
      METRICS.vendor_name,
      METRICS.property_country_nm,
      METRICS.account_type_desc,
      METRICS.end_date,
      METRICS.yrs_nbr,
      METRICS.supply_taxes_per_kwh,
      METRICS.delivery_kwh_cost_per_kwh,
      METRICS.kvar_cost,
      METRICS.square_footage_sqft,
      METRICS.is_property_ind,
      METRICS.load_dt,
      METRICS.load_month_nbr,
      METRICS.load_year_nbr,
      METRICS.created_at_tmst,
      METRICS.user_nm,
      METRICS.batch_load_tmst,
      METRICS.job_nm,
      METRICS.job_run_id
    FROM
      {curated_table_name} METRICS
  ),
  /*
  This SQL block defines a subquery named "ConvertedCosts". It selects distinct rows from the "sdf_electricity_usage_metrics_v" table in the "development.global_sustainability_dev" schema where the property name is 'Stockholm Showroom - WESWE - GPS'.
  
  
  The query extracts a number (derived_KEY) from the property name, and selects various other columns related to electricity usage and costs.
  For the 'total_cost' and 'currency_cd' columns, the query applies specific transformations for the 'Stockholm Showroom - WESWE - GPS' property for the years 2019, 2020, and 2021.
  For 'total_cost', it multiplies the original cost by a conversion factor to adjust for currency differences for the specified years and if the original currency is 'USD'.
  For 'currency_cd', it replaces the original currency with 'EUR' for the specified years.
  The result of this subquery is a table with the same columns as the original, but with the 'total_cost' and 'currency_cd' columns potentially transformed for the 'Stockholm Showroom - WESWE - GPS' property.
  */
  ELECTRICITY_USAGE_METRICS_USD_TO_EUR_CONVERSION AS (
    SELECT DISTINCT
      REGEXP_EXTRACT(PROPERTY_NM, '\\d+', 0) AS derived_KEY,
      account_id,
      location_nbr,
      location_nm_latest,
      location_nbr_latest,
      cdd_nbr,
      total_kwh,
      delivery_kw_charges_cost,
      universal_usage_uom,
      days_in_billing_period_days,
      CASE
        WHEN property_nm = 'Stockholm Showroom - WESWE - GPS'
        AND start_dt BETWEEN DATE '2019-12-31' AND DATE  '2020-12-31'
        AND currency_cd = 'USD' THEN total_cost * 0.876827827
        WHEN property_nm = 'Stockholm Showroom - WESWE - GPS'
        AND start_dt BETWEEN DATE '2021-01-01' AND DATE  '2021-12-31'
        AND currency_cd = 'USD' THEN total_cost * 0.845982465
        WHEN property_nm IN (
          'Nike Europe - 999 - Warsaw Annopol Factory Store',
          'Nike Europe - 662 - Krakow Factory Store'
        )
        AND currency_cd = 'PLN' THEN total_cost * 0.21865354
        ELSE total_cost
      END AS total_cost,
      CASE
        WHEN property_nm = 'Stockholm Showroom - WESWE - GPS'
        AND (
          start_dt BETWEEN DATE '2019-12-31' AND DATE  '2021-12-31'
        ) THEN 'EUR'
        WHEN property_nm IN (
          'Nike Europe - 999 - Warsaw Annopol Factory Store',
          'Nike Europe - 662 - Krakow Factory Store'
        )
        AND currency_cd = 'PLN' THEN 'EUR'
        ELSE currency_cd
      END AS currency_cd,
      start_dt,
      mos_nbr,
      supply_kw_charges_cost,
      supply_cost,
      delivery_cost_per_kwh,
      billing_kvar_cost,
      account_cd,
      client_node_id,
      delivery_kwh_charges_cost,
      universal_unit_uom,
      supply_cost_per_kwh,
      mid_peak_kwh,
      on_peak_kwh,
      service_zip_cd,
      invoice_id,
      property_state_nm,
      universal_usage_kbtu,
      property_address_nm,
      off_peak_kwh,
      supply_kwh_cost_per_kwh,
      kva_uom,
      demand_kw,
      percent_renewable_pct,
      property_city_nm,
      delivery_misc_charges_cost,
      service_address_nm,
      account_active_ind,
      calendarized_usage_qty,
      vendor_id,
      hdd_nbr,
      delivery_taxes_cost,
      supply_kwh_charges_cost,
      kva_cost,
      service_city_nm,
      vendor_cd,
      supply_taxes_cost,
      delivery_taxes_per_kwh,
      property_cd,
      property_zip_cd,
      property_nm,
      delivery_invoice_nbr,
      service_state_nm,
      delivery_kw_cost_per_kw,
      total_usage_uom,
      energy_unit,
      delivery_cost,
      total_cost_per_kwh,
      delivery_customer_charges_cost,
      vendor_name,
      property_country_nm,
      account_type_desc,
      end_date,
      yrs_nbr,
      supply_taxes_per_kwh,
      delivery_kwh_cost_per_kwh,
      kvar_cost,
      square_footage_sqft,
      is_property_ind,
      load_dt,
      load_month_nbr,
      load_year_nbr,
      created_at_tmst,
      user_nm,
      batch_load_tmst,
      job_nm,
      job_run_id
    FROM
      {curated_table_name}
    WHERE
      property_nm IN (
        'Stockholm Showroom - WESWE - GPS',
        'Nike Europe - 999 - Warsaw Annopol Factory Store',
        'Nike Europe - 662 - Krakow Factory Store'
      )
  ),
  DETAIL_INTEGRATION AS (
    SELECT DISTINCT
      COALESCE(
        curated_tbl.location_nbr_latest,
        curated_tbl.location_nbr
      ) AS electricity_location_nbr,
      COALESCE(
        curated_tbl.location_nm_latest,
        curated_tbl.property_nm
      ) AS electricity_location_nm,
      curated_tbl.total_kwh,
      curated_tbl.universal_usage_uom,
      curated_tbl.days_in_billing_period_days,
      curated_tbl.currency_cd AS SERVICE_COST_UOM,
      curated_tbl.START_DT AS BILLING_MONTH_START_DT,
      curated_tbl.total_cost AS SERVICE_COST,
      curated_tbl.mos_nbr,
      curated_tbl.yrs_nbr,
      curated_tbl.account_cd,
      curated_tbl.universal_unit_uom,
      curated_tbl.service_zip_cd,
      curated_tbl.invoice_id,
      curated_tbl.universal_usage_kbtu,
      curated_tbl.property_address_nm,
      curated_tbl.property_city_nm,
      curated_tbl.service_address_nm,
      curated_tbl.account_active_ind,
      curated_tbl.service_city_nm,
      curated_tbl.property_cd,
      curated_tbl.property_zip_cd,
      curated_tbl.total_usage_uom AS SERVICE_USAGE_QTY,
      curated_tbl.energy_unit AS SERVICE_USAGE_QTY_UOM,
      curated_tbl.vendor_name,
      curated_tbl.property_country_nm,
      curated_tbl.account_type_desc,
      curated_tbl.end_date AS BILLING_MONTH_END_DT,
      NULL AS lease_nbr,
      12 AS DATA_FREQUENCY_CD,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
        ELSE 'NON-RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN curated_tbl.property_nm LIKE 'Nike%'
        OR curated_tbl.property_nm LIKE 'NIKE%'
        OR curated_tbl.property_nm LIKE '%CFS%' THEN 'Stores'
        WHEN curated_tbl.property_nm LIKE '%EHQ%' THEN 'Main HQ'
        ELSE 'Local Office'
      END AS nike_department_type_txt,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Nike Direct/Retail Locations-Nike'
        WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'Nike Direct/Retail Locations-Converse'
        WHEN curated_tbl.property_nm LIKE 'Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
        ELSE 'WD+C (N)'
      END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      CASE
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Factory (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Factory (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Store (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Store (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN ' Headquarters (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN ' Headquarters (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Other Facilities (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Other Facilities (C)'
        ELSE NULL
      END AS division_nm,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.property_address_nm
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(
        building_tbl.CITY_CODE_MAIN,
        curated_tbl.property_city_nm
      ) AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.property_state_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.service_zip_cd
      ) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(
          building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
          curated_tbl.service_zip_cd
        ),
        COALESCE(
          building_tbl.CITY_CODE_MAIN,
          curated_tbl.property_city_nm
        )
      ) AS geographical_axis_nm,
      building_tbl.COUNTRY_CODE_MAIN AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.square_footage_sqft
      ) AS LOCATION_AREA_IN_SQFT,
      CASE
        WHEN curated_tbl.is_property_ind LIKE 'true' THEN 'Open'
        ELSE 'Close'
      END AS LOCATION_STATUS_CD,
      building_tbl.LATITUDE_MAIN AS latitude_deg,
      building_tbl.LONGITUDE_MAIN AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_metrics' AS cost_usage_data_source_nm,
      cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      COALESCE(cd.YEAR_NBR, 0) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(cd.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      COALESCE(cd.MONTH_OF_YEAR_NBR, 0) AS REPORTING_MONTH_OF_YEAR_NBR,
      COALESCE(cd.QUARTER_NBR, 0) AS REPORTING_QUARTER_NBR,
      COALESCE(cd.WEEK_OF_YEAR_NBR, 0) AS REPORTING_WEEK_OF_YEAR_NBR,
      TO_DATE(
        CONCAT(
          curated_tbl.yrs_nbr,
          '-',
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electric' AS SERVICE_TYPE_CD,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_tbl.yrs_nbr,
              '-',
              LPAD(curated_tbl.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_tbl.yrs_nbr,
                  '-',
                  LPAD(curated_tbl.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT
    FROM
      ELECTRICITY_USAGE_METRICS curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON curated_tbl.derived_KEY = building_tbl.derived_POS_Store_ID_column
      LEFT JOIN {calendar_table_name} AS cd ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_tbl.yrs_nbr,
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = cd.calendar_dt
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      AND (
        curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%'
      )
      AND curated_tbl.property_nm NOT LIKE 'Nike Europe - 999 - Warsaw Annopol Factory Store'
      AND curated_tbl.property_nm NOT LIKE 'Nike Europe - 662 - Krakow Factory Store'
    UNION ALL
    SELECT DISTINCT
      COALESCE(
        curated_tbl.location_nbr_latest,
        curated_tbl.location_nbr
      ) AS electricity_location_nbr,
      COALESCE(
        curated_tbl.location_nm_latest,
        curated_tbl.property_nm
      ) AS electricity_location_nm,
      curated_tbl.total_kwh,
      curated_tbl.universal_usage_uom,
      curated_tbl.days_in_billing_period_days,
      curated_tbl.currency_cd AS SERVICE_COST_UOM,
      curated_tbl.START_DT AS BILLING_MONTH_START_DT,
      curated_tbl.total_cost AS SERVICE_COST,
      curated_tbl.mos_nbr,
      curated_tbl.yrs_nbr,
      curated_tbl.account_cd,
      curated_tbl.universal_unit_uom,
      curated_tbl.service_zip_cd,
      curated_tbl.invoice_id,
      curated_tbl.universal_usage_kbtu,
      curated_tbl.property_address_nm,
      curated_tbl.property_city_nm,
      curated_tbl.service_address_nm,
      curated_tbl.account_active_ind,
      curated_tbl.service_city_nm,
      curated_tbl.property_cd,
      curated_tbl.property_zip_cd,
      curated_tbl.total_usage_uom AS SERVICE_USAGE_QTY,
      curated_tbl.energy_unit AS SERVICE_USAGE_QTY_UOM,
      curated_tbl.vendor_name,
      curated_tbl.property_country_nm,
      curated_tbl.account_type_desc,
      curated_tbl.end_date AS BILLING_MONTH_END_DT,
      NULL AS lease_nbr,
      12 AS DATA_FREQUENCY_CD,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
        ELSE 'NON-RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN curated_tbl.property_nm LIKE 'Nike%'
        OR curated_tbl.property_nm LIKE 'NIKE%'
        OR curated_tbl.property_nm LIKE '%CFS%' THEN 'Stores'
        WHEN curated_tbl.property_nm LIKE '%EHQ%' THEN 'Main HQ'
        ELSE 'Local Office'
      END AS nike_department_type_txt,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Nike Direct/Retail Locations-Nike'
        WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'Nike Direct/Retail Locations-Converse'
        WHEN curated_tbl.property_nm LIKE 'Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
        ELSE 'WD+C (N)'
      END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      CASE
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Factory (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Factory (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Store (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Store (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN ' Headquarters (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN ' Headquarters (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Other Facilities (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Other Facilities (C)'
        ELSE NULL
      END AS division_nm,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.property_address_nm
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(
        building_tbl.CITY_CODE_MAIN,
        curated_tbl.property_city_nm
      ) AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.property_state_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.service_zip_cd
      ) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(
          building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
          curated_tbl.service_zip_cd
        ),
        COALESCE(
          building_tbl.CITY_CODE_MAIN,
          curated_tbl.property_city_nm
        )
      ) AS geographical_axis_nm,
      COALESCE(
        building_tbl.COUNTRY_CODE_MAIN,
        curated_tbl.property_country_nm
      ) AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.square_footage_sqft
      ) AS LOCATION_AREA_IN_SQFT,
      CASE
        WHEN curated_tbl.is_property_ind LIKE 'true' THEN 'Open'
        ELSE 'Close'
      END AS LOCATION_STATUS_CD,
      building_tbl.LATITUDE_MAIN AS latitude_deg,
      building_tbl.LONGITUDE_MAIN AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_metrics' AS cost_usage_data_source_nm,
      cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      COALESCE(cd.YEAR_NBR, 0) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(cd.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      COALESCE(cd.MONTH_OF_YEAR_NBR, 0) AS REPORTING_MONTH_OF_YEAR_NBR,
      COALESCE(cd.QUARTER_NBR, 0) AS REPORTING_QUARTER_NBR,
      COALESCE(cd.WEEK_OF_YEAR_NBR, 0) AS REPORTING_WEEK_OF_YEAR_NBR,
      TO_DATE(
        CONCAT(
          curated_tbl.yrs_nbr,
          '-',
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electric' AS SERVICE_TYPE_CD,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_tbl.yrs_nbr,
              '-',
              LPAD(curated_tbl.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_tbl.yrs_nbr,
                  '-',
                  LPAD(curated_tbl.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT
    FROM
      ELECTRICITY_USAGE_METRICS_USD_TO_EUR_CONVERSION curated_tbl -- CURATED TABLE IS REPLACED WITH ELECTRICITY_USAGE_METRICS_USD_TO_EUR_CONVERSION CTE
      LEFT JOIN BUILDING_COMBINE building_tbl ON curated_tbl.derived_KEY = building_tbl.derived_BLDG_ID_column
      LEFT JOIN {calendar_table_name} AS cd ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_tbl.yrs_nbr,
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = cd.calendar_dt
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
    UNION ALL
    SELECT DISTINCT
      COALESCE(
        curated_tbl.location_nbr_latest,
        curated_tbl.location_nbr
      ) AS electricity_location_nbr,
      COALESCE(
        curated_tbl.location_nm_latest,
        curated_tbl.property_nm
      ) AS electricity_location_nm,
      curated_tbl.total_kwh,
      curated_tbl.universal_usage_uom,
      curated_tbl.days_in_billing_period_days,
      curated_tbl.currency_cd AS SERVICE_COST_UOM,
      curated_tbl.START_DT AS BILLING_MONTH_START_DT,
      curated_tbl.total_cost AS SERVICE_COST,
      curated_tbl.mos_nbr,
      curated_tbl.yrs_nbr,
      curated_tbl.account_cd,
      curated_tbl.universal_unit_uom,
      curated_tbl.service_zip_cd,
      curated_tbl.invoice_id,
      curated_tbl.universal_usage_kbtu,
      curated_tbl.property_address_nm,
      curated_tbl.property_city_nm,
      curated_tbl.service_address_nm,
      curated_tbl.account_active_ind,
      curated_tbl.service_city_nm,
      curated_tbl.property_cd,
      curated_tbl.property_zip_cd,
      curated_tbl.total_usage_uom AS SERVICE_USAGE_QTY,
      curated_tbl.energy_unit AS SERVICE_USAGE_QTY_UOM,
      curated_tbl.vendor_name,
      curated_tbl.property_country_nm,
      curated_tbl.account_type_desc,
      curated_tbl.end_date AS BILLING_MONTH_END_DT,
      NULL AS lease_nbr,
      12 AS DATA_FREQUENCY_CD,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
        ELSE 'NON-RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN curated_tbl.property_nm LIKE 'Nike%'
        OR curated_tbl.property_nm LIKE 'NIKE%'
        OR curated_tbl.property_nm LIKE '%CFS%' THEN 'Stores'
        WHEN curated_tbl.property_nm LIKE '%EHQ%' THEN 'Main HQ'
        ELSE 'Local Office'
      END AS nike_department_type_txt,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Nike Direct/Retail Locations-Nike'
        WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'Nike Direct/Retail Locations-Converse'
        WHEN curated_tbl.property_nm LIKE 'Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
        ELSE 'WD+C (N)'
      END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      CASE
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Factory (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Factory (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Store (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Store (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN ' Headquarters (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN ' Headquarters (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Other Facilities (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Other Facilities (C)'
        ELSE 'NA'
      END AS division_nm,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.property_address_nm
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(
        building_tbl.CITY_CODE_MAIN,
        curated_tbl.property_city_nm
      ) AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.property_state_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.service_zip_cd
      ) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(
          building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
          curated_tbl.service_zip_cd
        ),
        COALESCE(
          building_tbl.CITY_CODE_MAIN,
          curated_tbl.property_city_nm
        )
      ) AS geographical_axis_nm,
      COALESCE(
        building_tbl.COUNTRY_CODE_MAIN,
        curated_tbl.property_country_nm
      ) AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.square_footage_sqft
      ) AS LOCATION_AREA_IN_SQFT,
      CASE
        WHEN curated_tbl.is_property_ind LIKE 'true' THEN 'Open'
        ELSE 'Close'
      END AS LOCATION_STATUS_CD,
      building_tbl.LATITUDE_MAIN AS latitude_deg,
      building_tbl.LONGITUDE_MAIN AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_metrics' AS cost_usage_data_source_nm,
      cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      COALESCE(cd.YEAR_NBR, 0) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(cd.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      COALESCE(cd.MONTH_OF_YEAR_NBR, 0) AS REPORTING_MONTH_OF_YEAR_NBR,
      COALESCE(cd.QUARTER_NBR, 0) AS REPORTING_QUARTER_NBR,
      COALESCE(cd.WEEK_OF_YEAR_NBR, 0) AS REPORTING_WEEK_OF_YEAR_NBR,
      TO_DATE(
        CONCAT(
          curated_tbl.yrs_nbr,
          '-',
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electric' AS SERVICE_TYPE_CD,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_tbl.yrs_nbr,
              '-',
              LPAD(curated_tbl.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_tbl.yrs_nbr,
                  '-',
                  LPAD(curated_tbl.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT
    FROM
      ELECTRICITY_USAGE_METRICS curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON curated_tbl.derived_KEY = building_tbl.derived_BLDG_ID_column
      LEFT JOIN {calendar_table_name} AS cd ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_tbl.yrs_nbr,
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = cd.calendar_dt
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      AND (
        curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE 'Converse%'
      )
    UNION ALL
    SELECT DISTINCT
      COALESCE(
        curated_tbl.location_nbr_latest,
        curated_tbl.location_nbr
      ) AS electricity_location_nbr,
      COALESCE(
        curated_tbl.location_nm_latest,
        curated_tbl.property_nm
      ) AS electricity_location_nm,
      curated_tbl.total_kwh,
      curated_tbl.universal_usage_uom,
      curated_tbl.days_in_billing_period_days,
      curated_tbl.currency_cd AS SERVICE_COST_UOM,
      curated_tbl.START_DT AS BILLING_MONTH_START_DT,
      curated_tbl.total_cost AS SERVICE_COST,
      curated_tbl.mos_nbr,
      curated_tbl.yrs_nbr,
      curated_tbl.account_cd,
      curated_tbl.universal_unit_uom,
      curated_tbl.service_zip_cd,
      curated_tbl.invoice_id,
      curated_tbl.universal_usage_kbtu,
      curated_tbl.property_address_nm,
      curated_tbl.property_city_nm,
      curated_tbl.service_address_nm,
      curated_tbl.account_active_ind,
      curated_tbl.service_city_nm,
      curated_tbl.property_cd,
      curated_tbl.property_zip_cd,
      curated_tbl.total_usage_uom AS SERVICE_USAGE_QTY,
      curated_tbl.energy_unit AS SERVICE_USAGE_QTY_UOM,
      curated_tbl.vendor_name,
      curated_tbl.property_country_nm,
      curated_tbl.account_type_desc,
      curated_tbl.end_date AS BILLING_MONTH_END_DT,
      NULL AS lease_nbr,
      12 AS DATA_FREQUENCY_CD,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'RETAIL'
        ELSE 'NON-RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.property_nm LIKE '%CFS%'
        OR curated_tbl.property_nm LIKE '%Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      CASE
        WHEN curated_tbl.property_nm LIKE 'Nike%'
        OR curated_tbl.property_nm LIKE 'NIKE%'
        OR curated_tbl.property_nm LIKE '%CFS%' THEN 'Stores'
        WHEN curated_tbl.property_nm LIKE '%EHQ%' THEN 'Main HQ'
        ELSE 'Local Office'
      END AS nike_department_type_txt,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      COALESCE(building_tbl.BUILDING_USE_MAIN, NULL) AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Nike Direct/Retail Locations-Nike'
        WHEN curated_tbl.property_nm LIKE 'CFS%' THEN 'Nike Direct/Retail Locations-Converse'
        WHEN curated_tbl.property_nm LIKE 'Converse%'
        OR curated_tbl.property_nm LIKE '%CONVERSE%' THEN 'WD+C (C)'
        ELSE 'WD+C (N)'
      END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      CASE
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Factory (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` IN ('NFS', 'FACTORY')
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Factory (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Retail Store (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'RETAIL'
        AND building_tbl.`"Primary Use"` = 'NSO'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Retail Store (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN ' Headquarters (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN ' Headquarters (C)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE '%Nike%'
        OR curated_tbl.property_nm LIKE '%NIKE%' THEN 'Other Facilities (N)'
        WHEN building_tbl.BUSINESS_GROUP_MAIN = 'NON-RETAIL'
        AND building_tbl.`"Location Type"` = 'Main HQ'
        AND building_tbl.BUILDING_USE_MAIN = 'FREESTYLE OFFICE'
        AND curated_tbl.property_nm LIKE 'CFS%' THEN 'Other Facilities (C)'
        ELSE NULL
      END AS division_nm,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      'Europe' AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.property_address_nm
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(
        building_tbl.CITY_CODE_MAIN,
        curated_tbl.property_city_nm
      ) AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.property_state_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.service_zip_cd
      ) AS POSTAL_CD,
      CONCAT_WS(
        '-',
        COALESCE(
          building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
          curated_tbl.service_zip_cd
        ),
        COALESCE(
          building_tbl.CITY_CODE_MAIN,
          curated_tbl.property_city_nm
        )
      ) AS geographical_axis_nm,
      COALESCE(
        building_tbl.COUNTRY_CODE_MAIN,
        curated_tbl.property_country_nm
      ) AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.square_footage_sqft
      ) AS LOCATION_AREA_IN_SQFT,
      CASE
        WHEN curated_tbl.is_property_ind LIKE 'true' THEN 'Open'
        ELSE 'Close'
      END AS LOCATION_STATUS_CD,
      building_tbl.LATITUDE_MAIN AS latitude_deg,
      building_tbl.LONGITUDE_MAIN AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_metrics' AS cost_usage_data_source_nm,
      cd.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      cd.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      cd.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      COALESCE(cd.YEAR_NBR, 0) AS REPORTING_CALENDAR_YEAR_NBR,
      COALESCE(cd.MONTH_LONG_NM, NULL) AS REPORTING_MONTH_LONG_NM,
      COALESCE(cd.MONTH_OF_YEAR_NBR, 0) AS REPORTING_MONTH_OF_YEAR_NBR,
      COALESCE(cd.QUARTER_NBR, 0) AS REPORTING_QUARTER_NBR,
      COALESCE(cd.WEEK_OF_YEAR_NBR, 0) AS REPORTING_WEEK_OF_YEAR_NBR,
      TO_DATE(
        CONCAT(
          curated_tbl.yrs_nbr,
          '-',
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) AS reporting_period_dt,
      'Electric' AS SERVICE_TYPE_CD,
      CONCAT(
        DATE_FORMAT(
          TO_DATE(
            CONCAT(
              curated_tbl.yrs_nbr,
              '-',
              LPAD(curated_tbl.mos_nbr, 2, '0')
            ),
            'yyyy-MM'
          ),
          'MM/dd/yyyy'
        ),
        '-',
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(
              TO_DATE(
                CONCAT(
                  curated_tbl.yrs_nbr,
                  '-',
                  LPAD(curated_tbl.mos_nbr, 2, '0')
                ),
                'yyyy-MM'
              ),
              1
            )
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT
    FROM
      ELECTRICITY_USAGE_METRICS curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON curated_tbl.derived_KEY = building_tbl.derived_BLDG_ID_column
      LEFT JOIN {calendar_table_name} AS cd ON TO_DATE(
        CONCAT_WS(
          '-',
          curated_tbl.yrs_nbr,
          LPAD(curated_tbl.mos_nbr, 2, '0')
        ),
        'yyyy-MM'
      ) = cd.calendar_dt
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      AND curated_tbl.property_nm NOT LIKE '%CFS%'
      AND curated_tbl.property_nm NOT LIKE '%Nike%'
      AND curated_tbl.property_nm NOT LIKE '%NIKE%'
      AND curated_tbl.property_nm NOT LIKE 'Stockholm Showroom - WESWE - GPS'
      AND curated_tbl.property_nm NOT LIKE 'Nike Europe - 999 - Warsaw Annopol Factory Store'
      AND curated_tbl.property_nm NOT LIKE 'Nike Europe - 662 - Krakow Factory Store'
    ORDER BY
      invoice_id DESC,
      electricity_location_nm ASC,
      yrs_nbr DESC,
      mos_nbr DESC
  ),
  DETAILS_UUID AS (
    SELECT DISTINCT
      ELECTRIC_DETAIL_U.electricity_location_nbr,
      ELECTRIC_DETAIL_U.electricity_location_nm,
      ELECTRIC_DETAIL_U.reporting_period_dt,
      ELECTRIC_DETAIL_U.SERVICE_TYPE_CD,
      COALESCE(
        ELECTRIC_DETAIL_U.BILLING_MONTH_START_DT,
        DATE_TRUNC(
          'MONTH',
          TO_DATE(ELECTRIC_DETAIL_U.reporting_period_dt)
        )
      ) AS BILLING_MONTH_START_DT,
      COALESCE(
        ELECTRIC_DETAIL_U.BILLING_MONTH_END_DT,
        DATE_FORMAT(
          LAST_DAY(
            ADD_MONTHS(TO_DATE(ELECTRIC_DETAIL_U.reporting_period_dt), 1)
          ),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL_U.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL_U.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL_U.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_U.REPORTING_QUARTER_NBR,
      ELECTRIC_DETAIL_U.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL_U.building_id,
      ELECTRIC_DETAIL_U.DATA_FREQUENCY_CD,
      ELECTRIC_DETAIL_U.SERVICE_USAGE_QTY,
      ELECTRIC_DETAIL_U.SERVICE_USAGE_QTY_UOM,
      ELECTRIC_DETAIL_U.SERVICE_COST,
      ELECTRIC_DETAIL_U.SERVICE_COST_UOM,
      ELECTRIC_DETAIL_U.extrapolation_ind,
      ELECTRIC_DETAIL_U.scope_nbr,
      ELECTRIC_DETAIL_U.invoice_id,
      'electricity_usage_metrics' AS cost_usage_data_source_nm
    FROM
      DETAIL_INTEGRATION ELECTRIC_DETAIL_U
  ),
  DETAILS_AGG AS (
    SELECT
      ELECTRIC_DETAIL_A.electricity_location_nbr,
      ELECTRIC_DETAIL_A.electricity_location_nm,
      ELECTRIC_DETAIL_A.reporting_period_dt,
      ELECTRIC_DETAIL_A.SERVICE_TYPE_CD,
      ELECTRIC_DETAIL_A.BILLING_MONTH_START_DT,
      ELECTRIC_DETAIL_A.BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.building_id,
      ELECTRIC_DETAIL_A.DATA_FREQUENCY_CD,
      -- adding this to adhere to get min for same invoice, and sum for different invoice
      CASE
        WHEN COUNT(DISTINCT ELECTRIC_DETAIL_A.invoice_id) > 1 THEN ROUND(SUM(ELECTRIC_DETAIL_A.SERVICE_USAGE_QTY), 2)
        ELSE ROUND(MIN(ELECTRIC_DETAIL_A.SERVICE_USAGE_QTY), 2)
      END AS SERVICE_USAGE_QTY,
      ELECTRIC_DETAIL_A.SERVICE_USAGE_QTY_UOM,
      -- adding this to adhere to get min for same invoice, and sum for different invoice
      CASE
        WHEN COUNT(DISTINCT ELECTRIC_DETAIL_A.invoice_id) > 1 THEN ROUND(SUM(ELECTRIC_DETAIL_A.SERVICE_COST), 2)
        ELSE ROUND(MIN(ELECTRIC_DETAIL_A.SERVICE_COST), 2)
      END AS SERVICE_COST,
      ELECTRIC_DETAIL_A.SERVICE_COST_UOM,
      ELECTRIC_DETAIL_A.extrapolation_ind,
      ELECTRIC_DETAIL_A.scope_nbr,
      ELECTRIC_DETAIL_A.cost_usage_data_source_nm
    FROM
      DETAILS_UUID ELECTRIC_DETAIL_A
    GROUP BY
      ELECTRIC_DETAIL_A.electricity_location_nbr,
      ELECTRIC_DETAIL_A.electricity_location_nm,
      ELECTRIC_DETAIL_A.reporting_period_dt,
      ELECTRIC_DETAIL_A.SERVICE_TYPE_CD,
      ELECTRIC_DETAIL_A.BILLING_MONTH_START_DT,
      ELECTRIC_DETAIL_A.BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL_A.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.REPORTING_QUARTER_NBR,
      ELECTRIC_DETAIL_A.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL_A.building_id,
      ELECTRIC_DETAIL_A.DATA_FREQUENCY_CD,
      ELECTRIC_DETAIL_A.SERVICE_USAGE_QTY_UOM,
      ELECTRIC_DETAIL_A.SERVICE_COST_UOM,
      ELECTRIC_DETAIL_A.extrapolation_ind,
      ELECTRIC_DETAIL_A.scope_nbr,
      ELECTRIC_DETAIL_A.cost_usage_data_source_nm
  ),
  FINAL_AGG AS (
    SELECT
      ELECTRIC_DETAIL.electricity_location_nbr AS electricity_location_nbr,
      ELECTRIC_DETAIL.electricity_location_nm AS electricity_location_nm,
      CAST(ELECTRIC_DETAIL.reporting_period_dt AS DATE) AS reporting_period_dt,
      CASE
        WHEN ELECTRIC_DETAIL.SERVICE_TYPE_CD ILIKE 'Electric' THEN 'Electricity'
        ELSE ELECTRIC_DETAIL.SERVICE_TYPE_CD
      END AS SERVICE_TYPE_CD,
      CAST(
        MIN(ELECTRIC_DETAIL.BILLING_MONTH_START_DT) AS DATE
      ) AS BILLING_MONTH_START_DT,
      CAST(MAX(ELECTRIC_DETAIL.BILLING_MONTH_END_DT) AS DATE) AS BILLING_MONTH_END_DT,
      CONCAT_WS(
        '-',
        DATE_FORMAT(
          MIN(ELECTRIC_DETAIL.BILLING_MONTH_START_DT),
          'MM/dd/yyyy'
        ),
        DATE_FORMAT(
          MAX(ELECTRIC_DETAIL.BILLING_MONTH_END_DT),
          'MM/dd/yyyy'
        )
      ) AS BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRIC_DETAIL.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_CALENDAR_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
      CAST(
        ELECTRIC_DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_MONTH_OF_YEAR_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_QUARTER_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_QUARTER_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_WEEK_OF_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL.building_id AS building_id,
      ELECTRIC_DETAIL.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
      CAST(
        ROUND(SUM(ELECTRIC_DETAIL.SERVICE_USAGE_QTY)) AS DECIMAL(38, 2)
      ) AS SERVICE_USAGE_QTY,
      INITCAP(
        COALESCE(
          MAX(ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM),
          MIN(ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM)
        )
      ) AS SERVICE_USAGE_QTY_UOM,
      CAST(
        ROUND(SUM(ELECTRIC_DETAIL.SERVICE_COST)) AS DECIMAL(38, 2)
      ) AS SERVICE_COST,
      ELECTRIC_DETAIL.SERVICE_COST_UOM AS SERVICE_COST_UOM,
      ELECTRIC_DETAIL.extrapolation_ind AS extrapolation_ind,
      ELECTRIC_DETAIL.scope_nbr AS scope_nbr,
      ELECTRIC_DETAIL.cost_usage_data_source_nm AS cost_usage_data_source_nm
    FROM
      DETAILS_AGG ELECTRIC_DETAIL
    GROUP BY
      ELECTRIC_DETAIL.electricity_location_nbr,
      ELECTRIC_DETAIL.electricity_location_nm,
      ELECTRIC_DETAIL.reporting_period_dt,
      ELECTRIC_DETAIL.SERVICE_TYPE_CD,
      ELECTRIC_DETAIL.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_QUARTER_NBR,
      ELECTRIC_DETAIL.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL.building_id,
      ELECTRIC_DETAIL.DATA_FREQUENCY_CD,
      ELECTRIC_DETAIL.SERVICE_COST_UOM,
      ELECTRIC_DETAIL.extrapolation_ind,
      ELECTRIC_DETAIL.scope_nbr,
      ELECTRIC_DETAIL.cost_usage_data_source_nm
  )
  /* SDF-3777: Adding this extra filter for watchwire to filter out duplicate records for building_id from BCV for non-changing watchwire code */
SELECT
  *
FROM
  FINAL_AGG
WHERE
  NOT (
    (
      electricity_location_nbr = '500'
      AND building_id IN ('RUKIKC2026')
    )
    OR (
      electricity_location_nbr = 'WEST2SO'
      AND building_id IN ('172')
    )
    OR (
      electricity_location_nbr = '818'
      AND building_id IS NULL
    )
  );
