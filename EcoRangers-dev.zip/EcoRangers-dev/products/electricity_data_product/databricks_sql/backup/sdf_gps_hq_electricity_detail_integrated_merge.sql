WITH
  GPS_USAGE_METRICS AS (
    SELECT
      report_period_dt AS reporting_period_dt,
      reporting_month_mos,
      reporting_fiscal_year_yrs,
      your_nm,
      headquarter_cd,
      team_desc,
      natural_gas_uom,
      occupants_cnt,
      combined_square_footage_sqft,
      electricity_usage_kwh,
      electricity_landlord_kwh,
      solar_generation_kwh,
      solar_consumption_kwh,
      propane_uom,
      generator_diesel_gallons,
      fuel_usage_unit_uom,
      gasoline_consumed_uom,
      diesel_consumed_uom,
      electric_vehicle_quantity_kwh,
      diesel_combustion_vehicle_quantity_uom,
      gasoline_combustion_vehicle_quantity_uom,
      refrigerant_units_uom,
      your_email_txt,
      fleet_owner_desc,
      vehicle_data_y_or_n_ind,
      vehicle_types_desc,
      current_dt,
      refrigerants_nm,
      created_by_desc,
      modified_by_desc,
      data_entry_uid,
      fleet_vehicles_conventional_nbr,
      refrigerants_gal,
      natural_gas_usage_therms,
      load_dt,
      load_month_nbr,
      load_year_nbr,
      created_at_tmst,
      user_nm,
      batch_load_tmst,
      job_nm,
      job_run_id
    FROM
      {curated_table_name}
    WHERE
      electricity_usage_kwh IS NOT NULL
      OR solar_generation_kwh IS NOT NULL
  ),
  -- New CTE Added for airtable to filter only GPS data
  AIR_TABLE_METRICS AS (
    SELECT
      generation_or_consumption_country_nm,
      site_common_nm,
      site_official_nm,
      location_nbr,
      nike_business_function_cd,
      sourcing_method_desc,
      tech_type_desc,
      source_method_type
    FROM
      {curated_air_table} air_table
    WHERE
      air_table.nike_business_function_cd ilike 'GPS'
  ),
  ELECTRICITY_INTEGRATION AS (
    SELECT DISTINCT
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        /* SDF-3105: Commenting the below lines to not consider the EV consumption dataset from fleet sites, requirement from SDF-WHQ Team */
        -- when curated_tbl.headquarter_cd = 'WHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (WHQ)'
        -- when curated_tbl.headquarter_cd = 'GCHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (GCHQ)'
        -- when curated_tbl.headquarter_cd like '%Converse%' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'Converse HQ Fleet (WHQ)'
        -- when curated_tbl.headquarter_cd = 'EHQ' and (VEHICLE_TYPES_DESC like '%Electric%' OR TEAM_DESC ='Transportation') then 'HQ Fleet (EHQ)'
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'TMT'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'HQ (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'HQ (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'Greater China Headquarters'
        WHEN curated_tbl.headquarter_cd LIKE '%Converse%' THEN 'Others' -- DATA render from engie source
        ELSE NULL
      END AS electricity_location_nbr,
      CASE
        WHEN curated_tbl.headquarter_cd = 'WHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ'
        AND TEAM_DESC = 'Security' THEN 'Security Fleet (GCHQ)'
        /* SDF-3105: Commenting the below lines to not consider the EV consumption dataset from fleet sites, requirement from SDF-WHQ Team */
        -- when curated_tbl.headquarter_cd = 'WHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (WHQ)'
        -- -- Renaming Nike HQ Fleet - Greater China (GCHQ) for transportation to HQ Fleet (GCHQ) as per Pritha's suggestion from Enablon screenshots
        -- when curated_tbl.headquarter_cd = 'GCHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (GCHQ)'
        -- ---------
        -- --- Renaming Nike HQ Fleet - Europe (EHQ) to HQ Fleet (EHQ) as per Pritha's suggestion from Enablon screenshots 
        -- when curated_tbl.headquarter_cd = 'EHQ' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'HQ Fleet (EHQ)'
        -- --------
        -- when curated_tbl.headquarter_cd like '%Converse%' and (VEHICLE_TYPES_DESC like '%Electric%' or TEAM_DESC ='Transportation') then 'Converse HQ Fleet (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'WHQ' THEN 'Nike HQ - North America (WHQ)'
        WHEN curated_tbl.headquarter_cd = 'EHQ' THEN 'Nike HQ - Europe (EHQ)'
        WHEN curated_tbl.headquarter_cd = 'GCHQ' THEN 'Nike HQ - Greater China (GCHQ)'
        WHEN curated_tbl.headquarter_cd LIKE '%Converse%' THEN 'Others' -- DATA render from engie source
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN 'Tokyo Midtown Tower'
        ELSE NULL
      END AS electricity_location_nm,
      --    CASE
      --        WHEN curated_tbl.headquarter_cd = 'Japan' and curated_tbl.electricity_usage_kwh IS NOT NULL THEN
      --            'Green Power Purchase - Retail Supply - Solar'
      --        ELSE
      --            'Electricity'
      --    END AS SERVICE_TYPE_CD,     -- Commented logic for service type, new logic added below once migrate with airtable
      DATE_FORMAT(reporting_period_dt, 'yyyy-MM') AS reporting_year_month, -- Added column to do aggregation based on same month and year
      reporting_period_dt,
      CONCAT_WS(
        '-',
        DATE_FORMAT(calendar_tbl.MONTH_START_DT, 'MM/dd/yyyy'),
        DATE_FORMAT(calendar_tbl.MONTH_END_DT, 'MM/dd/yyyy')
      ) AS BILLING_MONTH_DATE_RANGE_TXT,
      calendar_tbl.FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      calendar_tbl.FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      calendar_tbl.FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      calendar_tbl.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
      calendar_tbl.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
      calendar_tbl.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
      calendar_tbl.QUARTER_NBR AS REPORTING_QUARTER_NBR,
      calendar_tbl.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
      calendar_tbl.MONTH_START_DT AS BILLING_MONTH_START_DT,
      calendar_tbl.MONTH_END_DT AS BILLING_MONTH_END_DT,
      NULL AS building_id,
      12 AS DATA_FREQUENCY_CD,
      --ELECTRICITY_USAGE_KWH AS SERVICE_USAGE_QTY,
      CASE
        WHEN curated_tbl.headquarter_cd IN ('Japan', 'Tokyo Midtown Tower') THEN solar_generation_kwh
        ELSE ELECTRICITY_USAGE_KWH
      END AS SERVICE_USAGE_QTY,
      'KWH' AS SERVICE_USAGE_QTY_UOM,
      NULL AS SERVICE_COST,
      NULL AS SERVICE_COST_UOM,
      'FALSE' AS extrapolation_ind,
      'SCOPE 2' AS scope_nbr,
      'gps_usage_metrics' AS cost_usage_data_source_nm
    FROM
      GPS_USAGE_METRICS curated_tbl
      LEFT JOIN {calendar_table_name} calendar_tbl ON curated_tbl.reporting_period_dt = calendar_tbl.calendar_dt
  ),
  ELECTRICITY_AIRTABLE_INT AS (
    SELECT
      electricity_location_nbr AS electricity_location_nbr,
      electricity_location_nm AS electricity_location_nm,
      CASE
        WHEN EINT.electricity_location_nbr = 'TMT'
        AND airtable.sourcing_method_desc ilike '%Purchase%' THEN 'Green Power Purchase - Retail Supply - Solar'
        WHEN EINT.electricity_location_nbr = 'TMT'
        AND airtable.sourcing_method_desc ilike '%Owned%' THEN 'Green Power Owned - Retail Supply - Solar'
        ELSE 'Electricity'
      END AS SERVICE_TYPE_CD,
      --   explode(CASE
      --    WHEN EINT.electricity_location_nbr = 'TMT' and airtable.sourcing_method_desc ilike '%Purchase%' THEN array('Green Power Purchase - Retail Supply - Solar Generation','Green Power Purchase - Retail Supply - Solar Consumption')
      --    WHEN EINT.electricity_location_nbr = 'TMT' and airtable.sourcing_method_desc ilike '%Owned%' THEN array('Green Power Owned - Retail Supply - Solar Generation','Green Power Owned - Retail Supply - Solar Consumption')
      --    ELSE array('Electricity')
      --  END) AS SERVICE_TYPE_CD,
      reporting_year_month AS reporting_year_month,
      reporting_period_dt AS reporting_period_dt,
      BILLING_MONTH_DATE_RANGE_TXT AS BILLING_MONTH_DATE_RANGE_TXT,
      REPORTING_FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR AS REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
      BILLING_MONTH_START_DT AS BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT AS BILLING_MONTH_END_DT,
      building_id AS building_id,
      DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
      SERVICE_USAGE_QTY AS SERVICE_USAGE_QTY,
      SERVICE_USAGE_QTY_UOM AS SERVICE_USAGE_QTY_UOM,
      SERVICE_COST AS SERVICE_COST,
      SERVICE_COST_UOM AS SERVICE_COST_UOM,
      extrapolation_ind AS extrapolation_ind,
      scope_nbr AS scope_nbr,
      cost_usage_data_source_nm AS cost_usage_data_source_nm
    FROM
      ELECTRICITY_INTEGRATION EINT
      LEFT JOIN AIR_TABLE_METRICS airtable ON EINT.electricity_location_nbr = airtable.location_nbr
  ),
  ELECTRICITY_AGG AS (
    SELECT
      ELECTRIC_DETAIL.electricity_location_nbr,
      ELECTRIC_DETAIL.electricity_location_nm,
      MIN(ELECTRIC_DETAIL.reporting_period_dt) AS reporting_period_dt, -- Added to get minimum data among the same month and year have multiple reporting date
      ELECTRIC_DETAIL.reporting_year_month,
      CASE
        WHEN ELECTRIC_DETAIL.SERVICE_TYPE_CD ILIKE 'Electric' THEN 'Electricity'
        ELSE ELECTRIC_DETAIL.SERVICE_TYPE_CD
      END AS SERVICE_TYPE_CD,
      ELECTRIC_DETAIL.BILLING_MONTH_START_DT,
      ELECTRIC_DETAIL.BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL.BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRIC_DETAIL.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_CALENDAR_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_MONTH_LONG_NM,
      CAST(
        ELECTRIC_DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_MONTH_OF_YEAR_NBR,
      CAST(
        ELECTRIC_DETAIL.REPORTING_QUARTER_NBR AS DECIMAL(38, 0)
      ) AS REPORTING_QUARTER_NBR,
      -- ELECTRIC_DETAIL.REPORTING_WEEK_OF_YEAR_NBR,
      CAST(
        MIN(ELECTRIC_DETAIL.REPORTING_WEEK_OF_YEAR_NBR) AS DECIMAL(38, 0)
      ) AS REPORTING_WEEK_OF_YEAR_NBR, -- Added this as reporting date is getting as minimum of reporting_period_dt
      ELECTRIC_DETAIL.building_id,
      ELECTRIC_DETAIL.DATA_FREQUENCY_CD,
      CAST(
        SUM(ELECTRIC_DETAIL.SERVICE_USAGE_QTY) AS DECIMAL(38, 2)
      ) AS SERVICE_USAGE_QTY,
      -- INITCAP(ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM) AS SERVICE_USAGE_QTY_UOM,
      INITCAP(
        COALESCE(
          MAX(ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM),
          MIN(ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM)
        )
      ) AS SERVICE_USAGE_QTY_UOM, -- Added to get the maximum value of uom if there are multiple uom with NULL
      -- ELECTRIC_DETAIL.SERVICE_COST,
      CAST(
        SUM(ELECTRIC_DETAIL.SERVICE_COST) AS DECIMAL(38, 2)
      ) AS SERVICE_COST,
      ELECTRIC_DETAIL.SERVICE_COST_UOM,
      ELECTRIC_DETAIL.extrapolation_ind,
      ELECTRIC_DETAIL.scope_nbr,
      'gps_usage_metrics' AS cost_usage_data_source_nm
    FROM
      ELECTRICITY_AIRTABLE_INT ELECTRIC_DETAIL
    GROUP BY
      ELECTRIC_DETAIL.electricity_location_nbr,
      ELECTRIC_DETAIL.electricity_location_nm,
      ELECTRIC_DETAIL.reporting_year_month,
      ELECTRIC_DETAIL.SERVICE_TYPE_CD,
      ELECTRIC_DETAIL.BILLING_MONTH_START_DT,
      ELECTRIC_DETAIL.BILLING_MONTH_END_DT,
      ELECTRIC_DETAIL.BILLING_MONTH_DATE_RANGE_TXT,
      ELECTRIC_DETAIL.REPORTING_FISCAL_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_QUARTER_NBR,
      ELECTRIC_DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_CALENDAR_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_MONTH_LONG_NM,
      ELECTRIC_DETAIL.REPORTING_MONTH_OF_YEAR_NBR,
      ELECTRIC_DETAIL.REPORTING_QUARTER_NBR,
      -- ELECTRIC_DETAIL.REPORTING_WEEK_OF_YEAR_NBR,
      ELECTRIC_DETAIL.building_id,
      ELECTRIC_DETAIL.DATA_FREQUENCY_CD,
      -- ELECTRIC_DETAIL.SERVICE_USAGE_QTY_UOM,
      ELECTRIC_DETAIL.SERVICE_COST,
      ELECTRIC_DETAIL.SERVICE_COST_UOM,
      ELECTRIC_DETAIL.extrapolation_ind,
      ELECTRIC_DETAIL.scope_nbr,
      cost_usage_data_source_nm
  )
SELECT
  ELECTRIC_DETAIL_AGG.electricity_location_nbr,
  /* Changes suggested by Pritha, Nike GCHQ for GPS needs to be renamed to Greater China HeadQuarters */
  CASE
    WHEN ELECTRIC_DETAIL_AGG.electricity_location_nm = 'Nike HQ - Greater China (GCHQ)' THEN 'Greater China Headquarters'
    ELSE ELECTRIC_DETAIL_AGG.electricity_location_nm
  END AS electricity_location_nm,
  ELECTRIC_DETAIL_AGG.reporting_period_dt,
  ELECTRIC_DETAIL_AGG.SERVICE_TYPE_CD,
  ELECTRIC_DETAIL_AGG.BILLING_MONTH_START_DT,
  ELECTRIC_DETAIL_AGG.BILLING_MONTH_END_DT,
  ELECTRIC_DETAIL_AGG.BILLING_MONTH_DATE_RANGE_TXT,
  ELECTRIC_DETAIL_AGG.REPORTING_FISCAL_YEAR_NBR,
  ELECTRIC_DETAIL_AGG.REPORTING_FISCAL_QUARTER_NBR,
  ELECTRIC_DETAIL_AGG.REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  ELECTRIC_DETAIL_AGG.REPORTING_CALENDAR_YEAR_NBR,
  ELECTRIC_DETAIL_AGG.REPORTING_MONTH_LONG_NM,
  ELECTRIC_DETAIL_AGG.REPORTING_MONTH_OF_YEAR_NBR,
  ELECTRIC_DETAIL_AGG.REPORTING_QUARTER_NBR,
  ELECTRIC_DETAIL_AGG.REPORTING_WEEK_OF_YEAR_NBR,
  ELECTRIC_DETAIL_AGG.building_id,
  ELECTRIC_DETAIL_AGG.DATA_FREQUENCY_CD,
  ELECTRIC_DETAIL_AGG.SERVICE_USAGE_QTY,
  ELECTRIC_DETAIL_AGG.SERVICE_USAGE_QTY_UOM,
  ELECTRIC_DETAIL_AGG.SERVICE_COST,
  ELECTRIC_DETAIL_AGG.SERVICE_COST_UOM,
  ELECTRIC_DETAIL_AGG.extrapolation_ind,
  ELECTRIC_DETAIL_AGG.scope_nbr,
  ELECTRIC_DETAIL_AGG.cost_usage_data_source_nm
FROM
  ELECTRICITY_AGG ELECTRIC_DETAIL_AGG
WHERE
  /* Remove 'Others' category corresponding to Converse headquarter data which is already coming from engie data source, Removing EHQ data as it is already coming from MACE data source.*/
  ELECTRIC_DETAIL_AGG.electricity_location_nbr != 'Others'
  AND ELECTRIC_DETAIL_AGG.electricity_location_nm != 'Others'
  AND ELECTRIC_DETAIL_AGG.electricity_location_nbr IS NOT NULL
  AND ELECTRIC_DETAIL_AGG.electricity_location_nm IS NOT NULL
  AND NOT (
    ELECTRIC_DETAIL_AGG.electricity_location_nbr = 'HQ (EHQ)'
    AND ELECTRIC_DETAIL_AGG.SERVICE_TYPE_CD ilike '%electricity%'
  );
