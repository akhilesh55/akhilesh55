WITH
  BUILDING_COMBINE AS (
    SELECT
      CASE
        WHEN TRIM(
          SPLIT_PART (B_COMBINE.`"Tririga POS Store ID"`, '-', 2)
        ) = '' THEN NULL
        ELSE TRIM(
          SPLIT_PART (B_COMBINE.`"Tririga POS Store ID"`, '-', 2)
        )
      END AS derived_POS_Store_ID_column,
      B_COMBINE.`"Tririga POS Store ID"`,
      RIGHT(B_COMBINE.TRIRIGA_BUILDING_ID, 4) AS derived_BLDG_ID_column,
      B_COMBINE.TRIRIGA_BUILDING_ID,
      B_COMBINE.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
      B_COMBINE.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
      B_COMBINE.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
      B_COMBINE.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
      B_COMBINE.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
      B_COMBINE.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
      B_COMBINE.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
      B_COMBINE.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
      B_COMBINE.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
      B_COMBINE.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
      B_COMBINE.`"Building Type"` AS `"Building Type"`,
      B_COMBINE.`"Location Type"` AS `"Location Type"`,
      B_COMBINE.`"Nike Key City"` AS `"Nike Key City"`,
      B_COMBINE.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
      B_COMBINE.`"Business Group"` AS `"Business Group"`,
      B_COMBINE.`"Campus - Corporate Park"` AS `"Campus - Corporate Park"`,
      B_COMBINE.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
      B_COMBINE.CITY_CODE_MAIN AS CITY_CODE_MAIN,
      B_COMBINE.CONTINENT_CODE AS CONTINENT_CODE,
      B_COMBINE.CONTINENT_NAME AS CONTINENT_NAME,
      B_COMBINE.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
      B_COMBINE.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
      B_COMBINE.LOCATION_REGION AS LOCATION_REGION,
      B_COMBINE.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
      B_COMBINE.`"NIKE GEO"` AS `"NIKE GEO"`,
      B_COMBINE.`"Primary Use"` AS `"Primary Use"`,
      B_COMBINE.REPORT_DATE AS REPORT_DATE,
      B_COMBINE.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
      B_COMBINE.STATE_PROV_MAIN AS STATE_PROV_MAIN,
      B_COMBINE.STATE_CODE_MAIN AS STATE_CODE_MAIN,
      B_COMBINE.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
      B_COMBINE.`"Tririga Brand"` AS `"Tririga Brand"`,
      B_COMBINE.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
      -- B_COMBINE.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
      B_COMBINE.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
      B_COMBINE.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
      B_COMBINE.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
      B_COMBINE.`"Tririga Contract Status"` AS `"Tririga Contract Status"`,
      B_COMBINE.TRIRIGA_GEO AS TRIRIGA_GEO,
      B_COMBINE.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
      B_COMBINE.LATITUDE_MAIN AS LATITUDE_MAIN,
      B_COMBINE.LONGITUDE_MAIN AS LONGITUDE_MAIN,
      B_COMBINE.`"Tririga GIS LAT"` AS `"Tririga GIS LAT"`,
      B_COMBINE.`"Tririga GIS LON"` AS `"Tririga GIS LON"`,
      -- B_COMBINE.`Tririga POS Store ID` AS `Tririga POS Store ID"`,
      B_COMBINE.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
      B_COMBINE.TRIRIGA_ZIP_POSTAL_CODE AS TRIRIGA_ZIP_POSTAL_CODE,
      B_COMBINE.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
      B_COMBINE.WDC_REGION_MAIN AS WDC_REGION_MAIN,
      B_COMBINE.`"Zip Code Main"` AS `"Zip Code Main"`,
      B_COMBINE.ARCHIBUS_USF AS ARCHIBUS_USF,
      B_COMBINE.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
      B_COMBINE.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      B_COMBINE.`"Max. Bldg. Capacity"` AS `"Max. Bldg. Capacity"`,
      B_COMBINE.`"Number of Floors"` AS `"Number of Floors"`,
      ROW_NUMBER() OVER (
        PARTITION BY
          B_COMBINE.BUILDING_CODE_MAIN,
          B_COMBINE.`"Tririga POS Store ID"`
          -- B_COMBINE.BUILDING_USF_MAIN
        ORDER BY
          B_COMBINE.report_date DESC
      ) AS COMBINE_PART
    FROM
      BUILDING_TABLE_NAME B_COMBINE
    WHERE
      B_COMBINE.`"NIKE GEO"` = 'EMEA'
      --AND B_COMBINE.DISPLAY_LATEST_MAIN='LATEST'
  ),
  TAXONOMY_TABLE AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_mapping_tbl}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  CURATED_VIEW AS (
    SELECT
      REGEXP_EXTRACT(curated_tbl.concept_nm, '\\d+', 0) AS derived_KEY,
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm,
      curated_tbl.client_site_ref_id,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.concept_nm,
      curated_tbl.street_txt,
      curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt,
      curated_tbl.end_dt,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh,
      curated_tbl.invoiced_cost,
      curated_tbl.invoiced_usage_qty,
      curated_tbl.currency_cd -- 
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm
    FROM
      {curated_table_name} curated_tbl MINUS
    SELECT
      REGEXP_EXTRACT(curated_tbl.concept_nm, '\\d+', 0) AS derived_KEY,
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm,
      curated_tbl.client_site_ref_id,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.concept_nm,
      curated_tbl.street_txt,
      curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt,
      curated_tbl.end_dt,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh,
      curated_tbl.invoiced_cost,
      curated_tbl.invoiced_usage_qty,
      curated_tbl.currency_cd -- 
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm
    FROM
      {curated_table_name_rejects} curated_tbl
  ),
  SITE_INTEGRATION AS (
    SELECT DISTINCT
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm AS electricity_location_nm,
      curated_tbl.client_site_ref_id AS electricity_location_nbr,
      curated_tbl.concept_nm,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.street_txt,
      -- curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt,
      curated_tbl.end_dt,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh,
      curated_tbl.invoiced_cost,
      curated_tbl.invoiced_usage_qty,
      curated_tbl.currency_cd,
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%Nike Offices%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Offices%' THEN 'NON-RETAIL'
        ELSE 'RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Office%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      CASE
        WHEN building_tbl.BUILDING_USE_MAIN IS NOT NULL THEN building_tbl.BUILDING_USE_MAIN
        WHEN emea_tbl.BUILDING_USE_MAIN_bcv IS NOT NULL THEN emea_tbl.BUILDING_USE_MAIN_bcv
        WHEN curated_tbl.concept_nm IN ('NSO', 'NFS') THEN curated_tbl.concept_nm
        WHEN curated_tbl.concept_nm IN ('NVS', 'CFS') THEN 'FACTORY'
        WHEN curated_tbl.concept_nm ILIKE '%office%' THEN 'OFFICE'
      END AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN building_tbl.`"Primary Use"` ILIKE 'NSO' THEN 'Retail Inline'
        WHEN building_tbl.`"Primary Use"` IN ('NVS', 'NFS', 'CFS', 'FACTORY') THEN 'Retail Factory'
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` = 'Key Location' THEN 'Other Facilities'
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` IS NOT NULL THEN building_tbl.`"Location Type"`
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` ILIKE '%Main HQ%' THEN 'Main HQ'
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IN ('NVS', 'NFS', 'CFS') THEN 'Retail Factory'
        WHEN emea_tbl.primary_use_bcv IN ('NVS', 'NFS', 'CFS', 'FACTORY') THEN 'Retail Factory'
        WHEN curated_tbl.concept_nm ILIKE '%nike office%' THEN 'Local Office'
      END AS nike_department_type_txt,
      -- CASE
      --     WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline (N)'
      --     WHEN curated_tbl.concept_nm IN ('NVS') THEN 'Retail Factory (N)'
      --     WHEN curated_tbl.concept_nm IN ('CFS') THEN 'Retail Factory (C)'
      --     WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Other Facilities (N)'
      --     WHEN curated_tbl.concept_nm LIKE 'NIKE%' AND building_tbl.`"Primary Use"` IN ("NVS","NFS") THEN 'Retail Factory(N)'
      --     WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'Retail Factory(C)'
      --     WHEN curated_tbl.concept_nm LIKE '%EHQ%' THEN 'Headquarters (N)'
      --     WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Other Facilities (C)'
      -- ELSE 'Retail Factory (N)' END AS division_nm,
      COALESCE(ctry_mapping.ctry_nm, curated_tbl.city_nm) AS geographical_axis_nm,
      -- CASE 
      -- WHEN curated_tbl.concept_nm IN ("NSO", 'NVS') THEN 'DTC (N)'
      -- WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'DTC (C)'
      -- WHEN curated_tbl.concept_nm LIKE 'Converse%' OR curated_tbl.concept_nm LIKE '%CONVERSE%' THEN 'WD+C (C)' 
      -- ELSE 'DTC (N)'
      -- END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      COALESCE(building_tbl.CONTINENT_NAME, 'Europe') AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.street_txt
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(building_tbl.CITY_CODE_MAIN, curated_tbl.city_nm) AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.subleague_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.zip_cd
      ) AS POSTAL_CD,
      -- curated_tbl.zip_cd AS POSTAL_CD,
      -- CONCAT_WS(
      --     '-',
      --     COALESCE(building_tbl.TRIRIGA_ZIP_POSTAL_CODE,curated_tbl.zip_cd),
      --     COALESCE(building_tbl.CITY_CODE_MAIN,curated_tbl.city_nm)
      -- ) AS geographical_axis_nm,
      COALESCE(
        building_tbl.COUNTRY_CODE_MAIN,
        ctry_mapping.CTRY_CD
      ) AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.site_size_in_sqft
      ) AS LOCATION_AREA,
      CASE
        WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'square feet'
        ELSE 'square metre'
      END AS LOCATION_AREA_UOM,
      -- CASE WHEN curated_tbl.is_property_ind = 'true' THEN 'Open'
      -- ELSE 'Close'
      -- END as LOCATION_STATUS_CD,
      COALESCE(
        building_tbl.LATITUDE_MAIN,
        curated_tbl.location_latitude_deg
      ) AS latitude_deg,
      COALESCE(
        building_tbl.LONGITUDE_MAIN,
        curated_tbl.location_longitude_deg
      ) AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      CASE
        WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'building_combined'
        ELSE 'electricity_usage_and_cost_metrics'
      END AS LOCATION_AREA_DATA_SOURCE_NM
    FROM
      CURATED_VIEW curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl
      -- ON curated_tbl.property_zip_cd = building_tbl.TRIRIGA_ZIP_POSTAL_CODE
      --ON curated_tbl.derived_KEY = building_tbl.derived_POS_Store_ID_column
      ON curated_tbl.client_site_ref_id = building_tbl.`"Tririga POS Store ID"`
      OR LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) = building_tbl.derived_POS_Store_ID_column
      LEFT JOIN emea_tbl emea_tbl ON curated_tbl.client_site_ref_id = emea_tbl.location_nbr
      LEFT JOIN TAXONOMY_TABLE ctry_mapping ON curated_tbl.country_nm = ctry_mapping.ctry_nm
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      --  and building_tbl.derived_POS_Store_ID_column is not null
      AND LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) IS NOT NULL
      AND curated_tbl.site_nm NOT LIKE '%Converse%'
    UNION ALL
    SELECT DISTINCT
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm AS electricity_location_nm,
      curated_tbl.client_site_ref_id AS electricity_location_nbr,
      curated_tbl.concept_nm,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.street_txt,
      curated_tbl.zip_cd,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt,
      curated_tbl.end_dt,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh,
      curated_tbl.invoiced_cost,
      curated_tbl.invoiced_usage_qty,
      curated_tbl.currency_cd,
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%Nike Offices%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Offices%' THEN 'NON-RETAIL'
        ELSE 'RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Office%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      CASE
        WHEN building_tbl.BUILDING_USE_MAIN IS NOT NULL THEN building_tbl.BUILDING_USE_MAIN
        WHEN curated_tbl.concept_nm IN ('NSO', 'NFS') THEN curated_tbl.concept_nm
        WHEN curated_tbl.concept_nm IN ('NVS', 'CFS') THEN 'FACTORY'
        WHEN curated_tbl.concept_nm ILIKE '%office%' THEN 'OFFICE'
      END AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN building_tbl.`"Primary Use"` ILIKE 'NSO' THEN 'Retail Inline'
        WHEN building_tbl.`"Primary Use"` IN ('NVS', 'NFS', 'CFS', 'FACTORY') THEN 'Retail Factory'
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` = 'Key Location' THEN 'Other Facilities'
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` IS NOT NULL THEN building_tbl.`"Location Type"`
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` ILIKE '%Main HQ%' THEN 'Main HQ'
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IN ('NVS', 'NFS', 'CFS') THEN 'Retail Factory'
        WHEN curated_tbl.concept_nm ILIKE '%nike office%' THEN 'Local Office'
      END AS nike_department_type_txt,
      -- CASE
      --     WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline (N)'
      --     WHEN curated_tbl.concept_nm IN ('NVS') THEN 'Retail Factory (N)'
      --     WHEN curated_tbl.concept_nm IN ('CFS') THEN 'Retail Factory (C)'
      --     WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Other Facilities (N)'
      --     WHEN curated_tbl.concept_nm LIKE 'NIKE%' AND building_tbl.`"Primary Use"` IN ("NVS","NFS") THEN 'Retail Factory(N)'
      --     WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'Retail Factory(C)'
      --     WHEN curated_tbl.concept_nm LIKE '%EHQ%' THEN 'Headquarters (N)'
      --     WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Other Facilities (C)'
      -- ELSE 'Retail Factory (N)' END AS division_nm,
      COALESCE(ctry_mapping.ctry_nm, curated_tbl.city_nm) AS geographical_axis_nm,
      -- CASE 
      -- WHEN curated_tbl.concept_nm IN ("NSO", 'NVS') THEN 'DTC (N)'
      -- WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'DTC (C)'
      -- WHEN curated_tbl.concept_nm LIKE 'Converse%' OR curated_tbl.concept_nm LIKE '%CONVERSE%' THEN 'WD+C (C)' 
      -- ELSE 'DTC (N)'
      -- END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      COALESCE(building_tbl.CONTINENT_NAME, 'Europe') AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.street_txt
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(building_tbl.CITY_CODE_MAIN, curated_tbl.city_nm) AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.subleague_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.zip_cd
      ) AS POSTAL_CD,
      -- curated_tbl.zip_cd AS POSTAL_CD,
      -- CONCAT_WS(
      --     '-',
      --     COALESCE(building_tbl.TRIRIGA_ZIP_POSTAL_CODE,curated_tbl.zip_cd),
      --     COALESCE(building_tbl.CITY_CODE_MAIN,curated_tbl.city_nm)
      -- ) AS geographical_axis_nm,
      COALESCE(
        building_tbl.COUNTRY_CODE_MAIN,
        ctry_mapping.CTRY_CD
      ) AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.site_size_in_sqft
      ) AS LOCATION_AREA,
      CASE
        WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'square feet'
        ELSE 'square metre'
      END AS LOCATION_AREA_UOM,
      -- CASE WHEN curated_tbl.is_property_ind = 'true' THEN 'Open'
      -- ELSE 'Close'
      -- END as LOCATION_STATUS_CD,
      COALESCE(
        building_tbl.LATITUDE_MAIN,
        curated_tbl.location_latitude_deg
      ) AS latitude_deg,
      COALESCE(
        building_tbl.LONGITUDE_MAIN,
        curated_tbl.location_longitude_deg
      ) AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      CASE
        WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'building_combined'
        ELSE 'electricity_usage_and_cost_metrics'
      END AS LOCATION_AREA_DATA_SOURCE_NM
    FROM
      CURATED_VIEW curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl
      -- ON curated_tbl.property_zip_cd = building_tbl.TRIRIGA_ZIP_POSTAL_CODE
      --ON curated_tbl.derived_KEY = building_tbl.derived_POS_Store_ID_column
      ON curated_tbl.client_site_ref_id = building_tbl.`"Tririga POS Store ID"`
      OR LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) = RIGHT(building_tbl.TRIRIGA_BUILDING_ID, 4)
      LEFT JOIN TAXONOMY_TABLE ctry_mapping ON curated_tbl.country_nm = ctry_mapping.ctry_nm
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      --  and building_tbl.derived_POS_Store_ID_column is not null
      AND LPAD(
        REGEXP_SUBSTR (curated_tbl.client_site_ref_id, '^[0-9]+'),
        4,
        '0'
      ) IS NOT NULL
      AND curated_tbl.site_nm LIKE '%Converse%'
    UNION ALL
    SELECT DISTINCT
      curated_tbl.site_address_company_nm,
      curated_tbl.site_nm AS electricity_location_nm,
      curated_tbl.client_site_ref_id AS electricity_location_nbr,
      curated_tbl.concept_nm,
      curated_tbl.league_nm,
      curated_tbl.subleague_nm,
      curated_tbl.street_txt,
      -- curated_tbl.city_nm,
      curated_tbl.zip_cd,
      curated_tbl.location_latitude_deg,
      curated_tbl.location_longitude_deg,
      curated_tbl.store_nm,
      curated_tbl.country_nm,
      curated_tbl.site_size_in_sqft,
      curated_tbl.start_dt,
      curated_tbl.end_dt,
      curated_tbl.site_status_Ind_cd,
      curated_tbl.utility_type_nm,
      curated_tbl.energy_unit_in_kwh,
      curated_tbl.invoiced_cost,
      curated_tbl.invoiced_usage_qty,
      curated_tbl.currency_cd,
      -- curated_tbl.load_dt,
      -- curated_tbl.load_month_nbr,
      -- curated_tbl.load_year_nbr,
      -- curated_tbl.created_at_tmst,
      -- curated_tbl.user_nm,
      building_tbl.TRIRIGA_BUILDING_ID AS building_id,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%Nike Offices%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Offices%' THEN 'NON-RETAIL'
        ELSE 'RETAIL'
      END AS business_group_txt,
      CASE
        WHEN curated_tbl.concept_nm LIKE '%CFS%'
        OR curated_tbl.concept_nm LIKE '%Converse - Nike Office%' THEN 'Converse'
        ELSE 'Nike'
      END AS brand_nm,
      COALESCE(building_tbl.LOCATION_REGION, 'Europe') AS BUSINESS_ENTITY_GEO_REGION_CD,
      CASE
        WHEN building_tbl.BUILDING_USE_MAIN IS NOT NULL THEN building_tbl.BUILDING_USE_MAIN
        WHEN emea_tbl.BUILDING_USE_MAIN_bcv IS NOT NULL THEN emea_tbl.BUILDING_USE_MAIN_bcv
        WHEN curated_tbl.concept_nm IN ('NSO', 'NFS') THEN curated_tbl.concept_nm
        WHEN curated_tbl.concept_nm IN ('NVS', 'CFS') THEN 'FACTORY'
        WHEN curated_tbl.concept_nm ILIKE '%office%' THEN 'OFFICE'
      END AS ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN building_tbl.`"Primary Use"` ILIKE 'NSO' THEN 'Retail Inline'
        WHEN building_tbl.`"Primary Use"` IN ('NVS', 'NFS', 'CFS', 'FACTORY') THEN 'Retail Factory'
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` = 'Key Location' THEN 'Other Facilities'
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` ILIKE '%Main HQ%' THEN 'Main HQ'
        WHEN building_tbl.`"Primary Use"` ILIKE '%office%'
        AND building_tbl.`"Location Type"` IS NOT NULL THEN building_tbl.`"Location Type"`
        WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline'
        WHEN curated_tbl.concept_nm IN ('NVS', 'NFS', 'CFS') THEN 'Retail Factory'
        WHEN emea_tbl.primary_use_bcv IN ('NVS', 'NFS', 'CFS', 'FACTORY') THEN 'Retail Factory'
        WHEN (
          emea_tbl.primary_use_bcv ILIKE '%office%'
          AND emea_tbl.Location_type_bcv ilike '%Main HQ%'
        )
        OR (
          emea_tbl.building_name_main_bcv ilike '%NIKE EHQ%'
        ) THEN 'Main HQ'
        WHEN emea_tbl.primary_use_bcv IN ('NVS', 'NFS', 'CFS', 'FACTORY') THEN 'Retail Factory'
        WHEN curated_tbl.concept_nm ILIKE '%nike office%' THEN 'Local Office'
      END AS nike_department_type_txt,
      -- CASE
      --     WHEN curated_tbl.concept_nm ILIKE 'NSO' THEN 'Retail Inline (N)'
      --     WHEN curated_tbl.concept_nm IN ('NVS') THEN 'Retail Factory (N)'
      --     WHEN curated_tbl.concept_nm IN ('CFS') THEN 'Retail Factory (C)'
      --     WHEN curated_tbl.concept_nm LIKE 'Nike%' THEN 'Other Facilities (N)'
      --     WHEN curated_tbl.concept_nm LIKE 'NIKE%' AND building_tbl.`"Primary Use"` IN ("NVS","NFS") THEN 'Retail Factory(N)'
      --     WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'Retail Factory(C)'
      --     WHEN curated_tbl.concept_nm LIKE '%EHQ%' THEN 'Headquarters (N)'
      --     WHEN curated_tbl.concept_nm LIKE '%Converse%' THEN 'Other Facilities (C)'
      -- ELSE 'Retail Factory (N)' END AS division_nm,
      COALESCE(ctry_mapping.ctry_nm, curated_tbl.city_nm) AS geographical_axis_nm,
      -- CASE 
      -- WHEN curated_tbl.concept_nm IN ("NSO", 'NVS') THEN 'DTC (N)'
      -- WHEN curated_tbl.concept_nm LIKE 'CFS%' THEN 'DTC (C)'
      -- WHEN curated_tbl.concept_nm LIKE 'Converse%' OR curated_tbl.concept_nm LIKE '%CONVERSE%' THEN 'WD+C (C)' 
      -- ELSE 'DTC (N)'
      -- END AS business_function_nm,
      building_tbl.`"Tririga Brand"`,
      building_tbl.`"Primary Use"`,
      building_tbl.TRIRIGA_BUILDING_ID,
      building_tbl.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
      COALESCE(building_tbl.`"NIKE GEO"`, 'EMEA') AS LOCATION_GEO_REGION_CD,
      COALESCE(building_tbl.CONTINENT_NAME, 'Europe') AS continent_nm,
      COALESCE(
        building_tbl.BUILDING_ADDRESS_MAIN,
        curated_tbl.street_txt
      ) AS ADDRESS_LINE_1_TXT,
      COALESCE(building_tbl.CITY_CODE_MAIN, curated_tbl.city_nm) AS city_nm,
      COALESCE(
        building_tbl.STATE_CODE_MAIN,
        curated_tbl.subleague_nm
      ) AS STATE_CD,
      COALESCE(
        building_tbl.TRIRIGA_ZIP_POSTAL_CODE,
        curated_tbl.zip_cd
      ) AS POSTAL_CD,
      -- curated_tbl.zip_cd AS POSTAL_CD,
      -- CONCAT_WS(
      --     '-',
      --     COALESCE(building_tbl.TRIRIGA_ZIP_POSTAL_CODE,curated_tbl.zip_cd),
      --     COALESCE(building_tbl.CITY_CODE_MAIN,curated_tbl.city_nm)
      -- ) AS geographical_axis_nm,
      COALESCE(
        building_tbl.COUNTRY_CODE_MAIN,
        ctry_mapping.CTRY_CD
      ) AS COUNTRY_CD,
      COALESCE(
        building_tbl.BUILDING_USF_MAIN,
        curated_tbl.site_size_in_sqft
      ) AS LOCATION_AREA,
      CASE
        WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'square feet'
        ELSE 'square metre'
      END AS LOCATION_AREA_UOM,
      -- CASE WHEN curated_tbl.is_property_ind = 'true' THEN 'Open'
      -- ELSE 'Close'
      -- END as LOCATION_STATUS_CD,
      COALESCE(
        building_tbl.LATITUDE_MAIN,
        curated_tbl.location_latitude_deg
      ) AS latitude_deg,
      COALESCE(
        building_tbl.LONGITUDE_MAIN,
        curated_tbl.location_longitude_deg
      ) AS longitude_deg,
      NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      CASE
        WHEN building_tbl.BUILDING_USF_MAIN IS NOT NULL THEN 'building_combined'
        ELSE 'electricity_usage_and_cost_metrics'
      END AS LOCATION_AREA_DATA_SOURCE_NM
    FROM
      CURATED_VIEW curated_tbl
      LEFT JOIN BUILDING_COMBINE building_tbl ON (
        REGEXP_SUBSTR (
          curated_tbl.client_site_ref_id,
          '^[a-zA-Z][a-zA-Z0-9_]*'
        ) = building_tbl.TRIRIGA_BUILDING_ID
        OR REGEXP_SUBSTR (
          curated_tbl.client_site_ref_id,
          '^[a-zA-Z][a-zA-Z0-9_]*'
        ) = `"Tririga POS Store ID"`
      )
      LEFT JOIN emea_tbl emea_tbl ON curated_tbl.client_site_ref_id = emea_tbl.location_nbr
      LEFT JOIN TAXONOMY_TABLE ctry_mapping ON curated_tbl.country_nm = ctry_mapping.ctry_nm
    WHERE
      (
        building_tbl.COMBINE_PART IS NULL
        OR building_tbl.COMBINE_PART = 1
      )
      AND REGEXP_SUBSTR (
        curated_tbl.client_site_ref_id,
        '^[a-zA-Z][a-zA-Z0-9_]*'
      ) IS NOT NULL
  ),
  FINAL_AGG AS (
    SELECT DISTINCT
      ELECTRICITY_SITE.electricity_location_nbr AS electricity_location_nbr,
      ELECTRICITY_SITE.electricity_location_nm AS electricity_location_nm,
      NULL AS lease_nbr,
      ELECTRICITY_SITE.TRIRIGA_BUILDING_ID AS building_id,
      INITCAP(
        REGEXP_REPLACE(ELECTRICITY_SITE.business_group_txt, '-', ' ')
      ) AS business_group_txt,
      INITCAP(ELECTRICITY_SITE.brand_nm) AS brand_nm,
      ELECTRICITY_SITE.nike_department_type_txt AS nike_department_type_txt,
      CASE
        WHEN ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
        WHEN ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
        ELSE ELECTRICITY_SITE.BUSINESS_ENTITY_GEO_REGION_CD
      END AS BUSINESS_ENTITY_GEO_REGION_CD,
      ELECTRICITY_SITE.ELECTRICITY_LOCATION_USE_CD,
      CASE
        WHEN nike_department_type_txt IN ('Retail Inline', 'Retail Factory')
        AND brand_nm = "Nike" THEN 'DTC (N)'
        WHEN nike_department_type_txt IN ('Retail Inline', 'Retail Factory')
        AND brand_nm = "Converse" THEN 'DTC (C)'
        WHEN nike_department_type_txt = 'Main HQ'
        AND brand_nm = "Nike" THEN 'WD+C (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = "Nike" THEN 'WD+C (N)'
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = "Converse" THEN 'WD+C (C)'
        ELSE 'DTC (N)'
      END AS business_function_nm,
      CASE
        WHEN nike_department_type_txt = 'Retail Inline'
        AND brand_nm = "Nike" THEN "Retail Inline (N)"
        WHEN nike_department_type_txt = 'Retail Factory'
        AND brand_nm = "Nike" THEN "Retail Factory (N)"
        WHEN nike_department_type_txt = 'Retail Inline'
        AND brand_nm = "Converse" THEN "Retail Inline (C)"
        WHEN nike_department_type_txt = 'Retail Factory'
        AND brand_nm = "Converse" THEN "Retail Factory (C)"
        WHEN nike_department_type_txt = 'Main HQ'
        AND brand_nm = "Nike" THEN "Headquarters (N)"
        WHEN nike_department_type_txt IN ('Local Office', 'Other Facilities')
        AND brand_nm = "Converse" THEN "Other Facilities (C)"
        ELSE 'Other Facilities (N)'
      END AS division_nm,
      CASE
        WHEN ELECTRICITY_SITE.LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN ELECTRICITY_SITE.LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
        ELSE ELECTRICITY_SITE.LOCATION_GEO_REGION_CD
      END AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN ELECTRICITY_SITE.continent_nm ILIKE 'EMEA' THEN 'Europe'
        WHEN ELECTRICITY_SITE.continent_nm ILIKE 'APLA' THEN 'Asia'
        WHEN ELECTRICITY_SITE.continent_nm ILIKE 'North America' THEN 'North America'
        WHEN ELECTRICITY_SITE.continent_nm ILIKE 'Greater China' THEN 'Asia'
        ELSE ELECTRICITY_SITE.continent_nm
      END AS continent_nm,
      ELECTRICITY_SITE.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
      INITCAP(ELECTRICITY_SITE.city_nm) AS city_nm,
      ELECTRICITY_SITE.STATE_CD AS STATE_CD,
      ELECTRICITY_SITE.POSTAL_CD AS POSTAL_CD,
      ELECTRICITY_SITE.geographical_axis_nm AS geographical_axis_nm,
      CASE
        WHEN ELECTRICITY_SITE.COUNTRY_CD ILIKE 'Canada' THEN 'CA'
        WHEN ELECTRICITY_SITE.COUNTRY_CD ILIKE 'United States' THEN 'US'
        ELSE UPPER(ELECTRICITY_SITE.COUNTRY_CD)
      END AS COUNTRY_CD,
      CAST(ELECTRICITY_SITE.LOCATION_AREA AS DECIMAL(31, 5)) AS LOCATION_AREA,
      LOCATION_AREA_UOM,
      ELECTRICITY_SITE.site_status_Ind_cd AS LOCATION_STATUS_CD,
      ELECTRICITY_SITE.latitude_deg AS latitude_deg,
      ELECTRICITY_SITE.longitude_deg AS longitude_deg,
      ELECTRICITY_SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
      'electricity_usage_and_cost_metrics' AS cost_usage_data_source_nm,
      LOCATION_AREA_DATA_SOURCE_NM
    FROM
      SITE_INTEGRATION ELECTRICITY_SITE
  )
  /* SDF-3777: Adding this extra filter for mace to filter out duplicate records for building_id from BCV */
SELECT
  *
FROM
  FINAL_AGG
WHERE
  NOT (
    (
      electricity_location_nbr = '500'
      AND building_id IN ('RUKIKC2026')
    )
  );
