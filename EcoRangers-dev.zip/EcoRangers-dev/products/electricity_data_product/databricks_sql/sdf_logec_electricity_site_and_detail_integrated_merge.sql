SELECT
  DETAIL.electricity_consumption_uuid AS electricity_consumption_uuid,
  DETAIL.electricity_location_nbr AS electricity_location_nbr,
  DETAIL.electricity_location_nm AS electricity_location_nm,
  DETAIL.reporting_period_dt AS reporting_period_dt,
  DETAIL.SERVICE_TYPE_CD AS SERVICE_TYPE_CD,
  DETAIL.BILLING_MONTH_START_DT AS BILLING_MONTH_START_DT,
  DETAIL.BILLING_MONTH_END_DT AS BILLING_MONTH_END_DT,
  DETAIL.BILLING_MONTH_DATE_RANGE_TXT AS BILLING_MONTH_DATE_RANGE_TXT,
  SITE.lease_nbr AS lease_nbr,
  SITE.building_id AS building_id,
  SITE.business_group_txt AS business_group_txt,
  SITE.brand_nm AS brand_nm,
  SITE.nike_department_type_txt AS nike_department_type_txt,
  SITE.BUSINESS_ENTITY_GEO_REGION_CD AS BUSINESS_ENTITY_GEO_REGION_CD,
  SITE.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
  SITE.business_function_nm AS business_function_nm,
  SITE.division_nm AS division_nm,
  SITE.LOCATION_GEO_REGION_CD AS LOCATION_GEO_REGION_CD,
  SITE.continent_nm AS continent_nm,
  SITE.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
  SITE.city_nm AS city_nm,
  SITE.STATE_CD AS STATE_CD,
  SITE.POSTAL_CD AS POSTAL_CD,
  SITE.geographical_axis_nm AS geographical_axis_nm,
  SITE.COUNTRY_CD AS COUNTRY_CD,
  SITE.LOCATION_AREA AS LOCATION_AREA,
  SITE.LOCATION_AREA_UOM AS LOCATION_AREA_UOM,
  SITE.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
  SITE.latitude_deg AS latitude_deg,
  SITE.longitude_deg AS longitude_deg,
  SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
  DETAIL.REPORTING_FISCAL_YEAR_NBR AS REPORTING_FISCAL_YEAR_NBR,
  DETAIL.REPORTING_FISCAL_QUARTER_NBR AS REPORTING_FISCAL_QUARTER_NBR,
  DETAIL.REPORTING_FISCAL_MONTH_OF_YEAR_NBR AS REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  DETAIL.REPORTING_CALENDAR_YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
  DETAIL.REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
  DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
  DETAIL.REPORTING_QUARTER_NBR AS REPORTING_QUARTER_NBR,
  DETAIL.REPORTING_WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
  DETAIL.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
  DETAIL.SERVICE_USAGE_QTY AS SERVICE_USAGE_QTY,
  DETAIL.SERVICE_USAGE_QTY_UOM AS SERVICE_USAGE_QTY_UOM,
  DETAIL.SERVICE_COST AS SERVICE_COST,
  DETAIL.SERVICE_COST_UOM AS SERVICE_COST_UOM,
  DETAIL.extrapolation_ind AS extrapolation_ind,
  DETAIL.scope_nbr AS scope_nbr,
  SITE.location_area_data_source_nm AS location_area_data_source_nm,
  SITE.location_area_data_source_cd AS location_area_data_source_cd,
  DETAIL.cost_usage_data_source_nm AS cost_usage_data_source_nm,
  DETAIL.cost_usage_data_source_cd AS cost_usage_data_source_cd
FROM
  {site_table_name} SITE
  LEFT JOIN {detail_table_name} DETAIL ON CONCAT_WS(
    '_',
    DETAIL.electricity_consumption_uuid,
    DETAIL.electricity_location_nbr,
    DETAIL.electricity_location_nm,
    DETAIL.reporting_period_dt
  ) = CONCAT_WS(
    '_',
    SITE.electricity_consumption_uuid,
    SITE.electricity_location_nbr,
    SITE.electricity_location_nm,
    SITE.reporting_period_dt
  )
WHERE
  (
    DETAIL.cost_usage_data_source_nm = 'logec'
    AND SITE.cost_usage_data_source_nm = 'logec'
  )
