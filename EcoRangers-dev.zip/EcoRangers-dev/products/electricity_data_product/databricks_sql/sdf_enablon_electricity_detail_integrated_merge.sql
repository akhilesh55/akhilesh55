WITH
  impact_tbl AS (
    SELECT
      *,
      CASE
        WHEN entity_country_nm = 'United States of America' THEN 'USA'
        WHEN entity_country_nm = 'South Korea' THEN 'Korea'
        ELSE entity_country_nm
      END AS entity_country_nm_trimmed,
      CASE
        WHEN entity_geography_nm LIKE '%Factory%' THEN 'NFS'
        WHEN entity_geography_nm LIKE '%EHQ%' THEN 'Freestyle office'
        WHEN entity_geography_nm LIKE '%Distribution Center%' THEN 'DISTRIBUTION  CENTER'
        WHEN entity_geography_nm LIKE "HQ"
        OR entity_geography_nm = "GCHQ"
        OR entity_geography_nm = "WHQ" THEN 'OFFICE'
        WHEN entity_geography_nm LIKE '%Retail inline%' THEN 'NSO'
        WHEN entity_geography_nm LIKE '%Air Zoom Alpha AIR MI%' THEN 'MANUFACTURING'
        WHEN entity_geography_nm LIKE "%Warehouse%"
        OR entity_geography_nm LIKE "%Vietnam%"
        OR entity_geography_nm LIKE "%Viet nam%" THEN 'WAREHOUSE'
        WHEN entity_geography_nm = 'Other Facilities' THEN 'OTHER'
      END AS entity_geography_nm_validated
    FROM
      {enablon_5_impact_areas}
    WHERE
      entity_scope_nm IN ('SCOPE 2', 'SCOPE 1&2')
      AND reporting_period_fiscal_year_nbr = 2025
      AND extrapolated_ind = 'FALSE'
      AND indicator_type_nm = 'Primary Indicator'
  ),
  taxonomy_tbl AS (
    SELECT DISTINCT
      label AS CTRY_NM,
      metadata_iso2CountryCode AS CTRY_CD,
      CASE
        WHEN gpos.name = 'APLA' THEN 'APLA'
        WHEN gpos.name = 'EMEA' THEN 'EMEA'
        WHEN gpos.name = 'GC' THEN 'GREATER CHINA'
        WHEN gpos.name = 'NA' THEN 'NORTH AMERICA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS GEOSHORT_NM,
      CASE
        WHEN gpos.name = 'APLA' THEN 'AP'
        WHEN gpos.name = 'EMEA' THEN 'EU'
        WHEN gpos.name = 'GC' THEN 'CN'
        WHEN gpos.name = 'NA' THEN 'NA'
        WHEN gpos.name = 'Other' THEN 'UNK'
      END AS NDF_GEO,
      gpos.name AS REGION
    FROM
      {taxonomy_table}
    LATERAL VIEW EXPLODE (
      relatedResources_countryIsPhysicallyLocatedInNikeGeo.name
    ) gpos AS name
    WHERE
      metadata_iso2CountryCode IS NOT NULL
      AND language = 'en'
  ),
  lookup_tbl AS (
    SELECT
      *
    FROM
      {enablon_lookup_table}
    WHERE
      (
        enablon_data_ingestion_method_nm = 'manually entered in enablon'
        AND entity_comparison_txt = 'exists in enablon but not in source'
        OR service_type_comparison_txt = 'more service types in enablon	more service types in enablon'
      )
      OR (
        enablon_data_ingestion_method_nm = 'manually entered in enablon'
        AND entity_comparison_txt = 'exists in source and enablon'
        OR service_type_comparison_txt = 'more service types in enablon	more service types in enablon'
      )
  ),
  detail_tbl AS (
    SELECT DISTINCT
      electricity_location_nbr AS location_nbr,
      electricity_location_nm AS location_nm
    FROM
      {detail_elec_table}
    WHERE
      cost_usage_data_source_cd NOT IN ('ENABLON', 'SEE')
    UNION
    SELECT DISTINCT
      fuel_location_nbr AS location_nbr,
      fuel_location_nm AS location_nm
    FROM
      {detail_fuel_table}
    WHERE
      cost_usage_data_source_cd NOT IN ('ENABLON', 'SEE')
  ),
  calendar_tbl AS (
    SELECT
      *
    FROM
      {calendar_table}
  ),
  DETAIL_INTEGRATION AS (
    SELECT DISTINCT
      COALESCE(e.location_nbr, a.entity_reference_cd) AS electricity_location_nbr,
      a.entity_reference_nm AS electricity_location_nm,
      'null' AS building_id,
      TO_DATE(DATE_FORMAT(a.source_reporting_dt, "yyyy-MM-dd")) AS reporting_period_dt,
      a.source_reporting_dt AS billing_month_start_dt,
      LAST_DAY(a.source_reporting_dt) AS billing_month_end_dt,
      CONCAT_WS(
        '-',
        DATE_FORMAT(BILLING_MONTH_START_DT, 'MM/dd/yyyy'),
        DATE_FORMAT(BILLING_MONTH_END_DT, 'MM/dd/yyyy')
      ) AS BILLING_MONTH_DATE_RANGE_TXT,
      4 AS data_frequency_cd,
      CAST(
        CASE
          WHEN a.family_base_uom_nm = 'Energy'
          AND a.category_base_uom_id = 145 THEN ROUND(a.source_value_nbr, 2)
          WHEN a.family_base_uom_nm = 'Dimension'
          AND a.category_base_uom_id = 29 THEN ROUND(a.source_value_nbr, 2)
          ELSE NULL
        END AS DECIMAL(38, 2)
      ) AS service_usage_qty,
      CASE
        WHEN a.family_base_uom_nm = 'Energy'
        AND a.category_base_uom_id = 145 THEN a.category_base_uom_cd
        WHEN a.family_base_uom_nm = 'Dimension'
        AND a.category_base_uom_id = 29 THEN a.category_base_uom_cd
        ELSE NULL
      END AS service_usage_qty_uom,
      CAST(
        CASE
          WHEN a.family_base_uom_nm = 'Financial / Cost' THEN a.source_value_nbr
          ELSE NULL
        END AS DECIMAL(38, 2)
      ) AS service_cost,
      CASE
        WHEN a.family_base_uom_nm = 'Financial / Cost' THEN a.category_base_uom_cd
        ELSE NULL
      END AS service_cost_uom,
      a.extrapolated_ind AS extrapolation_ind,
      d.fiscal_year_nbr AS reporting_fiscal_year_nbr,
      d.fiscal_quarter_nbr AS reporting_fiscal_quarter_nbr,
      d.fiscal_Month_of_Year_NBR AS reporting_fiscal_month_of_year_nbr,
      CAST(d.year_nbr AS DECIMAL(38, 0)) AS reporting_calendar_year_nbr,
      d.month_long_nm AS reporting_month_long_nm,
      CAST(d.month_of_year_nbr AS DECIMAL(38, 0)) AS reporting_month_of_year_nbr,
      CAST(d.quarter_nbr AS DECIMAL(38, 0)) AS reporting_quarter_nbr,
      CAST(d.week_of_year_nbr AS DECIMAL(38, 0)) AS reporting_week_of_year_nbr,
      a.entity_consumption_group_nm AS service_type_cd,
      a.entity_brand_nm AS brand_nm,
      CASE
        WHEN entity_continent_nm = 'America' THEN 'North America'
        ELSE entity_continent_nm
      END AS continent_nm,
      entity_address_txt AS address_line_1_txt,
      entity_city_nm AS city_nm,
      'null' AS state_cd,
      entity_zip_cd AS postal_cd,
      entity_geographical_reference_txt AS geographical_axis_nm,
      entity_country_nm AS country_cd,
      CAST(a.entity_area_in_sqft AS DECIMAL(31, 5)) AS LOCATION_AREA,
      entity_status_nm AS location_status_cd,
      'Square foot' AS LOCATION_AREA_UOM,
      entity_business_function_nm AS business_function_nm,
      entity_division_nm AS division_nm,
      CASE
        WHEN entity_country_nm = 'United States of America' THEN 'USA'
        WHEN entity_country_nm = 'South Korea' THEN 'Korea'
        ELSE entity_country_nm
      END AS LOCATION_GEO_REGION_CD,
      entity_country_nm AS Business_entity_geo_region_cd
    FROM
      impact_tbl a
      INNER JOIN lookup_tbl c ON a.entity_reference_cd = c.enablon_entity_reference_cd
      LEFT JOIN detail_tbl e ON a.entity_reference_nm = e.location_nm
      LEFT JOIN calendar_tbl d ON a.source_reporting_dt = d.Calendar_DT
    WHERE
      a.entity_consumption_group_nm NOT IN ("Biomass", "Electricity+Biomass", "Site Area")
  ),
  FINAL_AGG AS (
    SELECT
      electricity_location_nbr,
      electricity_location_nm,
      reporting_period_dt,
      SERVICE_TYPE_CD,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      BILLING_MONTH_DATE_RANGE_TXT,
      building_id,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      DATA_FREQUENCY_CD,
      CAST(SUM(SERVICE_USAGE_QTY) AS DECIMAL(38, 2)) AS SERVICE_USAGE_QTY,
      SERVICE_USAGE_QTY_UOM,
      CAST(SUM(SERVICE_COST) AS DECIMAL(38, 2)) AS SERVICE_COST,
      SERVICE_COST_UOM,
      extrapolation_ind
    FROM
      DETAIL_INTEGRATION
    GROUP BY
      electricity_location_nbr,
      electricity_location_nm,
      reporting_period_dt,
      SERVICE_TYPE_CD,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      BILLING_MONTH_DATE_RANGE_TXT,
      building_id,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      DATA_FREQUENCY_CD,
      SERVICE_USAGE_QTY_UOM,
      SERVICE_COST_UOM,
      extrapolation_ind
  ),
  CONSOLIDATE_DATA AS (
    SELECT
      electricity_location_nbr,
      electricity_location_nm,
      reporting_period_dt,
      SERVICE_TYPE_CD,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      BILLING_MONTH_DATE_RANGE_TXT,
      building_id,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_FISCAL_QUARTER_NBR,
      REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      DATA_FREQUENCY_CD,
      -- BELOW TO HANDLE PIVOTING CONDITIONS
      MAX(SERVICE_USAGE_QTY) OVER (
        PARTITION BY
          electricity_location_nbr,
          electricity_location_nm,
          reporting_period_dt,
          SERVICE_TYPE_CD
      ) AS SERVICE_USAGE_QTY,
      MAX(SERVICE_USAGE_QTY_UOM) OVER (
        PARTITION BY
          electricity_location_nbr,
          electricity_location_nm,
          reporting_period_dt,
          SERVICE_TYPE_CD
      ) AS SERVICE_USAGE_QTY_UOM,
      MAX(SERVICE_COST) OVER (
        PARTITION BY
          electricity_location_nbr,
          electricity_location_nm,
          reporting_period_dt,
          SERVICE_TYPE_CD
      ) AS SERVICE_COST,
      MAX(SERVICE_COST_UOM) OVER (
        PARTITION BY
          electricity_location_nbr,
          electricity_location_nm,
          reporting_period_dt,
          SERVICE_TYPE_CD
      ) AS SERVICE_COST_UOM,
      extrapolation_ind
    FROM
      FINAL_AGG
  )
SELECT DISTINCT
  electricity_location_nbr,
  electricity_location_nm,
  reporting_period_dt,
  SERVICE_TYPE_CD,
  BILLING_MONTH_START_DT,
  BILLING_MONTH_END_DT,
  BILLING_MONTH_DATE_RANGE_TXT,
  building_id,
  REPORTING_FISCAL_YEAR_NBR,
  REPORTING_FISCAL_QUARTER_NBR,
  REPORTING_FISCAL_MONTH_OF_YEAR_NBR,
  REPORTING_CALENDAR_YEAR_NBR,
  REPORTING_MONTH_LONG_NM,
  REPORTING_MONTH_OF_YEAR_NBR,
  REPORTING_QUARTER_NBR,
  REPORTING_WEEK_OF_YEAR_NBR,
  DATA_FREQUENCY_CD,
  SERVICE_USAGE_QTY AS SERVICE_USAGE_QTY,
  CASE
    WHEN SERVICE_USAGE_QTY IS NULL THEN NULL
    ELSE SERVICE_USAGE_QTY_UOM
  END AS SERVICE_USAGE_QTY_UOM,
  SERVICE_COST,
  CASE
    WHEN SERVICE_COST IS NULL THEN NULL
    ELSE SERVICE_COST_UOM
  END AS SERVICE_COST_UOM,
  extrapolation_ind,
  'SCOPE 2' AS scope_nbr,
  'sustainability_impact_areas' AS cost_usage_data_source_nm,
  'ENABLON' AS cost_usage_data_source_cd
FROM
  CONSOLIDATE_DATA
