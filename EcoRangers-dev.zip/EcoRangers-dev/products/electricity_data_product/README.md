# Product directory for Electricity Data Product

This product contains the integrated object for Electricity Data Product for Consumption.

Product Details:

| Section             |                                          Details                                           |
| ------------------- | :----------------------------------------------------------------------------------------: |
| Product Name        |                                  Electricity Data Product                                  |
| Consumption Pattern |                                 Databricks Sole, Snowflake                                 |
| Confluence pages    | https://confluence.nike.com/display/SDF/Sustainability+Carbon+Electricity+Consumption+Data |
| Data Format         |                                      Delta, Snowflake                                      |
| Point of contact    |                          Lst-Technology.EDAI.Ecorangers@nike.com                           |
