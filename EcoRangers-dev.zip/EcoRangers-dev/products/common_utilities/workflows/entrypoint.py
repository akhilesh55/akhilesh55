# Databricks notebook source
from brickflow import Project, PypiTaskLibrary, JarTaskLibrary, ctx
import re, subprocess
import products.common_utilities.workflows as workflows

if ctx.env == "prod":
    BRANCH = "main"
else:
    BRANCH = ctx.env


def main() -> None:
    with Project(
        "common_utilities",
        git_reference="git_branch/" + BRANCH,
        git_repo="https://github.com/nike-data-engineering/EcoRangers",
        provider="github",
        libraries=[
            PypiTaskLibrary(package="pandas"),
            PypiTaskLibrary(package="boxsdk"),
            PypiTaskLibrary(package="spark-expectations"),
            PypiTaskLibrary(package="data-common-utilities"),
            PypiTaskLibrary(package="cerberus-python-client"),
            PypiTaskLibrary(package="prettytable"),
            JarTaskLibrary(
                "dbfs:/kafka-jars/databricks-shaded-strimzi-kafka-oauth-client-1.1.jar"
            ),
            PypiTaskLibrary(package="snowflake-connector-python"),
            PypiTaskLibrary(package="delta-spark"),
            PypiTaskLibrary(package="asyncssh"),
            PypiTaskLibrary(package="xlsxwriter"),
        ],
        enable_plugins=False,
    ) as f:
        f.add_pkg(workflows)


if __name__ == "__main__":
    main()
