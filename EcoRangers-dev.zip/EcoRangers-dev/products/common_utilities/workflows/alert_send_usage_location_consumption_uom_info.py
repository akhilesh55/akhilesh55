import os
from brickflow import (
    ctx,
    Cluster,
    Workflow,
    WorkflowPermissions,
    Group,
    PypiTaskLibrary,
    JarTaskLibrary,
    TaskSettings,
)
from products.common_utilities.spark.python.src.util_multi_site_info_to_table import (
    get_site_details,
)
from products.common_utilities.spark.python.src.util_email_and_slack_alerts import (
    send_location_uom_info_alerts,
)


from brickflow.bundles.model import JobsHealthRules

JOB_ID = ctx.get_parameter(key="brickflow_job_id", debug="987987987987987")
ENV = ctx.env

# Extracting script location and changing directory to parent
SCRIPT_PATH = os.path.abspath(__file__)
SCRIPTT_DIR = os.path.dirname(SCRIPT_PATH)
if ENV == "local":
    ENV = "dev"
    DATABASE = "development.global_sustainability_dev"

ROOT_DIR = os.path.dirname(SCRIPTT_DIR)
WF_NAME = "trigger_location_uom_info_slack_email_alerts"
PROJECT_NAME = "common_utilities"


def create_job_cluster(name: str):
    aws_config = {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK",
        "instance_profile_arn": "arn:aws:iam::572801069962:instance-profile/sole/group/ecorangers",
        "spot_bid_price_percent": 100,
        "ebs_volume_type": "GENERAL_PURPOSE_SSD",
        "ebs_volume_count": 3,
        "ebs_volume_size": 100,
    }
    custom_tags = {
        "nike-environment": ENV,
        "nike-squad": "ecorangers",
        "nike-techsolution": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-initiative": "sustainability-data-foundation",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    spark_conf = {
        "spark.databricks.delta.schema.autoMerge.enabled": "true",
        "spark.databricks.delta.properties.defaults.enableChangeDataFeed": "true",
        "spark.databricks.delta.changeDataFeed.timestampOutOfRange.enabled": "true",
        "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
        "spark.databricks.service.server.enabled": "false",
        "spark.databricks.delta.preview.enabled": "true",
        "spark.databricks.delta.merge.enableLowShuffle": "true",
    }
    return Cluster(
        name=name,
        spark_version="13.3.x-scala2.12",
        node_type_id="m7g.large",
        driver_node_type_id="m7g.large",
        min_workers=1,
        max_workers=1,
        data_security_mode="USER_ISOLATION",
        enable_elastic_disk=True,
        spark_conf=spark_conf,
        policy_id="0009B9D23ECAAA0B",
        custom_tags=custom_tags,
        aws_attributes=aws_config,
    )


wf = Workflow(
    WF_NAME,
    default_cluster=create_job_cluster("ecorangers_job_cluster"),
    health=[
        JobsHealthRules(metric="RUN_DURATION_SECONDS", op="GREATER_THAN", value=7200.0)
    ],
    schedule_quartz_expression=" 0 30 03 ? * SUN * ",  # 03:30 UTC (9:00 AM IST Every Saturday)
    timezone="UTC",
    tags={
        "product_id": "sustainability-data-foundation",
        "nike-techsolution": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
        "AvailabilitySLA": "AvailabilitySLA - 30 4 @ @ 6",
        "Criticality": "Non-Essential",
    },
    permissions=WorkflowPermissions(
        can_manage=[
            Group("App.NikeSole.ecorangers.Developer"),
            Group("App.NikeSole.ecorangers.DataAdmin"),
        ],
        can_view=[Group("App.NikeSole.ecorangers.Analyst")],
    ),
    default_task_settings=TaskSettings(max_retries=1),
    libraries=[
        JarTaskLibrary(
            "dbfs:/kafka-jars/databricks-shaded-strimzi-kafka-oauth-client-1.1.jar"
        ),
        PypiTaskLibrary(package="pandas"),
        PypiTaskLibrary(package="prettytable"),
        PypiTaskLibrary(package="snowflake-connector-python"),
        PypiTaskLibrary(package="asyncssh"),
    ],
)


@wf.task
# this task does nothing but explains the use of context object
def start():
    print(f"Starting the workflow with env: {ENV}, job_run_id: {JOB_ID}")


# workflow for to refresh alert table for location uom info
@wf.task(depends_on=start, name="trigger_location_uom_table_refresh")
def trigger_location_uom_info_table():
    get_site_details(
        config_path=ROOT_DIR + "/spark/python/config",
        config_name="sdf_location_uom_changes.toml",
        sql_file_path=ROOT_DIR + "/databricks_sql",
        sql_file_name="usage_location_and_consumption_uom_info.sql",
        env=ENV,
        bf_context=ctx,
        root_dir=ROOT_DIR,
    )


# workflow for to send alert  for location uom info table
@wf.task(
    depends_on="trigger_location_uom_table_refresh",
    name="trigger_location_uom_info_alerts",
)
def trigger_location_uom_info_slack_email_alerts():
    send_location_uom_info_alerts(
        config_path=ROOT_DIR + "/spark/python/config",
        config_name="alert_location_uom_info_config.toml",
        env=ENV,
        root_dir=ROOT_DIR,
        bf_context=ctx,
        html_path=ROOT_DIR + "/../common_utilities/spark/python/resources/",
        html_name="alert_send_email_location_uom_info.html",
    )


@wf.task(depends_on="trigger_location_uom_info_alerts", name="end")
# this task does nothing but explains the use of context object
def end():
    print(f"Ending the workflow with env: {ENV}, job_run_id: {JOB_ID}")


if __name__ == "__main__":
    wf.tasks[
        "start",
        "trigger_location_uom_table_refresh",
        "trigger_location_uom_info_alerts",
    ].execute()
