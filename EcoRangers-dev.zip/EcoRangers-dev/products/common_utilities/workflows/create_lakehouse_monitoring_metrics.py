import os
from brickflow import (
    ctx,
    Cluster,
    Workflow,
    WorkflowPermissions,
    Group,
    JarTaskLibrary,
    PypiTaskLibrary,
    NotebookTask,
    TaskSettings,
)

from brickflow.bundles.model import JobsHealthRules

JOB_ID = ctx.get_parameter(key="brickflow_job_id", debug="987987987987987")
ENV = ctx.env

# Extracting script location and changing directory to parent
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
CATALOG = ""
SCHEMA = ""

if ENV == "local":
    ENV = "dev"
    CATALOG = "development"
    SCHEMA = "global_sustainability_dev"
elif ENV == "dev":
    CATALOG = "development"
    SCHEMA = "global_sustainability_dev"
elif ENV == "qa":
    CATALOG = "non_published_domain"
    SCHEMA = "global_sustainability_qa"
elif ENV == "prod":
    CATALOG = "non_published_domain"
    SCHEMA = "global_sustainability_prod"

root_dir = os.path.dirname(script_dir)


def create_job_cluster(name: str):
    aws_config = {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK",
        "instance_profile_arn": "arn:aws:iam::572801069962:instance-profile/sole/group/ecorangers",
        "spot_bid_price_percent": 100,
        "ebs_volume_type": "GENERAL_PURPOSE_SSD",
        "ebs_volume_count": 3,
        "ebs_volume_size": 100,
    }
    spark_conf = {
        "spark.databricks.delta.schema.autoMerge.enabled": "true",
        "spark.databricks.delta.properties.defaults.enableChangeDataFeed": "true",
        "spark.databricks.delta.changeDataFeed.timestampOutOfRange.enabled": "true",
        "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
        "spark.databricks.service.server.enabled": "false",
        "spark.databricks.delta.preview.enabled": "true",
        "spark.databricks.delta.merge.enableLowShuffle": "true",
        "spark.databricks.delta.commitInfo.maxRetries": "20",
    }
    custom_tags = {
        "nike-environment": ENV,
        "nike-squad": "ecorangers",
        "nike-techsolution": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-initiative": "sustainability-data-foundation",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    return Cluster(
        name=name,
        spark_version="13.3.x-scala2.12",
        node_type_id="m6g.large",
        driver_node_type_id="m6g.large",
        min_workers=1,
        max_workers=1,
        data_security_mode="USER_ISOLATION",
        enable_elastic_disk=True,
        policy_id="0009B9D23ECAAA0B",
        custom_tags=custom_tags,
        spark_conf=spark_conf,
        aws_attributes=aws_config,
    )


wf = Workflow(
    "create_lakehouse_monitoring_metrics",
    health=[
        JobsHealthRules(metric="RUN_DURATION_SECONDS", op="GREATER_THAN", value=7200.0)
    ],
    default_cluster=create_job_cluster("ecorangers_job_cluster"),
    timezone="UTC",
    tags={
        "nike-initiative": "sustainability-data-foundation",
        "nike-techsolution": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    },
    permissions=WorkflowPermissions(
        can_manage=[
            Group("App.NikeSole.ecorangers.Developer"),
            Group("App.NikeSole.ecorangers.DataAdmin"),
        ],
        can_view=[Group("App.NikeSole.ecorangers.Analyst")],
    ),
    default_task_settings=TaskSettings(max_retries=3),
    max_concurrent_runs=50,
    libraries=[
        JarTaskLibrary(
            "dbfs:/kafka-jars/databricks-shaded-strimzi-kafka-oauth-client-1.1.jar"
        ),
        PypiTaskLibrary(package="pandas"),
        PypiTaskLibrary(package="boxsdk"),
        PypiTaskLibrary(package="spark-expectations"),
        PypiTaskLibrary(package="snowflake-connector-python"),
        PypiTaskLibrary(package="data-common-utilities"),
        PypiTaskLibrary(package="asyncssh"),
    ],
)


@wf.notebook_task
# this task does nothing but explains the use of context object
def add_monitor():
    user_id = ""
    if ctx.env == "dev":
        user_id = "0c87c6ad-1783-4d06-ba78-b204e466d72c"

    elif ctx.env == "qa" or ctx.env == "prod":
        user_id = "43977fb0-d4bc-45f3-9b73-4e887f913e06"

    return NotebookTask(
        notebook_path=f"/Workspace/Users/{user_id}/.brickflow_bundles/common_utilities/{ctx.env}/files/products/common_utilities/spark/python/notebooks/add_Timeseries_monitors",
        base_parameters={
            "catalog": CATALOG,
            "schema": SCHEMA,
            "table_name": "",
            "timestamp_col": "",
        },
        source="WORKSPACE",
    )


if __name__ == "__main__":
    wf.tasks["add_monitor"].execute()
