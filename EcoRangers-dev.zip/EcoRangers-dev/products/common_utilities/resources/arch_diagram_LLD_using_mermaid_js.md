# SDF LLD Arch diagram using Mermaid JS

```mermaid
flowchart LR
    %% Styling for components
    classDef awsStyle fill:#FF9900,stroke:#232F3E,stroke-width:2px,color:#232F3E
    classDef portalStyle fill:#87CEEB,stroke:#232F3E,stroke-width:2px
    classDef tableStyle fill:#B2F5EA,stroke:#232F3E,stroke-width:2px
    classDef dqStyle fill:#FFE4B5,stroke:#232F3E,stroke-width:2px
    classDef rejectStyle fill:#FFA07A,stroke:#232F3E,stroke-width:2px
    classDef apiStyle fill:#98FB98,stroke:#232F3E,stroke-width:2px
    classDef snowflakeStyle fill:#2D9CDB,stroke:#232F3E,stroke-width:2px,color:white
    classDef databricksObjectStyle fill:#FF7F50,stroke:#232F3E,stroke-width:2px
    classDef snowflakeObjectStyle fill:#4169E1,stroke:#232F3E,stroke-width:2px,color:white
    classDef nikeStyle fill:#FFD700,stroke:#232F3E,stroke-width:2px,color:black


    %% Layer styling
    classDef sourceLayer fill:#D4F1F4,stroke:#232F3E,stroke-width:2px
    classDef awsLayer fill:#FFE5CC,stroke:#232F3E,stroke-width:2px
    classDef bronzeLayer fill:#CD7F32,stroke:#232F3E,stroke-width:2px,color:white
    classDef silverLayer fill:#C0C0C0,stroke:#232F3E,stroke-width:2px
    classDef databricksLayer fill:#E6E6FA,stroke:#232F3E,stroke-width:2px
    classDef snowflakeLayer fill:#4169E1,stroke:#232F3E,stroke-width:2px,color:white

    %% Source Systems
    subgraph SRC["Source Layer"]
        direction TB
        subgraph EP["Engie Data Source"]
            EPortal["Engie Portal<br><br><br>"]:::portalStyle
            ECSV1["{{EMISSION_AND_USAGE_METRICS/FUEL_OIL_METRICS}}_FLOOR_RAW-{{TIMESTAMP}}.csv<br><br><br>"]
            ECSV2["{{EMISSION_AND_USAGE_METRICS/FUEL_OIL_METRICS}}_OWNERSHIP_RAW-{{TIMESTAMP}}.csv<br><br><br>"]
            ECSV3["{{EMISSION_AND_USAGE_METRICS/FUEL_OIL_METRICS}}_CONVERSE_RAW-{{TIMESTAMP}}.csv<br><br><br>"]
            ECSV4["{{EMISSION_AND_USAGE_METRICS/FUEL_OIL_METRICS}}_SITE_RAW-{{TIMESTAMP}}.csv<br><br><br>"]
        end
        subgraph NL["Nike Tools"]
            EMFT1["Engie_IMPACT (external MFT)<br><br><br>"]:::nikeStyle
            EMFT2["Engie_IMPACT (external MFT)<br><br><br>"]:::nikeStyle
            EMFT3["Engie_IMPACT (external MFT)<br><br><br>"]:::nikeStyle
            EMFT4["Engie_IMPACT (external MFT)<br><br><br>"]:::nikeStyle
            IMFT1["NIKE_SUSTAINABILITY (internal MFT)<br><br><br>"]:::nikeStyle
            IMFT2["NIKE_SUSTAINABILITY (internal MFT)<br><br><br>"]:::nikeStyle
            IMFT3["NIKE_SUSTAINABILITY (internal MFT)<br><br><br>"]:::nikeStyle
            IMFT4["NIKE_SUSTAINABILITY (internal MFT)<br><br><br>"]:::nikeStyle
        end

        subgraph WW["Watchwire Data Source"]
            WPortal["Watchwire Portal<br><br><br>"]:::portalStyle
            WAPI1["Property API<br><br><br>"]:::apiStyle
            WAPI2["Property Address API<br><br><br>"]:::apiStyle
            WAPI3["Aggregated Invoice API<br><br><br>"]:::apiStyle
            WAPI4["Electric Invoice API<br><br><br>"]:::apiStyle
            WJSON1["Property JSON Data<br><br><br>"]
            WJSON2["Property Address JSON Data<br><br><br><br>"]
            WJSON3["Aggregated Invoice JSON Data<br><br><br>"]
            WJSON4["Electric Invoice JSON Data<br><br><br>"]
        end
        subgraph MM["Mace Myenergy Data Source"]
            MPortal["Mace Portal<br><br><br>"]:::portalStyle
            MCSV["NIKE C&C V3_{{timestamp}}.csv<br><br><br>"]
        end
        subgraph GPS["GPS Data Source"]
            GPortal["GPS Airtable<br><br><br>"]:::portalStyle
            GAPI["GPS HQ Airtable API<br><br><br>"]:::apiStyle
            GJSON["GPS HQ JSON Data<br><br><br>"]
        end
        subgraph RE100["RE100 Data Source"]
            RPortal["RE100 Airtable<br><br><br>"]:::portalStyle
            RAPI["RE100 Airtable API<br><br><br>"]:::apiStyle
            RJSON["RE100 JSON Data<br><br><br>"]
        end
        subgraph ENV["Envision IOT Data Source"]
            EIPortal["Envision Portal<br><br><br>"]:::portalStyle
            EIAPI["Envision IOT REST API<br><br><br>"]:::apiStyle
            EIJSON["Envision IOT JSON Data<br><br><br>"]
        end
        subgraph ENT["Enterprise NDF Sources"]
            EC["published_domain.calendar_prod.enterprise_calendar_v<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            BCV["wdc_wi_prod.serve.building_combined_v<br>(Snowflake)<br><br><br>"]:::snowflakeObjectStyle
            NT["published_domain.logistics_node_profile.node_flat_v<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            EXT["published_domain.global_sustainability_prod.extrapolation_electricity_usage_and_cost_with_location_integrated_V<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            FIT["published_domain.sustainability_foundation_analytics.sustainability_impact_areas_integrated_v<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            TXT["non_published_analytics.team_taggingtaxonomy.nike_enterprise_model<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            LOG["fulfill_dcanalytics_prod.cons_metapipes.logec_transactional_v_2<br>(Snowflake)<br><br><br>"]:::snowflakeObjectStyle
        end
    end
    class SRC sourceLayer

    %% AWS Layer
    subgraph AWS["AWS Layer"]
        S3["s3://engie-landing-layer/{{dev/qa/prod}}/landing/<br><br><br>"]:::awsStyle
    end
    class AWS awsLayer

    %% Databricks Layer
    subgraph DBX["Databricks Processing Layer"]
        %% Bronze Layer
        subgraph BRONZE["Bronze Layer"]
            LT["sdf_api_to_landing<br>(delta format)<br><br><br>"]:::tableStyle
            RT["sdf_{{data_source}}_raw<br>(delta format)<br><br><br>"]:::tableStyle
            DQ{{"DQ checks using<br>Spark Expectations tool<br><br><br>"}}:::dqStyle
            CT["sdf_{{data_source}}_cleansed<br>(delta format)<br><br><br>"]:::tableStyle
            RJ["sdf_{{data_source}}_error<br><br><br>"]:::rejectStyle
        end
        class BRONZE bronzeLayer

        %% Silver Layer
        subgraph SILVER["Silver Layer"]
            CHT["sdf_{{data_source}}_hist<br>(delta format)<br><br><br>"]:::tableStyle
            CV["sdf_{{data_source}}_v<br>(delta format)<br><br><br>"]:::tableStyle
            IT["sdf_{{data_product}}_integrated with SCD Type2 History<br>(delta format)<br><br><br>"]:::tableStyle
            ITV["sdf_{{data_product}}_integrated_v with latest version<br>(delta format)<br><br><br>"]:::tableStyle
            ENTDQ{{"Enterprise DQ checks using<br>Spark Expectations tool<br><br><br>"}}:::dqStyle
            ENTRJ["sdf_{{data_source}}_error<br><br><br>"]:::rejectStyle
        end
        class SILVER silverLayer
    end
    class DBX databricksLayer

    %% Connect everything
    %% Engie Flow
    EPortal --> |Weekly| ECSV1
    EPortal --> |Weekly| ECSV2
    EPortal --> |Weekly| ECSV3
    EPortal --> |Weekly| ECSV4
    ECSV1 --> |Weekly| EMFT1
    ECSV2 --> |Weekly| EMFT2
    ECSV3 --> |Weekly| EMFT3
    ECSV4 --> |Weekly| EMFT4
    EMFT1 --> IMFT1
    EMFT2 --> IMFT2
    EMFT3 --> IMFT3
    EMFT4 --> IMFT4
    IMFT1 --> |SFTP Transfer| S3
    IMFT2 --> |SFTP Transfer| S3
    IMFT3 --> |SFTP Transfer| S3
    IMFT4 --> |SFTP Transfer| S3
    S3 --> |Auto Loader| RT

    %% Watchwire Flow
    WPortal --> WAPI1
    WPortal --> WAPI2
    WPortal --> WAPI3
    WPortal --> WAPI4
    WAPI1 --> WJSON1
    WAPI2 --> WJSON2
    WAPI3 --> WJSON3
    WAPI4 --> WJSON4
    WJSON1 --> LT
    WJSON2 --> LT
    WJSON3 --> LT
    WJSON4 --> LT
    LT --> RT

    %% GPS Flow
    GPortal --> |Weekly| GAPI
    GAPI --> |Weekly| GJSON
    GJSON --> |Weekly| LT

    %% RE100 Flow
    RPortal --> |Monthly| RAPI
    RAPI --> |Monthly| RJSON
    RJSON --> |Monthly| LT

    %% Mace Flow
    MPortal --> |Weekly| MCSV
    MCSV --> |SFTP Transfer| S3

    %% Envision IOT Flow
    EIPortal --> |Weekly| EIAPI
    EIAPI --> |Weekly| EIJSON
    EIJSON --> |Weekly| LT

    %% Common Flow
    RT --> DQ
    DQ -->|Pass| CT
    DQ -->|Fail| RJ
    CT --> |STM Transformations| CHT
    CHT --> CV
    CV --> IT

    %% Enterprise NDF Sources Flow
    EC & BCV  & NT & LOG  & EXT & FIT & TXT --> |Weekly| ENTDQ
    ENTDQ -->|Pass| IT
    IT --> ITV
    ENTDQ -->|Fail| ENTRJ
```
