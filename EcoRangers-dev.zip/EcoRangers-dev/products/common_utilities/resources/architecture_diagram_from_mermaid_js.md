# High Level Arch Diagram using Mermaid JS

```mermaid
flowchart LR
    %% Styling for components
    classDef awsStyle fill:#FF9900,stroke:#232F3E,stroke-width:2px,color:#232F3E
    classDef portalStyle fill:#87CEEB,stroke:#232F3E,stroke-width:2px
    classDef tableStyle fill:#B2F5EA,stroke:#232F3E,stroke-width:2px
    classDef dqStyle fill:#FFE4B5,stroke:#232F3E,stroke-width:2px
    classDef rejectStyle fill:#FFA07A,stroke:#232F3E,stroke-width:2px
    classDef apiStyle fill:#98FB98,stroke:#232F3E,stroke-width:2px
    classDef snowflakeStyle fill:#2D9CDB,stroke:#232F3E,stroke-width:2px,color:white
    classDef databricksObjectStyle fill:#FF7F50,stroke:#232F3E,stroke-width:2px
    classDef snowflakeObjectStyle fill:#4169E1,stroke:#232F3E,stroke-width:2px,color:white

    %% Layer styling
    classDef sourceLayer fill:#D4F1F4,stroke:#232F3E,stroke-width:2px
    classDef awsLayer fill:#FFE5CC,stroke:#232F3E,stroke-width:2px
    classDef bronzeLayer fill:#CD7F32,stroke:#232F3E,stroke-width:2px,color:white
    classDef silverLayer fill:#C0C0C0,stroke:#232F3E,stroke-width:2px
    classDef databricksLayer fill:#E6E6FA,stroke:#232F3E,stroke-width:2px
    classDef snowflakeLayer fill:#4169E1,stroke:#232F3E,stroke-width:2px,color:white

    %% Source Systems
    subgraph SRC["Source Layer"]
        direction TB
        subgraph EP["Engie Data Source"]
            EPortal["Engie Portal<br><br><br>"]:::portalStyle
            ECSV["CSV Files<br><br><br>"]
            EMFT["Nike MFT<br><br><br>"]
        end
        subgraph WW["Watchwire Data Source"]
            WPortal["Watchwire Portal<br><br><br>"]:::portalStyle
            WAPI["REST API<br><br><br>"]:::apiStyle
            WJSON["JSON Data<br><br><br>"]
        end
        subgraph MM["Mace Myenergy Data Source"]
            MPortal["Mace Portal<br><br><br>"]:::portalStyle
            MCSV["CSV Files<br><br><br>"]
        end
        subgraph GPS["GPS Data Source"]
            GPortal["GPS Airtable<br><br><br>"]:::portalStyle
            GAPI["Airtable API<br><br><br>"]:::apiStyle
            GJSON["JSON Data<br><br><br>"]
        end
        subgraph RE100["RE100 Data Source"]
            RPortal["RE100 Airtable<br><br><br>"]:::portalStyle
            RAPI["RE100 API<br><br><br>"]:::apiStyle
            RJSON["JSON Data<br><br><br>"]
        end
        subgraph ENV["Envision IOT Data Source"]
            EIPortal["Envision Portal<br><br><br>"]:::portalStyle
            EIAPI["REST API<br><br><br>"]:::apiStyle
            EIJSON["JSON Data<br><br><br>"]
        end
        subgraph ENT["Enterprise NDF Sources"]
            EC["Enterprise Calendar<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            BCV["BCV Object<br>(Snowflake)<br><br><br>"]:::snowflakeObjectStyle
            NT["Node Table<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            EXT["Extrapolation Table<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            FIT["5Impact Areas Table<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            TXT["Taxonomy Table<br>(Databricks)<br><br><br>"]:::databricksObjectStyle
            LOG["LOGEC<br>(Snowflake)<br><br><br>"]:::snowflakeObjectStyle
        end
    end
    class SRC sourceLayer

    %% AWS Layer
    subgraph AWS["AWS Layer"]
        S3["S3 Bucket<br><br><br>"]:::awsStyle
    end
    class AWS awsLayer

    %% Databricks Layer
    subgraph DBX["Databricks Processing Layer"]
        %% Bronze Layer
        subgraph BRONZE["Bronze Layer"]
            LT["Databricks Landing Table<br>(delta format)<br><br><br>"]:::tableStyle
            RT["Databricks RAW Layer Table<br>(delta format)<br><br><br>"]:::tableStyle
            DQ{{"DQ checks using<br>Spark Expectations tool<br><br><br>"}}:::dqStyle
            CT["Databricks Cleanse Layer Table<br>(delta format)<br><br><br>"]:::tableStyle
            RJ["Rejected Records<br><br><br>"]:::rejectStyle
        end
        class BRONZE bronzeLayer

        %% Silver Layer
        subgraph SILVER["Silver Layer"]
            CHT["Databricks Curated Hist Layer<br>(delta format)<br><br><br>"]:::tableStyle
            CV["Databricks Curated View<br>(delta format)<br><br><br>"]:::tableStyle
            IT["Databricks Integrated Layer with SCD Type2 History<br>(delta format)<br><br><br>"]:::tableStyle
            ENTDQ{{"Enterprise DQ checks using<br>Spark Expectations tool<br><br><br>"}}:::dqStyle
            ENTRJ["Enterprise Rejected Records<br><br><br>"]:::rejectStyle
        end
        class SILVER silverLayer
    end
    class DBX databricksLayer

    %% Connect everything
    %% Engie Flow
    EPortal --> |Weekly| ECSV
    ECSV --> |Weekly| EMFT
    EMFT --> |SFTP Transfer| S3
    S3 --> |Auto Loader| RT

    %% Watchwire Flow
    WPortal --> WAPI
    WAPI --> WJSON
    WJSON --> LT
    LT --> RT

    %% GPS Flow
    GPortal --> |Weekly| GAPI
    GAPI --> |Weekly| GJSON
    GJSON --> |Weekly| LT

    %% RE100 Flow
    RPortal --> |Monthly| RAPI
    RAPI --> |Monthly| RJSON
    RJSON --> |Monthly| LT

    %% Mace Flow
    MPortal --> |Weekly| MCSV
    MCSV --> |SFTP Transfer| S3

    %% Envision IOT Flow
    EIPortal --> |Weekly| EIAPI
    EIAPI --> |Weekly| EIJSON
    EIJSON --> |Weekly| LT

    %% Common Flow
    RT --> DQ
    DQ -->|Pass| CT
    DQ -->|Fail| RJ
    CT --> |STM Transformations| CHT
    CHT --> CV
    CV --> IT

    %% Enterprise NDF Sources Flow
    EC & BCV  & NT & LOG  & EXT & FIT & TXT --> |Weekly| ENTDQ
    ENTDQ -->|Pass| IT
    ENTDQ -->|Fail| ENTRJ
```
