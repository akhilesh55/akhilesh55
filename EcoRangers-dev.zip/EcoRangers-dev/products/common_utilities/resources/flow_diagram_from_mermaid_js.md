# SDF Arch diagram using Mermaid JS

```mermaid
flowchart LR
    %% Styles
    classDef sourceLayer fill:#e6f3ff,stroke:#2d6a9f,stroke-width:2px
    classDef sourceBox fill:#ffffff,stroke:#2d6a9f,stroke-width:1px
    classDef processingLayer fill:#f0f7eb,stroke:#5a9132,stroke-width:2px
    classDef processingBox fill:#ffffff,stroke:#5a9132,stroke-width:1px
    classDef dqEngine fill:#fff3e6,stroke:#ff8c00,stroke-width:2px,color:#ff8c00
    classDef awsLayer fill:#ffebd6,stroke:#ff9900,stroke-width:2px
    classDef awsBox fill:#ffffff,stroke:#ff9900,stroke-width:1px
    classDef bronzeLayer fill:#ffe6e6,stroke:#cc4400,stroke-width:2px
    classDef silverLayer fill:#e6e6ff,stroke:#0044cc,stroke-width:2px

    %% Source Layer
    subgraph SL["Source Layer"]
        direction TB
        subgraph Files["Files Sources"]
            F["fa:fa-file FILES<br><br><br>"]
        end
        subgraph APIs["API Sources"]
            A["fa:fa-plug API<br><br><br>"]
        end
        subgraph AT["Airtable Sources"]
            AIR["fa:fa-table Airtable<br><br><br>"]
        end
        subgraph ES["Enterprise Sources"]
            ENT["fa:fa-building NDF Enterprise Sources<br><br><br>"]
        end
    end

    %% AWS Layer
    subgraph AWS["AWS Layer"]
        direction LR
        S3["fa:fa-database S3 Landing<br><br><br>"]
    end

    %% Databricks Processing Layer
    subgraph DPL["Databricks Processing Layer"]
        direction LR
        subgraph BL["Bronze Layer"]
            LAND["fa:fa-download Databricks Landing Layer <br>(delta format)<br><br><br>"]
            RAW["fa:fa-cube Databricks RAW Layer<br>(delta format)<br><br><br>"] --> DQ["fa:fa-check-circle DQ Engine<br><br><br>"]
            LAND --> RAW
            DQ --> CL["fa:fa-shower Databricks Cleansed Layer<br>(delta format)<br><br><br>"]
        end
        subgraph SIL["Silver Layer"]
            CHT["fa:fa-history Databricks Curated<br>History Layer<br>(delta format)<br><br><br>"]
            CUR["fa:fa-database Databricks Curated<br>View Layer<br>(delta format)<br><br><br>"]
            IT["fa:fa-layer-group Databricks Integrated<br>Layer with SCD Type2 History<br>(delta format)<br><br><br>"]
            CHT --> CUR --> IT
        end
        CL --> CHT
    end

    %% Connections between layers
    F --> S3
    A --> LAND
    AIR --> LAND
    S3 --> RAW
    ENT --> DQ2["fa:fa-check-circle DQ Engine<br><br><br>"]
    DQ2 --> IT

    %% Apply styles
    class SL sourceLayer
    class F,A,AIR,ENT sourceBox
    class AWS awsLayer
    class S3 awsBox
    class DPL processingLayer
    class RAW,CL,LAND processingBox
    class CHT,CUR,IT processingBox
    class DQ,DQ2 dqEngine
    class BL bronzeLayer
    class SIL silverLayer
```
