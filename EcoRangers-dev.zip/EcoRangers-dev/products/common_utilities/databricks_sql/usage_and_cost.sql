########usage_and_cost########
select distinct 'SCOPE 1' as scope_nbr,fuel_location_nbr as location_nbr,fuel_location_nm as location_nm,reporting_period_dt,service_type_cd,service_cost,service_usage_qty,cost_usage_data_source_cd
from {src_db}.fuel_usage_consumption_integrated_v
where service_cost is null and service_usage_qty is null
and cost_usage_data_source_cd not in ('SEE', 'ENABLON')
union all
select distinct 'SCOPE 2' as scope_nbr,electricity_location_nbr as location_nbr,electricity_location_nm as location_nm,reporting_period_dt,service_type_cd,service_cost,service_usage_qty,cost_usage_data_source_cd
from {src_db}.electricity_usage_consumption_integrated_v
where service_cost is null and service_usage_qty is null
and cost_usage_data_source_cd not in ('SEE', 'ENABLON') 
order by cost_usage_data_source_cd,scope_nbr,location_nbr,location_nm,reporting_period_dt


########usage_and_cost_enablon########
select distinct 'SCOPE 1' as scope_nbr,fuel_location_nbr as location_nbr,fuel_location_nm as location_nm,reporting_period_dt,service_type_cd,service_cost,service_usage_qty,cost_usage_data_source_cd
from {src_db}.fuel_usage_consumption_integrated_v
where service_cost is null and service_usage_qty is null
and cost_usage_data_source_cd in ('ENABLON')
union all
select distinct 'SCOPE 2' as scope_nbr,electricity_location_nbr as location_nbr,electricity_location_nm as location_nm,reporting_period_dt,service_type_cd,service_cost,service_usage_qty,cost_usage_data_source_cd
from {src_db}.electricity_usage_consumption_integrated_v
where service_cost is null and service_usage_qty is null
and cost_usage_data_source_cd in ('ENABLON')
order by cost_usage_data_source_cd,scope_nbr,location_nbr,location_nm,reporting_period_dt

########usage_and_cost_seam########
select distinct 'SCOPE 1' as scope_nbr,fuel_location_nbr as location_nbr,fuel_location_nm as location_nm,reporting_period_dt,service_type_cd,service_cost,service_usage_qty,cost_usage_data_source_cd
from {src_db}.fuel_usage_consumption_integrated_v
where service_cost is null and service_usage_qty is null
and cost_usage_data_source_cd in ('SEE')
union all
select distinct 'SCOPE 2' as scope_nbr,electricity_location_nbr as location_nbr,electricity_location_nm as location_nm,reporting_period_dt,service_type_cd,service_cost,service_usage_qty,cost_usage_data_source_cd
from {src_db}.electricity_usage_consumption_integrated_v
where service_cost is null and service_usage_qty is null
and cost_usage_data_source_cd in ('SEE')
order by cost_usage_data_source_cd,scope_nbr,location_nbr,location_nm,reporting_period_dt

