WITH
  total_query AS (
    SELECT
      MONTH(DATE) AS month,
      YEAR(DATE) AS year,
      ROUND(AVG(avg_cpu_used), 3) AS avg_cpu_util
    FROM
      (
        SELECT
          DATE,
          workspace_name,
          compute_name,
          CASE
            WHEN group_name LIKE 'ecorangers' THEN 'SDF'
            ELSE 'Others'
          END Data_Product,
          CASE
            WHEN compute_name LIKE '%job%' THEN 'JOB'
            ELSE "All-purpose"
          END compute_type,
          CASE
            WHEN LOWER(run_name) LIKE '%dev%' THEN 'DEV'
            WHEN LOWER(run_name) LIKE '%test%' THEN 'QA'
            WHEN LOWER(run_name) LIKE '%qa%' THEN 'QA'
            WHEN LOWER(run_name) LIKE '%non%' THEN 'QA'
            WHEN LOWER(run_name) LIKE '%prod%' THEN 'PROD'
            ELSE 'PROD'
          END Env,
          run_name,
          cluster_owner,
          ROUND(SUM(dbus), 0) AS dbus,
          ROUND(SUM(dbu_price), 0) AS dbu_price,
          ROUND(SUM(aws_price), 0) AS aws_price,
          ROUND(SUM(total_price), 0) AS total_price,
          ROUND(AVG(max_cpu_used), 0) AS max_cpu_used,
          ROUND(AVG(avg_cpu_used), 0) AS avg_cpu_used,
          ROUND(SUM(max_disk_free), 0) AS max_disk_free,
          ROUND(SUM(avg_disk_free), 0) AS avg_disk_free,
          ROUND(SUM(max_mem_used), 0) AS max_mem_used,
          ROUND(SUM(avg_mem_used), 0) AS avg_mem_used,
          COUNT(1) run_count,
          ROUND(
            (
              ROUND(SUM(dbus), 0) * ROUND(SUM(dbu_price), 0) + ROUND(SUM(aws_price), 0)
            ) / COUNT(1),
            2
          ) AS average_cost_per_run,
          (avg_cpu_used / max_cpu_used) * 100 AS average_cpu_utilization_percentage
        FROM
          non_published_domain.sole_observability.clusters_cost_and_utilization
        WHERE
          workspace_name = 'nike-sole-react'
          AND group_name = 'ecorangers'
          AND cluster_owner NOT IN ('83e41ea8-660c-4c93-b5b9-978d15ea421b')
          AND DATE BETWEEN '2023-01-01' AND '2024-03-01'
        GROUP BY
          ALL
        ORDER BY
          DATE DESC
      )
    GROUP BY
      MONTH(DATE),
      YEAR(DATE)
  )
SELECT
  *
FROM
  total_query
ORDER BY
  year,
  month;
