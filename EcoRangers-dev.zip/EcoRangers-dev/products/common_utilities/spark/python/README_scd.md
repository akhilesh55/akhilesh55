# Low Code Patterns

The intention of creating this is to help in building common patterns in one place.

### SCD Type 2 utility

SCD type 2 can be implemented using this function based on either of the below two criteria

1. There should only a single record corresponding to a given set of primary keys
2. If there are multiple records for a given set of primary keys, a sequencing/sorting column should also be provided so that the correct linkage can be maintained between records and identify any missed or out of sync records.

Pre-requisite - Target table should already contain the additional columns viz. is_current, is_delete[optional], start_date(timestamp), end_date(timestamp)

The function usage/definition for running this sync process is as follows:

```python
from products.common_utilities.spark.python.src.low_code_patterns import SCD2DeltaTableWriter


class_obj = SCD2DeltaTableWriter(
        source = "Should be the source table or dataframe which has the new incoming data",
        keys = "List of primary key columns",
        target_table = "Target table name which will maintain or already has scd data",
        include_columns = "list of columns to be used for comparison to generate the hash & identify changes. Default is an empty list. Takes priority over exclude_columns. Should not include any of the keys. Applicable only for criteria 1",
        exclude_columns = "list of columns to be excluded from comparison while generating the hash to identify changes. Default is an empty list. Will be ignored if include_columns is passed. Should not include any of the keys. Applicable only for criteria 1",
        apply_as_deletes = "Flag to identify deletes exist",
        sequence_by = "Timestamp column that can be used to identify the sequence of records when multiple records are available for the same primarry key. Applicable only for criteria 2"
        delta_tbl_flag = "Values can be either delta or any other column name which may need to be optionally dropped",
        target_start_col_name = "Column name which will be present in target table to identify the start date of a record",
        target_end_col_name = "Column name which will be present in target table to identify the end date of a record",
        end_date_expr = "End date expression if it should be any other value or expression. Default : current_timestamp()
        spark = "SparkSession object to be used. If not provided, a new SparkSession will be created internally",
        logger = "Logger object to log the messages. If not provided, a logger will be created internally"

      )
class_obj.execute()
```

For more information, you can visit the [SCD-Type2 documentation](https://confluence.nike.com/display/SDF/SCD+Type+2).
