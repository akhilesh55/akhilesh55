# Databricks notebook source
# MAGIC %md
# MAGIC # Lakehouse monitoring Notebook
# MAGIC
# MAGIC **User requirements**
# MAGIC - You must have access to run commands on a cluster with access to Unity Catalog.
# MAGIC - You must have `USE CATALOG` privilege on at least one catalog, and you must have `USE SCHEMA` privileges on at least one schema. This notebook creates tables in the `main.default` schema. If you do not have the required privileges on the `main.default` schema, you must edit the notebook to change the default catalog and schema to ones that you do have privileges on.
# MAGIC
# MAGIC **System requirements:**
# MAGIC - Your workspace must be enabled for Unity Catalog.
# MAGIC - Databricks Runtime 12.2 LTS or above.
# MAGIC - A Single user or Assigned cluster.
# MAGIC
# MAGIC This notebook illustrates how to create a time series monitor.
# MAGIC
# MAGIC For more information about Lakehouse monitoring, see the documentation ([AWS](https://docs.databricks.com/lakehouse-monitoring/index.html)|[Azure](https://learn.microsoft.com/azure/databricks/lakehouse-monitoring/index)).

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup
# MAGIC * Verify cluster configuration
# MAGIC * Install Python SDK
# MAGIC * Define catalog, schema and table names

# COMMAND ----------

# Check the cluster configuration. If this cell fails, use the cluster selector at the top right of the notebook to select or configure a cluster running Databricks Runtime 12.2 LTS or above.
import os

assert (
    float(os.environ.get("DATABRICKS_RUNTIME_VERSION", 0)) >= 12.2
), "Please configure your cluster to use Databricks Runtime 12.2 LTS or above."

# COMMAND ----------

# DBTITLE 1,Install Lakehouse Monitoring client wheel
# MAGIC %pip install "databricks-sdk>=0.28.0"

# COMMAND ----------

# This step is necessary to reset the environment with our newly installed wheel.
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Specify catalog and schema to use
# You must have `USE CATALOG` privileges on the catalog, and you must have `USE SCHEMA` privileges on the schema.
# If necessary, change the catalog and schema name here.

CATALOG = dbutils.widgets.get("catalog")
SCHEMA = dbutils.widgets.get("schema")
TABLE_NAME = dbutils.widgets.get("table_name")

# COMMAND ----------

username = spark.sql("SELECT current_user()").first()["current_user()"]
# username_prefixes = username.split("@")[0].split(".")

# COMMAND ----------

# unique_suffix = "_".join([username_prefixes[0], username_prefixes[1][0:2]])
TABLE_NAME = f"{CATALOG}.{SCHEMA}.{TABLE_NAME}"
# BASELINE_TABLE = f"{CATALOG}.{SCHEMA}.sys_genai_ts_baseline_profiling"
TIMESTAMP_COL = dbutils.widgets.get("timestamp_col")

# COMMAND ----------

spark.sql(f"DROP TABLE IF EXISTS {TABLE_NAME}_drift_metrics")
spark.sql(f"DROP TABLE IF EXISTS {TABLE_NAME}_profile_metrics")

# COMMAND ----------

# MAGIC %md
# MAGIC ## User Journey
# MAGIC 1. Create tables: Read raw data and create the primary table (the table to be monitored) and the baseline table (which contains data known to meet expected quality standards).
# MAGIC 2. Create a monitor on the primary table.
# MAGIC 3. Inspect the metrics tables.
# MAGIC 4. Apply changes to table and refresh metrics. Inspect the metrics tables.
# MAGIC 5. [Optional] Delete the monitor.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Create the monitor
# MAGIC This notebook illustrates `TimeSeries` type analysis. For other types of analysis, see the Lakehouse Monitoring documentation ([AWS](https://docs.databricks.com/lakehouse-monitoring/index.html)|[Azure](https://learn.microsoft.com/azure/databricks/lakehouse-monitoring/index)).
# MAGIC
# MAGIC **Make sure to drop any columns that should be excluded from a business or use-case perspective.**

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.catalog import (
    MonitorTimeSeries,
    MonitorInfoStatus,
    MonitorRefreshInfoState,
    MonitorMetric,
    MonitorCronSchedule,
    MonitorCronSchedulePauseStatus,
)

w = WorkspaceClient()

# COMMAND ----------

# Window sizes to analyze data over
GRANULARITIES = ["1 day"]

# Expressions to slice data with
SLICING_EXPRS = [TIMESTAMP_COL]

# Directory to store generated dashboard
ASSETS_DIR = f"/Workspace/Users/{username}/databricks_lakehouse_monitoring/{TABLE_NAME}"

# COMMAND ----------

# DBTITLE 1,Create Monitor
print(f"Creating monitor for {TABLE_NAME}")

info = w.quality_monitors.create(
    table_name=TABLE_NAME,
    schedule=MonitorCronSchedule(
        quartz_cron_expression="0 0 0 ? * * *", timezone_id="UTC"
    ),
    time_series=MonitorTimeSeries(
        timestamp_col=TIMESTAMP_COL, granularities=GRANULARITIES
    ),
    slicing_exprs=SLICING_EXPRS,
    # baseline_table_name=BASELINE_TABLE,
    output_schema_name=f"{CATALOG}.{SCHEMA}",
    assets_dir=ASSETS_DIR,
)

# COMMAND ----------


import time


# Wait for monitor to be created
while info.status == MonitorInfoStatus.MONITOR_STATUS_PENDING:
    info = w.quality_monitors.get(table_name=TABLE_NAME)
    time.sleep(10)

assert info.status == MonitorInfoStatus.MONITOR_STATUS_ACTIVE, "Error creating monitor"

# COMMAND ----------

# A metric refresh will automatically be triggered on creation
refreshes = w.quality_monitors.list_refreshes(table_name=TABLE_NAME).refreshes
assert len(refreshes) > 0

run_info = refreshes[0]
while run_info.state in (
    MonitorRefreshInfoState.PENDING,
    MonitorRefreshInfoState.RUNNING,
):
    run_info = w.quality_monitors.get_refresh(
        table_name=TABLE_NAME, refresh_id=run_info.refresh_id
    )
    time.sleep(30)

assert run_info.state == MonitorRefreshInfoState.SUCCESS, "Monitor refresh failed"

# COMMAND ----------

# MAGIC %md
# MAGIC Click the highlighted Dashboard link in the cell output to open the dashboard. You can also navigate to the dashboard from the Catalog Explorer UI.

# COMMAND ----------

w.quality_monitors.get(table_name=TABLE_NAME)

# COMMAND ----------

# Display profile metrics table
profile_table = f"{TABLE_NAME}_profile_metrics"
display(spark.sql(f"SELECT * FROM {profile_table}"))

if CATALOG == "development":
    spark.sql(
        f"ALTER TABLE {profile_table} OWNER TO `App.NikeSole.ecorangers.Developer`"
    )
else:
    spark.sql(
        f"ALTER TABLE {profile_table} OWNER TO `App.NikeSole.ecorangers.DataAdmin`"
    )

# COMMAND ----------

# MAGIC %md ### Orientation to the drift metrics table
# MAGIC
# MAGIC The drift metrics table has the suffix `_drift_metrics`. For a list of statistics that are shown in the table, see the documentation ([AWS](https://docs.databricks.com/lakehouse-monitoring/monitor-output.html#drift-metrics-table)|[Azure](https://learn.microsoft.com/azure/databricks/lakehouse-monitoring/monitor-output#drift-metrics-table)).
# MAGIC
# MAGIC - For every column in the primary table, the drift table shows a set of metrics that compare the current values in the table to the values at the time of the previous analysis run and to the baseline table. The column `drift_type` shows `BASELINE` to indicate drift relative to the baseline table, and `CONSECUTIVE` to indicate drift relative to a previous time window. As in the profile table, the column from the primary table is identified in the column `column_name`.
# MAGIC   - At this point, because this is the first run of this monitor, there is no previous window to compare to. So there are no rows where `drift_type` is `CONSECUTIVE`.
# MAGIC - For `TimeSeries` type analysis, the `granularity` column shows the granularity corresponding to that row.
# MAGIC - The table shows statistics for each value of each slice key in each time window, and for the table as whole. Statistics for the table as a whole are indicated by `slice_key` = `slice_value` = `null`.
# MAGIC - The `window` column shows the the time window corresponding to that row. The `window_cmp` column shows the comparison window. If the comparison is to the baseline table, `window_cmp` is `null`.
# MAGIC - Some statistics are calculated based on the table as a whole, not on a single column. In the column `column_name`, these statistics are identified by `:table`.

# COMMAND ----------

# Display the drift metrics table
drift_table = f"{TABLE_NAME}_drift_metrics"
display(spark.sql(f"SELECT * FROM {drift_table}"))

if CATALOG == "development":
    spark.sql(f"ALTER TABLE {drift_table} OWNER TO `App.NikeSole.ecorangers.Developer`")
else:
    spark.sql(f"ALTER TABLE {drift_table} OWNER TO `App.NikeSole.ecorangers.DataAdmin`")

# COMMAND ----------

# MAGIC %md
# MAGIC ## [Optional] Delete the monitor
# MAGIC Uncomment the following line of code to clean up the monitor. Only a single monitor can exist for a table.

# COMMAND ----------

# w.quality_monitors.delete(table_name=TABLE_NAME)

# COMMAND ----------
