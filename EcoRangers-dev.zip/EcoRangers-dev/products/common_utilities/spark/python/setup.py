#!/usr/bin/env python

import os
from setuptools import setup, find_packages
from wheel.bdist_wheel import bdist_wheel
from setuptools.command.test import test as TestCommand

DESCRIPTION = "Template for pyspark"
NAME = "template_python"
AUTHOR = "Analytics Engineering Development Team"
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


class PyTest(TestCommand):
    user_options = [("pytest-args=", "a", "Arguments to pass into py.test")]

    def initialize_options(self):
        TestCommand.initialize_options(self)
        self.pytest_args = []

    def finalize_options(self):
        TestCommand.finalize_options(self)
        self.test_args = []
        self.test_suite = True

    def run_tests(self):
        import pytest
        import sys

        errno = pytest.main(self.pytest_args)
        sys.exit(errno)


setup(
    name="<product_name>",
    version=1.0,
    description="Bundled spark artifact for <product_name>.",
    tests_require=["pytest"],
    packages=find_packages(exclude=["tests"]),
    author=AUTHOR,
    test_suite="tests",
    cmdclass={"bdist_pyspark": bdist_wheel, "test": PyTest},
)
