# """
# util_ingest_bcl_to_integrated.py

# This module contains utility functions for ingesting BCL data into the integrated system.
# It includes functions for updating batch load trackers, loading alert tables, and logging
# audit metadata.

# Functions:
#     update_batch_load_tracker: Updates the batch load tracker with the current status.
#     load_alerts_table: Loads data into the alerts table.
#     load_audit_table: Logs metadata into the audit table.
# """

# ########################################################################################
# # Module: UTIL_INGEST_BCL_TO_INTEGRATED
# # Purpose: This module is responsible for
# #            reading the data from logEC and Node snowflake tables and loading to
# #               snowflake integrated tables
# # Modification History:
# # =================================================================================
# # Date         Version  Created/Modified By               Comments
# # -----------  -------  ----------------------         -------------------------------
# # 5-JAN-2024  v1.00    MohanaSilpa Palla(MPall6)         Initial Development (SDF- 1076)
# # ====================================================================================
# #######################################################################################

# import sys
# import os
# import inspect

# # from data_common_utilities.src.lib.common.snowflake_utils import SnowflakeGenericUtils
# # from data_common_utilities.src.lib.common.snowflake_utils import SnowflakeWriter
# from products.common_utilities.spark.python.src.common_utilities import (
#     SparkUtils,
#     LoggerUtils,
#     ConfigUtils,
#     QueryUtils,
#     AuditUtils,
#     AlertUtils,
# )

# # from pyspark.sql.functions import
# # from pyspark.sql.types import *

# ## adding the current directory of the file to the sys path list ##
# sys.path.append(os.path.abspath(os.getcwd()))


# def run_ingest_bcl_to_integrated(
#     config_path: str,
#     config_name: str,
#     sql_file_path: str,
#     sql_file_name: str,
#     env: str,
#     bf_context: object,
#     root_dir: str,
# ) -> None:
#     """
#     Function Name: run_ingest_bcl_to_integrated.\n
#     Params:
#             :param config_path: string\n
#             :param config_name: string\n
#             :param sql_file_path: string\n
#             :param sql_file_name: string\n
#             :param env: string\n
#             :param bf_context: object\n
#             :param root_dir: string\n
#     Returns: None
#     """
#     try:
#         ## call the function in LoggerUtils to configure the logger object ##
#         logger = LoggerUtils().get_logger_object()
#         logger.info("%s START: run_ingest_bcl_to_integrated() %s", "*" * 20, "*" * 20)
#         function_name = inspect.currentframe().f_code.co_name

#         ## call the function in ConfigUtils to read the configurations
#         # present in TOML file and get dictionary of values ##
#         conf = ConfigUtils().read_config_variables(
#             config_path=config_path, config_name=config_name, env=env, logger=logger
#         )
#         product_conf = ConfigUtils().read_config_variables(
#             config_path=root_dir,
#             config_name="product-info.toml",
#             env=env,
#             logger=logger,
#         )
#         job_id = str(
#             bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
#         )
#         # call the function from common utils to get spark session object ##
#         job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
#         spark = SparkUtils().get_spark_session(logger, job_name)

#         ## assign the config values to respective variables ##
#         batch_complete_table_name = (
#             conf["audit_database_name"] + "." + "sdf_batch_load_tracker"
#         )
#         target_complete_table_name = (
#             conf["target_database_name"] + "." + conf["target_table_name"]
#         )
#         conf["batch_id"] = str(
#             spark.sql(
#                 f"""SELECT batch_id FROM {batch_complete_table_name}
#                 where status in ('RUNNING', 'FAILURE') and env = '{env}'
#                 and project_name = '{product_conf['product_name']}'"""
#             ).head()[0]
#         )
#         status = ""
#         conf["function_name"] = function_name
#         conf["tech_solution_id"] = product_conf["tech_solution_id"]
#         conf["cloudred_gid"] = product_conf["nike-tagguid"]
#         token_username = None
#         token_password = None

#         (
#             token_username,
#             token_password,
#         ) = ConfigUtils().get_username_password_from_dbx_secrets(
#             logger, bf_context, conf["dbx_scope"]
#         )
#         if token_username is None or token_password is None:
#             raise ValueError("Username or Password is None")

#         conf["username"] = token_username
#         conf["password"] = token_password

#         ## Connection to snowflake  ##
#         sf_options = SnowflakeGenericUtils().get_snowflake_options(
#             url=conf["sfurl"],
#             sfUser=conf["username"],
#             gid_password=conf["password"],
#             sfDatabase=conf["sfdatabase"],
#             sfSchema=conf["sfschema"],
#             sfRole=conf["sfrole"],
#             sfWarehouse=conf["sfwarehouse"],
#         )

#         ## count target table data before new load
#         try:
#             target_count_query = f"""
#             SELECT TO_VARCHAR(COUNT(*)) as table_count FROM {target_complete_table_name}"""
#             target_count_df = SparkUtils().run_snowflake_queries_as_spark_df(
#                 logger, spark, conf, target_count_query
#             )
#             conf["target_data_count_before_load"] = target_count_df.head()[0]
#         except Exception as err:
#             logger.error("Error in counting target table data: %s", err)
#             conf["target_data_count_before_load"] = 0

#         ## Returns file_contents from sql file ##
#         sql_file_contents = SparkUtils().get_sql_file_content(
#             logger, sql_file_path, sql_file_name
#         )

#         ## format_sql_query_with_variables ##
#         sql_query = SparkUtils().format_sql_query_with_variables(
#             logger, sql_file_contents, kwargs=conf["tables_mapping_dict"]
#         )

#         ## count target table data before new load
#         conf["source_record_count"] = 0
#         conf["target_record_count"] = 0
#         copy_conf = conf.copy()

#         ## iterate over the tables_mapping_dict and get the source table name and count ##
#         for key, value in conf["tables_mapping_dict"].items():
#             parts = value.split(".")
#             if len(parts) >= 3:
#                 database = parts[0]
#                 schema = parts[1]
#                 table = parts[-1]
#                 copy_conf["sfdatabase"] = database
#                 copy_conf["sfschema"] = schema
#                 source_count_query = (
#                     f"""SELECT TO_VARCHAR(COUNT(*)) as table_count FROM {table}"""
#                 )
#                 source_count_df = SparkUtils().run_snowflake_queries_as_spark_df(
#                     logger, spark, copy_conf, source_count_query
#                 )
#                 conf["source_record_count"] = int(conf["source_record_count"]) + int(
#                     source_count_df.head()[0]
#                 )
#             else:
#                 err = f"Invalid format for {key}: {value}. \
#                 Expected format: database.schema.table in table mapping data"
#                 logger.error(err)
#                 raise SystemError(err) from err

#         conf["source_database_name"] = (
#             conf.get("sfdatabase") + "." + conf.get("sfschema")
#         )
#         table_names = {
#             k: v.split(".")[-1] for k, v in conf["tables_mapping_dict"].items()
#         }
#         conf["source_table_name"] = ",".join(list(table_names.values()))

#         conf["target_database_name"] = (
#             conf.get("sfdatabase") + "." + conf.get("sfschema")
#         )

#         ## executing the merge sql query  ##
#         query_data = SnowflakeWriter().execute_snowflake_query(
#             spark, sql_query, sf_options
#         )
#         logger.info("Query executed successfully: %s", query_data)
#         conf["target_record_count"] = conf["source_record_count"]

#         ## count target table data after new load ##
#         try:
#             target_count_query = f"""SELECT TO_VARCHAR(COUNT(*)) \
#             as table_count FROM {target_complete_table_name}"""
#             target_count_df = SparkUtils().run_snowflake_queries_as_spark_df(
#                 logger, spark, conf, target_count_query
#             )
#             conf["target_data_count_after_load"] = target_count_df.head()[0]
#         except Exception as err:
#             logger.error("Error in counting target table data: %s", err)
#             conf["target_data_count_after_load"] = 0

#         status = "SUCCESS"

#     except Exception as err:
#         logger.error("Error In - run_ingest_bcl_to_integrated() : %s", err)
#         conf["target_record_count"] = 0
#         status = "FAILURE"
#         conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
#         QueryUtils(spark=spark).update_batch_load_tracker(
#             project_name=product_conf["product_name"],
#             env=bf_context.env,
#             batch_tracker_table=batch_complete_table_name,
#             status=status,
#         )
#         AlertUtils().load_alerts_table(logger, spark, job_id, conf)
#         raise SystemError(err) from err
#     finally:
#         ## call the function in AuditUtils to log the metadata ##
#         AuditUtils().load_audit_table(
#             logger,
#             spark,
#             job_id,
#             conf,
#             status,
#             source_table_type="snowflake",
#             target_table_type="snowflake",
#             source_hop=conf["source_hop_name"],
#             target_hop=conf["target_hop_name"],
#         )
#         logger.info("%s END: run_ingest_bcl_to_integrated() %s", "*" * 20, "*" * 20)
