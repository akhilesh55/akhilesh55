"""
This module contains the function `run_api_source_to_landing` which is responsible for
fetching data from an API and loading it into a target table in a Spark environment.

The function performs the following steps:
1. Configures the logger.
2. Reads configuration variables from TOML files.
3. Initializes a Spark session.
4. Fetches an API token using provided credentials.
5. Calls the API to get data and processes the response.
6. Converts the JSON response to Spark DataFrames.
7. Writes the DataFrames to a Delta table.
8. Updates the batch load tracker and audit tables.
9. Handles errors and generates alerts if necessary.

Imports:
    - sys
    - json
    - os
    - datetime
    - inspect
    - reduce
    - requests
    - pyspark.sql.functions
    - pyspark.sql.types
    - products.common_utilities.spark.python.src.common_utilities

Functions:
    - run_api_source_to_landing(config_path: str, config_name: str, env: str,
    bf_context: object, root_dir: str) -> None
"""

import sys
import json
import os
from datetime import datetime
import inspect
import requests
from pyspark.sql.functions import col
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    JSONUtils,
    APIUtils,
    AuditUtils,
    AlertUtils,
)


## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_api_source_to_landing(
    config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
) -> None:
    """
    Function Name: run_api_source_to_landing.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_api_source_to_landing()" + "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        # call the function in ConfigUtils to read the configurations present in TOML
        # file and get dictionary of values
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)
        batch_complete_table_name = (
            conf["target_database_name"] + "." + "sdf_batch_load_tracker"
        )
        ## assign the config values to respective variables ##
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        # authentication_endpoint = conf['authentication_endpoint'].format(id= conf['id'],
        # start_date = conf['start_date'], end_date = conf['end_date'])
        # #start_date and end_date will not be there
        date_time = datetime.now()
        current_timestamp = date_time.strftime("%Y%m%d%H%M%S")
        load_date = date_time.strftime("%Y-%m-%d")
        conf["batch_id"] = str(
            spark.sql(
                f"""SELECT batch_id FROM {batch_complete_table_name} where status in 
        ('RUNNING', 'FAILURE') and env = '{env}' 
        and project_name = '{product_conf['product_name']}'"""
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except:
            conf["target_data_count_before_load"] = 0

        # set start and end dates.
        start_end_date_list = ConfigUtils().set_start_end_date(logger, conf)
        start_date = start_end_date_list[0]
        end_date = start_end_date_list[1]

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        response_object = APIUtils().get_token_from_api(
            logger, token_username, token_password, conf
        )

        ## check if response code is in list of 200, 201, 203, 204
        if str(response_object.status_code).startswith("2"):
            logger.info("API Token fetched successfully using requests module.")

            payload = json.dumps(
                {"username": token_username, "password": token_password}
            )
            headers = {"Content-Type": "application/json"}
            org_list_response = requests.request(
                "POST",
                conf["authentication_endpoint"],
                headers=headers,
                data=payload,
                timeout=600,
            )
            choose_org_url = conf["authentication_endpoint"]
            org_list_json = org_list_response.json()
            access_token = org_list_json.get("data").get("accessToken")
            org_list_access_token = conf["org_list_access_token"] + "" + access_token
            response = requests.request("GET", org_list_access_token, timeout=600)
            choose_org_response = response.json()
            choose_org_json = choose_org_response.get("body")
            api_data = (
                conf["solar_api_endpoint"].format(
                    start_date=start_date, end_date=end_date
                )
                + ""
                + access_token
            )
            metric_response = requests.request("GET", api_data, timeout=600)
            final_response = metric_response.json().get("metrics")

            df_list = []
            logger.info("Running the API to get solar data.")
            list_without_id = APIUtils().fetch_api_without_id(
                logger,
                api_data,
                load_date,
                current_timestamp,
                access_token,
                conf,
                job_id,
                spark,
            )

            df_list.append(
                JSONUtils().json_dict_to_spark_df(logger, list_without_id[0], spark)
            )
            logger.info("Finished getting the solar data.")

            logger.info("Creating dataframes from JSON data")
            # create dfs from the api response
            df_without_id = JSONUtils().json_dict_to_spark_df(
                logger, list_without_id[0], spark
            )

            ## drop rows from a dataframe that has all null values in all columns ##
            df_without_id = df_without_id.dropna(how="all")

            ## count the incremental dataframe
            conf["source_record_count"] = df_without_id.count()
            logger.info("Union of dataframes done, inserting them into delta table.")
            ## Casting all the columns to String ##
            df_without_id = df_without_id.select(
                [col(each_col).cast("string") for each_col in df_without_id.columns]
            )
            df_without_id = df_without_id.withColumn("id", col("id").cast("long"))
            # ## writing the dataframe to final raw layer tables ##
            QueryUtils(spark=spark).write_dataframe_to_delta(
                logger,
                spark,
                conf,
                df_without_id,
                target_complete_table_name,
                tech_solution_id=conf["tech_solution_id"],
                cloudred_gid=conf["cloudred_gid"],
            )
            ## count master dataframe
            conf["target_record_count"] = df_without_id.count()
            status = "SUCCESS"
            conf["target_data_count_after_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        else:
            ## some issue with API token endpoint, so we got different status code ##
            logger.error(
                "Issue while getting the API token, \
                         status code: %s",
                response_object.status_code,
            )

    except Exception as err:
        logger.error("Error In - run_api_source_to_landing() : %s", err)
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        raise SystemError(err) from err
    finally:
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("%s END: run_api_source_to_landing() %s", "*" * 20, "*" * 20)
