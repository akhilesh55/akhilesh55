from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql import DataFrame, SparkSession

# from data_common_utilities.src.lib.common.logging_utils import logger_for_spark
# from data_common_utilities.src.lib.common.spark_utils import get_spark_session
import traceback
from logging import DEBUG
import multiprocessing
import logging
import sys
from contextlib import contextmanager
import timeit
import os
import time


def format_exception(message=None):
    try:
        if message and isinstance(message, str):
            return message + "\n" + traceback.format_exc()
        else:
            return traceback.format_exc()
    except Exception:
        return "Unable to format the underlying error"  # not expecting this ever, but just incase


def error_formatted(logger, message=None):
    logger.error(format_exception(message))


def get_extra_format(extra):
    """
    Function to get the log format with extra dictionary
    :param dict extra:
    :return:
    """
    return " - ".join("{}: %({})s".format(key, key) for key, value in extra.items())


def logger_for(name, extra=None):
    """
    Returns a logger instance depending on whether there is a spark context or not.
    :param name:
    :return:
    """
    result = logging.getLogger(name)
    return add_logger_formatting(result, extra)


def add_logger_formatting(logger, extra):
    logger.propagate = False  # necessary to avoid duplicate logging

    logger.setLevel(DEBUG)
    if logger.hasHandlers():
        logger.handlers.clear()

    stdouthandler = logging.StreamHandler(sys.stdout)

    if extra:
        format = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - "
            + get_extra_format(extra)
            + " - %(message)s"
        )
        stdouthandler.setFormatter(format)
        logger.addHandler(stdouthandler)
        logger = logging.LoggerAdapter(logger, extra)
    else:
        format = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        stdouthandler.setFormatter(format)
        logger.addHandler(stdouthandler)

    logger.error_formatted = lambda m: error_formatted(logger, m)
    return logger


def logger_for_spark(spark, name=__name__):
    """
    This logger helps in spark job to write log messages with additional context which may help later in splunk

    :param name: Name of the module where this function is called
    :param SparkSession spark: spark session
    :return:
    """
    return logger_for(
        name,
        dict(
            spark_job_id=spark.conf.get("spark.app.id"),
            spark_job_name=spark.conf.get("spark.app.name"),
            user=spark.conf.get("spark.app.name"),
        ),
    )


def logger_for_threads(name, extra=None):
    """
    Logger that helps in multi threading
    :param name:
    :param extra:
    :return:
    """
    multiprocessing.log_to_stderr()
    result = multiprocessing.get_logger()
    return add_logger_formatting(result, extra)


def metric_key(basename, **kwargs):
    if len(kwargs) == 0:
        return basename
    else:
        return "%s.%s" % (
            basename,
            ".".join(["%s.%s" % (k, v) for k, v in kwargs.items()]),
        )


"""
Log Metrics to stdout with a standard formatting so that they can be picked by Splunk or other tools.
"""
metrics_logger = logger_for("metrics")


@contextmanager
def timer(basename, **kwargs):
    start = timeit.default_timer()
    try:
        yield
    finally:
        elapsed = timeit.default_timer() - start
        metrics_logger.info(
            "{}={:.3f} seconds".format(metric_key(basename, **kwargs), elapsed)
        )


def get_spark_session(
    spark_app_name: str, options: dict = None, custom_listener_meta_data: dict = None
):
    """
    Spark session with option overridable
    :param custom_listener_meta_data: DEPRECATED - use spark conf to add listener metadata
    :param spark_app_name:
    :param options: SparkConf params
    add metadata to listener  with metadata like
        {"spark.nike.tech_solution_id": "test_product_id} in spark conf
    :return:
    """
    if options:
        spark = (
            SparkSession.builder.config(map=options)
            .enableHiveSupport()
            .appName(spark_app_name)
            .getOrCreate()
        )
    else:
        spark = (
            SparkSession.builder.enableHiveSupport()
            .appName(spark_app_name)
            .config("spark.databricks.delta.merge.enableLowShuffle", "true")
            .getOrCreate()
        )
    return spark


class SCD2utils:
    """
    This utility aims to implement SCD of Type 2 based on the type of the incoming data, whether we have single or multiple incoming records for a given set of primary keys.
    **Would recommend to use [low code pattern](low_code_patterns.md) as much as possible. This is only for cases where low code pattern is not possible**
    """

    def __init__(
        self,
        source,
        keys: list,
        target_table: str,
        include_columns: list = [],
        exclude_columns: list = [],
        apply_as_deletes=None,
        sequence_by: str = None,
        delta_tbl_flag: bool = False,
        target_is_current_col_name: str = "is_current",
        target_start_col_name: str = None,
        target_end_col_name: str = None,
        spark: object = None,
        logger: object = None,
        end_date_expr: str = None,
    ):
        self.source = source
        self.keys = keys
        self.target_table = target_table
        self.include_columns = include_columns
        self.exclude_columns = exclude_columns
        self.apply_as_deletes = apply_as_deletes
        self.apply_as_deletes_condn = None
        if self.apply_as_deletes is not None and isinstance(
            self.apply_as_deletes, dict
        ):
            self.apply_as_deletes_col_nm = apply_as_deletes["col_nm"]
            self.apply_as_deletes_condn = apply_as_deletes["condn"]
        self.delta_tbl_flag = delta_tbl_flag
        self.sequence_by = sequence_by
        self.target_is_current_col_name = target_is_current_col_name
        self.target_start_col_name = target_start_col_name
        self.target_end_col_name = target_end_col_name
        self.end_date_expr = end_date_expr

        # Setting spark sessiom
        if spark is None:
            # self.spark = SparkSession.builder.enableHiveSupport().appName("SCD_Type_2").getOrCreate()
            self.spark = get_spark_session("SCD_Type_2")
        else:
            self.spark = spark
        # Setting logger
        if logger is None:
            self.logger = logger_for_spark(self.spark, __name__)
        else:
            self.logger = logger
        # Creating logger for test use
        # logger = logging.getLogger('SCD2DeltaTableWriter')
        # logger.setLevel(logging.INFO)
        # self.logger = logger

        # Initialization class variables
        self.df_union_list = []
        self.hash_col_list = []
        self.df_src = None
        self.df_src_del = None
        self.df_tgt = None
        self.df_tgt_del = None

    def get_scd_details(self):
        if isinstance(self.source, str):
            self.df_src = self.spark.read.table(self.source)
            if self.apply_as_deletes is not None and self.apply_as_deletes is not True:

                self.df_src_del = self.df_src.where(self.apply_as_deletes_condn).drop(
                    self.apply_as_deletes_col_nm
                )
                self.df_src = self.df_src.where(
                    "NOT("
                    + self.apply_as_deletes_condn
                    + ") or "
                    + self.apply_as_deletes_col_nm
                    + " is null"
                ).drop(self.apply_as_deletes_col_nm)

            if self.delta_tbl_flag is True and self.apply_as_deletes is True:
                self.df_src_del = (
                    self.spark.read.format("delta")
                    .option("readChangeFeed", "true")
                    .option("startingVersion", 1)
                    .table(self.source)
                    .filter(col("_change_type") == "delete")
                    .drop("_change_type", "_commit_version", "_commit_timestamp")
                )

                # filter out those deleted records if inserted again
                self.apply_as_deletes_col_nm = ""

        else:
            self.df_src = self.source
            if self.apply_as_deletes_condn is not None:
                self.df_src_del = self.df_src.where(self.apply_as_deletes_condn).drop(
                    self.apply_as_deletes_col_nm
                )
                self.df_src = self.df_src.where(
                    "NOT("
                    + self.apply_as_deletes_condn
                    + ") or "
                    + self.apply_as_deletes_col_nm
                    + " is null"
                ).drop(self.apply_as_deletes_col_nm)

        # Reading the exisitng target table but only the latest valid record where is_current=1
        self.df_tgt = self.spark.read.table(self.target_table).filter(
            col(self.target_is_current_col_name) == 1
        )

        # Generating the columns for which hash should be generated. Will be based on target table columns
        # include columns will get preference over excluded columnss
        """
        if self.include_columns == [] or self.col_check_flag is False :
            self.include_columns = [c for c in self.df_tgt.columns if c not in self.keys+self.include_columns+['is_current','is_delete','start_date','end_date']]
        self.logger.info(f'Hash columns are {self.keys+self.include_columns}')
        self.hash_col_list = self.keys + self.include_columns
        """
        if self.include_columns != []:
            self.hash_col_list = self.keys + self.include_columns
        elif self.exclude_columns != []:
            self.hash_col_list = self.keys + [
                c
                for c in self.df_tgt.columns
                if c
                not in self.keys
                + self.exclude_columns
                + [
                    self.target_is_current_col_name,
                    "is_delete",
                    self.target_start_col_name,
                    self.target_end_col_name,
                ]
            ]
        else:
            self.hash_col_list = self.keys + [
                c
                for c in self.df_tgt.columns
                if c
                not in self.keys
                + [
                    self.target_is_current_col_name,
                    "is_delete",
                    self.target_start_col_name,
                    self.target_end_col_name,
                ]
            ]
        # hash columns should also be present in source
        self.hash_col_list = [c for c in self.hash_col_list if c in self.df_src.columns]
        self.logger.info(f"Hash columns are {self.hash_col_list}")

        # Generating hash for source and target based on selected columns and for current(is_current=1) data from target
        self.df_src = self.df_src.withColumn("hash_col_src", hash(*self.hash_col_list))
        self.df_tgt = self.df_tgt.withColumn("hash_col_tgt", hash(*self.hash_col_list))

    def scd_inserts(self) -> None:
        # New data can be identified by joining based on PK's
        if self.apply_as_deletes or self.delta_tbl_flag is True:
            # Generate insert statement to identify records with is_current=1 and is_delete=0
            ins_del_condn = "is_delete<>1"
        else:
            ins_del_condn = "1=1"
        df_tgt_ins = self.df_tgt  # .where(ins_del_condn)
        df_ins = (
            self.df_src.alias("df_src")
            .join(df_tgt_ins.alias("df_tgt"), self.keys, "leftanti")
            .select(
                "*",
                expr(f"1 as {self.target_is_current_col_name}"),
                expr("0 as is_delete"),
                expr(f"current_timestamp() as {self.target_start_col_name}"),
                expr(f'cast("9999-12-31" as timestamp) as {self.target_end_col_name}'),
                expr("0 as old_current"),
            )
        )
        self.col_order = df_ins.columns
        self.df_union_list.append(df_ins)

    def scd_updates(self) -> None:
        # Updated data can be identified by joining based on PK's and a mismatch in hash_col values.
        # If hash values are same, it indicates an unchanged record
        if self.apply_as_deletes or self.delta_tbl_flag is True:
            # Generate update statement to compare with is_current=1 and is_delete=1
            updt_sel_stmnt1 = (
                "or (df_src.hash_col_src = df_tgt.hash_col_tgt and df_tgt.is_delete=1)"
            )
            updt_sel_stmnt2 = (
                "case when df_tgt.is_delete=1 then 1 else null end as del_flag"
            )
        else:
            updt_sel_stmnt1 = ""
            updt_sel_stmnt2 = "null as del_flag"

        df_updt = (
            self.df_src.alias("df_src")
            .join(self.df_tgt.alias("df_tgt"), self.keys, "inner")
            .select(
                "df_src.*",
                expr(
                    f"case when df_src.hash_col_src <> df_tgt.hash_col_tgt {updt_sel_stmnt1} then 1  end as updt_check"
                ),
                expr(updt_sel_stmnt2),
            )
            .filter(col("updt_check") == 1)
            .drop("updt_check")
        )

        # Union with self since the older existing records need to updated for unmatched hash's
        df_updt = (
            df_updt.select(
                "*",
                expr(f"1 as {self.target_is_current_col_name}"),
                expr("0 as is_delete"),
                expr(f"current_timestamp() as {self.target_start_col_name}"),
                expr(f'cast("9999-12-31" as timestamp) as {self.target_end_col_name}'),
                expr("0 as old_current"),
            )
            .unionAll(
                df_updt.filter(col("del_flag").isNull()).select(
                    "*",
                    expr(f"0 as {self.target_is_current_col_name}"),
                    expr("0 as is_delete"),
                    expr(f"null as {self.target_start_col_name}"),
                    expr(f" null as {self.target_end_col_name}"),
                    expr("1 as old_current"),
                )
            )
            .drop("del_flag")
        )
        self.df_union_list.append(df_updt)

    def scd_deletes(self) -> None:
        print(f"**** Applying deletes *****")
        self.df_src_del = self.df_src_del.withColumn(
            "hash_col_src", hash(*self.hash_col_list)
        )

        # identify new deletes for which no pk exists
        df_del_ins_1 = (
            self.df_src_del.alias("df_src")
            .join(self.df_tgt.alias("df_tgt"), self.keys, "leftanti")
            .select(
                "*",
                expr(f"1 as {self.target_is_current_col_name}"),
                expr("1 as is_delete"),
                expr(f"current_timestamp() as {self.target_start_col_name}"),
                expr(f"current_timestamp() as {self.target_end_col_name}"),
                expr("0 as old_current"),
            )
        )  # .select(*self.col_order) #.withColumn('dell',lit(0))

        # Check if record is deleted for a given active PK
        df_del_existing = self.df_src_del.alias("df_src").join(
            self.df_tgt.filter(col("is_delete") == 0).alias("df_tgt"),
            self.keys,
            "leftsemi",
        )
        df_del_updt_1 = df_del_existing.select(
            "*",
            expr(f"1 as {self.target_is_current_col_name}"),
            expr("1 as is_delete"),
            expr(f"current_timestamp() as {self.target_start_col_name}"),
            expr(
                f"greatest({self.end_date_expr}, current_timestamp()) as {self.target_end_col_name}"
            ),
            expr("0 as old_current"),
        ).unionAll(
            df_del_existing.select(
                "*",
                expr(f"0 as {self.target_is_current_col_name}"),
                expr("0 as is_delete"),
                expr(f"current_timestamp() as {self.target_start_col_name}"),
                expr(
                    f"greatest({self.end_date_expr}, current_timestamp()) as {self.target_end_col_name}"
                ),
                expr("1 as old_current"),
            )  # .select(*self.col_order) #.withColumn('dell',lit(2))
        )

        # Comparison between deleted records
        df_tgt_del = self.df_tgt.where("is_delete=1")
        # Exclude source records with the same hash value as existing
        df_src_del = self.df_src_del.alias("df_src").join(
            df_tgt_del.alias("df_tgt"),
            col("df_src.hash_col_src") == col("df_tgt.hash_col_tgt"),
            "leftanti",
        )
        #  .select('*', expr('1 as is_current'), expr('1 as is_delete'), expr('current_timestamp() as start_date'), expr('current_timestamp() as end_date'), expr('0 as old_current'))

        # Create update dataframe for deleted records where is_current=1 is a deleted record and incoming record is also an is_delete with different data
        df_del_updates = df_src_del.alias("df_src").join(
            df_tgt_del.alias("df_tgt"), self.keys, "leftsemi"
        )
        df_del_updt_2 = df_del_updates.select(
            "*",
            expr(f"1 as {self.target_is_current_col_name}"),
            expr("1 as is_delete"),
            expr(f"current_timestamp() as {self.target_start_col_name}"),
            expr(
                f"greatest({self.end_date_expr}, current_timestamp()) as {self.target_end_col_name}"
            ),
            expr("0 as old_current"),
        ).unionAll(
            df_del_updates.select(
                "*",
                expr(f"0 as {self.target_is_current_col_name}"),
                expr("1 as is_delete"),
                expr(f"null as {self.target_start_col_name}"),
                expr(
                    f"greatest({self.end_date_expr}, current_timestamp()) as {self.target_end_col_name}"
                ),
                expr("1 as old_current"),
            )
        )

        # Records which were deleted but now an active record is inserted
        df_del_updt_3 = (
            self.df_src.alias("df_src")
            .join(df_tgt_del.alias("df_tgt"), self.keys, "leftsemi")
            .select(
                "*",
                expr(f"0 as {self.target_is_current_col_name}"),
                expr("1 as is_delete"),
                expr(f"null as {self.target_start_col_name}"),
                expr(
                    f"greatest({self.end_date_expr}, current_timestamp())as {self.target_end_col_name}"
                ),
                expr("1 as old_current"),
            )
        )

        df_del = (
            df_del_ins_1.unionAll(df_del_updt_1)
            .unionAll(df_del_updt_2)
            .unionAll(df_del_updt_3)
        )
        df_del = df_del.drop("dell")

        self.df_union_list.append(df_del)

    def scd_union_list(self) -> object:
        return self.df_union_list

    def scd_seq(self):
        tgt_seq_col = self.sequence_by

        if self.apply_as_deletes is None and self.delta_tbl_flag is False:
            self.apply_as_deletes_condn = "1=0"

        # Read the source data & get the change types from the change feed or custom columm
        if self.delta_tbl_flag is True:
            change_types = ["insert", "update_postimage"]
            if self.apply_as_deletes is True:
                change_types = ["insert", "delete", "update_postimage"]
            else:
                self.apply_as_deletes_condn = "1=0"
            df_src = (
                self.spark.read.format("delta")
                .option("readChangeFeed", "true")
                .option("startingVersion", 1)
                .table(self.source)
                .filter(col("_change_type").isin(*change_types))
                .select(
                    "*",
                    expr(
                        'case when _change_type="delete" then 1 else 0 end as is_delete'
                    ),
                )
                .withColumn("sequence_by", col(tgt_seq_col))
                .drop("_commit_timestamp", "_change_type", "_commit_version")
            )

        else:
            if isinstance(self.source, str):
                if self.apply_as_deletes_condn != "1=0":
                    df_src = (
                        self.spark.read.table(self.source)
                        .select(
                            "*",
                            expr(
                                f"case when {self.apply_as_deletes_condn} then 1 else 0 end as is_delete"
                            ),
                        )
                        .withColumn("sequence_by", col(tgt_seq_col))
                        .drop(self.apply_as_deletes_col_nm)
                    )
                else:
                    df_src = (
                        self.spark.read.table(self.source)
                        .select(
                            "*",
                            expr(
                                f"case when {self.apply_as_deletes_condn} then 1 else 0 end as is_delete"
                            ),
                        )
                        .withColumn("sequence_by", col(tgt_seq_col))
                    )
            else:
                if self.apply_as_deletes_condn != "1=0":
                    df_src = (
                        self.source.select(
                            "*",
                            expr(
                                f"case when {self.apply_as_deletes_condn} then 1 else 0 end as is_delete"
                            ),
                        )
                        .withColumn("sequence_by", col(tgt_seq_col))
                        .drop(self.apply_as_deletes_col_nm)
                    )
                else:
                    df_src = self.source.select(
                        "*",
                        expr(
                            f"case when {self.apply_as_deletes_condn} then 1 else 0 end as is_delete"
                        ),
                    ).withColumn("sequence_by", col(tgt_seq_col))

        if (
            tgt_seq_col == "_commit_timestamp"
        ):  # and self.delta_type_or_dropcol == 'delta' :
            tgt_seq_col = self.target_start_col_name
        df_src = df_src.drop("_commit_timestamp")
        src_cols = df_src.columns

        join_cols = ["sequence_by", "is_delete"]
        df_tgt = self.spark.read.table(self.target_table).select(
            "*", expr(f"{tgt_seq_col} as sequence_by")
        )

        if self.apply_as_deletes_condn == "1=0":
            df_tgt = df_tgt.select("*", expr("null as is_delete"))
            join_cols = ["sequence_by"]

        # Get the minimum timestamp value from the source & get only those target records which are greater than this value, thus working on a smaller subset of the entire data.
        min_seq_val = df_src.agg(min("sequence_by")).head()[0]
        df_tgt_min_seq = df_tgt.filter(col(self.target_end_col_name) >= min_seq_val)

        """ Get source records not already present in the target using left anti join and primary key + sequencing column
            as for existing records, we need to get the target records with their existing flags
            AND UNION with
            existing records from the target with their flags    
        """
        df_join_all = (
            df_src.join(df_tgt_min_seq, self.keys + join_cols, "leftanti")
            .select(*src_cols, expr("0 as old_is_current"))
            .unionAll(
                df_tgt_min_seq.select(
                    *src_cols,
                    expr(f"{self.target_is_current_col_name} as old_is_current"),
                )
            )
        )

        """ fetch the records from the target table where is_current=1 and sequence_by < min_seq_val

        """
        df_join_all = (
            df_tgt.filter(
                (col(self.target_is_current_col_name) == 1)
                & (col(self.target_end_col_name) < min_seq_val)
            )
            .select(*src_cols)
            .withColumnRenamed(self.target_start_col_name, "sequence_by")
            .withColumn("old_is_current", lit(1))
            .unionAll(df_join_all)
        )

        # Generating the flags based on the sorted data
        df_join_sorted = (
            df_join_all.withColumn(
                "ranking",
                row_number().over(
                    Window.partitionBy(self.keys).orderBy(
                        col("sequence_by").desc(), col("is_delete").desc()
                    )
                ),
            )
            .withColumn("new_is_current", when(col("ranking") == 1, 1).otherwise(0))
            .withColumn(
                self.target_end_col_name,
                when(
                    (col("new_is_current") == 1) & (col("is_delete") == 1),
                    current_timestamp(),
                ).otherwise(
                    lag("sequence_by", 1, "9999-12-31").over(
                        Window.partitionBy(self.keys).orderBy(
                            col("new_is_current").desc(), col("sequence_by").desc()
                        )
                    )
                ),
            )
            .drop(
                "tgt_ctry_id",
                "tgt_continent",
                "record_type",
                "ranking",
                self.target_is_current_col_name,
            )
            .withColumnRenamed("new_is_current", self.target_is_current_col_name)
            .select(
                *[
                    cols
                    for cols in df_join_all.columns
                    if cols not in ("sequence_by", "is_delete", "isdelete")
                ],
                self.target_is_current_col_name,
                "is_delete",
                expr(f"sequence_by as {self.target_start_col_name}"),
                self.target_end_col_name,
                "sequence_by",
            )
        )

        return df_join_sorted
