########################################################################################
# Module: UTIL_INGEST_CLEANSED_TO_CURATEDHIST
# Purpose: This module is responsible for
#            reading the data from cleansed layers and loading to
#               curatedhist layer
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 27-DEC-2023  v1.00    MohanaSilpa Palla(MPall6)         Initial Development (SDF- 953)
# ====================================================================================
#######################################################################################

import sys
import os
import inspect
from datetime import datetime
from pyspark.sql.functions import to_json, struct, from_json
from pyspark.sql.functions import lit
from pyspark.sql.types import MapType, StringType
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    AuditUtils,
    AlertUtils,
)

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_ingest_cleansed_to_curatedhist(
    config_path: str,
    config_name: str,
    sql_file_path: str,
    sql_file_name: str,
    env: str,
    bf_context: object,
    root_dir: str,
) -> None:
    """
    Function Name: run_ingest_cleansed_to_curatedhist.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param sql_file_path: string\n
            :param sql_file_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info(
            "%s START: run_ingest_cleansed_to_curatedhist() %s", "*" * 20, "*" * 20
        )
        function_name = inspect.currentframe().f_code.co_name
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        ## call the function in ConfigUtils to read the configurations present in
        # TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        incremental_df_list = []

        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except:
            conf["target_data_count_before_load"] = 0

        conf["source_record_count"] = 0

        conf["source_table_name"] = ",".join(conf.get("source_tables_list"))
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        batch_complete_table_name = (
            conf["source_database_name"] + "." + "sdf_batch_load_tracker"
        )

        for each_table in conf.get("source_tables_list"):

            ## assign the config values to respective variables ##
            source_complete_table_name = conf["source_database_name"] + "." + each_table
            target_complete_table_name = (
                conf["target_database_name"] + "." + conf["target_table_name"]
            )
            predicates = conf.get("predicates")
            custom_starting_timestamp = conf.get("custom_starting_timestamp")
            # temp_view_name = conf.get("temp_view_name")
            conf["batch_id"] = str(
                spark.sql(
                    f"SELECT batch_id FROM {batch_complete_table_name} where status \
                    in ('RUNNING', 'FAILURE') and env = '{env}' \
                    and project_name = '{product_conf['product_name']}'"
                ).head()[0]
            )
            status = ""
            conf["function_name"] = function_name
            latest_timestamp = datetime.strptime(conf["batch_id"], "%Y%m%d%H%M%S")

            try:
                ## based on predicates and custom starting timestamp, reading the
                # CDC incremental dataset from source ##
                if predicates and custom_starting_timestamp:
                    incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                        logger,
                        source_complete_table_name,
                        latest_timestamp=latest_timestamp,
                        predicates=predicates,
                        custom_starting_timestamp=custom_starting_timestamp,
                    )
                    incremental_df_list.append(incremental_df)
                elif predicates and not custom_starting_timestamp:
                    incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                        logger,
                        source_complete_table_name,
                        latest_timestamp=latest_timestamp,
                        predicates=predicates,
                    )
                    incremental_df_list.append(incremental_df)
                elif custom_starting_timestamp and not predicates:
                    incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                        logger,
                        source_complete_table_name,
                        latest_timestamp=latest_timestamp,
                        custom_starting_timestamp=custom_starting_timestamp,
                    )
                    incremental_df_list.append(incremental_df)
                else:
                    incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                        logger,
                        source_complete_table_name,
                        latest_timestamp=latest_timestamp,
                    )
                    incremental_df_list.append(incremental_df)
            except Exception as e:
                conf = AlertUtils().generate_alerts_dictionary(
                    logger,
                    conf,
                    "LOW",
                    "Minor error during reading of the CDC incremental dataset: "
                    + str(e),
                )
                AlertUtils().load_alerts_table(logger, spark, job_id, conf)

            if incremental_df.count() == 0:
                if (
                    conf.get("skip_on_no_incremental_records")
                    and conf.get("skip_on_no_incremental_records", {}).get(each_table)
                    and conf["skip_on_no_incremental_records"][each_table] == True
                ):
                    logger.info(
                        "*" * 10
                        + f" No incremental data fetched from earlier hop for : {each_table}. Flag skip_on_no_incremental_records : True "
                        + "*" * 10
                    )
                    continue
                else:
                    logger.info(
                        f"No incremental data fetched from earlier hop for {each_table} "
                    )
                    raise Exception(
                        f"No incremental data fetched from earlier hop, \
                        raising exception to abort further execution of the script."
                    )

            # if incremental_df.count() == 0:
            #     logger.error(
            #         "No incremental data fetched from earlier hop, exiting the script."
            #     )
            #     conf["target_record_count"] = 0
            #     status = "FAILURE"
            #     conf = AlertUtils().generate_alerts_dictionary(
            #         logger, conf, "CRITICAL", "No incremental data to process."
            #     )
            #     AlertUtils().load_alerts_table(logger, spark, job_id, conf)
            #     AuditUtils().load_audit_table(
            #         logger,
            #         spark,
            #         job_id,
            #         conf,
            #         status,
            #         source_table_type="delta",
            #         target_table_type="delta",
            #         source_hop=conf["source_hop_name"],
            #         target_hop=conf["target_hop_name"],
            #     )
            #     logger.info(
            #         "%s END: run_ingest_cleansed_to_curatedhist() %s",
            #         "*" * 20,
            #         "*" * 20,
            #     )
            #     sys.exit(
            #         "No incremental data fetched from earlier hop, exiting the script."
            #     )
            else:
                conf["source_record_count"] = (
                    conf["source_record_count"] + incremental_df.count()
                )

        ## create the spark dataframe  ##
        master_spark_df = SparkUtils().read_spark_sql_file(
            logger, spark, sql_file_path, sql_file_name, incremental_df_list, conf
        )

        ## count the incremental dataframe
        conf["source_record_count"] = master_spark_df.count()

        master_spark_df = master_spark_df.dropDuplicates()

        logger.info("Dataframe created")

        ## typecast void type columns to string to avoid unexpected errors ##
        expressions = [
            f"CAST({each_col} AS STRING) AS {each_col}" if dtype == "void" else each_col
            for each_col, dtype in master_spark_df.dtypes
        ]

        master_spark_df = master_spark_df.selectExpr(*expressions)

        try:
            ## generate the operational attributes using common_utils ##
            master_spark_df = SparkUtils().add_operational_attributes(
                logger,
                spark,
                master_spark_df,
                job_name=job_name,
                run_id=job_id,
                hop_name=conf["target_hop_name"],
            )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "MEDIUM",
                "Issue with adding operational attributes: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)

        ## count master dataframe
        conf["target_record_count"] = master_spark_df.count()

        # ## writing the dataframe to final raw layer tables ##
        QueryUtils(spark=spark).write_dataframe_to_delta(
            logger,
            spark,
            conf,
            master_spark_df,
            target_complete_table_name,
            tech_solution_id=conf["tech_solution_id"],
            cloudred_gid=conf["cloudred_gid"],
        )

        ##change status and get the count of delta table
        status = "SUCCESS"
        conf["target_data_count_after_load"] = spark.sql(
            f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
        ).head()[0]
        logger.info("Starting Loacation data coverage")
        location_cvg_cols = conf.get("location_coverge_cols", {}).get("cols", [])
        tmstp_cols = conf.get("location_coverge_cols", {}).get("timestamp_cols", [])
        location_alert_table = (
            str(conf.get("source_database_name"))
            + "."
            + str(conf.get("location_coverage_table"))
            if conf.get("location_coverage_table", [])
            else []
        )
        # consider object name as well
        if location_cvg_cols and tmstp_cols and location_alert_table:
            location_cvg_df = QueryUtils(
                spark=spark
            ).get_data_difference_between_batches(
                conf["target_database_name"],
                conf["target_table_name"],
                tmstp_cols,
                location_cvg_cols,
            )
            if location_cvg_df.count() > 0:
                logger.info(
                    "Location data coverage for the batch: %s",
                    location_cvg_df.take(5),
                )
                # logger.info("Reading Location coverage alert table")
                # logger.info("Location coverage alert table read successfully")
                # result_df = result_df.select(rename_col_select)
                logger.info("********** Json df ************")
                json_string_df = location_cvg_df.withColumn(
                    "data", to_json(struct(*location_cvg_df.columns))
                )
                map_schema = MapType(StringType(), StringType())
                json_map_df = json_string_df.withColumn(
                    "json_data", from_json(json_string_df["data"], map_schema)
                )
                json_map_df = json_map_df.select("json_data")
                final_df = (
                    json_map_df.withColumn("status", lit("UNPROCESSED"))
                    .withColumn("data_source", lit(conf.get("object_name", "")))
                    .withColumn("load_timestamp", lit(datetime.now()))
                )
                if final_df:
                    QueryUtils(spark=spark).write_dataframe_to_delta(
                        logger,
                        spark,
                        conf,
                        final_df,
                        conf["target_database_name"]
                        + "."
                        + conf["location_coverage_table"],
                        tech_solution_id=conf["tech_solution_id"],
                        cloudred_gid=conf["cloudred_gid"],
                        do_partition=False,
                    )
            else:
                logger.info("No location data coverage for the batch.")

    except Exception as err:
        logger.error("Error In - run_ingest_cleansed_to_curatedhist() : %s", err)
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        if incremental_df.count() == 0:
            conf = AlertUtils().generate_alerts_dictionary(
                logger, conf, "CRITICAL", "No incremental data to process."
            )

        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        raise SystemError(err) from err
    finally:
        # load data in audit table
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info(
            "%s END: run_ingest_cleansed_to_curatedhist() %s", "*" * 20, "*" * 20
        )
