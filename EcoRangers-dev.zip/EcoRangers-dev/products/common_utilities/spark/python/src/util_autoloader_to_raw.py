####################################################################################################
# Module: UTIL_AUTOLOADER_TO_RAW
# Purpose: This module is responsible for
#            reading the incremental csv file data from external volume and
#               loading to raw layers
# Modification History:
# ==================================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         ---------------------------------------------
# 27-NOV-2023  v1.00    Shwetha Bc (sbc)               Initial Development (SDF- 716)
# 01-DEC-2023  v1.01    Shwetha Bc (sbc)               Added file_name_col config variable (SDF-716)
# ==================================================================================================
####################################################################################################

import sys
import os
import inspect
from pyspark.sql.functions import col
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    AuditUtils,
    AlertUtils,
)

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_autoloader_to_raw(
    config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
) -> None:
    """
    Function Name: run_autoloader_to_raw.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_autoloader_to_raw()" + "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        ## call the function in ConfigUtils to read the configurations present
        # in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        ## call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(
            logger, f"{job_name}_{conf['object_name']}"
        )

        ## assign the config values to respective variables ##
        batch_complete_table_name = (
            conf["target_database_name"] + "." + "sdf_batch_load_tracker"
        )
        conf["data_completeness_tbl"] = (
            conf["target_database_name"] + "." + conf["data_completeness_tbl"]
        )
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        file_name_col = conf["file_name_col"]
        custom_starting_timestamp = conf.get("custom_starting_timestamp")
        conf["batch_id"] = str(
            spark.sql(
                f"""SELECT batch_id FROM {batch_complete_table_name} 
                where status in ('RUNNING', 'FAILURE') 
                and project_name = '{product_conf['product_name']}'"""
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        ## count target table data before new load
        try:
            # spark.catalog.refreshTable(f"{conf['target_database_name']}
            # .{conf['target_table_name']}")
            spark.sql(
                f"REFRESH TABLE {conf['target_database_name']}.{conf['target_table_name']}"
            )
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except:
            conf["target_data_count_before_load"] = 0
        # data completeness file format checks
        if conf["input_file_format"] not in ["csv", "json"]:
            logger.error(
                "Error In - run_autoloader_to_raw() --> File format not supported"
            )
            QueryUtils(spark=spark).load_data_completeness_tracker(
                conf["data_product"],
                "False",
                "False",
                "False",
                env,
                conf["data_completeness_tbl"],
            )
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "CRITICAL",
                "Given File format(input_file_format) not supported!",
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)
            sys.exit("Error In - run_autoloader_to_raw() --> File format not supported")
        else:
            ## read all the new/unread files in the external volume into a
            # streaming df via autoloader ##
            incremental_streaming_df = (
                SparkUtils().read_streaming_dataframe_from_external_volume(
                    logger, spark, conf
                )
            )
            logger.info("Dataframe created")
            # data completeness column checks
            if conf["input_file_format"] in ["csv", "json"]:
                try:
                    incremental_streaming_df.select(conf["source_mandatory_cols"])
                    logger.info("data completeness checks passed")
                    QueryUtils(spark=spark).load_data_completeness_tracker(
                        conf["data_product"],
                        "True",
                        "True",
                        "True",
                        env,
                        conf["data_completeness_tbl"],
                    )

                except Exception as err:
                    logger.error(
                        """Error In - run_autoloader_to_raw() --> 
                    mandatory columns not present in source layer"""
                    )
                    QueryUtils(spark=spark).load_data_completeness_tracker(
                        conf["data_product"],
                        "True",
                        "True",
                        "False",
                        env,
                        conf["data_completeness_tbl"],
                    )

                    conf = AlertUtils().generate_alerts_dictionary(
                        logger,
                        conf,
                        "CRITICAL",
                        """Issue with curated layer source mandatory columns:
                    required columns not found on source layer """
                        + str(err),
                    )
                    AlertUtils().load_alerts_table(logger, spark, job_id, conf)
                    sys.exit(
                        """Error In - run_autoloader_to_raw() --> 
                    mandatory columns not present in source layer"""
                    )
            ## rename the columns for raw layer, remove special characters and spaces ##
            master_spark_df = SparkUtils().rename_columns_for_raw(
                logger, incremental_streaming_df
            )
            ## count the incremental dataframe
            conf["source_record_count"] = SparkUtils().get_streaming_df_rows_count(
                logger, spark, master_spark_df, conf, bf_context
            )

        ## extract file_name substring from file_path column ##
        master_spark_df = SparkUtils().extract_file_name_from_file_path(
            logger, master_spark_df, file_name_col
        )

        ## based on common_cols and table_cols params, set the select statement ##
        df_cols = None
        if conf.get("common_cols") and conf.get("table_cols"):
            df_cols = conf.get("common_cols") + [file_name_col] + conf.get("table_cols")
        elif conf.get("common_cols") and not conf.get("table_cols"):
            df_cols = conf.get("common_cols") + [file_name_col]
        elif not conf.get("common_cols") and conf.get("table_cols"):
            df_cols = conf.get("table_cols") + [file_name_col]

        ## based on select statement, get only the required columns ##
        if df_cols:
            master_spark_df = master_spark_df.select(*df_cols)
            logger.info("Column names have been filtered based on config")
        # column_mismatch = SparkUtils.check_schema_mismatch_stream(
        # spark, logger,master_spark_df, target_complete_table_name,
        # schema_mismatch_check= True if conf.get('schema_check')=='true' else False)
        # if column_mismatch:
        #     logger.error(f"Error In - run_autoloader_to_raw() --> Column mismatch found")
        #     conf = AlertUtils().generate_alerts_dictionary(logger,
        # conf, 'MEDIUM', 'Issue with checking column mismatch: '+str(master_spark_df))
        #     AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        #     raise SystemError(f'Issue with checking column mismatch:{master_spark_df}')
        # else:
        #     logger.info("Column mismatch not found / Schema mismatch checks not enabled")

        try:
            ## generate the operational attributes using common_utils ##
            master_spark_df = SparkUtils().add_operational_attributes(
                logger,
                spark,
                master_spark_df,
                job_name=job_name,
                run_id=job_id,
                hop_name=conf["target_hop_name"],
            )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "MEDIUM",
                "Issue with adding operational attributes: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)

        ## Casting all the columns to String ##
        master_spark_df = master_spark_df.select(
            [col(each_col).cast("string") for each_col in master_spark_df.columns]
        )

        ## count master dataframe
        conf["target_record_count"] = SparkUtils().get_streaming_df_rows_count(
            logger, spark, master_spark_df, conf, bf_context
        )

        ## writing the dataframe to final raw layer tables ##
        SparkUtils().write_streaming_dataframe_to_delta(
            logger, spark, master_spark_df, target_complete_table_name, conf
        )

        ##change status and get the count of delta table
        status = "SUCCESS"
        # spark.catalog.refreshTable(f"{conf['target_database_name']}.{conf['target_table_name']}")
        spark.sql(
            f"REFRESH TABLE {conf['target_database_name']}.{conf['target_table_name']}"
        )
        conf["target_data_count_after_load"] = spark.sql(
            f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
        ).head()[0]

    except Exception as err:
        logger.error(f"Error In - run_autoloader_to_raw() : {err}")
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        raise SystemError(err)
    finally:
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("*" * 20 + " END: run_autoloader_to_raw()" + "*" * 20)
