# ########################################################################################
# # Module: UTIL_INGEST_INTEGRATED_TO_BCL
# # Purpose: This module is responsible for
# #            reading the data from databricks integrated layer and loading to
# #               snowflake BCL layer
# # Modification History:
# # =================================================================================
# # Date         Version  Created/Modified By               Comments
# # -----------  -------  ----------------------         -------------------------------
# # 09-MAY-2024  v1.00    Prasad Nadiger (pnadig)        Initial Development (SDF- 2040)
# # ====================================================================================
# #######################################################################################

# import sys
# import os
# import inspect

# # from data_common_utilities.src.etl.high_code_patterns import SyncDeltaToSnowflake
# from products.common_utilities.spark.python.src.common_utilities import (
#     SparkUtils,
#     LoggerUtils,
#     ConfigUtils,
#     QueryUtils,
#     AuditUtils,
#     AlertUtils,
# )

# ## adding the current directory of the file to the sys path list ##
# sys.path.append(os.path.abspath(os.getcwd()))


# def run_ingest_integrated_to_bcl(
#     config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
# ) -> None:
#     """
#     Function Name: run_ingest_integrated_to_bcl.\n
#     Params:
#             :param config_path: string\n
#             :param config_name: string\n
#             :param env: string\n
#             :param bf_context: object\n
#             :param root_dir: string\n
#     Returns: None
#     """
#     try:
#         ## call the function in LoggerUtils to configure the logger object ##
#         logger = LoggerUtils().get_logger_object()
#         logger.info("%s START: run_ingest_integrated_to_bcl() %s", "*" * 20, "*" * 20)
#         function_name = inspect.currentframe().f_code.co_name

#         ## call the function in ConfigUtils to read the configurations present
#         # in TOML file and get dictionary of values ##
#         conf = ConfigUtils().read_config_variables(
#             config_path=config_path, config_name=config_name, env=env, logger=logger
#         )
#         product_conf = ConfigUtils().read_config_variables(
#             config_path=root_dir,
#             config_name="product-info.toml",
#             env=env,
#             logger=logger,
#         )
#         job_id = str(
#             bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
#         )
#         # call the function from common utils to get spark session object ##
#         job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
#         spark = SparkUtils().get_spark_session(logger, job_name)

#         ## assign the config values to respective variables ##
#         batch_complete_table_name = (
#             conf["delta_table_database"] + "." + "sdf_batch_load_tracker"
#         )
#         conf["batch_id"] = str(
#             spark.sql(
#                 f"SELECT batch_id FROM {batch_complete_table_name} where \
#                     status in ('RUNNING', 'FAILURE') and env = '{env}'\
#                          and project_name = '{product_conf['product_name']}'"
#             ).head()[0]
#         )
#         status = ""
#         conf["function_name"] = function_name
#         conf["tech_solution_id"] = product_conf["tech_solution_id"]
#         conf["cloudred_gid"] = product_conf["nike-tagguid"]

#         token_username = None
#         token_password = None

#         (
#             token_username,
#             token_password,
#         ) = ConfigUtils().get_username_password_from_dbx_secrets(
#             logger, bf_context, conf["dbx_scope"]
#         )
#         if token_username is None or token_password is None:
#             raise ValueError("Username or Password is None")

#         conf["username"] = token_username
#         conf["password"] = token_password

#         ## count source table data ##
#         try:
#             conf["source_record_count"] = spark.sql(
#                 f"SELECT COUNT(*) FROM {conf['delta_table_database']}.{conf['source']} \
#                     where batch_load_tmst = (select MAX(batch_load_tmst)\
#                          from {conf['delta_table_database']}.{conf['source']})"
#             ).head()[0]
#             conf["target_record_count"] = conf["source_record_count"]
#         except:
#             conf["source_record_count"] = 0
#             conf["target_record_count"] = 0

#         ## count target table data before new load
#         try:
#             target_count_query = (
#                 f"""SELECT TO_VARCHAR(COUNT(*)) as table_count FROM {conf['target']}"""
#             )
#             target_count_df = SparkUtils().run_snowflake_queries_as_spark_df(
#                 logger, spark, conf, target_count_query
#             )
#             conf["target_data_count_before_load"] = target_count_df.head()[0]
#         except:
#             conf["target_data_count_before_load"] = 0

#         conf["source_database_name"] = conf["delta_table_database"]
#         conf["source_table_name"] = conf["source"]
#         conf["target_database_name"] = (
#             conf.get("sfdatabase") + "." + conf.get("sfschema")
#         )
#         conf["target_table_name"] = conf["target"]

#         class_obj = SyncDeltaToSnowflake(
#             url=conf["sfurl"],
#             sfUser=conf["username"],
#             gid_password=conf["password"],
#             sfDatabase=conf["sfdatabase"],
#             sfSchema=conf["sfschema"],
#             sfRole=conf["sfrole"],
#             sfWarehouse=conf["sfwarehouse"],
#             delta_table_database=conf["delta_table_database"],
#             checkpoint_basepath=conf["checkpoint_basepath"],
#             env=conf["env"],
#             key_columns=conf["key_columns"],
#             source=conf["source"],
#             target=conf["target"],
#             stage=None,
#             rename_delta_columns=False,
#             truncate=True,
#             tz_required=False,
#         )
#         class_obj.run()

#         ## count target table data after new load
#         try:
#             target_count_query = (
#                 f"""SELECT TO_VARCHAR(COUNT(*)) as table_count FROM {conf['target']}"""
#             )
#             target_count_df = SparkUtils().run_snowflake_queries_as_spark_df(
#                 logger, spark, conf, target_count_query
#             )
#             conf["target_data_count_after_load"] = target_count_df.head()[0]
#         except:
#             conf["target_data_count_after_load"] = 0

#         status = "SUCCESS"

#     except Exception as err:
#         logger.error("Error In - run_ingest_integrated_to_bcl() : %s", err)
#         conf["target_record_count"] = 0
#         status = "FAILURE"
#         conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
#         QueryUtils(spark=spark).update_batch_load_tracker(
#             project_name=product_conf["product_name"],
#             env=bf_context.env,
#             batch_tracker_table=batch_complete_table_name,
#             status=status,
#         )
#         AlertUtils().load_alerts_table(logger, spark, job_id, conf)
#         raise SystemError(err) from err
#     finally:
#         # load data in audit table
#         AuditUtils().load_audit_table(
#             logger,
#             spark,
#             job_id,
#             conf,
#             status,
#             source_table_type="delta",
#             target_table_type="snowflake",
#             source_hop=conf["source_hop_name"],
#             target_hop=conf["target_hop_name"],
#         )
#         logger.info("%s END: run_ingest_integrated_to_bcl() %s", "*" * 20, "*" * 20)
