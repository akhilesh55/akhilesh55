import time
import os
import inspect
from datetime import datetime
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
)
import asyncssh


class ConnectionFailureException(Exception):
    """Raised when all attempts to connect and transfer the file fail"""


class PermissionDeniedException(Exception):
    """Raised when the user does not have permission to access the specified directory"""


async def run_sftp_to_s3(
    project_name,
    config_path: str,
    config_name: str,
    env: str,
    bf_context: object,
    root_dir: str,
    timestamp_to_pull_from: str = None,
):
    """
    Transfers files from an SFTP server to an S3 bucket.

    This function connects to a specified SFTP server, retrieves files from a
    specified directory, and uploads them to a specified S3 bucket. It handles
    any necessary authentication and error handling during the transfer process.

    Raises:
        SFTPConnectionError: If there is an issue connecting to the SFTP server.
        S3UploadError: If there is an issue uploading files to the S3 bucket.
    """
    i = 0
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: run_sftp_to_s3() %s", "*" * 20, "*" * 20)
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        for i in range(conf["max_retries"]):
            function_name = inspect.currentframe().f_code.co_name
            job_id = str(
                bf_context.get_parameter(
                    key="brickflow_job_id", debug="987987987987987"
                )
            )
            ## call the function in ConfigUtils to read the configurations present
            #  in TOML file and get dictionary of values ##
            product_conf = ConfigUtils().read_config_variables(
                config_path=root_dir,
                config_name="product-info.toml",
                env=env,
                logger=logger,
            )
            spark = SparkUtils().get_spark_session(
                logger, app_name="my_energy_sftp_to_s3"
            )
            batch_complete_table_name = (
                conf["target_database_name"] + "." + "sdf_batch_load_tracker"
            )
            batch_id_timestamp = str(
                spark.sql(
                    f"SELECT batch_id FROM {batch_complete_table_name} \
                where status in ('RUNNING') and env = '{env}' and project_name = '{project_name}'"
                ).head()[0]
            )
            logger.info("Batch ID: %s", batch_id_timestamp)
            batch_id_timestamp = timestamp_to_pull_from
            logger.info("New Batch ID: %s", batch_id_timestamp)
            dev_volume_path = conf["target_path"]
            ## assign the config values to respective variables ##
            conf["function_name"] = function_name
            conf["tech_solution_id"] = product_conf["tech_solution_id"]
            conf["cloudred_gid"] = product_conf["nike-tagguid"]
            sftp_server = bf_context.dbutils.secrets.get(
                scope=conf["dbx_scope"], key="host_name"
            )
            sftp_user = bf_context.dbutils.secrets.get(
                scope=conf["dbx_scope"], key="user_name"
            )
            sftp_scrt = bf_context.dbutils.secrets.get(
                scope=conf["dbx_scope"], key="password"
            )
            async with asyncssh.connect(
                sftp_server, username=sftp_user, password=sftp_scrt, known_hosts=None
            ) as conn:
                async with conn.start_sftp_client() as sftp:
                    files = await sftp.listdir("/Nike")
                    logger.info("Files in the directory:")
                    logger.info("%s", files)
                    for file in files:
                        file_stat = await sftp.stat("/Nike/" + file)
                        logger.info("File Details:\n")
                        logger.info("Modified Time: %s", str(file_stat.atime))
                        logger.info("File Size: %s", str(file_stat.mtime))
                        logger.info("%s", file_stat)
                        mtime = datetime.fromtimestamp(file_stat.mtime).strftime(
                            "%Y%m%d%H%M%S"
                        )
                        logger.info("mtime: %s", mtime)
                        if ".csv" in file.lower() and mtime >= batch_id_timestamp:
                            logger.info("File Details:\n")
                            logger.info("Modified Time: %s", mtime)
                            logger.info("File Size: %s", str(file_stat.size))
                            logger.info("File Name: %s", file)
                            logger.info("Downloading File...")

                            # Replace spaces in the file name with underscores
                            file_without_spaces = file.replace(" ", "_")

                            # Add the modification time at the end before the extension
                            file_name, file_extension = os.path.splitext(
                                file_without_spaces
                            )
                            # ...
                            new_file_name = f"{file_name}_{mtime}{file_extension}"
                            logger.info("%s", new_file_name)

                            # Replace spaces in the file name with underscores
                            local_file_path = os.path.join(
                                dev_volume_path, new_file_name
                            )
                            logger.info("%s", local_file_path)

                            if not os.path.exists(dev_volume_path):
                                logger.info("Creating directory: %s", dev_volume_path)
                                os.makedirs(dev_volume_path)

                            await sftp.get("/Nike/" + file, local_file_path)
                            # break
                    # If the connection and file transfer was successful, break the loop
                    # return modified time to be used in the end task to update
                    #  the batch_load_tracker table which helps to pulling out latest
                    # records from the source when we run the workflow next time.
                    return mtime

    except asyncssh.Error as e:
        logger.info(
            "Attempt %d of %d failed with error: %s", i + 1, conf["max_retries"], e
        )
        if i < conf["max_retries"] - 1:  # If it's not the last attempt
            wait_time = 2**i  # Exponential backoff
            logger.info("Waiting %d seconds before retrying...", wait_time)
            time.sleep(wait_time)  # Wait before retrying
        else:
            logger.info("All attempts failed. Exiting.")
            raise ConnectionFailureException(
                "All attempts to connect and transfer the file failed"
            ) from e
    except PermissionError as exc:
        raise PermissionDeniedException(
            "The user does not have permission to access\
                                         the specified directory"
        ) from exc
