"""
Module: UTIL_BOX_TO_S3_WITH_ARCHIVE
Purpose: This module is responsible for transferring files from Box to S3 with archiving.

The function `run_box_to_s3` performs the following steps:
1. Configures the logger.
2. Reads configuration variables from TOML files.
3. Authenticates with Box using JWT.
4. Fetches files from Box.
5. Uploads files to S3.
6. Archives the files in Box.
7. Handles errors and generates alerts if necessary.

Modification History:
=================================================================================
Date         Version  Created/Modified By               Comments
-----------  -------  ----------------------         -------------------------------
04-DEC-2023  v1.00    Shwetha Bc (sbc)               Initial Development (SDF- 715)
==================================================================================
"""

import sys
import os
import inspect
from products.common_utilities.spark.python.src.common_utilities import (
    LoggerUtils,
    ConfigUtils,
    BoxToS3Utils,
)
from boxsdk import JWTAuth, Client

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_box_to_s3(
    config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
) -> None:
    """
    Function Name: run_box_to_s3.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_box_to_s3()" + "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        ## call the function in ConfigUtils to read the configurations
        # present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        ## assign the config values to respective variables ##
        conf["timestamp"] = BoxToS3Utils().get_timestamp(logger)
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        (
            client_id,
            client_secret,
            enterprise_id,
            jwt_key_id,
            rsa_private_key_data,
            rsa_private_key_passphrase,
        ) = BoxToS3Utils().get_secrets_from_databricks(
            logger=logger, bf_context=bf_context, scope=conf["dbx_scope"]
        )

        box_params = {
            "client_id": client_id,
            "client_secret": client_secret,
            "enterprise_id": enterprise_id,
            "jwt_key_id": jwt_key_id,
            "rsa_private_key_data": rsa_private_key_data,
            "rsa_private_key_passphrase": rsa_private_key_passphrase,
        }

        ## get box sdk client object ##
        sdk = JWTAuth(**box_params)
        client = Client(sdk)

        ## get list of files to process, copy to s3 and archive to box folder ##
        if conf["archive_flag"].lower().startswith("y") or conf[
            "archive_flag"
        ].lower().startswith("t"):
            for i in range(0, len(conf["src_box_id"])):
                files_dict = BoxToS3Utils().get_files_list(
                    logger, conf, client, conf["src_box_id"][i]
                )
                BoxToS3Utils().parse_files(
                    logger, conf, client, files_dict, conf["archive_box_id"][i]
                )
        else:
            for i in range(0, len(conf["src_box_id"])):
                files_dict = BoxToS3Utils().get_files_list(
                    logger, conf, client, conf["src_box_id"][i]
                )
                BoxToS3Utils().parse_files(logger, conf, client, files_dict)

    except Exception as err:
        logger.error(f"Error In - run_box_to_s3() : {err}")
        raise SystemError(err)
    finally:
        logger.info("*" * 20 + " END: run_box_to_s3()" + "*" * 20)
