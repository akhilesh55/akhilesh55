########################################################################################
# Module: UTIL_API_SOURCE_TO_LANDING
# Purpose: This module is responsible for
#            reading the json data from API source to landing layer
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 22-NOV-2023  v1.00    Shwetha BC(sbc)                 Initial Development (SDF- 587)
# 27-NOV-2023  v1.01    Prasad Nadiger(pnadig)          Code Modularization (SDF- 739)
# ====================================================================================
#######################################################################################

import sys
import json
import os
from datetime import datetime
import concurrent.futures
import inspect

from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    JSONUtils,
    APIUtils,
    AuditUtils,
    AlertUtils,
)
from pyspark.sql.functions import col

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_api_source_to_landing(
    config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
) -> None:
    """
    Function Name: run_api_source_to_landing.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_api_source_to_landing()" + "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        ## call the function in ConfigUtils to read the configurations present in TOML file and
        #  get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)
        batch_complete_table_name = (
            conf["target_database_name"] + "." + "sdf_batch_load_tracker"
        )

        # set start and end dates.
        start_end_date_list = ConfigUtils().set_start_end_date(logger, conf)
        start_date = start_end_date_list[0]
        end_date = start_end_date_list[1]

        ## assign the config values to respective variables ##
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        invoice_api_endpoint = conf["invoice_api_endpoint"].format(
            id=conf["id"], start_date=start_date, end_date=end_date
        )
        date_time = datetime.now()
        token_username = None
        token_password = None
        current_timestamp = date_time.strftime("%Y%m%d%H%M%S")
        load_date = date_time.strftime("%Y-%m-%d")
        conf["batch_id"] = str(
            spark.sql(
                f"""SELECT batch_id FROM {batch_complete_table_name} 
                where status in ('RUNNING', 'FAILURE') and env = '{env}' 
                and project_name = '{product_conf['product_name']}'"""
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except:
            conf["target_data_count_before_load"] = 0

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        response_object = APIUtils().get_token_from_api(
            logger, token_username, token_password, conf
        )

        ## check if response code is in list of 200, 201, 203, 204
        if str(response_object.status_code).startswith("2"):
            logger.info("API Token fetched successfully using requests module.")
            api_token_dict = json.loads(response_object.text)
            api_token = api_token_dict.get("token")

            logger.info("Running the API to get properties data.")
            list_without_id = APIUtils().fetch_api_without_id(
                logger,
                conf["property_api_endpoint"],
                load_date,
                current_timestamp,
                api_token,
                conf,
                job_id,
                spark,
            )
            flattened_json_records = JSONUtils().list_flatten_nested_json(
                logger,
                list_without_id[0]["payload"],
                conf["root_node"],
                conf["children_node"],
            )
            logger.info("Finished getting the properties data.")
            try:
                if flattened_json_records:
                    api_response_with_id_list = []
                    logger.info("Running the API to get invoices data.")
                    for record in flattened_json_records:
                        id = record["id"]
                        with concurrent.futures.ThreadPoolExecutor(
                            max_workers=10
                        ) as executor:
                            future = executor.submit(
                                APIUtils().fetch_api_with_id,
                                logger,
                                invoice_api_endpoint,
                                id,
                                load_date,
                                current_timestamp,
                                api_token,
                                job_id,
                                conf,
                                spark,
                            )
                            record_json = future.result()
                            api_response_with_id_list.append(record_json)
                    logger.info("Finished getting the invoices data.")
                else:
                    logger.info("No Batches to process for invoices")
            except Exception as e:
                exception_message = "message: {0}\nline no:{1}\n".format(
                    str(e), sys.exc_info()[2].tb_lineno
                )
                logger.error(exception_message)
                conf = AlertUtils().generate_alerts_dictionary(
                    logger, conf, "CRITICAL", exception_message
                )
                AlertUtils().load_alerts_table(logger, spark, job_id, conf)
                raise SystemExit(e) from e
            finally:
                logger.info("Creating dataframes from JSON data")
                # create dfs from the api response
                df_without_id = JSONUtils().json_dict_to_spark_df(
                    logger, list_without_id[0], spark
                )
                df_with_id = JSONUtils().array_of_json_to_spark_df(
                    logger, api_response_with_id_list, spark
                )
                try:
                    final_data_df = SparkUtils().union_dataframes(
                        logger, df_without_id, df_with_id
                    )
                    ## drop rows from a dataframe that has all null values in all columns ##
                    final_data_df = final_data_df.dropna(how="all")
                except Exception as e:
                    conf = AlertUtils().generate_alerts_dictionary(
                        logger, conf, "LOW", "Minor error during union: " + str(e)
                    )
                    AlertUtils().load_alerts_table(logger, spark, job_id, conf)
                ## count the incremental dataframe
                conf["source_record_count"] = final_data_df.count()
                logger.info(
                    "Union of dataframes done, inserting them into delta table."
                )
                ## Casting all the columns to String ##
                final_data_df = final_data_df.select(
                    [col(each_col).cast("string") for each_col in final_data_df.columns]
                )
                final_data_df = final_data_df.withColumn("id", col("id").cast("long"))
                # ## writing the dataframe to final raw layer tables ##
                QueryUtils(spark=spark).write_dataframe_to_delta(
                    logger,
                    spark,
                    conf,
                    final_data_df,
                    target_complete_table_name,
                    tech_solution_id=conf["tech_solution_id"],
                    cloudred_gid=conf["cloudred_gid"],
                )
                ## count master dataframe
                conf["target_record_count"] = final_data_df.count()
                status = "SUCCESS"
                conf["target_data_count_after_load"] = spark.sql(
                    f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
                ).head()[0]
        else:
            ## some issue with API token endpoint, so we got different status code ##
            logger.error(
                f"Issue while getting the API token, status code: {response_object.status_code}"
            )

    except Exception as err:
        logger.error(f"Error In - run_api_source_to_landing() : {err}")
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        raise SystemError(err)
    finally:
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("*" * 20 + " END: run_api_source_to_landing()" + "*" * 20)
