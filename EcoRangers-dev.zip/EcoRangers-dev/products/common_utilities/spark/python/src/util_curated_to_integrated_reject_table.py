"""
util_ingest_curated_to_integrated_reject_table.py

This module contains utility functions for DQ rules filter of curated data into the integrated system.
It includes functions for reading data from Snowflake, creating temporary views in Databricks,
running Spark SQL queries, and processing the resulting dataframes.

Functions:
    run_ingest_curated_to_integrated_reject_table: Main function to run the ingestion process.
    read_snowflake_table: Reads a table from Snowflake and returns it as a Spark DataFrame.
    create_temp_view: Creates a temporary view in Databricks from a Spark DataFrame.
    run_spark_sql_query: Runs a Spark SQL query and returns the result as a Spark DataFrame.
"""

###########################################################################################################################
# Module: UTIL_INGEST_CURATED_TO_INTEGRATED_REJECT_TABLE
# Purpose: This module is responsible for
#            reading the data from curated layer for BCV,CALENDAR,TAXOMMONY,LOGEC & NODE TABLES and pass through DQ rules
#            and load the reject data in delta format.
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 10-Jan-2025   v1.00  Aklesh Kumar Sah (aku213)         Initial Development (SDF- 3628)
# ====================================================================================
#############################################################################################################################


import sys, re
import os
import inspect
from pyspark import StorageLevel

# from pyspark.sql.functions import hash, current_timestamp
from datetime import datetime
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
)
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_ingest_curated_to_integrated_reject_table(
    config_path: str,
    config_name: str,
    env: str,
    bf_context: object,
    root_dir: str,
    tables_to_validate: list = None,
) -> None:
    """
    Function Name: run_ingest_curated_to_integrated_reject_table.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """

    try:
        # This function runs the ingestion process from curated to integrated reject table
        logger = LoggerUtils().get_logger_object()
        logger.info(
            "*" * 20
            + " START: run_ingest_curated_to_integrated_reject_table()"
            + "*" * 20
        )
        function_name = inspect.currentframe().f_code.co_name
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        token_username = None
        token_password = None

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password

        ## count target table data before new load
        conf["source_record_count"] = 0
        conf["target_record_count"] = 0

        ### Read the data from Snowflake and after applying the DQ rules, load the data in delta format ####
        try:
            if conf.get("sf_tables_mapping_dict") is not None:
                for global_temp_sf_table_name, complete_table_name in conf[
                    "sf_tables_mapping_dict"
                ].items():
                    read_table_query = f"select * from {complete_table_name}"
                    logger.info(f"Reading snowflake table:{read_table_query}")
                    table_sf_df = SparkUtils().run_snowflake_queries_as_spark_df(
                        logger, spark, conf, read_table_query
                    )

                    ## generate the operational attributes for calculation ##
                    table_source_sf_df = SparkUtils().add_operational_attributes(
                        logger,
                        spark,
                        table_sf_df,
                        job_name=job_name,
                        run_id=job_id,
                        hop_name=conf["target_hop_name"],
                    )
                    logger.info("Start casting meta columns to the snowflake dataframe")
                    table_source_sf_df = (
                        table_source_sf_df.withColumn(
                            "load_dt", table_source_sf_df["load_dt"].cast("string")
                        )
                        .withColumn(
                            "load_month_nbr",
                            table_source_sf_df["load_month_nbr"].cast("string"),
                        )
                        .withColumn(
                            "load_year_nbr",
                            table_source_sf_df["load_year_nbr"].cast("string"),
                        )
                        .withColumn(
                            "created_at_tmst",
                            table_source_sf_df["created_at_tmst"].cast("string"),
                        )
                        .withColumn(
                            "batch_load_tmst",
                            table_source_sf_df["batch_load_tmst"].cast("string"),
                        )
                    )

                    ## count the incremental dataframe
                    conf["source_record_count"] = table_source_sf_df.count()

                    source_sf_complete_table_name = f"{conf['source_database_name']}.{global_temp_sf_table_name}_src"

                    logger.info(
                        f"Start: create source delta table {source_sf_complete_table_name}"
                    )
                    spark.sql(f"drop table if exists {source_sf_complete_table_name}")
                    table_source_sf_df.write.format("delta").mode("overwrite").option(
                        "mergeSchema", conf["merge_schema"]
                    ).saveAsTable(f"{source_sf_complete_table_name}")
                    spark.sql(
                        f"ALTER TABLE {source_sf_complete_table_name} SET OWNER TO `{conf['group_name']}` "
                    )

                    logger.info(
                        f"End: writting source delta table {source_sf_complete_table_name}"
                    )

                    target_sf_complete_table_name = (
                        f"{conf['target_database_name']}.{global_temp_sf_table_name}"
                    )
                    meta_dq_run_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
                    conf["predicate_rej_default"] = (
                        f'meta_dq_run_datetime >= "{meta_dq_run_date}"'
                    )

                    ### Run DQ checks on the snowflake dataframe ###
                    table_target_sf_df = SparkUtils().run_spark_expectations_dq_checks(
                        logger,
                        spark,
                        conf,
                        target_sf_complete_table_name,
                        table_source_sf_df,
                    )
                    ### Run Consolidate DQ checks on the dataframe ###
                    if conf.get("reject_table_name"):
                        error_write_sf_df = SparkUtils().reject_table_load(
                            spark,
                            logger,
                            table_source_sf_df,
                            table_target_sf_df,
                            conf,
                            product_conf["product_name"],
                            source_sf_complete_table_name,
                            target_sf_complete_table_name,
                        )
                        if error_write_sf_df is not False:
                            reject_table_name = (
                                conf["target_database_name"]
                                + "."
                                + conf["reject_table_name"]
                            )
                            conf_rejects = dict(list(conf.items()))
                            conf_rejects["partition_by_cols"] = [
                                "product_name",
                                "error_table_name",
                                "load_year_nbr",
                            ]
                            QueryUtils(spark=spark).write_dataframe_to_delta(
                                logger,
                                spark,
                                conf_rejects,
                                error_write_sf_df,
                                reject_table_name,
                                tech_solution_id=conf["tech_solution_id"],
                                cloudred_gid=conf["cloudred_gid"],
                                do_partition=True,
                            )
                            logger.info("Data written to reject table")
                    else:
                        logger.info(
                            "Reject table name not provided in config file for snowflake, so not processsing for reject table"
                        )
                    logger.info(
                        f"Start: create target delta table {target_sf_complete_table_name}"
                    )
                    spark.sql(f"drop table if exists {target_sf_complete_table_name}")
                    table_target_sf_df.write.format("delta").mode("overwrite").option(
                        "mergeSchema", conf["merge_schema"]
                    ).saveAsTable(f"{target_sf_complete_table_name}")
                    spark.sql(
                        f"ALTER TABLE {target_sf_complete_table_name} SET OWNER TO `{conf['group_name']}` "
                    )
                    logger.info(
                        "Delta table created for snowflake object %s",
                        target_sf_complete_table_name,
                    )
        except Exception as err:
            logger.error(
                "Error occured: Issue while creating table for Snowflake object %s", err
            )
            raise SystemError(err)
        ### Read the data from Databricks and after applying the DQ rules, load the data in delta format ####
        try:
            if conf.get("delta_tables_mapping_dict") is not None:
                if tables_to_validate is not None:
                    conf["delta_tables_mapping_dict"] = {
                        target_dq_table_name: source_table_name
                        for target_dq_table_name, source_table_name in conf[
                            "delta_tables_mapping_dict"
                        ].items()
                        if target_dq_table_name in tables_to_validate
                    }
                for global_temp_dbx_table_name, complete_table_name in conf[
                    "delta_tables_mapping_dict"
                ].items():
                    predicate = "1=1"
                    logger.info(
                        f"Processing table: {global_temp_dbx_table_name} with complete table name: {complete_table_name}"
                    )
                    if isinstance(complete_table_name, dict):
                        predicate = complete_table_name.get("predicate", "1=1")
                        complete_table_name = complete_table_name.get("tbl")

                    # if global_temp_dbx_table_name == "enablon_5_impact_areas_table":
                    #     read_table_query = f"select * from {complete_table_name} where entity_impact_area_nm = 'CARBON'"
                    # else:
                    #     read_table_query = f"select * from {complete_table_name} where {predicate}"
                    read_table_query = (
                        f"select * from {complete_table_name} where {predicate}"
                    )
                    logger.info(f"Reading DBX delta table:{read_table_query}")

                    table_dbx_df = SparkUtils().run_spark_sql_query_as_spark_df(
                        logger, spark, read_table_query
                    )
                    ## drop the unnecessary columns from the table for comparison ##
                    table_dbx_df = table_dbx_df.drop(
                        *[
                            "user_nm",
                            "load_dt",
                            "load_month_nbr",
                            "load_year_nbr",
                            "created_at_tmst",
                            "batch_load_tmst",
                            "job_nm",
                            "job_run_id",
                        ]
                    )
                    source_dbx_complete_table_name = f"{conf.get('source_dbx_name') or conf['source_database_name']}.{global_temp_dbx_table_name}_src"
                    try:
                        source_dbx_complete_df = spark.read.table(
                            source_dbx_complete_table_name
                        )
                        ## drop the unnecessary columns from the table for comparison ##
                        source_dbx_complete_df = source_dbx_complete_df.drop(
                            *[
                                "user_nm",
                                "load_dt",
                                "load_month_nbr",
                                "load_year_nbr",
                                "created_at_tmst",
                                "batch_load_tmst",
                                "job_nm",
                                "job_run_id",
                            ]
                        )
                        logger.info(
                            f"******comparing data b/w {complete_table_name} and {source_dbx_complete_table_name}**************"
                        )
                        diff_df = table_dbx_df.subtract(source_dbx_complete_df)

                        logger.info(f"Diff record count: {diff_df.count()}")

                        logger.info(
                            "Finding the diff between the source and already available src table data"
                        )
                        # find the diff b/etween the source and already avble table data
                        if diff_df.count() == 0:
                            logger.info(
                                f"No new data found in the source table {complete_table_name}"
                            )
                            logger.info(
                                f"Skipping the table {global_temp_dbx_table_name} as no new data found"
                            )
                            continue
                    except Exception as err:
                        logger.error(
                            f"Error occured: {global_temp_dbx_table_name}_src Table while reading source table %s. *_src table may not exist.",
                            err,
                        )
                    conf["global_temp_dbx_table_name"] = global_temp_dbx_table_name
                    ## generate the operational attributes for calculation ##
                    table_source_dbx_df = SparkUtils().add_operational_attributes(
                        logger,
                        spark,
                        table_dbx_df,
                        job_name=job_name,
                        run_id=job_id,
                        hop_name=conf["target_hop_name"],
                    )
                    logger.info("Start casting meta columns to the dbx dataframe")
                    table_source_dbx_df = (
                        table_source_dbx_df.withColumn(
                            "load_dt", table_source_dbx_df["load_dt"].cast("string")
                        )
                        .withColumn(
                            "load_month_nbr",
                            table_source_dbx_df["load_month_nbr"].cast("string"),
                        )
                        .withColumn(
                            "load_year_nbr",
                            table_source_dbx_df["load_year_nbr"].cast("string"),
                        )
                        .withColumn(
                            "created_at_tmst",
                            table_source_dbx_df["created_at_tmst"].cast("string"),
                        )
                        .withColumn(
                            "batch_load_tmst",
                            table_source_dbx_df["batch_load_tmst"].cast("string"),
                        )
                    )

                    ## count the incremental dataframe
                    conf["source_record_count"] = table_source_dbx_df.count()
                    logger.info(f"Source record count: {table_source_dbx_df.count()}")

                    logger.info(
                        f"Start: create source delta table {source_dbx_complete_table_name}"
                    )
                    spark.sql(f"drop table if exists {source_dbx_complete_table_name}")
                    table_source_dbx_df.write.format("delta").mode("overwrite").option(
                        "mergeSchema", conf["merge_schema"]
                    ).saveAsTable(f"{source_dbx_complete_table_name}")
                    spark.sql(
                        f"ALTER TABLE {source_dbx_complete_table_name} SET OWNER TO `{conf['group_name']}` "
                    )
                    logger.info(
                        f"End: writting source delta table {source_dbx_complete_table_name}"
                    )

                    target_dbx_complete_table_name = (
                        f"{conf['target_database_name']}.{global_temp_dbx_table_name}"
                    )
                    meta_dq_run_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
                    conf["predicate_rej_default"] = (
                        f'meta_dq_run_datetime >= "{meta_dq_run_date}"'
                    )

                    ### Run DQ checks on the dbx dataframe ###
                    table_target_dbx_df = SparkUtils().run_spark_expectations_dq_checks(
                        logger,
                        spark,
                        conf,
                        target_dbx_complete_table_name,
                        table_source_dbx_df,
                    )

                    logger.info(f"Target record count: {table_target_dbx_df.count()}")

                    # table_target_dbx_df.persist(
                    #     storageLevel=StorageLevel(True, True, False, True, 1)
                    # )
                    # table_target_dbx_df = table_target_dbx_df.repartition(1000)
                    ### Run Consolidate DQ checks on the dataframe ###
                    if conf.get("reject_table_name"):
                        error_write_dbx_df = SparkUtils().reject_table_load(
                            spark,
                            logger,
                            table_source_dbx_df,
                            table_target_dbx_df,
                            conf,
                            product_conf["product_name"],
                            source_dbx_complete_table_name,
                            target_dbx_complete_table_name,
                        )
                        reject_table_name = None
                        if (
                            re.sub(
                                r"([^.]+)(\.)([^.]+)(\.)([^.]+)$",
                                r"\2\4",
                                conf.get("reject_table_name"),
                            )
                            == ".."
                        ):
                            reject_table_name = conf.get("reject_table_name")

                        if error_write_dbx_df is not False:
                            reject_table_name = reject_table_name or (
                                conf["target_database_name"]
                                + "."
                                + conf["reject_table_name"]
                            )
                            conf_rejects = dict(list(conf.items()))
                            conf_rejects["partition_by_cols"] = [
                                "product_name",
                                "error_table_name",
                                "load_year_nbr",
                            ]
                            logger.info(
                                f"Writing data to reject table{error_write_dbx_df.count()}"
                            )

                            QueryUtils(spark=spark).write_dataframe_to_delta(
                                logger,
                                spark,
                                conf_rejects,
                                error_write_dbx_df,
                                reject_table_name,
                                tech_solution_id=conf["tech_solution_id"],
                                cloudred_gid=conf["cloudred_gid"],
                                do_partition=True,
                            )
                            logger.info(
                                f"Data written to reject table : {target_dbx_complete_table_name}"
                            )
                    else:
                        logger.info(
                            "Reject table name not provided in config file for dbx, so not processsing for reject table"
                        )

                    ### Write the data in dbx delta external table ###
                    logger.info(
                        f"Start: create target delta table load {target_dbx_complete_table_name}"
                    )
                    # below code used to check the column length for debugging

                    # Repartition the DataFrame to reduce skew
                    table_target_dbx_df = table_target_dbx_df.repartition(1000)

                    # Persist the DataFrame to avoid recomputation
                    # table_target_dbx_df.persist(StorageLevel.MEMORY_AND_DISK)
                    spark.sql(f"drop table if exists {target_dbx_complete_table_name}")
                    table_target_dbx_df.write.format("delta").mode("overwrite").option(
                        "mergeSchema", conf["merge_schema"]
                    ).saveAsTable(f"{target_dbx_complete_table_name}")
                    spark.sql(
                        f"ALTER TABLE {target_dbx_complete_table_name} SET OWNER TO `{conf['group_name']}` "
                    )
                    logger.info(
                        "Delta table created for databricks object %s",
                        target_dbx_complete_table_name,
                    )
        except Exception as err:
            logger.error(
                "Error occured: Issue while creating table for DBX object %s", err
            )
            raise SystemError(err)

    except Exception as err:
        logger.error(
            "Error In - run_ingest_curated_to_integrated_reject_table() : %s", err
        )
        # Handle the exception here
        raise SystemError(err)
    finally:
        logger.info(
            "*" * 20
            + " END: run_ingest_curated_to_integrated_reject_table()"
            + "*" * 20
        )
