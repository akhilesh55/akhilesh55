"""
Module: UTIL_AIRTABLE_SOURCE_TO_LANDING
Purpose: This module is responsible for reading the data
from Airtable source and loading it to the landing layer.

The function `run_source_to_landing_airtable` performs the following steps:
1. Configures the logger.
2. Reads configuration variables from TOML files.
3. Initializes a Spark session.
4. Fetches data from Airtable using provided credentials.
5. Processes the response and converts it to Spark DataFrames.
6. Writes the DataFrames to a Delta table.
7. Updates the batch load tracker and audit tables.
8. Handles errors and generates alerts if necessary.

Modification History:
=================================================================================
Date         Version  Created/Modified By               Comments
-----------  -------  ----------------------         -------------------------------
25-JUN-2024  v1.00    Bryan Almeida                  Initial Development (SDF- 2178)
==================================================================================
"""

from datetime import datetime
import inspect
import urllib.parse
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    JSONUtils,
    APIUtils,
    AuditUtils,
    AlertUtils,
)
from pyspark.sql.functions import col


def run_source_to_landing_airtable(
    config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
) -> None:
    """
    Function Name: run_source_to_landing_airtable.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """

    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_source_to_landing_airtable()" + "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        print(config_path, config_name)
        ## call the function in ConfigUtils to read the configurations
        # present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        batch_complete_table_name = (
            conf["target_database_name"] + "." + "sdf_batch_load_tracker"
        )
        token_username = None
        token_password = None

        ## assign the config values to respective variables ##
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        req_method = conf["request_method"]
        bearer_auth = conf["bearer_auth"]
        date_time = datetime.now()
        current_timestamp = date_time.strftime("%Y%m%d%H%M%S")
        load_date = date_time.strftime("%Y-%m-%d")
        conf["batch_id"] = str(
            spark.sql(
                f"""SELECT batch_id FROM {batch_complete_table_name} where status 
                in ('RUNNING', 'FAILURE') and env = '{env}' 
                and project_name = '{product_conf['product_name']}'"""
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        # set start and end dates.
        # start_end_date_list = ConfigUtils().set_start_end_date(logger, conf)
        # start_date = start_end_date_list[0]
        # end_date = start_end_date_list[1]
        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {target_complete_table_name}"
            ).head()[0]
        except Exception as e:
            logger.error(e)
            conf["target_data_count_before_load"] = 0
        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        api_token = bf_context.dbutils.secrets.get(
            scope=conf["scope"], key=conf["airtable_secret"]
        )
        # dbutils.secrets.get("airtable_token",conf['airtable_secret'])
        api_url_actual = conf["api_endpoint"]
        final_data_df = None

        ## check the list of tables that needs to be retrieved from airtable workspace
        for table_name, table_dict in conf["table_dict"].items():
            logger.info(
                f"{'*' * 20} Started processing airtable: {table_name} {'*' * 20}"
            )
            condition_check = False
            if isinstance(table_dict, dict):
                # table_id = table_arr[0]
                # url_condition = table_arr[1]
                # url_sql_statement = table_arr[2]
                condition_check = True
                table_id = table_dict["table_id"]
            else:
                table_id = table_dict
            url = conf["api_endpoint"] = conf["api_endpoint"].format(
                base_id=conf["base_id"], airtable_id=table_id
            )
            conf["object_name"] = table_name
            # check if any additional condition needs to be added to the url for its
            # first api request
            if condition_check is True:
                sql_condition_result = None
                logger.info("Adding additional condition to the url")
                try:
                    logger.info(
                        f"{table_dict['url_sql_statement']}".format(
                            **table_dict
                        ).format(target_database_name=conf["target_database_name"])
                    )
                    sql_condition_result = spark.sql(
                        f"{table_dict['url_sql_statement']}".format(
                            **table_dict
                        ).format(target_database_name=conf["target_database_name"])
                    ).head()[0]
                except Exception as e:
                    logger.error(
                        f"Error in getting sql condition result since table may not exist : {e}"
                    )
                if sql_condition_result is not None:
                    filter_formula = table_dict["url_condition"].format(
                        sql_condition_result=sql_condition_result
                    )
                    logger.info(
                        "*" * 20 + f" Filter Formula : {filter_formula} " + "*" * 20
                    )
                    encoded_filter_formula = urllib.parse.quote(filter_formula)
                    url = (
                        conf["api_endpoint"]
                        + "?filterByFormula="
                        + encoded_filter_formula
                    )

            list_without_id = APIUtils().fetch_api_without_id(
                logger,
                url,
                load_date,
                current_timestamp,
                api_token,
                conf,
                job_id,
                spark,
                req_method=req_method,
                bearer_auth=bearer_auth,
                offset="True",
            )

            if not final_data_df:
                final_data_df = JSONUtils().json_dict_to_spark_df(
                    logger, list_without_id[0], spark
                )
            else:
                if list_without_id:
                    final_data_df = final_data_df.unionAll(
                        JSONUtils().json_dict_to_spark_df(
                            logger, list_without_id[0], spark
                        )
                    )
                else:
                    logger.error(
                        f"No data found in the list_without_id:{list_without_id}"
                    )
            conf["api_endpoint"] = api_url_actual
            logger.info(
                "*" * 20 + f" Ended processing airtable : {table_name} " + "*" * 20
            )

        conf["source_record_count"] = final_data_df.count()

        ## Casting all the columns to String ##
        final_data_df = final_data_df.select(
            [col(each_col).cast("string") for each_col in final_data_df.columns]
        )

        final_data_df = final_data_df.withColumn("id", col("id").cast("long"))
        ### writing the dataframe to final raw layer tables ##
        QueryUtils(spark=spark).write_dataframe_to_delta(
            logger,
            spark,
            conf,
            final_data_df,
            target_complete_table_name,
            tech_solution_id=conf["tech_solution_id"],
            cloudred_gid=conf["cloudred_gid"],
        )

        ## count master dataframe
        conf["target_record_count"] = final_data_df.count()
        status = "SUCCESS"
        conf["target_data_count_after_load"] = spark.sql(
            f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
        ).head()[0]

    except Exception as err:
        logger.error(f"Error In - run_source_to_landing_airtable() : {err}")
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        raise SystemError(err) from err
    finally:
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info(f"{'*' * 20} END: run_source_to_landing_airtable() {'*' * 20}")
