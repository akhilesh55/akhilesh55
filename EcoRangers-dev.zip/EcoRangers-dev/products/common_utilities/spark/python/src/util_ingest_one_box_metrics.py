########################################################################################
# Module: UTIL_INGEST_ONE_BOX_METRICS
# Purpose: This module is responsible for
#            reading the data from one box SF tables and
#             APLA node delta tables and loading the  query result to
#               delta table
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 07-FEB-2024    v1.00    Shwetha Bc (sbc)              Initial Development (SDF- 1281)
# ====================================================================================
#######################################################################################

import sys
import os
import inspect
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    AuditUtils,
    AlertUtils,
)

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_ingest_one_box_metrics(
    config_path: str,
    config_name: str,
    sql_file_path: str,
    sql_file_name: str,
    env: str,
    bf_context: object,
    root_dir: str,
) -> None:
    """
    Function Name: run_ingest_bcl_to_integrated.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param sql_file_path: string\n
            :param sql_file_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: run_ingest_bcl_to_integrated() %s", "*" * 20, "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        ## call the function in ConfigUtils to read the configurations present in
        # TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        ## assign the config values to respective variables ##
        batch_complete_table_name = (
            conf["audit_database_name"] + "." + "sdf_batch_load_tracker"
        )
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        conf["batch_id"] = str(
            spark.sql(
                f"SELECT batch_id FROM {batch_complete_table_name} where \
                    status in ('RUNNING', 'FAILURE') and env = '{env}' \
                        and project_name = '{product_conf['product_name']}'"
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        token_username = None
        token_password = None

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password

        ## assign the config values to respective variables ##
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        # predicates = conf.get("predicates")
        # custom_starting_timestamp = conf.get("custom_starting_timestamp")
        temp_view_name = conf.get("temp_view_name")

        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except Exception as err:
            logger.error("Error In - run_ingest_one_box_metrics() : %s", err)
            conf["target_data_count_before_load"] = 0

        ## Returns file_contents from sql file ##
        sql_file_contents = SparkUtils().get_sql_file_content(
            logger, sql_file_path, sql_file_name
        )

        ## format_sql_query_with_variables ##
        # conf['delta_tables_mapping_dict']['target_database_name'] = conf['target_database_name']
        sql_query = SparkUtils().format_sql_query_with_variables(
            logger, sql_file_contents, kwargs=conf["delta_tables_mapping_dict"]
        )

        ## count target table data before new load
        conf["source_record_count"] = 0
        conf["target_record_count"] = 0

        ## iterate over SF tables_mapping_dict and create temp views in databricks ##
        for temp_view_name, complete_table_name in conf[
            "sf_tables_mapping_dict"
        ].items():
            read_table_query = f"select * from {complete_table_name}"
            logger.info("Reading snowflake table: %s", read_table_query)
            table_df = SparkUtils().run_snowflake_queries_as_spark_df(
                logger, spark, conf, read_table_query
            )
            table_df.createOrReplaceTempView(temp_view_name)
            logger.info("temp view created %s", temp_view_name)

        ## run spark sql query on databricks and store the result in a dataframe ##
        query_result_df = SparkUtils().run_spark_sql_query_as_spark_df(
            logger, spark, sql_query
        )
        logger.info("%sQuery Result Dataframe Created%s", "*" * 20, "*" * 20)

        try:
            ## generate the operational attributes using common_utils ##
            master_spark_df = SparkUtils().add_operational_attributes(
                logger,
                spark,
                query_result_df,
                job_name=job_name,
                run_id=job_id,
                hop_name=conf["target_hop_name"],
            )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "MEDIUM",
                "Issue with adding operational attributes: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)

        ## count master dataframe ##
        conf["target_record_count"] = master_spark_df.count()

        ## writing the dataframe to curated layer table ##
        QueryUtils(spark=spark).write_dataframe_to_delta(
            logger,
            spark,
            conf,
            master_spark_df,
            target_complete_table_name,
            tech_solution_id=conf["tech_solution_id"],
            cloudred_gid=conf["cloudred_gid"],
        )

        status = "SUCCESS"
        conf["target_data_count_after_load"] = spark.sql(
            f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
        ).head()[0]

    except Exception as err:
        logger.error("Error In - run_ingest_one_box_metrics() : %s", err)
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        raise SystemError(err) from err
    finally:
        ## call the function in AuditUtils to log the metadata ##
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="snowflake",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("%s END: run_ingest_one_box_metrics() %s", "*" * 20, "*" * 20)
