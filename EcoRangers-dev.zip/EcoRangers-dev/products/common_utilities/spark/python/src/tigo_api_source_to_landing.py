########################################################################################
# Module: UTIL_TIGO_API_SOURCE_TO_LANDING
# Purpose: This module is responsible for
#            reading the json data from API source to landing layer
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 08-JAN-2024  v1.00    Bryan Almeida                  Initial Development (SDF- 587)
# ====================================================================================
#######################################################################################

"""
This module contains the function `run_api_source_to_landing` which is responsible for
fetching data from an API and loading it into a target table in a Spark environment.

The function performs the following steps:
1. Configures the logger.
2. Reads configuration variables from TOML files.
3. Initializes a Spark session.
4. Fetches an API token using provided credentials.
5. Calls the API to get data and processes the response.
6. Converts the JSON response to Spark DataFrames.
7. Writes the DataFrames to a Delta table.
8. Updates the batch load tracker and audit tables.
9. Handles errors and generates alerts if necessary.

Imports:
    - sys
    - json
    - os
    - datetime
    - inspect
    - reduce
    - requests
    - pyspark.sql.functions
    - pyspark.sql.types
    - products.common_utilities.spark.python.src.common_utilities

Functions:
    - run_api_source_to_landing(config_path: str, config_name: str, env: str,
    bf_context: object, root_dir: str) -> None
"""

import json
import csv
from datetime import datetime
import inspect
from functools import reduce  # to be added
from pyspark.sql.functions import col
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    JSONUtils,
    APIUtils,
    AuditUtils,
    AlertUtils,
)
from pyspark.sql import DataFrame


def run_api_source_to_landing(
    config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
) -> None:
    """
    Function Name: run_api_source_to_landing.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """

    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_api_source_to_landing()" + "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        ## call the function in ConfigUtils to read the configurations
        # present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        batch_complete_table_name = (
            conf["target_database_name"] + "." + "sdf_batch_load_tracker"
        )

        token_username = None
        token_password = None

        ## assign the config values to respective variables ##
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        req_method = conf["request_method"]
        bearer_auth = conf["bearer_auth"]
        date_time = datetime.now()
        current_timestamp = date_time.strftime("%Y%m%d%H%M%S")
        load_date = date_time.strftime("%Y-%m-%d")
        conf["batch_id"] = str(
            spark.sql(
                f"""SELECT batch_id FROM {batch_complete_table_name} where 
        status in ('RUNNING', 'FAILURE') and env = '{env}' 
        and project_name = '{product_conf['product_name']}'"""
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        # set start and end dates.
        start_end_date_list = ConfigUtils().set_start_end_date(logger, conf)
        start_date = start_end_date_list[0]
        end_date = start_end_date_list[1]

        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {target_complete_table_name}"
            ).head()[0]
        except:
            conf["target_data_count_before_load"] = 0

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        response_object = APIUtils().get_token_from_api(
            logger, token_username, token_password, conf, req_method, bearer_auth
        )

        ## check if response code is in list of 200, 201, 203, 204
        if str(response_object.status_code).startswith("2"):
            logger.info("API Token fetched successfully using requests module.")
            api_token = response_object.json().get("user").get("auth")

            data = {}
            system_id = (
                APIUtils()
                .api_call_basic_auth(
                    logger,
                    conf["system_id_api_endpoint"],
                    api_token,
                    data,
                    req_method,
                    True,
                )
                .json()
                .get("systems")[0]
                .get("system_id")
            )
            print(f"system_id : {system_id}")

            logger.info("Running the API to get properties data.")

            # looping through 4 apis defined in config
            api_endpoints = conf["api_endpoints"]
            df_list = []
            for api_key in list(api_endpoints.keys()):
                api_url = api_endpoints[api_key].format(system_id=system_id)
                conf["object_name"] = api_key

                list_without_id = APIUtils().fetch_api_without_id(
                    logger,
                    api_url,
                    load_date,
                    current_timestamp,
                    api_token,
                    conf,
                    job_id,
                    spark,
                    req_method=req_method,
                    bearer_auth=bearer_auth,
                )
                if api_key == "objects":
                    object_id_list_of_json = json.loads(list_without_id[0]["payload"])[
                        "objects"
                    ]

                df_list.append(
                    JSONUtils().json_dict_to_spark_df(logger, list_without_id[0], spark)
                )

            # Creating a list of object ids. Extracting id info of every dictionary
            # in the list -> object_id_list_of_json
            object_id_list = []
            for element in object_id_list_of_json:
                object_id_list.append(str(element["id"]))

            # Getting Api data of object_ids by looping over the list of object_ids
            # & converting it to JSON to insert into landing table
            aggregate_api = {}
            aggr_rows = []
            no_of_apis_per_fetch = 150
            conf["object_name"] = "aggregate"
            for object_id_index in range(0, len(object_id_list), no_of_apis_per_fetch):
                object_id_str = ",".join(
                    object_id_list[
                        object_id_index : object_id_index + no_of_apis_per_fetch
                    ]
                )
                list_without_id = APIUtils().fetch_api_without_id(
                    logger,
                    conf["aggregate_api_endpoint"].format(
                        system_id=system_id,
                        start_date=start_date,
                        end_date=end_date,
                        object_ids=object_id_str,
                    ),
                    load_date,
                    current_timestamp,
                    api_token,
                    conf,
                    job_id,
                    spark,
                    req_method=req_method,
                    bearer_auth=bearer_auth,
                )

                payload_data = csv.DictReader(
                    list_without_id[0]["payload"].splitlines()
                )
                # Convert the reader into a list of dictionaries, filtering out the unwanted records
                aggr_rows.append([row for row in payload_data])

            aggregate_api["aggregate"] = aggr_rows
            aggregate_api_json = json.dumps(aggregate_api)
            list_without_id[0]["payload"] = aggregate_api_json

            logger.info("Finished getting the properties data.")

            df_list.append(
                JSONUtils().json_dict_to_spark_df(logger, list_without_id[0], spark)
            )
            final_data_df = reduce(DataFrame.unionAll, df_list)

            conf["source_record_count"] = final_data_df.count()
            logger.info("Union of dataframes done, inserting them into delta table.")
            print("Union of dataframes done, inserting them into delta table.")

            ## Casting all the columns to String ##
            final_data_df = final_data_df.select(
                [col(each_col).cast("string") for each_col in final_data_df.columns]
            )
            final_data_df = final_data_df.withColumn("id", col("id").cast("long"))

            ### writing the dataframe to final raw layer tables ##
            QueryUtils(spark=spark).write_dataframe_to_delta(
                logger,
                spark,
                conf,
                final_data_df,
                target_complete_table_name,
                tech_solution_id=conf["tech_solution_id"],
                cloudred_gid=conf["cloudred_gid"],
            )

            ## count master dataframe
            conf["target_record_count"] = final_data_df.count()
            status = "SUCCESS"
            conf["target_data_count_after_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]

        else:
            ## some issue with API token endpoint, so we got different status code ##
            logger.error(
                "Issue while getting the API token, status code: %s",
                response_object.status_code,
            )

    except Exception as err:
        logger.error(f"Error In - run_api_source_to_landing() : {err}")
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        raise SystemError(err) from err
    finally:
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("%s END: run_api_source_to_landing() %s", "*" * 20, "*" * 20)
