########################################################################################
# Module: UTIL_API_RAW_TO_CLEANSED
# Purpose: This module is responsible for
#            reading the incremental data from raw layer and loading to
#               cleansed layers
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 1-DEC-2023  v1.00    MohanaSilpa Palla(MPall6)         Initial Development (SDF- 631)
# 19-DEC-2023  v1.01   Aklesh Kumar Sah(AKU213)          Added AuditUtils (SDF- 838)
# ====================================================================================
#######################################################################################

import sys
import inspect
import os
from datetime import datetime
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    AuditUtils,
    AlertUtils,
)
from pyspark import StorageLevel

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_ingest_raw_to_cleansed(
    config_path: str,
    config_name: str,
    sql_file_path: str,
    sql_file_name: str,
    env: str,
    bf_context: object,
    root_dir: str,
) -> None:
    """
    Function Name: run_api_raw_to_cleansed.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param sql_file_path: string\n
            :param sql_file_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: run_api_landing_to_raw() %s", "*" * 20, "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        ## call the function in ConfigUtils to read the configurations present in
        # TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        ## assign the config values to respective variables ##
        source_complete_table_name = (
            conf["source_database_name"] + "." + conf["source_table_name"]
        )
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        predicates = conf.get("predicates")
        custom_starting_timestamp = conf.get("custom_starting_timestamp")
        # temp_view_name = conf.get("temp_view_name")
        batch_complete_table_name = (
            conf["source_database_name"] + "." + "sdf_batch_load_tracker"
        )

        conf["batch_id"] = str(
            spark.sql(
                f"SELECT batch_id FROM {batch_complete_table_name} where \
                    status in ('RUNNING', 'FAILURE') and env = '{env}' \
                        and project_name = '{product_conf['product_name']}'"
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        latest_timestamp = datetime.strptime(conf["batch_id"], "%Y%m%d%H%M%S")

        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except:
            conf["target_data_count_before_load"] = 0

        try:
            ## based on predicates and custom starting timestamp, reading the
            # CDC incremental dataset from source ##
            if predicates and custom_starting_timestamp:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                    predicates=predicates,
                    custom_starting_timestamp=custom_starting_timestamp,
                )
            elif predicates and not custom_starting_timestamp:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                    predicates=predicates,
                )
            elif custom_starting_timestamp and not predicates:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                    custom_starting_timestamp=custom_starting_timestamp,
                )
            else:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "LOW",
                "Minor error during reading of the CDC incremental dataset: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)

        ## count the incremental dataframe
        conf["source_record_count"] = incremental_df.count()

        if conf["source_record_count"] == 0:
            raise Exception(
                "No incremental data fetched from earlier hop,\
                 raising exception to abort further execution of the script."
            )

        ## copy the conf dictionary to another dictionary to use in audit table ##
        copy_dict = dict(conf)

        ## getting the records before loading data into error tables ##
        try:
            copy_dict["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM \
                {copy_dict['target_database_name']}.{copy_dict['target_table_name']}_error"
            ).head()[0]
        except:
            copy_dict["target_data_count_before_load"] = 0

        ## load audit records for error table ##
        try:
            # check for spark dq checks on incremental df
            copy_dict["target_table_name"] = copy_dict["target_table_name"] + "_error"
            # Generate predicate condition since meta_dq_run_date should be prior
            # to current timestamp
            meta_dq_run_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            conf["predicate_rej_default"] = (
                f'meta_dq_run_datetime >= "{meta_dq_run_date}"'
            )
            cleansed_df = SparkUtils().run_spark_expectations_dq_checks(
                logger, spark, conf, target_complete_table_name, incremental_df
            )
            spark.sql(f"drop table if exists {target_complete_table_name}_temp ")
            cleansed_df.write.format("delta").mode("overwrite").saveAsTable(
                target_complete_table_name + "_temp"
            )
            cleansed_df = spark.read.table(target_complete_table_name + "_temp")
            # cleansed_df.persist(StorageLevel.DISK_ONLY)
            ##change status and get the count of delta table
            status = "SUCCESS"
            copy_dict["cleansed_count"] = cleansed_df.count()
            copy_dict["target_record_count"] = (
                copy_dict["source_record_count"] - copy_dict["cleansed_count"]
            )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "MEDIUM",
                "Issue with running spark expectations on incremental df: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)
            status = "FAILURE"
            copy_dict["target_record_count"] = 0
            raise SystemError(e) from e
        finally:
            copy_dict["target_hop_name"] = "reject"
            # load data in audit table
            AuditUtils().load_audit_table(
                logger,
                spark,
                job_id,
                copy_dict,
                status,
                source_table_type="delta",
                target_table_type="delta",
                source_hop=copy_dict["source_hop_name"],
                target_hop=copy_dict["target_hop_name"],
            )

        if conf.get("reject_table_name"):
            error_write_df = SparkUtils().reject_table_load(
                spark,
                logger,
                incremental_df,
                cleansed_df,
                conf,
                product_conf["product_name"],
                source_complete_table_name,
                target_complete_table_name,
            )
            if error_write_df is not False:
                reject_table_name = (
                    conf["target_database_name"] + "." + conf["reject_table_name"]
                )
                conf_rejects = dict(list(conf.items()))
                conf_rejects["partition_by_cols"] = [
                    "product_name",
                    "error_table_name",
                    "load_year_nbr",
                ]
                QueryUtils(spark=spark).write_dataframe_to_delta(
                    logger,
                    spark,
                    conf_rejects,
                    error_write_df,
                    reject_table_name,
                    tech_solution_id=conf["tech_solution_id"],
                    cloudred_gid=conf["cloudred_gid"],
                    do_partition=True,
                )
        else:
            logger.info(
                "Reject table name not provided in config file, so not processsing for reject table"
            )

        ## create the spark dataframe  ##
        master_spark_df = SparkUtils().read_spark_sql_file(
            logger, spark, sql_file_path, sql_file_name, cleansed_df, conf
        )
        master_spark_df.persist(StorageLevel.DISK_ONLY)
        master_spark_df = master_spark_df.dropDuplicates()
        logger.info("Dataframe created")

        ## typecast void type columns to string to avoid unexpected errors ##
        expressions = [
            f"CAST({each_col} AS STRING) AS {each_col}" if dtype == "void" else each_col
            for each_col, dtype in master_spark_df.dtypes
        ]

        master_spark_df = master_spark_df.selectExpr(*expressions)

        try:
            ## generate the operational attributes using common_utils ##
            master_spark_df = SparkUtils().add_operational_attributes(
                logger,
                spark,
                master_spark_df,
                job_name=job_name,
                run_id=job_id,
                hop_name=conf["target_hop_name"],
            )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "MEDIUM",
                "Issue with adding operational attributes: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)

        ## count master dataframe
        conf["target_record_count"] = master_spark_df.count()

        # ## writing the dataframe to final raw layer tables ##
        QueryUtils(spark=spark).write_dataframe_to_delta(
            logger,
            spark,
            conf,
            master_spark_df,
            target_complete_table_name,
            tech_solution_id=conf["tech_solution_id"],
            cloudred_gid=conf["cloudred_gid"],
        )
        master_spark_df.unpersist()

        ##change status and get the count of delta table
        status = "SUCCESS"
        conf["target_data_count_after_load"] = spark.sql(
            f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
        ).head()[0]

    except Exception as err:
        logger.info(f"Error In - run_api_raw_to_cleansed() : {err}")
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        if (
            conf["source_record_count"] == 0
            and conf.get("skip_on_no_incremental_records")
            and conf["skip_on_no_incremental_records"] == True
        ):
            logger.info(
                "No incremental data fetched from earlier hop, exiting the script without error."
            )
        else:
            conf = AlertUtils().generate_alerts_dictionary(
                logger, conf, "CRITICAL", "No incremental data to process."
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)
            raise SystemError(err) from err
    finally:
        spark.sql(f"drop table if exists {target_complete_table_name}_temp ")
        # load data in audit table
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("%s END: run_api_raw_to_cleansed() %s", "*" * 20, "*" * 20)
