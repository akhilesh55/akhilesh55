########################################################################################
# Module: UTIL_MULTI_SITE_INFO_TO_TABLE
# Purpose: This module is responsible for
#            reading duplicate/new data from curated view and load data alert table
#            delta format.
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 19-SEP-2024    v1.00  Aklesh Kumar Sah (aku213)       Initial Development (SDF- 2790)
# ====================================================================================
#######################################################################################

import sys
import os
import inspect
from pyspark.sql.functions import col
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
)

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def get_site_details(
    config_path: str,
    config_name: str,
    sql_file_path: str,
    sql_file_name: str,
    env: str,
    bf_context: object,
    root_dir: str,
) -> None:
    """
    Function Name: get_site_details.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param sql_file_path: string\n
            :param sql_file_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: get_site_details() %s", "*" * 20, "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        ## call the function in ConfigUtils to read the configurations present in
        #  TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        ## assign the config values to respective variables ##

        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        site_predicates_name = conf.get("site_predicates_name")
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        site_data_list = conf.get("site_data_list")

        # Returns file_contents from sql file ##
        sql_file_contents = SparkUtils().get_sql_file_content(
            logger, sql_file_path, sql_file_name
        )

        # Formats the sql query with variables ##
        sql_query = SparkUtils().format_sql_query_with_variables(
            logger, sql_file_contents, kwargs=conf.get("delta_tables_mapping_dict")
        )

        # Run the sql query and get the result as dataframe ##
        query_result_df = SparkUtils().run_spark_sql_query_as_spark_df(
            logger, spark, sql_query
        )

        # Check DF if any site data available to get unfiltered
        if site_predicates_name and site_data_list:
            query_result_df = query_result_df.filter(
                ~col(site_predicates_name).isin(site_data_list)
            )
        # logger.info("%sQuery Result Dataframe Created%s", "*" * 20, "*" * 20)

        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except Exception as err:
            logger.error("Error in counting target table data: %s", err)
            conf["target_data_count_before_load"] = 0

        if query_result_df.count() == 0 and conf["target_data_count_before_load"] == 0:
            query_result_df = SparkUtils().add_operational_attributes(
                logger,
                spark,
                query_result_df,
                job_name=job_name,
                run_id=job_id,
                hop_name=conf["target_hop_name"],
            )

            ## take only the columns/schema from df to create the
            # table with schema evolution if the table not exists ##
            master_spark_zero_rows = query_result_df.limit(0)
            ## creating the table if not exists, and also handling schema
            # evolution with zero rows dataframe ##

            QueryUtils(spark=spark).write_dataframe_to_delta(
                logger,
                spark,
                conf,
                master_spark_zero_rows,
                target_complete_table_name,
                tech_solution_id=conf["tech_solution_id"],
                cloudred_gid=conf["cloudred_gid"],
            )

            logger.info(
                "*" * 20
                + " No Duplicate Available In Current and Previous Load - Created table schema for succesfully"
                + "*" * 20
            )

        # Return the dataframe if any duplicates available and insert into table##
        elif (
            query_result_df.count() == 0
            and conf.get("delete_filter")
            and conf["target_data_count_before_load"] != 0
        ):
            spark.sql(
                f"delete from {target_complete_table_name} where {conf['delete_filter']} "
            )
            logger.info(
                "*" * 20
                + f" No Duplicate Available In Current Load - Table truncated for {conf['delete_filter']} "
                + "*" * 20
            )

        else:
            if query_result_df.count() == 0:
                logger.info(
                    "*" * 20 + f" No Duplicates Available In Current Load " + "*" * 20
                )
            query_result_df = SparkUtils().add_operational_attributes(
                logger,
                spark,
                query_result_df,
                job_name=job_name,
                run_id=job_id,
                hop_name=conf["target_hop_name"],
            )

            QueryUtils(spark=spark).write_dataframe_to_delta(
                logger,
                spark,
                conf,
                query_result_df,
                target_complete_table_name,
                tech_solution_id=conf["tech_solution_id"],
                cloudred_gid=conf["cloudred_gid"],
            )

    except Exception as err:
        logger.error("Error In - get_site_details() : %s", err)
        raise SystemError(err) from err
    finally:
        logger.info("%s END: get_site_details() %s", "*" * 20, "*" * 20)
