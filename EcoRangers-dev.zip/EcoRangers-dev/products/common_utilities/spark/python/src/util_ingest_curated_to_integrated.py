"""
util_ingest_curated_to_integrated.py

This module contains utility functions for ingesting curated data into the integrated system.
It includes functions for reading data from Snowflake, creating temporary views in Databricks,
running Spark SQL queries, and processing the resulting dataframes.

Functions:
    run_ingest_curated_to_integrated: Main function to run the ingestion process.
    read_snowflake_table: Reads a table from Snowflake and returns it as a Spark DataFrame.
    create_temp_view: Creates a temporary view in Databricks from a Spark DataFrame.
    run_spark_sql_query: Runs a Spark SQL query and returns the result as a Spark DataFrame.
    add_uuid_column: Adds a UUID column to a Spark DataFrame.
    drop_unwanted_columns: Drops unwanted columns from a Spark DataFrame.
    add_operational_attributes: Adds operational attributes to a Spark DataFrame.
"""

########################################################################################
# Module: UTIL_INGEST_CURATED_TO_INTEGRATED
# Purpose: This module is responsible for
#            reading the data from curated layer and load data into integrated
#            layer in delta format.
# Modification History:
# =================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         -------------------------------
# 09-MAY-2024    v1.00  Prasad Nadiger (pnadig)         Initial Development (SDF- 2040)
# ====================================================================================
#######################################################################################

import sys
import os
import inspect
from pyspark.sql.functions import hash, current_timestamp
from pyspark.sql import DataFrame
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    AuditUtils,
    AlertUtils,
)
from products.common_utilities.spark.python.src.low_code_patterns import (
    SCD2DeltaTableWriter,
)


## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_ingest_curated_to_integrated(
    config_path: str,
    config_name: str,
    sql_file_path: str,
    sql_file_name: str,
    env: str,
    bf_context: object,
    root_dir: str,
    set_operation_attributes: bool = True,
    create_table_if_not_exists: bool = True,
    extrapltion_sql_file_name: str = None,
    project_name: str = None,
) -> None:
    """
    Function Name: run_ingest_curated_to_integrated.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param sql_file_path: string\n
            :param sql_file_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_ingest_curated_to_integrated()" + "*" * 20)
        function_name = inspect.currentframe().f_code.co_name
        ## call the function in ConfigUtils to read the configurations present in TOML
        # file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )
        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        ## assign the config values to respective variables ##
        batch_complete_table_name = (
            conf["target_database_name"] + "." + "sdf_batch_load_tracker"
        )
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        PROJECT_NAME = project_name or product_conf.get("product_name")

        conf["batch_id"] = str(
            spark.sql(
                f"SELECT batch_id FROM {batch_complete_table_name} where \
                status in ('RUNNING', 'FAILURE') and env = '{env}' \
                and project_name = '{PROJECT_NAME}'"
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        token_username = None
        token_password = None

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password

        ## assign the config values to respective variables ##
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        # predicates = conf.get("predicates")
        # custom_starting_timestamp = conf.get("custom_starting_timestamp")
        temp_view_name = conf.get("temp_view_name")

        ## count target table data before new load
        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except Exception as err:
            logger.error("Error in counting target table data: %s", err)
            conf["target_data_count_before_load"] = 0

        ## Returns file_contents from sql file ##
        sql_file_contents = SparkUtils().get_sql_file_content(
            logger, sql_file_path, sql_file_name
        )

        ## format_sql_query_with_variables ##
        # conf['delta_tables_mapping_dict']['target_database_name'] = conf['target_database_name']
        sql_query = SparkUtils().format_sql_query_with_variables(
            logger, sql_file_contents, kwargs=conf.get("delta_tables_mapping_dict")
        )

        ## count target table data before new load
        conf["source_record_count"] = 0
        conf["target_record_count"] = 0

        ## iterate over SF tables_mapping_dict and create temp views in databricks ##
        if conf.get("sf_tables_mapping_dict") is not None:
            for temp_view_name, complete_table_name in conf[
                "sf_tables_mapping_dict"
            ].items():
                read_table_query = f"select * from {complete_table_name}"
                logger.info(f"Reading snowflake table:{read_table_query}")
                table_df = SparkUtils().run_snowflake_queries_as_spark_df(
                    logger, spark, conf, read_table_query
                )
                table_df.createOrReplaceTempView(temp_view_name)
                logger.info("temp view created %s", temp_view_name)

        ## run spark sql query on databricks and store the result in a dataframe ##
        query_result_df = SparkUtils().run_spark_sql_query_as_spark_df(
            logger, spark, sql_query
        )
        logger.info("%sQuery Result Dataframe Created%s", "*" * 20, "*" * 20)

        ## add the UUID for the dataframe fetched ##
        if conf.get("uuid_col") is not None:
            query_result_df = SparkUtils().calculate_uuid_from_pk_cols(
                logger, query_result_df, conf
            )

        ## drop the unwanted columns that were generated as part of UUID logic ##
        if conf.get("drop_after_uuid") is not None:
            query_result_df = query_result_df.drop(
                *conf.get("drop_after_uuid")
            ).dropDuplicates()

        if set_operation_attributes:
            try:
                ## generate the operational attributes using common_utils ##
                master_spark_df = SparkUtils().add_operational_attributes(
                    logger,
                    spark,
                    query_result_df,
                    job_name=job_name,
                    run_id=job_id,
                    hop_name=conf["target_hop_name"],
                )

                ## adding this logic below to ensure hash_col and updated_at_tmst are
                # added as new cols in integrated layer table ##
                master_spark_df = master_spark_df.withColumn(
                    "hash_col", hash(master_spark_df["*"])
                )
                master_spark_df = master_spark_df.withColumn(
                    "updated_at_tmst", current_timestamp()
                )

            except Exception as e:
                conf = AlertUtils().generate_alerts_dictionary(
                    logger,
                    conf,
                    "MEDIUM",
                    "Issue with adding operational attributes: " + str(e),
                )
                AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        else:
            ## if set_operation_attributes is False, then just copy the dataframe ##
            master_spark_df = query_result_df

        ## count master dataframe ##
        conf["target_record_count"] = master_spark_df.count()

        ## typecast void type columns to string to avoid unexpected errors ##
        expressions = [
            f"CAST({each_col} AS STRING) AS {each_col}" if dtype == "void" else each_col
            for each_col, dtype in master_spark_df.dtypes
        ]

        master_spark_df = master_spark_df.selectExpr(*expressions)

        if create_table_if_not_exists:
            ## take only the columns/schema from df to create the
            # table with schema evolution if the table not exists ##
            master_spark_zero_rows = master_spark_df.limit(0)

            ## creating the table if not exists, and also handling schema
            # evolution with zero rows dataframe ##
            QueryUtils(spark=spark).write_dataframe_to_delta(
                logger,
                spark,
                conf,
                master_spark_zero_rows,
                target_complete_table_name,
                tech_solution_id=conf["tech_solution_id"],
                cloudred_gid=conf["cloudred_gid"],
            )

        ## convert the string version of NULL, NAN to proper nulls back
        master_spark_df = master_spark_df.selectExpr(
            *[
                f"CASE WHEN {col_name} IN ('NULL', 'Null', 'null', 'None', 'NaN', 'nan', 'NAN') OR {col_name} IS NULL THEN NULL ELSE {col_name} END AS {col_name}"
                for col_name in master_spark_df.columns
            ]
        )

        ## convert all the columns to lowercase to avoid issues with case sensitivity
        master_spark_df = master_spark_df.select(
            *[col.lower() for col in master_spark_df.columns]
        )

        if conf.get("scd2_write") and conf.get("scd2_write") is True:
            logger.info("Start : SCD2 Delta Table Writer")
            # master_spark_df.display()
            scd_obj = SCD2DeltaTableWriter(
                source=master_spark_df,
                keys=conf["merge_key_cols"],
                target_table=target_complete_table_name,
                include_columns=conf.get("scd2_params", {}).get("include_cols", []),
                exclude_columns=conf.get("scd2_params", {}).get("exclude_cols", []),
                target_is_current_col_name=conf.get("scd2_params", {}).get(
                    "is_current_col", "is_current"
                ),
                target_start_col_name=conf.get("scd2_params", {}).get(
                    "start_dt_col", "start_date"
                ),
                target_end_col_name=conf.get("scd2_params", {}).get(
                    "end_dt_col", "end_date"
                ),
                ins_ignore_cols=conf.get("scd2_params", {}).get("ins_ignore_cols", []),
                updt_cols_existing_rec=conf.get("scd2_params", {}).get(
                    "updt_cols_existing_rec", []
                ),
                spark=spark,
                logger=logger,
            )
            scd_obj.execute()
            logger.info("End : SCD2 Delta Table Writer")

        else:
            # run the merge statement ##
            SparkUtils().merge_dataframe_using_spark_sql(
                logger, spark, master_spark_df, conf, target_complete_table_name
            )

        ## run the merge statement ##
        # SparkUtils().merge_dataframe_using_spark_sql(
        #    logger, spark, master_spark_df, conf, target_complete_table_name
        # )

        status = "SUCCESS"
        conf["target_data_count_after_load"] = spark.sql(
            f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
        ).head()[0]
        if conf.get("actual_over_extrapolation_ind_alert", False):
            atul_ovr_extptn_alert_complete_tbl_nm = (
                conf["target_database_name"]
                + "."
                + conf["alert_actual_ovr_extrapolation_table_name"]
            )
            final_df = SparkUtils().trigger_actual_ovr_extrapolation(
                logger,
                spark,
                sql_file_path,
                atul_ovr_extptn_alert_complete_tbl_nm,
                extrapltion_sql_file_name,
                sql_file_contents,
                master_spark_df,
                conf,
            )
            if final_df:
                QueryUtils(spark=spark).write_dataframe_to_delta(
                    logger,
                    spark,
                    conf,
                    final_df,
                    atul_ovr_extptn_alert_complete_tbl_nm,
                    tech_solution_id=conf["tech_solution_id"],
                    cloudred_gid=conf["cloudred_gid"],
                    do_partition=False,
                )

        # Logic to generate alerts if there is any new/updated location related info different from the existing data
        if conf.get("trigger_alerts_location_updates_sdf") is True and (
            conf["target_table_name"]
            == "ELECTRICITY_USAGE_LOCATION_AND_CONSUMPTION_INTEGRATED"
            or conf["target_table_name"]
            == "FUEL_USAGE_LOCATION_AND_CONSUMPTION_INTEGRATED"
        ):
            ## check if the site+detail table is present before checking the location updates ##
            query = f"SHOW TABLES IN {conf['target_database_name']}"
            result = spark.sql(query).where(
                f"tableName ILIKE '{conf['target_table_name']}'"
            )
            if result.count() != 0:
                conf_alerts = conf.copy()
                conf_alerts["partition_by_cols"] = conf[
                    "alert_location_table_name_partition_cols"
                ]
                alert_df = AuditUtils().trigger_alerts_location_updates(
                    spark,
                    logger,
                    master_spark_df,
                    conf_alerts,
                )
                if not isinstance(alert_df, str):
                    QueryUtils(spark=spark).write_dataframe_to_delta(
                        logger,
                        spark,
                        conf_alerts,
                        alert_df,
                        conf["alert_database_name"]
                        + "."
                        + conf["alert_location_table_name"],
                        tech_solution_id=conf["tech_solution_id"],
                        cloudred_gid=conf["cloudred_gid"],
                    )
                else:
                    logger.info(
                        "***** No new/updated location related info found *****"
                    )

    except Exception as err:
        logger.error("Error In - run_ingest_curated_to_integrated() : %s", err)
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        raise SystemError(err) from err
    finally:
        ## call the function in AuditUtils to log the metadata ##
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("*" * 20 + " END: run_ingest_curated_to_integrated()" + "*" * 20)
