#################################################################################################################
# Module: COMMON_UTILITIES
# Purpose: This module contains the common functions used across all products in SDF
# Modification History:
# ===============================================================================================================
# Date         Version  Created/Modified By               Comments
# -----------  -------  ----------------------         ----------------------------------------------------------
# 24-NOV-2023  v1.00    Prasad Nadiger(Pnadig)          Initial Development (SDF- 739)
# 29-NOV-2023  v1.01    Prasad Nadiger(Pnadig)          added logger & try catch (SDF-739)
# 01-DEC-2023  v1.02    Prasad Nadiger(pnadig)          removed * from sparksql functions (SDF-739)
# 01-DEC-2023  v1.03    Shwetha Bc(sbc)                 Added file_name_col config variable (SDF-716)
# 04-DEC-2023  v1.04    Shwetha Bc(sbc)                 Added new class BoxToS3Utils (SDF-715)
# 13-DEC-2023  v1.05    Shwetha Bc(sbc)                 Added new class AlertUtils (SDF-839)
# 15-DEC-2023  v1.06    Prasad Nadiger (Pnadig)         Added new class AuditUtils (SDF-838)
# 05-JAN-2024  v1.07    Prasad Nadiger (Pnadig)         Added new functions for AlertUtils (SDF-962)
# 31-JAN-2024  v1.08    Prasad Nadiger (Pnadig)         Added Batch ID tracker function (SDF-962)
# 07-FEB-2024  v1.09    Shwetha Bc(sbc)                 Added function to run sql query in dbx (SDF- 1281)
# 09-MAY-2024  v1.10    Prasad Nadiger (pnadig)         Added function to calculate UUID in spark (SDF- 2040)
# 10-June-2024 v1.11    Aklesh Sah (aku213)             Added function to do optimisation on delta tables in QueryUtils (SDF- 2148)
# ================================================================================================================
##################################################################################################################
# dummy commit to check artifactory

import sys
import os
import uuid
import logging
import io
import configparser
import fnmatch
import smtplib
import json
from datetime import datetime
import re
import inspect
from email import encoders
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from dateutil.parser import parse
import requests
from prettytable import PrettyTable
import pandas as pd
from pyspark.sql import DataFrame
from cerberus.client import CerberusClient
from spark_expectations.core.expectations import (
    SparkExpectations,
    WrappedDataFrameWriter,
)
from spark_expectations.config.user_config import Constants as user_config
from dateutil.relativedelta import relativedelta
from pyspark.sql import Window
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    array_contains,
    col,
    desc,
    lit,
    when,
    month,
    year,
    current_timestamp,
    current_date,
    reverse,
    split,
    max as max_,
    md5,
    concat_ws,
    regexp_replace,
    hash,
    explode,
    collect_list,
    expr,
    to_json,
    struct,
    count,
    round,
    row_number,
    sum,
    to_timestamp,
    from_unixtime,
    map_keys,
    concat,
    dense_rank,
)
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    LongType,
    ArrayType,
    MapType,
)


class SparkUtils:
    """
    ClassName: SparkUtils.\n
    Purpose: This class contains the methods for spark related objects.\n
    """

    def __init__(self): ...

    def get_spark_session(self, logger: object, app_name: str) -> object:
        """
        Function Name: get_spark_session.\n
        Params:
        :param logger: object
        :param app_name: string
        Returns: spark session object
        """
        try:
            logger.info("*" * 20 + " START: get_spark_session" + "*" * 20)
            ## Create the spark session object using app_name ##
            spark = (
                SparkSession.builder.appName(app_name).enableHiveSupport().getOrCreate()
            )
            return spark
        except Exception as err:
            raise (err)
        finally:
            logger.info("*" * 20 + " END: get_spark_session" + "*" * 20)

    def run_snowflake_queries_as_spark_df(
        self: object, logger: object, spark: object, snowflake_config: dict, query: str
    ) -> object:
        """
        Function Name: run_snowflake_queries.\n
        Params:
        :param logger: object
        :param spark: object
        :param snowflake_config: dict
        :param query: string
        Returns: spark dataframe object

        """
        try:
            logger.info("*" * 20 + " START: run_snowflake_queries" + "*" * 20)
            ## get the snowflake credentials from config ##
            sf_user = snowflake_config["username"]
            sf_password = snowflake_config["password"]
            sf_url = snowflake_config["sfurl"]
            sf_database = snowflake_config["sfdatabase"]
            sf_schema = snowflake_config["sfschema"]
            sf_warehouse = snowflake_config["sfwarehouse"]
            sf_role = snowflake_config["sfrole"]
            sf_query = query
            logger.info(f"Snowflake query to be executed: {sf_query}")
            ## create the spark dataframe using the snowflake credentials ##
            df = (
                spark.read.format("snowflake")
                .option("sfUrl", sf_url)
                .option("sfUser", sf_user)
                .option("sfPassword", sf_password)
                .option("sfdatabase", sf_database)
                .option("sfschema", sf_schema)
                .option("sfwarehouse", sf_warehouse)
                .option("sfrole", sf_role)
                .option("query", sf_query)
                .option("authenticator", "https://nike.okta.com")
                .option("tracing", "all")
                .load()
            )
            return df
        except Exception as err:
            logger.error(f"Issue while running the snowflake query: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: run_snowflake_queries" + "*" * 20)

    def run_spark_sql_query_as_spark_df(
        self: object, logger: object, spark: object, query: str
    ) -> object:
        """
        Function Name: run_spark_sql_query_as_spark_df.\n
        Params:
        :param logger: object
        :param spark: object
        :param query: string
        Returns: spark dataframe object
        """
        try:
            logger.info("*" * 20 + " START: run_spark_sql_query_as_spark_df" + "*" * 20)
            ## create the spark dataframe using the snowflake credentials ##
            df = spark.sql(query)
            return df
        except Exception as err:
            logger.error(f"Issue while running the sql query: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: run_spark_sql_query_as_spark_df" + "*" * 20)

    def get_username(self, logger: object, spark_obj: object) -> str:
        """
        Function Name: get_user_name.\n
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        Returns: user_name: string
        """
        try:
            logger.info("*" * 20 + " START: get_username" + "*" * 20)
            user_name = spark_obj.sql("SELECT CURRENT_USER()").head()[0]
            return user_name
        except Exception as err:
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: get_username" + "*" * 20)

    def read_streaming_dataframe_from_external_volume(
        self, logger: object, spark: object, conf: object
    ) -> object:
        """
        Function Name: read_streaming_dataframe_from_external_volume.\n
        Params:
        :param logger: object\n
        :param spark: object\n
        :param conf: dict\n
        Returns: incremental autoloaded data
        """
        try:
            logger.info(
                "*" * 20
                + " START: read_streaming_dataframe_from_external_volume"
                + "*" * 20
            )
            streaming_df = (
                spark.readStream.format("cloudFiles")
                .option("cloudFiles.format", conf["input_file_format"])
                .option("cloudFiles.schemaLocation", conf["checkpoint_path"])
                .option("escape", '"')
                .option(
                    "multiLine",
                    True if str(conf.get("multiline", "false")) == "true" else False,
                )
                .option("charset", conf.get("encoding", "UTF-8"))
                .load(conf["src_volume_path"])
                .withColumn(conf["file_name_col"], expr("_metadata.file_path"))
            )  # adds a new column capturing the file path
            ## if predicates are present in config, then apply them ##
            if (
                "predicates" in conf.keys()
                and len(conf["predicates"]) > 0
                and conf["predicates"]
            ):
                streaming_df = streaming_df.filter(conf["predicates"])
            logger.info("Completed reading dataframe to delta table.")

            if conf["input_file_format"] == "json":
                # Added the condition to filter the records based on the umd operation action
                if conf.get("table_type") == "umd":
                    streaming_df = (
                        streaming_df.where(
                            (col("OPERATION_ACTION") != "XDELETE")
                            & (col("OPERATION_ACTION") != "XOVERWRITE")
                            & (col("OPERATION_ACTION") != "DELETE")
                        )
                        .drop("OPERATION_ACTION", "partition", "_rescued_data")
                        .dropDuplicates()
                    )

                    # Renamed the custom columns to standard columns
                    streaming_df = streaming_df.withColumnRenamed(
                        "OPERATION_TIMESTAMP", "effectivePayloadTimestamp"
                    )
                    streaming_df = streaming_df.withColumnRenamed(
                        "OPERATION_USER", "updatedBy"
                    )
                    streaming_df = streaming_df.withColumn(
                        "effectivePayloadTimestamp",
                        to_timestamp(
                            from_unixtime(
                                col("effectivePayloadTimestamp") / 1000,
                                "yyyy-MM-dd HH:mm:ss.SSS",
                            )
                        ),
                    )

                else:
                    streaming_df = streaming_df.filter(
                        f"{conf['file_name_col']} LIKE '%{conf['file_nm_pattern']}%'"
                    )
                    streaming_df = streaming_df.drop("_rescued_data").withColumnRenamed(
                        "_id", "job_scan_id"
                    )
            else:
                streaming_df = streaming_df.drop("_rescued_data")

            return streaming_df

        except Exception as err:
            logger.error(f"Issue while reading spark dataframe to delta table: {err}")
            raise SystemError(err) from err
        finally:
            logger.info(
                "*" * 20
                + " END: read_streaming_dataframe_from_external_volume"
                + "*" * 20
            )

    def get_streaming_df_rows_count(
        self,
        logger: object,
        spark_obj: object,
        streaming_df: object,
        conf: dict,
        bf_context: object,
    ) -> int:
        """
        Function Name: get_streaming_df_rows_count.\n
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param streaming_df: Streaming Dataframe\n
        :param conf: dict\n
        :param bf_context: object\n
        Returns: streaming_df_rows_count: int
        """
        streaming_df_rows_count = 0
        try:
            logger.info("*" * 20 + " START: get_streaming_df_rows_count" + "*" * 20)
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            temp_table_name = f"{conf['target_database_name']}.{conf['object_name']}_df_count_{timestamp}"
            temp_checkpoint_location = os.path.join(
                conf["checkpoint_path"], "temp/count_df/_chkp"
            )
            ## writing the streaming dataframe to memory as a temp table to get the count ##
            query = (
                streaming_df.writeStream.option(
                    "checkpointLocation", temp_checkpoint_location
                )
                .trigger(once=True)
                .toTable(tableName=temp_table_name, outputMode="append")
            )
            ## wait for the query to complete ##
            query.awaitTermination()
            ## getting the count from the temp table ##
            streaming_df_rows_count = spark_obj.sql(
                f"SELECT COUNT(*) FROM {temp_table_name}"
            ).head()[0]
            # spark_obj.catalog.refreshTable(temp_table_name)
            spark_obj.sql(f"REFRESH TABLE {temp_table_name}")
        except Exception as err:
            logger.error(f"Issue while getting streaming dataframe rows count: {err}")
            raise SystemError(err) from err
        finally:
            ## dropping the temp table to release memory of SparkSession##
            spark_obj.sql(f"DROP TABLE IF EXISTS {temp_table_name}")
            bf_context.dbutils.fs.rm(temp_checkpoint_location, True)
            logger.info("*" * 20 + " END: get_streaming_df_rows_count" + "*" * 20)
            return streaming_df_rows_count

    def merge_dataframe_using_spark_sql(
        self,
        logger: object,
        spark_obj: object,
        master_df: object,
        conf: dict,
        target_complete_table: str,
    ) -> None:
        """
        Function Name: merge_dataframe_using_spark_sql.\n
        Params:
        :param logger: object\n
        :param master_df: object\n
        :param conf: dict\n
        :param target_complete_table: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: merge_dataframe_using_spark_sql" + "*" * 20)
            ## Generate the merge conditions for the MERGE statement ##
            (
                on_condition,
                update_condition,
                insert_condition,
                insert_values,
                columns_without_tmst,
            ) = self.generate_merge_conditions(logger, master_df, conf)
            ## columns required for hashing only by leaving audit columns behind ##
            hashing_only_cols = [
                col
                for col in columns_without_tmst
                if col
                not in (
                    "user_nm",
                    "load_dt",
                    "load_month_nbr",
                    "load_year_nbr",
                    "job_nm",
                    "job_run_id",
                    "hash_col",
                )
            ]
            ## convert all the columns to lowercase to avoid issues with case sensitivity
            master_df = master_df.select(*[col.lower() for col in master_df.columns])

            ## add the hash column to the source and target dfs for comparision ##
            master_df = master_df.withColumn("hash_col", hash(*hashing_only_cols))
            ## register master dataframe as the temp view for merge operation ##
            master_df.createOrReplaceTempView("source")
            ## Generate the MERGE statement ##
            merge_query = f"""
            MERGE INTO {target_complete_table} as target
            USING source
            ON {on_condition}
            WHEN MATCHED THEN
                UPDATE SET {update_condition},
                created_at_tmst = target.created_at_tmst,
                batch_load_tmst = current_timestamp(),
                updated_at_tmst =   CASE 
                                        WHEN target.hash_col <> source.hash_col THEN current_timestamp() 
                                        ELSE target.updated_at_tmst 
                                    END
            WHEN NOT MATCHED THEN
                INSERT ({insert_condition}, batch_load_tmst, created_at_tmst, updated_at_tmst)
                VALUES ({insert_values}, current_timestamp(), current_timestamp(), current_timestamp())
            """
            ## Execute the MERGE statement ##
            self.execute_spark_sql(spark_obj, merge_query)
            logger.info("Completed merging the dataframe using Spark SQL.")

            ## convert all columns to lower case for existing columns ##
            existing_cols = [
                f.name for f in spark_obj.table(target_complete_table).schema.fields
            ]
            for c in existing_cols:
                if c != c.lower():
                    try:
                        spark_obj.sql(
                            f"ALTER TABLE {target_complete_table} RENAME COLUMN `{c}` TO `{c.lower()}`"
                        )
                        logger.info(
                            f"Renamed column {c} to {c.lower()} in {target_complete_table}"
                        )
                    except Exception as err:
                        logger.warning(f"Could not rename column {c}: {err}")

        except Exception as err:
            logger.error(f"Issue while merging the dataframe using Spark SQL: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: merge_dataframe_using_spark_sql" + "*" * 20)

    def generate_merge_conditions(
        self, logger: object, master_df: object, conf: dict
    ) -> object:
        """
        Function Name: generate_merge_conditions.\n
        Params:
        :param logger: object\n
        :param master_df: object\n
        :param conf: dict\n
        Returns: merge_conditions: string
        """
        try:
            logger.info("*" * 20 + " START: generate_merge_conditions" + "*" * 20)
            # Generate the ON condition for the MERGE statement
            on_condition = " AND ".join(
                [f"target.{col} = source.{col}" for col in conf["merge_key_cols"]]
            )
            ## dynamic merge statements for all columns except batch_load_tmst ##
            columns_without_tmst = [
                col
                for col in master_df.columns
                if col not in ("batch_load_tmst", "created_at_tmst", "updated_at_tmst")
            ]
            # Generate the UPDATE condition for the MERGE statement
            update_condition = ", ".join(
                [f"{col} = source.{col}" for col in columns_without_tmst]
            )
            # Generate the INSERT condition for the MERGE statement
            insert_condition = ", ".join(columns_without_tmst)
            insert_values = ", ".join([f"source.{col}" for col in columns_without_tmst])
            return (
                on_condition,
                update_condition,
                insert_condition,
                insert_values,
                columns_without_tmst,
            )

        except Exception as err:
            logger.error(f"Issue while generating merge conditions: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: generate_merge_conditions" + "*" * 20)

    def write_streaming_dataframe_to_delta(
        self,
        logger: object,
        spark: object,
        streaming_df: object,
        table_name: str,
        conf: dict,
    ) -> None:
        """
        Function Name: write_streaming_dataframe_to_delta.\n
        Params:
        :param logger: object\n
        :param spark: object\n
        :param streaming_df: Streaming Dataframe\n
        :param table_name: string\n
        :param conf: dict\n
        Returns: None
        """
        try:
            logger.info(
                "*" * 20 + " START: write_streaming_dataframe_to_delta" + "*" * 20
            )

            if conf["input_file_format"] == "json":
                if (
                    "load_year_nbr" not in streaming_df.columns
                    and "load_month_nbr" not in streaming_df.columns
                ):
                    streaming_df = (
                        streaming_df.withColumn("load_dt", current_date())
                        .withColumn("load_month_nbr", month(col("load_dt")))
                        .withColumn("load_year_nbr", year(col("load_dt")))
                    )
                    streaming_df = streaming_df.drop("load_dt")

            ## check for schema evolution mode and write the streaming dataframe to delta table ##
            if conf.get("schema_evolution_mode") is not None:
                streaming_df.writeStream.option(
                    "checkpointLocation", conf["checkpoint_path"]
                ).option("mergeSchema", conf["merge_schema"]).option(
                    "schemaEvolutionMode", conf.get("schema_evolution_mode")
                ).partitionBy(
                    conf["partition_by_cols"]
                ).trigger(
                    availableNow=True
                ).toTable(
                    table_name
                )
            else:
                streaming_df.writeStream.option(
                    "checkpointLocation", conf["checkpoint_path"]
                ).option("mergeSchema", conf["merge_schema"]).partitionBy(
                    conf["partition_by_cols"]
                ).trigger(
                    availableNow=True
                ).toTable(
                    table_name
                )
            ## setting owner to specified group in config ##
            try:
                spark.sql(f"alter table {table_name} owner to `{conf['group_name']}`")
            except Exception as err:
                logger.error(
                    f"Unable to change the owner for the table, try it manually. Error: {err}"
                )

            try:
                spark.sql(
                    f"""ALTER TABLE {table_name} SET TAGS ("nike_techsolution" = "{conf['tech_solution_id']}")"""
                )
                spark.sql(
                    f"""ALTER TABLE {table_name} SET TAGS ("nike_tagguid" = "{conf['cloudred_gid']}")"""
                )
            except Exception as err:
                logger.error(
                    f"Unable to set tech_solution_id and cloudred GID for the table, try it manually. Error: {err}"
                )

            logger.info("Completed writing streaming dataframe to delta table.")
        except Exception as err:
            logger.error(
                f"Issue while writing streaming dataframe to delta table: {err}"
            )
            raise SystemError(err) from err
        finally:
            # spark.catalog.refreshTable(table_name)
            spark.sql(f"REFRESH TABLE {table_name}")
            logger.info(
                "*" * 20 + " END: write_streaming_dataframe_to_delta" + "*" * 20
            )

    def rename_columns_for_raw(self, logger: object, master_spark_df: object) -> object:
        """
        Function Name: rename_columns_for_raw.\n
        Params:
        :param logger: object\n
        :param spark_df: object\n
        Returns: spark_df : object
        """
        try:
            logger.info("*" * 20 + " START: rename_columns_for_raw" + "*" * 20)
            ## working on the column names to make them compatible with the raw STM ##
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(
                        re.sub(r"\((.*?)\)", lambda x: x.group(1).upper(), colname)
                    )
                    for colname in master_spark_df.columns
                ]
            )
            ## replacing special chars with words ##
            symbol_to_word_dict = {
                "#": "_Number_",
                "%": "_Percent_",
                "/": "_Or_",
                "(": "",
                ")": "",
                "+": "_And_",
                "&": "_And_",
                "'": "",
                "-": "_",
                ",": "_",
            }
            for key, value in symbol_to_word_dict.items():
                master_spark_df = master_spark_df.select(
                    [
                        col(colname).alias(re.sub(f"([{key}])", f"{value}", colname))
                        for colname in master_spark_df.columns
                    ]
                )
            ## replacing camel case to snake case ##
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(
                        re.sub("(.)([A-Z][a-z]+[a-z]+)", r"\1_\2", colname)
                    )
                    for colname in master_spark_df.columns
                ]
            )
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(re.sub("([a-z0-9]+)([A-Z])", r"\1_\2", colname))
                    for colname in master_spark_df.columns
                ]
            )
            ## removing leading and trailing whitespaces ##
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(re.sub(r"^[ \t]+|[ \t]+$", r"", colname))
                    for colname in master_spark_df.columns
                ]
            )
            ## removing double and triple whitespaces between column names ##
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(re.sub(r"\s+", r"_", colname))
                    for colname in master_spark_df.columns
                ]
            )
            ## replacing multiple underscores to single underscores between column names ##
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(re.sub("\_+", "_", colname))
                    for colname in master_spark_df.columns
                ]
            )
            ## replacing leading and trailing underscores ##
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(re.sub(r"^[_]+|[_]+$", r"", colname))
                    for colname in master_spark_df.columns
                ]
            )
            ## converting columns to lower case ##
            master_spark_df = master_spark_df.select(
                [
                    col(colname).alias(colname.lower())
                    for colname in master_spark_df.columns
                ]
            )

            return master_spark_df
        except Exception as err:
            logger.error(f"Issue while renaming the table as per raw STM: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: rename_columns_for_raw" + "*" * 20)

    def rename_columns_for_raw_having_dots(
        self, logger: object, master_spark_df: object
    ) -> object:
        """
        Function Name: rename_columns_for_raw.\n
        Params:
        :param logger: object\n
        :param spark_df: object\n
        Returns: spark_df : object
        """
        try:
            logger.info(
                "*" * 20 + " START: rename_columns_for_raw_having_dots" + "*" * 20
            )
            # Replacing all characters before sep = '.' if it exists
            master_spark_df = master_spark_df.select(
                [
                    col("`" + colname + "`").alias(re.sub("^[^.]*\.+", "", colname))
                    for colname in master_spark_df.columns
                ]
            )
            # Replacing all dots if any more exists
            master_spark_df = master_spark_df.select(
                [
                    col("`" + colname + "`").alias(re.sub("\.", "_", colname))
                    for colname in master_spark_df.columns
                ]
            )

            return master_spark_df
        except Exception as err:
            logger.error(f"Issue while renaming the table as per raw STM: {err}")
            raise SystemError(err)
        finally:
            logger.info(
                "*" * 20 + " END: rename_columns_for_raw_having_dots" + "*" * 20
            )

    def union_dataframes(self, logger: object, df1: object, df2: object) -> object:
        """
        Function Name: union_dataframes\n
        Params:
        :param logger: object\n
        :param df1: object\n
        :param df2: object\n
        Returns: spark_df : object
        """
        try:
            logger.info("*" * 20 + " START: union_dataframes" + "*" * 20)
            union_df = df1.unionByName(df2)
            return union_df
        except Exception as e:
            logger.error(f"There was an error union of dataframes: {e}")
            raise SystemExit(e) from e
        finally:
            logger.info("*" * 20 + " END: union_dataframes" + "*" * 20)

    def calculate_uuid_from_pk_cols(
        self, logger: object, query_result_df: object, conf: dict
    ) -> object:
        """
        Function Name: calculate_uuid_from_pk_cols\n
        Params:
        :param query_result_df: object\n
        :param conf: dict\n
        """
        try:
            logger.info("*" * 20 + " START: calculate_uuid_from_pk_cols" + "*" * 20)
            query_result_df = query_result_df.withColumn(
                conf["uuid_col"], md5(concat_ws("", *conf["primary_keys_cols"]))
            )
            query_result_df = query_result_df.withColumn(
                conf["uuid_col"],
                regexp_replace(
                    conf["uuid_col"],
                    "^(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})$",
                    "$1-$2-$3-$4-$5",
                ),
            )
            return query_result_df
        except Exception as e:
            logger.error(f"There was an error in calculate_uuid_from_pk_cols : {e}")
            raise SystemExit(e) from e
        finally:
            logger.info("*" * 20 + " END: calculate_uuid_from_pk_cols" + "*" * 20)

    def add_operational_attributes(
        self,
        logger: object,
        spark_obj: object,
        spark_df: object,
        job_name: str,
        run_id: str,
        hop_name: str,
    ) -> object:
        """
        Function Name: add_operational_attributes.\n
        Params:
        :param spark_obj: spark session\n
        :param spark_df: object\n
        :param job_name: string\n
        :param run_id: str\n
        :param hop_name: str\n
        Returns: spark_df : object
        """
        try:
            logger.info("*" * 20 + " START: add_operational_attributes" + "*" * 20)
            if hop_name.lower() == "raw" or hop_name.lower() == "integrated":
                spark_df = (
                    spark_df.withColumn(
                        "user_nm", lit(self.get_username(logger, spark_obj))
                    )
                    .withColumn("load_dt", current_date())
                    .withColumn("load_month_nbr", month(col("load_dt")))
                    .withColumn("load_year_nbr", year(col("load_dt")))
                    .withColumn("created_at_tmst", current_timestamp())
                    .withColumn("batch_load_tmst", current_timestamp())
                    .withColumn("job_nm", lit(job_name))
                    .withColumn("job_run_id", lit(run_id))
                )
            else:
                spark_df = (
                    spark_df.withColumn(
                        "user_nm", lit(self.get_username(logger, spark_obj))
                    )
                    .withColumn("batch_load_tmst", current_timestamp())
                    .withColumn("job_nm", lit(job_name))
                    .withColumn("job_run_id", lit(run_id))
                )
            return spark_df
        except Exception as e:
            logger.error(f"There was an error in add_operational_attributes : {e}")
            raise SystemExit(e) from e
        finally:
            logger.info("*" * 20 + " END: add_operational_attributes" + "*" * 20)

    def extract_file_name_from_file_path(
        self, logger: object, spark_df: object, file_name_col: str
    ) -> object:
        """
        Function Name: extract_file_name_from_file_path.\n
        Params:
        :param logger: object\n
        :param spark_df: object\n
        :param file_name_col: str\n
        Returns: spark_df : object
        """
        try:
            logger.info(
                "*" * 20 + " START: extract_file_name_from_file_path" + "*" * 20
            )
            spark_df = spark_df.withColumn(
                file_name_col, reverse(split(reverse(spark_df[file_name_col]), "/")[0])
            )
            logger.info("Source file name substring has been added")
            return spark_df
        except Exception as err:
            logger.error(f"Issue while extracting file name from file path: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: extract_file_name_from_file_path" + "*" * 20)

    def run_spark_expectations_dq_checks(
        self: object,
        logger: object,
        spark_obj: object,
        conf: dict,
        cleansed_table: str,
        incremental_df: object,
        is_dataframe: bool = True,
        incremental_sql_query: str = None,
        enable_streaming_to_global_stats_table: bool = True,
    ) -> object:
        """
        Function Name: run_spark_expectations_dq_checks\n
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param cleansed_table: string\n
        :param incremental_df: object\n
        :param is_dataframe: bool\n
        :param incremental_sql_query: str\n
        :param enable_streaming_to_global_stats_table: bool (defaults to True)\n
        Returns: spark_df : object
        """
        try:
            logger.info(
                "*" * 20 + " START: run_spark_expectations_dq_checks" + "*" * 20
            )
            self.cleansed_dataframe = None
            ## setting all environment variables for spark expectations to false ##
            se_user_conf = {
                user_config.se_notifications_enable_email: False,
                user_config.se_notifications_enable_slack: False,
                user_config.se_notifications_on_start: False,
                user_config.se_notifications_on_completion: False,
                user_config.se_notifications_on_fail: False,
                user_config.se_notifications_on_error_drop_exceeds_threshold_breach: False,
                user_config.se_notifications_on_error_drop_threshold: False,
            }
            ## reading the merge_schema flag from config ##
            merge_schema = conf["merge_schema"]
            ## setting the rules and stats table full name ##
            rules_table_name = conf["source_database_name"] + "." + conf["rules_table"]
            stats_table_name = conf["source_database_name"] + "." + conf["stats_table"]

            ## initializing the spark-expectations object which references to the product_id in the dq rules table ##
            writer = (
                WrappedDataFrameWriter()
                .mode("append")
                .format("delta")
                .option("mergeSchema", merge_schema)
            )

            ## setting the streaming options for global stats table based on enable_streaming_to_global_stats_table bool variable##
            if enable_streaming_to_global_stats_table is True:
                stats_streaming_options = {
                    user_config.se_enable_streaming: True,  # Enable streaming
                    user_config.secret_type: "databricks",
                    user_config.dbx_workspace_url: "https://workspace.cloud.databricks.com",
                    user_config.dbx_secret_scope: "sole_common_prod",
                    user_config.dbx_kafka_server_url: "se_streaming_server_url_secret_key",
                    user_config.dbx_secret_token_url: "se_streaming_auth_secret_token_url_key",
                    user_config.dbx_secret_app_name: "se_streaming_auth_secret_appid_key",
                    user_config.dbx_secret_token: "se_streaming_auth_secret_token_key",
                    user_config.dbx_topic_name: "se_streaming_topic_name",
                }
            else:
                stats_streaming_options = {user_config.se_enable_streaming: False}

            ## setting the SparkExpectations object with all required parameters ##
            se = SparkExpectations(
                ## use the product code from config ##
                product_id=conf.get("tech_solution_id") or conf["product_id"],
                ## read the rules table, stats table from config ##
                rules_df=spark_obj.table(rules_table_name),
                stats_table=stats_table_name,
                stats_table_writer=writer,
                target_and_error_table_writer=writer,
                debugger=False,
                stats_streaming_options=stats_streaming_options,
            )

            ## if the input is a dataframe, then run the DQ checks for dataframe, or else run spark.sql() to get input dataframe ##
            if is_dataframe is False and incremental_sql_query is not None:
                incremental_df = spark_obj.sql(
                    incremental_sql_query
                )  ## SELECT query to get incremental records for DQ checks processing ##

            ## call the decorator function to run SE DQ rules and get the cleansed dataframe ##
            @se.with_expectations(
                write_to_table=False,
                write_to_temp_table=False,
                user_conf=se_user_conf,
                target_table_view="order",
                ## take the target_table from config ##
                target_table=cleansed_table,
                target_and_error_table_writer=writer,
            )
            def run_dq_checks(latest_df):
                """
                Function Name: run_dq_checks()
                Inputs: Dataframe from RAW layer.
                Purpose: This function uses spark-expectations for performing DQ checks based on rules defined in the product_rules_table.
                """
                return latest_df

            self.cleansed_dataframe = run_dq_checks(incremental_df)
            self.cleansed_dataframe = self.cleansed_dataframe.drop(
                "meta_dq_run_id", "meta_dq_run_datetime"
            )
            try:
                ## change owner for the error tables to group name if created using this util ##
                spark_obj.sql(
                    f"ALTER TABLE {cleansed_table}_error OWNER TO `{conf['group_name']}`"
                )
            except Exception as err:
                logger.error(
                    f"Unable to change table owner, set it manually, error: {err}"
                )
            return self.cleansed_dataframe

        except Exception as err:
            logger.error(f"Issue while running the DQ checks: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: run_spark_expectations_dq_checks" + "*" * 20)

    def execute_spark_sql(self, spark: object, query: str) -> object:
        """
        Function Name: execute_spark_sql\n
        Params:
        :param spark: object\n
        :param query: string\n
        Returns: spark_df : object
        """
        df = spark.sql(query)
        return df

    def get_sql_file_content(
        self, logger: object, sql_file_path: str, sql_file_name: str
    ) -> str:
        """
        Function Name: get_sql_file_content\n
        Params:
        :param logger: object\n
        :param sql_file_path: str\n
        :param sql_file_name: str\n
        Returns: file_contents : string
        """
        try:
            ## reading the spark sql file ##
            with open(os.path.join(sql_file_path, sql_file_name)) as fp:
                sql_query = fp.read()
            return sql_query
        except Exception as err:
            logger.error(f"Issue while extracting contents from SQL file: {err}")
            raise SystemError(err) from err

    def format_sql_query_with_variables(
        self, logger: object, sql_query: str, kwargs=None, temp_view_name=None
    ) -> str:
        """
        Function Name: format_sql_query_with_variables\n
        Params:
        :param logger: object\n
        :param sql_query: str\n
        :param kwargs: dict (Optional)\n
        :param temp_view_name: str (Optional)\n
        Need to pass either one of kwargs or temp_view_name, both shouldn't be None.\n
        Returns: sql_query : string
        """
        try:
            ## format the SQL query based on dictionary or a temp view name ##
            if kwargs:
                sql_query = sql_query.format(**kwargs)
            elif temp_view_name:
                sql_query = sql_query.format(temp_view_name=temp_view_name)
            return sql_query
        except Exception as err:
            logger.error(f"Issue while formatting the SQL query: {err}")
            raise SystemError(err) from err

    def read_spark_sql_file(
        self,
        logger: object,
        spark: object,
        sql_file_path: str,
        sql_file_name: str,
        spark_df: object,
        conf: object,
    ) -> object:
        """
        Function Name: read_spark_sql_file\n
        Params:
        :param logger: object\n
        :param spark: object\n
        :param sql_file_path: str\n
        :param sql_file_name: str\n
        :param spark_df: object\n
        :param conf: object\n
        Returns: spark_df : object
        """
        try:
            logger.info("*" * 20 + " START: read_spark_sql_file" + "*" * 20)
            ## call the function to read the sql file contents ##
            sql_query = self.get_sql_file_content(logger, sql_file_path, sql_file_name)

            temp_view_name = conf["temp_view_names_list"]
            ## if spark dataframes and temp view names are is list notation (curated layer), then run the loop ##
            if isinstance(spark_df, list) and isinstance(temp_view_name, list):
                format_dict = {}
                ## iterate over all the spark df and create them as temp views ##
                for each_df, each_temp_view in zip(spark_df, temp_view_name):
                    each_df.createOrReplaceTempView(each_temp_view)
                    format_dict[each_temp_view] = each_temp_view
                ## format the SQL query with additional table references ##
                if "tables_mapping_dict" in conf:
                    format_dict.update(conf["tables_mapping_dict"])
                ## format the SQL query with these temp views ##
                sql_query = self.format_sql_query_with_variables(
                    logger, sql_query, kwargs=format_dict
                )
            else:
                spark_df.createOrReplaceTempView(temp_view_name)
                ## format the SQL query with these temp views ##
                sql_query = self.format_sql_query_with_variables(
                    logger, sql_query, temp_view_name=temp_view_name
                )
            df = self.execute_spark_sql(spark, sql_query)
            return df
        except Exception as err:
            logger.error(f"Issue while extracting file name from file path: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: read_spark_sql_file" + "*" * 20)

    def check_schema_mismatch_stream(
        self,
        spark,
        logger,
        master_spark_df,
        target_complete_table_name,
        schema_mismatch_check: bool = False,
    ):
        if schema_mismatch_check:
            try:
                existing_tbl_schema = spark.sql(
                    f"select * from {target_complete_table_name} limit 1"
                )
                logger.info("Existing table schema:", existing_tbl_schema.schema)
                logger.info("New file(s) schema:", master_spark_df.schema)
                columns_to_exclude = [
                    "user_nm",
                    "load_dt",
                    "load_month_nbr",
                    "load_year_nbr",
                    "created_at_tmst",
                    "batch_load_tmst",
                    "job_nm",
                    "job_run_id",
                ]
                selected_columns = [
                    col
                    for col in existing_tbl_schema.columns
                    if col not in columns_to_exclude
                ]
                df_selected = existing_tbl_schema.select(*selected_columns)
                logger.info("Selected columns for schema check:", df_selected)
                logger.warning(
                    "Schema mismatch check is enabled. Checking for schema mismatch between existing table and new file(s)."
                )
                logger.info(
                    "Schema Mismatch::",
                    list(set(df_selected.columns) - set(master_spark_df.columns)),
                )
                logger.info(
                    "New dataframe file names::",
                    list(
                        master_spark_df.select("file_nm")
                        .distinct()
                        .toDF("Mismatched Files")
                    ),
                )
                if df_selected.columns != master_spark_df.columns:
                    return True
                return False
            except SystemError as err:
                logger.error(
                    f"Error while checking schema mismatch (table not created a.k.a first run): {err}"
                )
                return False
        return False

    def reject_table_load(
        self,
        spark: object,
        logger: object,
        incremental_df: object,
        cleansed_df: object,
        conf: dict,
        product_name: str,
        source_complete_table_name: str,
        target_complete_table_name: str,
    ) -> None:

        try:
            logger.info("*" * 20 + " START: reject_table_load" + "*" * 20)

            # Get the columns to be matched to identify records that have been dropped from incremental_df
            hash_cols = [
                i
                for i in incremental_df.columns
                if i
                not in [
                    "user_nm",
                    "created_at_tmst",
                    "batch_load_tmst",
                    "job_nm",
                    "job_run_id",
                ]
            ]

            # Get dropped records only
            error_df = (
                incremental_df.withColumn(
                    "hash_key", hash(*hash_cols).alias("incremental_df")
                )
                .join(
                    cleansed_df.withColumn(
                        "hash_key", hash(*hash_cols).alias("cleansed_df")
                    ),
                    "hash_key",
                    "leftanti",
                )
                .drop("hash_key")
            )

            ##check if data exists for table already in target consolidated error table. if not present read entire error table
            target_error_complete_table_name = target_complete_table_name + "_error"
            predicates = f"""product_name='{product_name}' and error_table_name='{target_error_complete_table_name}' """
            if (
                re.sub(
                    r"([^.]+)(\.)([^.]+)(\.)([^.]+)$",
                    r"\2\4",
                    conf.get("reject_table_name"),
                )
                == ".."
            ):
                reject_table_name = conf["reject_table_name"]
            else:
                reject_table_name = (
                    conf["target_database_name"] + "." + conf["reject_table_name"]
                )

            # check if current table has data in reject table
            target_error_df_count = (
                spark.read.table(reject_table_name).where(predicates).count()
            )
            predicate_rej = conf["predicate_rej_default"]
            if target_error_df_count == 0:
                logger.info(
                    f"No data in reject table for {target_error_complete_table_name}. Processing the entire error table."
                )
                if conf.get("predicate_rej"):
                    predicate_rej = conf["predicate_rej"]
                else:
                    predicate_rej = f"load_dt >= add_months(current_date(), -12)"

            try:
                # Read the error table and get the rejected records
                error_df = (
                    spark.read.table(target_error_complete_table_name)
                    .where(predicate_rej)
                    .filter(col("meta_row_dq_results").cast("string").ilike("%drop%"))
                    .withColumn("hash_col", hash(*hash_cols))
                    .withColumn(
                        "dq_date_filter",
                        row_number().over(
                            Window.partitionBy("load_dt", "hash_col").orderBy(
                                col("meta_dq_run_datetime").desc()
                            )
                        ),
                    )
                    .filter(col("dq_date_filter") == 1)
                    .drop("dq_date_filter")
                    .withColumn("meta_row_dq_reason", explode("meta_row_dq_results"))
                    .filter(col("meta_row_dq_reason").cast("string").ilike("%drop%"))
                    .withColumn(
                        "meta_row_dq_reason_str",
                        expr("cast(meta_row_dq_reason as string)"),
                    )
                    .drop("meta_row_dq_results", "meta_row_dq_reason")
                    .withColumnRenamed("meta_row_dq_reason_str", "meta_row_dq_reason")
                    .withColumn(
                        "rejected_count",
                        lit(1)
                        / count("*").over(Window.partitionBy("load_dt", "hash_col")),
                    )
                )

                # Generate write dataframe. rejected percent is calculated based on load date
                groupBy_cols = [
                    "meta_row_dq_reason",
                    "load_dt",
                    "load_month_nbr",
                    "load_year_nbr",
                    "created_at_tmst",
                    "batch_load_tmst",
                    "job_nm",
                    "job_run_id",
                ]

                error_write_df = (
                    error_df.withColumn(
                        "row_as_json",
                        to_json(struct([error_df[x] for x in error_df.columns])),
                    )
                    .groupBy(*groupBy_cols)
                    .agg(
                        sum("rejected_count").alias("rejected_count"),
                        collect_list("row_as_json").alias("dq_rejected_records"),
                        count("row_as_json").alias("dq_rejected_record_count"),
                    )
                    .select(
                        lit(product_name).alias("product_name"),
                        lit(target_error_complete_table_name).alias("error_table_name"),
                        "meta_row_dq_reason",
                        col("load_dt").alias("load_dt_error_src"),
                        "dq_rejected_records",
                        expr(
                            "cast(dq_rejected_record_count as int) as dq_rejected_record_count"
                        ),
                        "rejected_count",
                        (
                            round(
                                col("rejected_count")
                                * 100
                                / lit(conf["source_record_count"]),
                                3,
                            )
                        ).alias("rejected_percent"),
                        expr(
                            'regexp_replace(meta_row_dq_reason,"\(.+\) \([^ ]+\)_check\(.+\)","$2") as attribute_name'
                        ),
                        expr("cast(current_date() as string) as load_dt"),
                        "load_month_nbr",
                        "load_year_nbr",
                        "created_at_tmst",
                        "batch_load_tmst",
                        "job_nm",
                        "job_run_id",
                        expr("cast(current_timestamp() as string) as load_tmst"),
                    )
                )

                if target_error_df_count == 0:
                    # get counts by load date of source data
                    source_df = (
                        spark.read.table(source_complete_table_name)
                        .select(col("load_dt").alias("load_dt_src"), "created_at_tmst")
                        .groupBy("load_dt_src", "created_at_tmst")
                        .agg(count("*").alias("count_by_load_dt"))
                        .drop("created_at_tmst")
                        .dropDuplicates()
                        .groupBy("load_dt_src")
                        .agg(sum("count_by_load_dt").alias("count_by_load_dt"))
                    )
                    # joining to get counts for history data
                    error_write_df = (
                        error_write_df.alias("error_write_df")
                        .join(
                            source_df,
                            error_write_df["load_dt_error_src"]
                            == source_df["load_dt_src"],
                        )
                        .select(
                            "product_name",
                            "error_table_name",
                            "meta_row_dq_reason",
                            "load_dt_error_src",
                            "dq_rejected_records",
                            "dq_rejected_record_count",
                            (
                                round(
                                    col("rejected_count")
                                    * lit(100)
                                    / col("count_by_load_dt"),
                                    3,
                                )
                            ).alias("rejected_percent"),
                            "attribute_name",
                            expr("cast(current_date() as string) as load_dt"),
                            "load_month_nbr",
                            "load_year_nbr",
                            "created_at_tmst",
                            "batch_load_tmst",
                            "job_nm",
                            "job_run_id",
                            "load_tmst",
                        )
                    )
                else:
                    error_write_df = error_write_df.drop("rejected_count")

                # Condition to the length of dq_rejected_records more than 50000 for integrated hop
                if conf.get("target_hop_name").lower() == "integrated":
                    if conf.get("global_temp_dbx_table_name") not in conf.get(
                        "drop_column_table"
                    ):
                        logger.info(
                            "Checking if dq_rejected_records length is more than 50000"
                        )
                        error_write_df = (
                            error_write_df.withColumn(
                                "dq_rejected_records_test",
                                concat_ws(",", col("dq_rejected_records")),
                            )
                            .withColumn(
                                "dq_rejected_records_test",
                                expr("substring(dq_rejected_records_test, 1, 50000)"),
                            )
                            .withColumn(
                                "dq_rejected_records",
                                split(col("dq_rejected_records_test"), ","),
                            )
                            .drop("dq_rejected_records_test")
                        )
                    else:
                        logger.info(
                            "Skipping the check for dq_rejected_records length as it is taxonomy_mapping_tbl and dropping the column dq_rejected_records"
                        )
                        error_write_df = error_write_df.drop("dq_rejected_records")

                return error_write_df
            except Exception as err:
                logger.error(
                    f"Error while loading the reject table. {target_error_complete_table_name} might not exist : {err}"
                )
                return False

        except Exception as err:
            logger.error(f"Issue while Loading the reject table: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: reject_table_load" + "*" * 20)

    def trigger_actual_ovr_extrapolation(
        self,
        logger,
        spark,
        sql_file_path,
        extrapolation_cmplt_tbl_name,
        extrapolation_sql_file_nm,
        sql_file_contents,
        master_spark_df,
        conf,
    ):
        # pass compare columns
        if conf["target_table_name"].lower().find("electricity") != -1:
            alert_cols_with_expr = {
                "electricity_location_nm": "electricity_location_nm as location_nm",
                "electricity_location_nbr": "electricity_location_nbr as location_nbr",
                "service_type_cd": "service_type_cd as service_type_nm",
                "reporting_period_dt": "reporting_period_dt as reporting_period_dt",
                "lease_nbr": "lease_nbr as lease_number_desc",
                "nike_department_type_txt": "nike_department_type_txt as department_nm",
                "extrapolation_ind": "extrapolation_ind as extrapolation_ind",
                "scope_nbr": "scope_nbr as scope_nbr",
                "cost_usage_data_source_nm": "cost_usage_data_source_nm as data_prvdr",
            }
            conf["alert_cols_with_expr"] = alert_cols_with_expr
            merge_keys = [
                "electricity_location_nm",
                "electricity_location_nbr",
                "service_type_cd",
                "reporting_period_dt",
            ]
        elif conf["target_table_name"].lower().find("fuel") != -1:
            alert_cols_with_expr = {
                "fuel_location_nm": "fuel_location_nm as location_nm",
                "fuel_location_nbr": "fuel_location_nbr as location_nbr",
                "service_type_cd": "service_type_cd as service_type_nm",
                "reporting_period_dt": "reporting_period_dt as reporting_period_dt",
                "lease_nbr": "lease_nbr as lease_number_desc",
                "nike_department_type_txt": "nike_department_type_txt as department_nm",
                "extrapolation_ind": "extrapolation_ind as extrapolation_ind",
                "scope_nbr": "scope_nbr as scope_nbr",
                "cost_usage_data_source_nm": "cost_usage_data_source_nm as data_prvdr",
            }
            conf["alert_cols_with_expr"] = alert_cols_with_expr
            merge_keys = [
                "fuel_location_nm",
                "fuel_location_nbr",
                "service_type_cd",
                "reporting_period_dt",
            ]

        sql_query_to_get_actuals_contents = SparkUtils().get_sql_file_content(
            logger, sql_file_path, sql_file_name=extrapolation_sql_file_nm
        )
        sql_query_to_get_actuals = SparkUtils().format_sql_query_with_variables(
            logger,
            sql_query_to_get_actuals_contents,
            kwargs={
                "target_database_name": conf["target_database_name"],
                "target_table_name": conf["target_table_name"],
            },
        )
        rename_col_select = (
            [
                expr(conf["alert_cols_with_expr"][i])
                for i in conf["alert_cols_with_expr"]
            ]
            + [
                expr(conf["other_cols_with_expr"][i])
                for i in conf.get("other_cols_with_expr", [])
            ]
            + [expr(i) for i in conf.get("other_cols", [])]
        )
        actual_over_extrapolation_df = SparkUtils().run_spark_sql_query_as_spark_df(
            logger, spark, sql_query_to_get_actuals
        )
        logger.info("actual_over_extrapolation temp view created ")
        joined_df = (
            master_spark_df.alias("master")
            .join(
                actual_over_extrapolation_df.alias("actual"),
                merge_keys,
                "inner",
            )
            .dropDuplicates()
        )
        result_df = joined_df.select(f"master.*")
        try:
            logger.info("Reading extrapolation alert table")
            alert_df = spark.read.table(extrapolation_cmplt_tbl_name)
            logger.info("Extrapolation alert table read successfully")
            result_df = result_df.select(rename_col_select)
            logger.info("Renamed columns in result_df")
            final_df = result_df.join(
                alert_df,
                [
                    "location_nm",
                    "location_nbr",
                    "service_type_nm",
                    "reporting_period_dt",
                ],
                "leftanti",
            ).dropDuplicates()
            logger.info("Joined with alert table")
            # final_df = final_df.select([f"master.{col}" for col in conf.get('merge_key_cols')[1:-2]]+ ["master.extrapolation_ind"])
            # final_df = final_df.select(*rename_col_select)
            # final_df =  final_df.withColumn("insertion_tmst", col(current_timestamp()))
            final_df = final_df.withColumn("status", lit("UNPROCESSED"))

        except Exception as e:
            logger.error("Error in reading alert table: %s", e)
            # final_df = result_df.select([f"master.{col}" for col in conf.get('merge_key_cols')[1:-2]]+ ["master.extrapolation_ind"])
            final_df = result_df.select(rename_col_select)
            final_df = result_df.join(
                alert_df,
                [
                    "location_nm",
                    "location_nbr",
                    "service_type_nm",
                    "reporting_period_dt",
                ],
                "leftanti",
            ).dropDuplicates()
            final_df = final_df.withColumn("status", lit("UNPROCESSED"))
            # logger.info("Inserted Actual over extrapolation data into table")

        if isinstance(final_df, DataFrame):
            return final_df
        else:
            logger.info("***** No newActual location related info found *****")
            return []


class LoggerUtils:
    """
    ClassName: LoggerUtils.\n
    Purpose: This class contains the objects for defining the logger.\n
    """

    def __init__(self) -> None: ...

    def get_logger_object(
        self: object,
    ) -> object:
        """
        Function Name: get_logger_object.\n
        Params:
        :param app_name: string
        Returns: spark session object
        """
        try:
            # create logger`
            logger_io = logging.getLogger(__name__)
            formatter = logging.Formatter(
                "%(asctime)s %(levelname)s \t[%(filename)s:%(lineno)s - %(funcName)s()] %(message)s"
            )
            logger_io.setLevel(logging.INFO)

            # add normal steam handler to display logs on screen
            io_log_handler = logging.StreamHandler()
            io_log_handler.setFormatter(formatter)
            logger_io.addHandler(io_log_handler)

            # create stream handler and initialise it with string io buffer
            string_io_log_handler = logging.StreamHandler(io.StringIO())
            string_io_log_handler.setFormatter(formatter)

            # add stream handler to logger
            logger_io.addHandler(string_io_log_handler)

            return logger_io

        except Exception as err:
            raise (err)


class ConfigUtils:
    """
    ClassName: ConfigUtils.\n
    Purpose: This class contains the methods for reading the config file.\n
    """

    def __init__(self) -> None: ...

    def read_config_variables(
        self,
        config_path: str,
        config_name: str,
        env: str,
        logger: object,
        wf_name: str = "NA",
    ) -> dict:
        """
        Function Name: read_config_variables.\n
        Params:
        :param config_path: string\n
        :param config_name: string\n
        :param env: string\n
        :param logger: object\n
        Returns: configuration dictionary.
        """
        try:
            logger.info("*" * 20 + " START: read_config_variables" + "*" * 20)
            ## initialize the empty dictionary to store all the config values from parser object ##
            conf = {}
            configure = configparser.ConfigParser(interpolation=None)
            ## Read the config file via provided path ##
            configure.read(os.path.join(config_path, config_name))
            ## Get all the sections from the config file ##
            config_sections = configure.sections()
            ## Check if 'main' section is present in config, if yes get common values ##
            if "main" in config_sections:
                conf["product_name"] = eval(
                    str(
                        configure.has_option("main", "product_name")
                        and configure.get("main", "product_name")
                        or None
                    )
                )
                conf["object_name"] = eval(
                    str(
                        configure.has_option("main", "object_name")
                        and configure.get("main", "object_name")
                        or None
                    )
                )
                conf["tech_solution_id"] = eval(
                    str(
                        configure.has_option("main", "tech_solution_id")
                        and configure.get("main", "tech_solution_id")
                        or None
                    )
                )
                conf["nike-tagguid"] = eval(
                    str(
                        configure.has_option("main", "nike-tagguid")
                        and configure.get("main", "nike-tagguid")
                        or None
                    )
                )
                conf["job_name"] = eval(
                    str(
                        configure.has_option("main", "job_name")
                        and configure.get("main", "job_name")
                        or None
                    )
                )
                conf["common_cols"] = eval(
                    str(
                        configure.has_option("main", "common_cols")
                        and configure.get("main", "common_cols")
                        or None
                    )
                )
                conf["write_mode"] = eval(
                    str(
                        configure.has_option("main", "write_mode")
                        and configure.get("main", "write_mode")
                        or None
                    )
                )
                conf["merge_schema"] = eval(
                    str(
                        configure.has_option("main", "merge_schema")
                        and configure.get("main", "merge_schema")
                        or False
                    )
                )
                conf["sla"] = eval(
                    str(
                        configure.has_option("main", wf_name)
                        and configure.get("main", wf_name)
                        or (
                            configure.has_option("main", "default_sla")
                            and configure.get("main", "default_sla")
                        )
                        or False
                    )
                )
            ## check if env variable (dev/qa/prod) is present in config_sections, if yes get all the values ##
            if env in config_sections:
                for each_key, each_val in configure.items(env):
                    conf[each_key] = eval(str(each_val))
            ## Get the default section values ##
            for each_key, each_val in configure.defaults().items():
                conf[each_key] = eval(str(each_val))
            logger.info(
                "Finished reading the configurations from TOML file, returning the dictionary object."
            )
            return conf
        except configparser.ParsingError as cferr:
            logger.error(f"Issue while parsing the config file: {cferr}")
            raise SystemError(cferr)
        except Exception as err:
            logger.error(f"Issue while parsing the config file: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: read_config_variables" + "*" * 20)

    def get_username_password_from_dbx_secrets(
        self, logger: object, bf_context: object, scope_name: str
    ) -> tuple:
        """
        Function Name: get_username_password_from_dbx_secrets.\n
        Params:
        :param logger: object\n
        :param bf_context: object\n
        :param scope_name: string\n
        Returns: username, password : string, string
        """
        try:
            logger.info(
                "*" * 20 + " START: get_username_password_from_dbx_secrets" + "*" * 20
            )
            username = bf_context.dbutils.secrets.get(
                scope=scope_name, key="gid_username"
            )
            password = bf_context.dbutils.secrets.get(
                scope=scope_name, key="gid_password"
            )
            return username, password
        except Exception as err:
            logger.error(
                f"Issue while getting username and password from Databricks secrets: {err}"
            )
            raise SystemError(err) from err
        finally:
            logger.info(
                "*" * 20 + " END: get_username_password_from_dbx_secrets" + "*" * 20
            )

    def cerberus_read(
        self, logger: object, input_dict: dict, secrets_path: str, url: str
    ) -> dict:
        """
        Function Name: cerberus_read\n
        Params:
        :param logger: object\n
        :param input_dict: dict\n
        :param secrets_path: str\n
        :param url: str\n
        Returns: cerberus dictionary object
        """
        try:
            cerberus = dict()
            logger.info("*" * 20 + " START: cerberus_read " + "*" * 20)
            cerberus_client = CerberusClient(url)
            for key in input_dict:
                cerberus[key] = cerberus_client.get_secrets_data(secrets_path)[
                    input_dict[key]
                ]
            return cerberus
        except UnicodeDecodeError as e:
            logger.error("There was an error Getting variables from Cerberus.")
            raise SystemError(e)
        finally:
            logger.info("*" * 20 + " END: cerberus_read " + "*" * 20)

    def set_start_end_date(self, logger: object, conf: dict) -> list:
        """
        Function Name: set_start_end_date\n
        Params:
        :param logger: object\n
        :param conf: dict\n
        The duration_prior depends on the frequency set. duration_prior of 1 means 1 week prior for weekly frequency and 1 month prior for monthly frequency or 1 day prior for daily frequency.
        Returns: list of start and end_date. Used to pass a dates to API calls that require a date range.
        """
        try:
            logger.info("*" * 20 + " START: set_start_end_date " + "*" * 20)
            now = datetime.now()
            # Adjusting date if day is sunday for weekly execution
            if (
                conf.get("frequency")
                and conf.get("frequency") == "weekly"
                and now.weekday() == 6
            ):
                now = now + relativedelta(days=1)
            day_or_month_count = conf.get("duration_prior") or 0
            if conf.get("historical_flag") and conf.get("historical_flag") == True:
                dates = ["2018-01-01", now.strftime("%Y-%m-%d")]
            elif conf.get("frequency"):
                if conf.get("frequency") == "daily":
                    dates = [
                        (now - relativedelta(days=day_or_month_count)).strftime(
                            "%Y-%m-%d"
                        ),
                        (now - relativedelta(days=day_or_month_count)).strftime(
                            "%Y-%m-%d"
                        ),
                    ]
                elif conf.get("frequency") == "weekly":
                    dates = [
                        (
                            now
                            - relativedelta(
                                days=now.weekday() + 1 + day_or_month_count * 7
                            )
                        ).strftime("%Y-%m-%d"),
                        (
                            now
                            + relativedelta(
                                days=5 - now.weekday() - 7 * day_or_month_count
                            )
                        ).strftime("%Y-%m-%d"),
                    ]
                elif conf.get("frequency") == "monthly":
                    dates = [
                        (now - relativedelta(months=day_or_month_count)).strftime(
                            "%Y-%m-01"
                        ),
                        (
                            (
                                now + relativedelta(months=1 - day_or_month_count)
                            ).replace(day=1)
                            - relativedelta(days=1)
                        ).strftime("%Y-%m-%d"),
                    ]
                elif conf.get("frequency") == "adhoc" or conf.get("frequency") == "":
                    dates = [
                        conf.get("start_date") or now.strftime("%Y-%m-%d"),
                        conf.get("end_date") or now.strftime("%Y-%m-%d"),
                    ]
            else:
                dates = [
                    conf.get("start_date") or now.strftime("%Y-%m-%d"),
                    conf.get("end_date") or now.strftime("%Y-%m-%d"),
                ]

            logger.info(f"Start and End dates are set to {dates}")
            return dates
        except Exception as err:
            logger.error(f"Issue while generating start and end date: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: set_start_end_date" + "*" * 20)


class QueryUtils:
    """
    ClassName: QueryUtils.\n
    Purpose: This class contains the methods for performing select operations on delta tables.\n
    """

    def __init__(self, spark: object):
        ## initializing the spark object sent to the class object ##
        self.spark = spark

    def read_cdc_batch(
        self,
        logger: object,
        table_name: str,
        latest_timestamp: datetime,
        predicates: str = None,
        custom_starting_timestamp: datetime = None,
    ) -> object:
        """
        Function Name: read_cdc_batch.\n
        Params:
        :param logger: object\n
        :param table_name: string\n
        :param latest_timestamp: datetime\n
        :param predicates: string\n
        :param custom_starting_timestamp: datetime\n
        Returns: cdc incremental dataframe.
        """
        try:
            logger.info("*" * 20 + " START: read_cdc_batch " + "*" * 20)
            # ## using spark sql, get the latest timestamp for the incremental dataset ##
            # latest_timestamp_obj = self.spark.sql(f"""DESCRIBE HISTORY {table_name}""").where(col('job').isNotNull()).selectExpr('max(timestamp) as latest_timestamp')
            # ## get the timestamp as python object ##
            # latest_timestamp = latest_timestamp_obj.head()[0]

            ## giving custom timestamp as highest priority take the custom or max timestamp as starting_timestamp ##
            starting_timestamp = custom_starting_timestamp or latest_timestamp

            ## read the incremental data using starting timestamp ##
            if predicates:
                df = (
                    self.spark.read.format("delta")
                    .option("readChangeFeed", "true")
                    .option("startingTimestamp", starting_timestamp)
                    .table(tableName=f"{table_name}")
                    .where(predicates)
                )
            else:
                df = (
                    self.spark.read.format("delta")
                    .option("readChangeFeed", "true")
                    .option("startingTimestamp", starting_timestamp)
                    .table(tableName=f"{table_name}")
                )

            logger.info("Finished reading the CDC dataframe")
            ## get only the insert records and avoid other change types ##
            if "_change_type" in df.columns:
                df = df.filter(~df["_change_type"].isin(["update_preimage", "delete"]))
            logger.info(
                "Filtered the CDC dataframe on change_type column and returning the df to main function"
            )
            ## dropping the change_type, commit_version, commit_timestamp columns as part of CDC logic##
            df = df.drop("_change_type", "_commit_version", "_commit_timestamp")
            return df
        except Exception as err:
            logger.error(f"Issue while fetching the incremental CDC data: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: read_cdc_batch " + "*" * 20)

    def pivot_dataframe(
        self,
        logger: object,
        input_df: object,
        unpivot_cols: list,
        id_col: str,
        value_col: str,
        df_pivot_list: list = [],
        conf: dict = None,
        target_complete_table_name: str = None,
        write_mode: str = "append",
    ) -> object:
        """
        Function Name: pivot_dataframe.\n
        Params:
        :param logger: object\n
        :param input_df: object\n
        :param pivot_cols: list\n
        :param id_col: string\n
        :param value_col: string\n
        Returns: pivoted dataframe.
        """
        try:
            logger.info("*" * 20 + " START: pivot_dataframe " + "*" * 20)

            # if not isinstance(input_df, pd.core.series.Series) and isinstance(input_df[0],dict):
            if isinstance(input_df, list) and isinstance(input_df[0], dict):
                df_temp = pd.DataFrame(input_df)
                df_temp_spark = self.spark.createDataFrame(df_temp)

                # Generating pivoted columns
                all_cols = df_temp_spark.columns
                pivot_cols = [cols for cols in all_cols if cols not in unpivot_cols]

                # Performing pivot
                df_pivot = None
                for col_name in pivot_cols:
                    df_temp = df_temp_spark.select(
                        *unpivot_cols,
                        lit(col_name).alias(id_col),
                        col(col_name).alias(value_col),
                    )
                    # If this is the first DataFrame, assign it to df_unpivot
                    if df_pivot is None:
                        df_pivot = df_temp
                    # Otherwise, union it with the existing df_unpivot
                    else:
                        df_pivot = df_pivot.union(df_temp)

                # save intermediate results. Done if pivoted table is huge
                if (
                    "pivot_intermediate_save" in conf.keys()
                    and conf.get("pivot_intermediate_save") == True
                ):
                    df_pivot.write.mode(write_mode).format("delta").saveAsTable(
                        target_complete_table_name + "_temp"
                    )
                else:
                    df_pivot_list.append(df_pivot)
                    return df_pivot_list

            else:
                write_mode = "overwrite"
                for row in input_df:
                    self.pivot_dataframe(
                        logger,
                        list(row),
                        unpivot_cols,
                        id_col,
                        value_col,
                        df_pivot_list,
                        conf=conf,
                        target_complete_table_name=target_complete_table_name,
                        write_mode=write_mode,
                    )
                    write_mode = "append"
                return df_pivot_list

        except Exception as err:
            logger.error(f"Issue while pivoting the dataframe: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: pivot_dataframe " + "*" * 20)

    def update_batch_load_tracker(
        self,
        project_name: str,
        env: str,
        batch_tracker_table: str,
        batch_id: str = datetime.now().strftime("%Y%m%d%H%M%S"),
        status="RUNNING",
    ) -> None:
        """
        Function Name: update_batch_load_tracker.\n
        Params:
        :param project_name: string\n
        :param env: string\n
        :param batch_tracker_table: string\n
        :param batch_id: string\n
        Returns: None
        """
        try:
            self.spark.sql(
                f"""
                CREATE TABLE IF NOT EXISTS {batch_tracker_table} (
                    project_name STRING,
                    env STRING,
                    batch_id STRING,
                    status STRING
                ) TBLPROPERTIES (delta.enableChangeDataFeed = true)
            """
            )

            if status == "FAILURE":
                self.spark.sql(
                    f"""
                MERGE INTO {batch_tracker_table} target
                USING (
                SELECT '{project_name}' AS project_name, 
                        '{env}' AS env, 
                        '{batch_id}' AS batch_id, 
                        '{status}' AS status
                ) source
                ON source.project_name = target.project_name AND source.env = target.env
                WHEN MATCHED THEN
                UPDATE SET status = source.status
                WHEN NOT MATCHED THEN
                INSERT (project_name, env, batch_id, status) 
                VALUES (source.project_name, source.env, source.batch_id, source.status)"""
                )
            else:
                self.spark.sql(
                    f"""MERGE INTO {batch_tracker_table} target
                USING (
                SELECT '{project_name}' AS project_name, 
                        '{env}' AS env, 
                        '{batch_id}' AS batch_id, 
                        '{status}' AS status
                ) source
                ON source.project_name = target.project_name AND source.env = target.env
                WHEN MATCHED THEN
                UPDATE SET batch_id = source.batch_id, status = source.status
                WHEN NOT MATCHED THEN
                INSERT (project_name, env, batch_id, status) 
                VALUES (source.project_name, source.env, source.batch_id, source.status)"""
                )
        except Exception as err:
            raise SystemError(err) from err

    def update_checkpoint_table(
        self,
        job_run_id: int,
        checkpoint_table: str,
    ) -> None:
        """
        Function Name: update_batch_load_tracker.\n
        Params:
        :param project_name: string\n
        :param env: string\n
        :param batch_tracker_table: string\n
        :param batch_id: string\n
        Returns: None
        """
        try:
            self.spark.sql(
                f"""
                CREATE TABLE IF NOT EXISTS {checkpoint_table} (
                    job_run_id BIGINT,
                    updated_at_tmst timestamp
                ) TBLPROPERTIES (delta.enableChangeDataFeed = true)
            """
            )

            self.spark.sql(
                f"""INSERT INTO {checkpoint_table} (job_run_id, updated_at_tmst)
                SELECT {job_run_id}, current_timestamp() 
                WHERE NOT  EXISTS (SELECT 1 FROM {checkpoint_table}
                WHERE updated_at_tmst >= current_timestamp() - INTERVAL 30 DAY)"""
            )
        except Exception as err:
            raise SystemError(err) from err

    def load_data_completeness_tracker(
        self,
        data_product: str,
        file_ext_check: str,
        delim_check: str,
        cols_check: str,
        env: str,
        data_completeness_table: str,
        batch_load_tmst: str = datetime.now().strftime("%Y%m%d%H%M%S"),
    ) -> None:
        """
        Function Name: load_data_completeness_tracker.\n
        Params:
        :param data_product:
        :param file_ext_check:
        :param delim_check: string\n
        :param env: string\n
        :param cols_check: string\n
        :param data_completeness_table: string\n
        :param batch_load_tmst: string\n
        Returns: None
        """
        try:
            # If the table does not exist, create it
            self.spark.sql(
                f"""
                CREATE TABLE IF NOT EXISTS {data_completeness_table} (
                    data_product STRING,
                    env STRING,
                    file_ext_check STRING,
                    delim_check STRING,
                    cols_check STRING,
                    batch_load_tmst STRING
                ) TBLPROPERTIES (delta.enableChangeDataFeed = true)
            """
            )
            # Perform the insert
            df = self.spark.createDataFrame(
                [
                    (
                        data_product,
                        file_ext_check,
                        delim_check,
                        cols_check,
                        env,
                        batch_load_tmst,
                    )
                ],
                [
                    "data_product",
                    "file_ext_check",
                    "delim_check",
                    "cols_check",
                    "env",
                    "batch_load_tmst",
                ],
            )
            df.write.mode("append").option("mergeSchema", "true").format(
                "delta"
            ).saveAsTable(data_completeness_table)
        except Exception as err:
            raise SystemError(err) from err

    def write_dataframe_to_delta(
        self,
        logger: object,
        spark: object,
        conf: dict,
        spark_df: object,
        table_name: str,
        tech_solution_id: str,
        cloudred_gid: str,
        do_partition: bool = True,
        update_tags: bool = True,
        set_not_null_constraint: bool = True,
    ) -> None:
        """
        Function Name: write_dataframe_to_delta.\n
        Params:
        :param logger: object\n
        :param spark: spark session object\n
        :conf: config dictionary\n
        :param spark_df: Spark Dataframe\n
        :param table_name: string\n
        :param tech_solution_id: string\n
        :param cloudred_gid: string\n
        :param do_partition: bool (Defaults to True)\n
        :param update_tags: bool (Defaults to True)\n
        :param set_not_null_constraint: bool (Defaults to True)\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: write_dataframe_to_delta " + "*" * 20)
            write_mode = conf["write_mode"]
            merge_schema = conf["merge_schema"]

            ## convert all the columns to lowercase to avoid issues with case sensitivity
            spark_df = spark_df.select(*[col.lower() for col in spark_df.columns])

            ## if not_null_columns are specified, then pyspark schema needs to be changed first, before running ALTER in upcoming steps to avoid schema mismatch issues ##
            if "not_null_columns" in conf.keys() and set_not_null_constraint is True:
                schema = spark_df.schema
                ## for each of not_null_columns specified in the list, make them as nullable = False ##
                try:
                    new_schema = StructType(
                        [
                            StructField(
                                field.name,
                                field.dataType,
                                (
                                    False
                                    if field.name in conf["not_null_columns"]
                                    else field.nullable
                                ),
                            )
                            for field in schema
                        ]
                    )
                    spark_df = spark.createDataFrame(spark_df.toPandas(), new_schema)
                    logger.info(
                        "Changed the schema for the dataframe to set the not null columns"
                    )
                except Exception as err:
                    logger.error(
                        f"Unable to change the schema for the dataframe, try it manually. Error: {err}"
                    )

            if (
                "partition_by_cols" in conf.keys()
                and conf["partition_by_cols"] is not None
                and len(conf["partition_by_cols"]) != 0
                and do_partition is True
            ):
                if (
                    conf.get("overwrite_by_partition")
                    and conf["overwrite_by_partition"] is True
                ):
                    spark.conf.set(
                        "spark.sql.sources.partitionOverwriteMode", "dynamic"
                    )

                spark_df.write.partitionBy(conf["partition_by_cols"]).mode(
                    write_mode
                ).option("mergeSchema", merge_schema).option(
                    "overwriteSchema", "true"
                ).format(
                    "delta"
                ).saveAsTable(
                    table_name
                )
            else:
                spark_df.write.mode(write_mode).option(
                    "mergeSchema", merge_schema
                ).option("overwriteSchema", "true").format("delta").saveAsTable(
                    table_name
                )

            logger.info("Completed writing dataframe to delta table.")

            ## convert all columns to lower case for existing columns ##
            existing_cols = [f.name for f in spark.table(table_name).schema.fields]
            for c in existing_cols:
                if c != c.lower():
                    try:
                        spark.sql(
                            f"ALTER TABLE {table_name} RENAME COLUMN `{c}` TO `{c.lower()}`"
                        )
                        logger.info(
                            f"Renamed column {c} to {c.lower()} in {table_name}"
                        )
                    except Exception as err:
                        logger.warning(f"Could not rename column {c}: {err}")

            ## setting owner to specified group in config ##
            try:
                spark.sql(f"alter table {table_name} owner to `{conf['group_name']}`")
            except Exception as err:
                logger.error(
                    f"Unable to change the owner for the table, try it manually. Error: {err}"
                )

            ## check for the not-null constraint on the table, if not present then add it for not-null columns specified in config ##
            if (
                "not_null_columns" in conf.keys()
                and "databricks_catalog" in conf.keys()
                and "databricks_schema" in conf.keys()
                and set_not_null_constraint is True
            ):
                try:
                    not_null_constraints_count = spark.sql(
                        f"""
                        SELECT count(*)
                        FROM {conf['databricks_catalog']}.information_schema.columns
                        WHERE is_nullable = 'NO'
                        AND table_catalog = '{conf['databricks_catalog']}'
                        AND table_schema = '{conf['databricks_schema']}'
                        AND table_name = '{conf['target_table_name']}';     
                    """
                    ).head()[0]
                    if not_null_constraints_count == 0:
                        logger.info(
                            "*" * 20
                            + f" START: Adding the not null constraint on the specified table: {table_name} "
                            + "*" * 20
                        )
                        for each_col in conf["not_null_columns"]:
                            spark.sql(
                                f"ALTER TABLE {table_name} ALTER COLUMN {each_col} SET NOT NULL"
                            )
                        logger.info(
                            "*" * 20
                            + f" END: Added the not null constraint on the specified table: {table_name} "
                            + "*" * 20
                        )
                    else:
                        logger.info(
                            f"The not null constraint is already set on the table: {table_name}"
                        )
                except Exception as err:
                    logger.error(
                        f"Unable to set the not null constraint on the table due to following error, try it manually. Error: {err}"
                    )
            else:
                logger.info(
                    "As not null keys are not specified in config, skipping the not null constraint operation on this table"
                )

            if update_tags is True:
                try:
                    spark.sql(
                        f'ALTER TABLE {table_name} SET TAGS ("nike_techsolution" = "{tech_solution_id}")'
                    )
                    spark.sql(
                        f'ALTER TABLE {table_name} SET TAGS ("nike_tagguid" = "{cloudred_gid}")'
                    )
                except Exception as err:
                    logger.error(
                        f"Unable to set tech_solution_id and cloudred GID for the table, try it manually. Error: {err}"
                    )

        except Exception as err:
            logger.error(f"Issue while writing spark dataframe to delta table: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: write_dataframe_to_delta " + "*" * 20)

    def run_delta_table_optimisation(
        self,
        logger: object,
        config_path: str,
        config_name: str,
        env: str,
        bf_context: object,
    ) -> None:
        logger.info("*" * 20 + " START: run_delta_table_optimisation " + "*" * 20)
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )

        vacuum_database_name = conf["vacuum_database_name"]
        try:

            for table_name in conf.get("vacuum_table_name"):

                logger.info(f"""Execution started for table {table_name}""")

                self.spark.sql(f"""VACUUM {vacuum_database_name}.{table_name}""")
                self.spark.sql(
                    f"""ANALYZE TABLE {vacuum_database_name}.{table_name} COMPUTE STATISTICS"""
                )
                self.spark.sql(f"""OPTIMIZE {vacuum_database_name}.{table_name}""")

        except Exception as err:
            logger.error(
                f"Issue occurred while processing optimisation on delta table : {err}"
            )
            raise SystemError(err) from err

        finally:
            logger.info("*" * 20 + " END: run_delta_table_optimisation " + "*" * 20)

    def get_data_difference_between_batches(
        self,
        database_name: str,
        table_name: str,
        batch_column: str,
        comparison_columns: list,
    ):
        """
        Find the data difference between the top two batch load timestamps in a table.

        :param table_name: Name of the table to query.
        :param batch_column: Name of the column containing batch load timestamps.
        :param comparison_columns: List of columns to compare for data difference.
        :return: DataFrame containing the difference between the two batches.
        """
        # Load the table into a DataFrame
        df = self.spark.table(str(database_name) + "." + str(table_name))

        # Add a dense rank column to rank batch timestamps in descending order
        window_spec = Window.orderBy(col(batch_column).desc())
        df_with_rank = df.withColumn("batch_rank", dense_rank().over(window_spec))

        # Filter for the top two batches
        batch_1_df = df_with_rank.filter(col("batch_rank") == 1).select(
            *comparison_columns
        )
        batch_2_df = df_with_rank.filter(col("batch_rank") == 2).select(
            *comparison_columns
        )

        # Perform the EXCEPT operation to find the difference
        difference_df = batch_2_df.subtract(batch_1_df)

        return difference_df


class JSONUtils:
    """
    ClassName: JSONUtils.\n
    Purpose: This class contains the methods for reading/flattening JSON records.\n
    """

    def __init__(self): ...

    def convert_spark_df_to_pandas_df(
        self, logger: object, spark_df: object, payload_col_name: str
    ) -> object:
        """
        Function Name: convert_spark_df_to_pandas_df\n
        Params:
        :param logger: object\n
        :param spark_df: object\n
        :param payload_col_name: string\n
        Returns: pandas dataframe
        """
        try:
            logger.info("*" * 20 + " START: convert_spark_df_to_pandas_df " + "*" * 20)
            df_pandas = spark_df.toPandas()
            df_pandas[payload_col_name] = df_pandas[payload_col_name].apply(
                lambda x: json.loads(x)
            )
            logger.info(
                "Finished converting Spark DF to Pandas DF, returning the dataframe object to main function."
            )
            return df_pandas
        except Exception as err:
            logger.error(f"Issue while converting spark df to pandas df: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("*" * 20 + " END: convert_spark_df_to_pandas_df " + "*" * 20)

    def extract_required_nested_data(
        self,
        logger: object,
        data_obj: dict,
        required_data: list,
        child_key: str,
        children_list: list = None,
        retain_json_parents: list = [],
        retain_json_dict: dict = {},
    ) -> None:
        """
        Function Name: flatten_nested_json\n
        Params:
        :param logger: object\n
        :param data_obj: row\n
        :param required_data: list\n
        Returns: None
        """
        try:
            if isinstance(children_list, list):
                if len(children_list) == 0:
                    if retain_json_dict != {}:
                        required_data.append({**retain_json_dict, **data_obj})
                    else:
                        required_data.append(data_obj)
                else:
                    child_key = children_list[0]
                    for each_obj in data_obj[child_key]:
                        # check if any parents are too be retained
                        if retain_json_parents != []:
                            for parent_ind in range(0, len(retain_json_parents[0]), 2):
                                retain_json_dict[
                                    retain_json_parents[0][parent_ind + 1]
                                ] = data_obj[retain_json_parents[0][parent_ind]]
                        self.extract_required_nested_data(
                            logger,
                            each_obj,
                            required_data,
                            child_key,
                            children_list[1:],
                            retain_json_parents=retain_json_parents[1:],
                            retain_json_dict=retain_json_dict,
                        )

            else:
                if child_key in data_obj.keys():
                    for each_obj in data_obj[child_key]:
                        if child_key in each_obj.keys():
                            self.extract_required_nested_data(
                                logger, each_obj, required_data, child_key
                            )
                        else:
                            if each_obj is not None:
                                required_data.append(each_obj)

        except Exception as err:
            logger.error(f"Issue while extracting required fields: {err}")
            raise SystemError(err) from err

    def pandas_flatten_nested_json(
        self,
        logger: object,
        pandas_df: object,
        parent_node: list,
        children_nodes: list = None,
        conf: dict = None,
    ):
        """
        Function Name: pandas_flatten_nested_json on a pandas dataframe\n
        Params:
        :param logger:  object\n
        :param pandas_df: object\n
        :param parent_node: string\n
        :param chilren_nodes: list\n
        Returns: flattened dictionary
        """
        if parent_node:
            try:
                for col_name in parent_node:
                    logger.info(
                        "*" * 20 + " START: pandas_flatten_nested_json " + "*" * 20
                    )
                    ## normalize the first layer of nested json object using pandas functions ##
                    df_pandas_norm = pd.json_normalize(
                        pandas_df[col_name], sep="_"
                    ).reset_index(drop=True)
                    ## if children_nodes are present apart from root node, then run loops to flatten this nested json ##
                    if children_nodes:
                        required_data = []
                        for _, row in df_pandas_norm.iterrows():
                            for each_obj in row:
                                if "nested_lists_json_children" in conf.keys():
                                    self.extract_required_nested_data(
                                        logger,
                                        each_obj,
                                        required_data,
                                        "",
                                        conf["children_nodes"],
                                        retain_json_parents=conf.get(
                                            "retain_json_parents"
                                        )
                                        or [],
                                    )
                                else:
                                    for each_child in children_nodes:
                                        self.extract_required_nested_data(
                                            logger, each_obj, required_data, each_child
                                        )

                            # for each_child in children_nodes:
                            #     self.extract_required_nested_data(logger, each_obj, required_data, each_child)

                    ## if children_nodes are not present, flatten the json directly ##
                    else:
                        required_data = []
                        for _, row in df_pandas_norm.iterrows():
                            for each_object in row:
                                if each_object is not None:
                                    if (
                                        "json_fields_multiple_format_keys"
                                        in conf.keys()
                                    ):
                                        for key in conf[
                                            "json_fields_multiple_format_keys"
                                        ]:
                                            if key in each_object.keys():
                                                each_object[key] = str(each_object[key])
                                    required_data.append(each_object)

                return required_data

            except Exception as err:
                logger.error(f"Issue while flattening nested json: {err}")
                raise SystemError(err) from err
            finally:
                logger.info("*" * 20 + " END: pandas_flatten_nested_json " + "*" * 20)
        else:
            if "select_root_column" in conf.keys():
                pandas_df = pandas_df[conf["select_root_column"]]
            logger.info(
                "*" * 20 + " END: pandas_flatten_nested_json step skipped " + "*" * 20
            )
            # required_data
            return pandas_df

    def list_flatten_nested_json(
        self,
        logger: object,
        list_obj_str: str,
        parent_node: str,
        children_nodes: list = None,
    ) -> list:
        """
        Function Name: list_flatten_nested_json on a python nested list\n
        Params:
        :param logger: object\n
        :param list_obj_str: string\n
        :param parent_node: string\n
        :param chilren_nodes: list\n
        Returns: flattened dictionary
        """
        try:
            logger.info("*" * 20 + " START: list_flatten_nested_json " + "*" * 20)
            list_obj = json.loads(list_obj_str)
            ## if children_nodes are present apart from root node, then run loops to flatten this nested json ##
            if children_nodes:
                required_data = []
                for each_obj in list_obj[parent_node]:
                    for each_child in children_nodes:
                        self.extract_required_nested_data(
                            logger, each_obj, required_data, each_child
                        )

            ## if children_nodes are not present, flatten the json directly ##
            else:
                required_data = []
                for each_object in list_obj[parent_node]:
                    if each_object is not None:
                        required_data.append(each_object)

            return required_data
        except Exception as err:
            logger.error("Issue while flattening nested json: %s", err)
            raise SystemError(err) from err
        finally:
            logger.info("%s END: list_flatten_nested_json %s", "*" * 20, "*" * 20)

    def json_dict_to_spark_df(
        self, logger: object, records_json_dict: dict, spark: object
    ) -> object:
        """
        Function Name: json_dict_to_df on a python nested list\n
        Params:
        :param logger: object\n
        :param records_json_dict: dict\n
        :param spark: object\n
        Returns: spark dataframe: object
        """
        try:
            logger.info("%s START: json_dict_to_spark_df %s", "*" * 20, "*" * 20)
            pandas_df = (
                pd.DataFrame.from_dict(records_json_dict, orient="index")
                .reset_index()
                .transpose()
            )
            pandas_df.columns = pandas_df.iloc[
                0
            ]  # rename columns by taking value from the first row
            pandas_df = pandas_df[1:]  # drop the first row
            ## typecasting all the columns to string type ##
            schema = StructType(
                [StructField(key, StringType(), True) for key in pandas_df.columns]
            )
            ## replacing NAN with proper null values in pandas dataframe ##
            pandas_df = pandas_df.where(pd.notnull(pandas_df), None)
            ## creating spark dataframe from pandas dataframe ##
            df = spark.createDataFrame(pandas_df, schema)
            return df
        except Exception as e:
            logger.error("Issue while creating dataframe from json dictionary : %s", e)
            raise SystemExit(e) from e
        finally:
            logger.info("%s END: json_dict_to_spark_df %s", "*" * 20, "*" * 20)

    def array_of_json_to_spark_df(
        self, logger: object, array_of_json_dict_list: list, spark: object
    ) -> object:
        """
        Function Name: array_of_json_to_spark_df on a python nested list\n
        Params:
        :param logger: object\n
        :param array_of_json_dict_list: list\n
        :param spark: object\n
        Returns: spark dataframe: object
        """
        try:
            logger.info("%s START: array_of_json_to_spark_df %s", "*" * 20, "*" * 20)
            df = spark.createDataFrame(array_of_json_dict_list)
            return df
        except Exception as e:
            logger.error("Issue while creating dataframe from array of json: %s", e)
            raise SystemExit(e) from e
        finally:
            logger.info("%s END: array_of_json_to_spark_df %s", "*" * 20, "*" * 20)

    def recursive_explode(self, logger: object, df, col_name):
        try:
            # Check if the column type is ArrayType or StructType
            if isinstance(df.schema[col_name].dataType, (ArrayType, StructType)):
                df = df.withColumn(col_name, explode(df[col_name]))
                return self.recursive_explode(logger, df, col_name)
            if isinstance(df.schema[col_name].dataType, (MapType)):
                keys_df = df.select(explode(map_keys(df[col_name]))).distinct()
                new_df = keys_df.withColumn(
                    "nested_cols", concat_ws(".", lit(str(col_name)), keys_df["col"])
                )
                keys_list = new_df.toPandas()["nested_cols"].to_list()
                df = df.selectExpr(keys_list)
                self.convert_spark_df_to_pandas_df(logger, df, keys_list)
                return df
            else:
                pandas_df = df.toPandas()
                return pandas_df
        except SystemError as err:
            logger.error("Issue while exploding the dataframe: %s", err)
            return df.toPandas()

    def process_map_columns(self, input_df):
        map_columns = [
            field.name
            for field in input_df.schema.fields
            if isinstance(field.dataType, MapType)
        ]
        for map_col in map_columns:
            keys_df = input_df.select(
                explode(map_keys(col(map_col))).alias("key")
            ).distinct()
            keys = [row["key"] for row in keys_df.collect()]
            select_expr = [f"{map_col}['{key}'] as {key}" for key in keys]
            other_cols = [c for c in input_df.columns if c != map_col]
            final_df = input_df.selectExpr(*(select_expr + other_cols))
        return final_df


class APIUtils(SparkUtils):
    """
    ClassName: APIUtils\n
    Purpose: This class contains the methods for working with API requests\n
    """

    def __init__(self): ...

    def get_token_from_api(
        self,
        logger: object,
        token_username: str,
        token_password: str,
        conf: dict,
        req_method: str = "POST",
        auth_param: bool = False,
    ) -> object:
        """
        Function Name: get_token_from_api\n
        Params:
        :param logger: object\n
        :param token_username: string\n
        :param token_password: string\n
        :param conf: dict\n
        :param req_method: string (DEFAULT to POST)\n
        :param auth_param: bool (DEFAULT to False)\n
        Returns: response object
        """
        try:
            logger.info("%s START: get_token_from_api %s", "*" * 20, "*" * 20)
            logger.info("Fetching token from api...")
            if auth_param is False:
                header = {"Content-Type": "application/json"}
                data = (
                    "{"
                    + '"email": "{0}", "password": "{1}"'.format(
                        token_username, token_password
                    )
                    + "}"
                )
                response = requests.request(
                    req_method,
                    conf["authentication_endpoint"],
                    headers=header,
                    data=data,
                    timeout=600,
                )
            else:
                response = requests.request(
                    req_method,
                    conf["authentication_endpoint"],
                    auth=(str(token_username), str(token_password)),
                    timeout=600,
                )
            return response
        except Exception as e:
            logger.error("Issue while getting token from API: %s", e)
            raise SystemError(e) from e
        finally:
            logger.info("%s END: get_token_from_api %s", "*" * 20, "*" * 20)

    def api_call_basic_auth(
        self,
        logger: object,
        url: str,
        api_token: str,
        payload: dict = {},
        req_method: str = "POST",
        bearer_auth: bool = False,
        conf: dict = {},
        response_json: dict = {},
        offset: str = "N/A",
    ) -> object:
        """
        Function Name: get_token_from_api\n
        Params:
        :param logger: object\n
        :param token_username: string\n
        :param token_password: string\n
        :param conf: dict\n
        :param req_method: string (DEFAULT to POST)\n
        :param auth_param: bool (DEFAULT to False)\n
        Returns: response object
        """
        try:
            logger.info("*" * 20 + " START: api_call_basic_auth " + "*" * 20)
            if bearer_auth is False:
                headers = {"Token": api_token}
            else:
                headers = {"Authorization": f"Bearer {api_token}"}
            response = requests.request(req_method, url, headers=headers, data=payload)

            if offset != "N/A" and str(response.status_code).startswith("2"):

                json_curr_loop = response.json()
                offset_value = json_curr_loop.get("offset")
                json_curr_loop.pop("offset", None)
                json_next_iteration = {}
                url = conf["api_endpoint"] + "?offset={offset_value}".format(
                    offset_value=offset_value
                )

                if response_json == {}:
                    print(
                        "*" * 20
                        + " response_json is empty. Initializing to current loop json "
                        + "*" * 20
                    )
                    response_json = json_curr_loop

                if offset_value == "N/A" or offset_value is None:
                    return response.json()
                else:
                    response_json = {
                        key: response_json.get(key, [])
                        + json_next_iteration.get(key, [])
                        for key in set(response_json) | set(json_next_iteration)
                    }
                    json_next_iteration = self.api_call_basic_auth(
                        logger,
                        url,
                        api_token,
                        req_method="GET",
                        bearer_auth=True,
                        conf=conf,
                        response_json={},
                        offset=offset_value,
                    )
                    response_json = {
                        key: response_json.get(key, [])
                        + json_next_iteration.get(key, [])
                        for key in set(response_json) | set(json_next_iteration)
                    }

                    return response_json
            else:
                logger.error("api_call_basic_auth failed - response : %s", response)
                logger.error(
                    "api_call_basic_auth failed - response message : %s", response.text
                )

            return response
        except Exception as err:
            logger.error(f"Issue while getting the response from API without ID: {err}")
            raise SystemError(err) from err
        finally:
            logger.info("%s END: api_call_basic_auth %s", "*" * 20, "*" * 20)

    def fetch_api_without_id(
        self,
        logger: object,
        url: str,
        load_date: str,
        current_timestamp: str,
        api_token: str,
        conf: dict,
        job_id: str,
        spark_obj: object,
        payload: dict = {},
        req_method: str = "POST",
        bearer_auth: bool = False,
        offset: str = "N/A",
    ) -> list:
        """
        Function Name: fetch_api_without_id\n
        Params:
        :param logger: object\n
        :param url: string\n
        :param load_date: string\n
        :param current_timestamp: string\n
        :param api_token: string\n
        :param conf: dict\n
        :param job_id: string\n
        :param spark_obj: object\n
        :param payload: dict (DEFAULT to {})\n
        :param req_method: string (DEFAULT to POST)\n
        :param bearer_auth: bool (DEFAULT to False)\n
        Returns: api_response_without_id: list
        """
        try:
            logger.info("*" * 20 + " START: fetch_api_without_id " + "*" * 20)
            api_response_without_id_list = []
            # assigning the load date
            load_date = load_date
            ## calling the api to get details without passing the ID ##
            # response = self.api_call_basic_auth(logger, url, api_token, payload=payload, req_method=req_method, bearer_auth=bearer_auth)
            response = self.api_call_basic_auth(
                logger,
                url,
                api_token,
                payload=payload,
                req_method=req_method,
                bearer_auth=bearer_auth,
                conf=conf,
                offset=offset,
            )
            ## if status code response is of 200, 201, 203 and 204 its ok ##
            if offset != "N/A" or str(response.status_code).startswith("2"):
                record_json = {}
                current_user = self.get_username(logger, spark_obj)
                record_json["batch_id"] = current_timestamp
                record_json["batch_load_tmst"] = current_timestamp
                record_json["job_nm"] = conf["job_name"]
                record_json["job_run_id"] = job_id
                record_json["load_dt"] = load_date
                record_json["id"] = None
                record_json["endpoint"] = url
                record_json["created_by"] = current_user
                record_json["modified_by"] = current_user
                record_json["object_nm"] = conf["object_name"]
                if offset != "N/A":
                    record_json["payload"] = json.dumps(response)
                else:
                    record_json["payload"] = response.text
                api_response_without_id_list.append(record_json)
            else:
                logger.error(
                    "util_api_to_landing : API fetch failed for without id : ", id
                )
                logger.error("util_api_to_landing : response :  ", response.text)
        except requests.exceptions.HTTPError as errh:
            logger.error("*" * 20 + " Error occured HTTPError" + str(errh) + "*" * 20)
            raise SystemExit(errh)
        except requests.exceptions.ConnectionError as errc:
            logger.error("util_api_to_landing:Error Connecting:", errc)
            raise SystemExit(errc)
        except requests.exceptions.Timeout as errt:
            logger.error("util_api_to_landing:Timeout Error:", errt)
            raise SystemExit(errt)
        except requests.exceptions.RequestException as e:
            logger.error("util_api_to_landing:RequestException")
            raise SystemExit(e) from e
        finally:
            logger.info("*" * 20 + " END: fetch_api_without_id " + "*" * 20)
            return api_response_without_id_list

    def fetch_api_with_id(
        self,
        logger: object,
        url: str,
        id: str,
        load_date: str,
        current_timestamp: str,
        api_token: str,
        job_id: str,
        conf: dict,
        spark_obj: object,
        payload: dict = {},
        req_method: str = "POST",
        bearer_auth: bool = False,
    ) -> list:
        """
        Function Name: fetch_api_with_id\n
        Params:
        :param logger: object\n
        :param url: string\n
        :param id: string\n
        :param load_date: string\n
        :param current_timestamp: string\n
        :param api_token: string\n
        :param job_id: string\n
        :param conf: dict\n
        :param spark_obj: object\n
        :param payload: dict (DEFAULT to {})\n
        :param req_method: string (DEFAULT to POST)\n
        :param bearer_auth: bool (DEFAULT to False)\n
        Returns: record_json: list
        """
        try:
            logger.info("*" * 20 + " START: fetch_api_with_id " + "*" * 20)
            load_date = load_date
            invoice = url.format(id=id)
            ## trigger the API to get the items with ID ##
            response = self.api_call_basic_auth(
                logger,
                invoice,
                api_token,
                payload=payload,
                req_method=req_method,
                bearer_auth=bearer_auth,
            )
            ## response code is 200, 201,202,203,204 are ok ##
            if str(response.status_code).startswith("2"):
                record_json = {}
                current_user = self.get_username(logger, spark_obj)
                record_json["batch_id"] = current_timestamp
                record_json["batch_load_tmst"] = current_timestamp
                record_json["job_nm"] = conf["job_name"]
                record_json["job_run_id"] = job_id
                record_json["load_dt"] = load_date
                record_json["id"] = id
                record_json["endpoint"] = invoice
                record_json["created_by"] = current_user
                record_json["modified_by"] = current_user
                record_json["object_nm"] = conf["object_name"]
                record_json["payload"] = response.text
                return record_json
            else:
                logger.error("util_api_to_landing : API fetch failed for id : ", id)
                logger.error("util_api_to_landing : response :  ", response)
                return {}
        except requests.exceptions.HTTPError as errh:
            logger.error("*" * 20 + " Error occured HTTPError" + str(errh) + "*" * 20)
            raise SystemExit(errh)
        except requests.exceptions.ConnectionError as errc:
            logger.error("util_api_to_landing:Error Connecting:", errc)
            raise SystemExit(errc)
        except requests.exceptions.Timeout as errt:
            logger.error("util_api_to_landing:Timeout Error:", errt)
            raise SystemExit(errt)
        except requests.exceptions.RequestException as e:
            logger.error("util_api_to_landing:RequestException")
            raise SystemExit(e) from e
        finally:
            logger.info("*" * 20 + " END: fetch_api_with_id " + "*" * 20)


class BoxToS3Utils:
    """
    ClassName: BoxToS3Utils.\n
    Purpose: This class contains the methods for reading/copying data from Box folder.\n
    """

    def __init__(self): ...

    def get_timestamp(self, logger: object) -> str:
        """
        Function Name: get_timestamp\n
        Params: logger: object\n
        Returns: formatted timestamp: string
        """
        try:
            logger.info("*" * 20 + " START: get_timestamp" + "*" * 20)
            current_datetime = datetime.now()
            formatted_datetime = current_datetime.strftime("%Y%m%d%H%M%S")
            return formatted_datetime

        except Exception as e:
            logger.error("get_timestamp - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: get_timestamp" + "*" * 20)

    def get_secrets_from_databricks(
        self, logger: object, bf_context: object, scope: str
    ) -> tuple:
        """
        Function Name: get_secrets_from_databricks\n
        Purpose: Fetches secrets from databricks\n
        Params:
        :param logger: object\n
        :param bf_context: object\n
        :param scope: string\n
        Returns: secrets: tuple
        """
        try:
            logger.info("*" * 20 + " START: get_secrets_from_databricks" + "*" * 20)
            client_id = bf_context.dbutils.secrets.get(scope=scope, key="client_id")
            client_secret = bf_context.dbutils.secrets.get(
                scope=scope, key="client_secret"
            )
            enterprise_id = bf_context.dbutils.secrets.get(
                scope=scope, key="enterprise_id"
            )
            jwt_key_id = bf_context.dbutils.secrets.get(scope=scope, key="jwt_key_id")
            rsa_private_key_data = bf_context.dbutils.secrets.get(
                scope=scope, key="rsa_private_key_data"
            )
            rsa_private_key_passphrase = bf_context.dbutils.secrets.get(
                scope=scope, key="rsa_private_key_passphrase"
            )
            return (
                client_id,
                client_secret,
                enterprise_id,
                jwt_key_id,
                rsa_private_key_data,
                rsa_private_key_passphrase,
            )
        except Exception as e:
            logger.error("get_secrets_from_databricks - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: get_secrets_from_databricks" + "*" * 20)

    def get_files_list(
        self, logger: object, conf: dict, client: object, src_box_id: str
    ) -> dict:
        """
        Function Name: get_files_list\n
        Purpose: Prepares list of files to be copied/processed
        Params:
        :param logger: object\n
        :param conf: dict\n
        :param client: object\n
        :param src_box_id: string\n
        Returns: files_dict: dict
        """
        try:
            logger.info("*" * 20 + " START: get_files_list" + "*" * 20)
            files_dict = dict()
            logger.info("Getting contents of folder: " + str(src_box_id))
            items = client.folder(folder_id=src_box_id).get_items()
            folders = filter(lambda x: x.type == "folder", items)
            items = client.folder(folder_id=src_box_id).get_items()
            files = filter(lambda x: x.type == "file", items)

            # Dealing with files
            if "last_run" in conf:
                logger.info("Filtering based on last run: " + conf["last_run"])
                for file_obj in files:
                    obj_ts = parse(
                        str(file_obj.get()["modified_at"])
                        .rsplit("-", 1)[0]
                        .replace("T", " ")
                    )
                    last_ts = parse(conf["last_run"])
                    if obj_ts > last_ts:
                        files_dict[file_obj.get()["id"]] = [
                            src_box_id,
                            file_obj.get()["name"],
                            str(file_obj.get()["modified_at"]),
                        ]
            else:
                for file_obj in files:
                    files_dict[file_obj.get()["id"]] = [
                        src_box_id,
                        file_obj.get()["name"],
                        str(file_obj.get()["modified_at"]),
                    ]

            # Dealing with folders
            if conf["sub_folders_flag"].lower().startswith("y") or conf[
                "sub_folders_flag"
            ].lower().startswith("t"):
                for folder_obj in folders:
                    files_dict.update(
                        self.get_files_list(
                            conf, client, folder_obj.get()["id"]
                        )  # pylint: disable=no-value-for-parameter
                    )

            logger.info(str(files_dict))
            return files_dict

        except Exception as e:
            logger.error("get_files_list - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: get_files_list" + "*" * 20)

    def parse_files(
        self,
        logger: object,
        conf: dict,
        client: object,
        files_dict: dict,
        archive_id: str = None,
    ) -> None:
        """
        Function Name: parse_files\n
        Purpose: Renames files and initiates the copy and archive
        Params:
        :param logger: object\n
        :param conf: dict\n
        :param client: object\n
        :param files_dict: dict\n
        :param archive_id: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: parse_files" + "*" * 20)
            if not files_dict:
                logger.info("The Box location has no files")
            else:
                logger.info("Downloading Files...")
                for file_id, values_list in files_dict.items():
                    logger.info("file_id: " + str(file_id))
                    src_box_id = values_list[0]
                    logger.info("src_box_id: " + str(src_box_id))
                    file_name = values_list[1]
                    logger.info("file_name: " + str(file_name))
                    modified_at = values_list[2]
                    logger.info("modified_at: " + modified_at)
                    if "handle_duplicates" in conf and (
                        conf["handle_duplicates"].lower().startswith("y")
                        or conf["handle_duplicates"].lower().startswith("t")
                    ):
                        renamed_file = (
                            conf["timestamp"]
                            + conf["file_name_separator"]
                            + src_box_id
                            + conf["file_name_separator"]
                            + file_name
                        )
                    else:
                        renamed_file = (
                            conf["timestamp"] + conf["file_name_separator"] + file_name
                        )
                    file_patterns = conf["input_file_pattern"]
                    for file_pattern in file_patterns:
                        pattern_match = fnmatch.fnmatch(file_name, file_pattern)
                        if str(pattern_match) == "True":
                            logger.info("Calling copy_box_to_s3 function...")
                            self.copy_box_to_s3(
                                logger, conf, client, file_id, file_name, renamed_file
                            )
                            if conf["archive_flag"].lower().startswith("y") or conf[
                                "archive_flag"
                            ].lower().startswith("t"):
                                logger.info(
                                    "Archiving Files in Box Folder:" + file_name
                                )
                                client.file(file_id=file_id).move(
                                    client.folder(folder_id=archive_id), renamed_file
                                )
        except Exception as e:
            logger.error("parse_files - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: parse_files" + "*" * 20)

    def copy_box_to_s3(
        self,
        logger: object,
        conf: dict,
        client: object,
        file_id: str,
        file_name: str,
        renamed_file: str,
    ) -> None:
        """
        Function Name: parse_files\n
        Purpose: Copies file to S3
        Params:
        :param logger: object\n
        :param conf: dict\n
        :param client: object\n
        :param file_id: string\n
        :param file_name: string\n
        :param renamed_file: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: copy_box_to_s3" + "*" * 20)
            s3_dest = conf["target_path"]
            content = client.file(file_id).content()
            file_path = s3_dest + "/" + renamed_file

            ## if folders are not created in volume/S3 location, create them before exporting file to S3/Volume ##
            if not os.path.exists(s3_dest):
                os.makedirs(s3_dest)

            with open(file_path, "wb") as file_loc:
                file_loc.write(content)
                logger.info(f"{file_name} written to location: {s3_dest}")

            ## if the file format is csv, output the csv that has correct format ##
            if os.path.splitext(os.path.basename(renamed_file))[-1] == ".csv":
                logger.info("CSV file will be formatted correctly to avoid issues.")
                df = pd.read_csv(file_path)
                df = df.where(pd.notnull(df), "")
                # Replace linebreaks in cells and strip extra spaces for csv file ##
                df.replace({"\n": ";"}, regex=True, inplace=True)
                df = df.applymap(lambda x: x.split(";") if isinstance(x, str) else x)
                for each in df.columns:
                    df[each] = df[each].astype(str).str.replace("\[|\]|'", "")
                    df[each] = df[each].fillna("")
                    df[each] = df[each].astype(str).str.strip()
                df.to_csv(file_path, index=False)
                logger.info(
                    f"{file_name} re-written to location with correct format: {s3_dest}"
                )

            logger.info("Copying file from box to s3:" + file_name)

        except Exception as e:
            logger.error("copy_box_to_s3 - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: copy_box_to_s3" + "*" * 20)


class AlertUtils(QueryUtils, SparkUtils, JSONUtils):
    """
    ClassName: AlertUtils.\n
    Purpose: This class contains the methods for sending email/slack alerts.\n
    """

    def __init__(self):
        self.uuid_list = []
        # self.send_email = False

    def get_table_content(
        self, logger: object, column_name_list: list, row_values_list: list
    ) -> str:
        """
        Function Name: get_table_content\n
        Purpose: created a string table out of rows and column values
        Params:
        :param logger: object\n
        :param conf: dict\n
        :param column_name_list: list\n
        :param row_values_list: list\n
        Returns: table: string
        """
        try:
            logger.info("*" * 20 + " START: get_table_content" + "*" * 20)
            x = PrettyTable()
            x.field_names = column_name_list
            x.add_rows([row_values_list])
            table = x.get_string()
            return table

        except Exception as e:
            logger.error("get_table_content - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: get_table_content" + "*" * 20)

    def get_detailed_payload_for_slack_alert(
        self, logger: object, count_and_headers_flag: bool = True
    ) -> dict:
        """
        Function Name: get_detailed_payload\n
        Purpose: creates a detailed payload for slack alert including header and content in alert message\n
        Params:
        :param logger: object\n
        :param count_and_headers_flag: bool (Default set to True)\n
        Returns: detailed_payload: dict
        """
        try:
            logger.info(
                "*" * 20 + " START: get_detailed_payload_for_slack_alert" + "*" * 20
            )
            detailed_inner_payload = {}
            detailed_inner_payload["type"] = "section"
            detailed_inner_payload["text"] = {}
            detailed_inner_payload["text"]["type"] = "mrkdwn"
            if count_and_headers_flag:
                detailed_inner_payload["text"]["text"] = "{}\n```{}```\n"
            else:
                detailed_inner_payload["text"]["text"] = "```{}```\n"
            detailed_payload = {}
            detailed_payload["blocks"] = []
            detailed_payload["blocks"].append(detailed_inner_payload)
            return detailed_payload
        except Exception as err:
            logger.error(
                "get_detailed_payload_for_slack_alert - error : {}".format(str(err))
            )
            sys.exit(1)
        finally:
            logger.info(
                "*" * 20 + " END: get_detailed_payload_for_slack_alert" + "*" * 20
            )

    def send_slack_alert(self, logger: object, spark_obj: object, conf: dict) -> None:
        """
        Function Name: send_slack_alert\n
        Purpose: sends a slack alert with the message body enclosed in it
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: send_slack_alert" + "*" * 20)
            ## initialize the variables with default values ##
            table_header = ""
            ## read the alerts table to get the unprocessed and failed records ##
            unprocessed_slack_records_df = spark_obj.sql(
                f"SELECT * FROM {conf['alert_complete_table_name']} WHERE status in ('UNPROCESSED', 'FAILED') and alert_type like '%slack%'"
            )
            logger.info(
                f"Number of unprocessed records for slack from alerts table: {unprocessed_slack_records_df.count()}"
            )
            ## Convert the DataFrames to pandas for easier processing ##
            slack_alerts = unprocessed_slack_records_df.toPandas()
            ## group the dataframe by alert_to column ##
            slack_alerts_grouped = slack_alerts.groupby("alert_to")
            ## run a loop to send slack alerts for each group ##
            for each_receiver, group in slack_alerts_grouped:
                ## initialize the variables with default values ##
                self.uuid_list = []
                ## get the pretty table content from the dataframe ##
                table = self.get_table_content(
                    logger, group.columns, group.values.tolist()
                )
                ## get the distinct UUID list from unprocessed and failed records ##
                self.uuid_list = (
                    group.select("alert_UUID")
                    .distinct()
                    .rdd.flatMap(lambda x: x)
                    .collect()
                )
                ## based on the number of records in the group, send the slack alert ##
                if len(group) > 0:
                    detailed_payload = {}
                    # self.send_email = True
                    ## get the table header based on the number of records in the group ##
                    table_header = (
                        "Alerts generated for the latest workflow execution: \n"
                    )
                    detailed_payload = self.get_detailed_payload_for_slack_alert(logger)
                    detailed_payload["blocks"][0]["text"]["text"] = detailed_payload[
                        "blocks"
                    ][0]["text"]["text"].format(table_header, table)
                    try:
                        # send payload using requests module via webhook
                        requests.post(each_receiver, json=detailed_payload)
                        logger.info(
                            f"Slack alert sent successfully to receiver: {each_receiver}"
                        )
                        ## update the alerts table with status as PROCESSED ##
                        self.update_alerts_table(
                            logger, spark_obj, conf, status="PROCESSED"
                        )
                    except Exception as e:
                        ## update the alerts table with status as FAILED ##
                        self.update_alerts_table(
                            logger, spark_obj, conf, status="FAILED"
                        )
                        logger.error(
                            "send_slack_alert while calling requests module to send slack alert - error : {}".format(
                                str(e)
                            )
                        )
                        continue
                else:
                    text_only_payload = {}
                    ## get the table header based on the number of records in the group ##
                    table_header = (
                        "No Alerts generated for the latest workflow execution.\n"
                    )
                    text_only_payload = self.get_detailed_payload_for_slack_alert(
                        logger, count_and_headers_flag=False
                    )
                    text_only_payload["blocks"][0]["text"]["text"] = text_only_payload[
                        "blocks"
                    ][0]["text"]["text"].format(table_header)
                    try:
                        ## send payload using requests module via webhook ##
                        requests.post(each_receiver, json=text_only_payload)
                        logger.info(
                            f"Slack alert sent successfully to receiver: {each_receiver}"
                        )
                        self.update_alerts_table(
                            logger, spark_obj, conf, status="PROCESSED"
                        )
                    except Exception as e:
                        ## update the alerts table with status as FAILED ##
                        self.update_alerts_table(
                            logger, spark_obj, conf, status="FAILED"
                        )
                        logger.error(
                            "send_slack_alert while calling requests module to send slack alert - error : {}".format(
                                str(e)
                            )
                        )
                        continue
        except Exception as e:
            logger.error("send_slack_alert - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: send_slack_alert" + "*" * 20)

    def send_alert_notification(
        self, logger: object, spark_obj: object, conf: dict, env: str
    ) -> dict:
        """
        Function Name: send_alert_notification\n
        Purpose: sends a slack alert and email alert with the message body enclosed in it
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: payload: dict
        """
        try:
            logger.info("*" * 20 + " START: send_alert_notification" + "*" * 20)
            ## complete table name  = db + table name ##
            conf["alert_complete_table_name"] = (
                conf["alert_database_name"] + "." + conf["alert_table_name"]
            )
            ## get the unprocessed and failed records from alerts table ##
            conf["subject"] = (
                conf.get("subject") or f"SDF Automated Alert Notifications - {env}"
            )
            ## read the email template file ##
            with open(
                os.path.join(
                    conf["email_template_dir"], conf["email_template_file_name"]
                ),
                "r",
            ) as fp:
                email_body = fp.read()

            ## read the alerts table to get the unprocessed and failed records ##
            unprocessed_email_records_df = spark_obj.sql(
                f"SELECT * FROM {conf['alert_complete_table_name']} WHERE alert_status in ('UNPROCESSED', 'FAILED') and alerts_from like '%a.ecorangers.{env}%'"
            )
            logger.info(
                f"Number of unprocessed records for email from alerts table: {unprocessed_email_records_df.count()}"
            )
            if unprocessed_email_records_df.count() > 0:
                ## Convert the DataFrames to pandas for easier processing ##
                email_alerts = unprocessed_email_records_df.toPandas()
                ## group the dataframe by alert_to column ##
                email_alerts_grouped = email_alerts.groupby(
                    ["alerts_to", "alerts_from"]
                )
                ## run a loop to send slack alerts for each group ##
                for name, group in email_alerts_grouped:
                    self.uuid_list = []
                    self.uuid_list = list(set(group["alert_UUID"].tolist()))
                    each_receiver = list(set(group["alerts_to"].tolist()))
                    each_sender = list(set(group["alerts_from"].tolist()))
                    conf["alert_from"] = each_sender[0]
                    conf["team_email"] = (
                        ", ".join(each_receiver) + "," + conf["team_email"]
                    )
                    ## get only 300 characters for sending emails ##
                    group["alert_description"] = group["alert_description"].str[:300]
                    ## select only the required columns from the dataframe ##
                    group = group[conf["email_columns"]]
                    # converts nextline characters to HTML equivalent
                    conf["body"] = email_body.format(
                        group.to_html(index=False), conf["team_email"]
                    )

                    try:
                        AlertUtils().send_mail(logger, conf, env)
                        logger.info(
                            f"Email alert sent successfully to receiver: {each_receiver}"
                        )
                        self.update_alerts_table(
                            logger, spark_obj, conf, status="PROCESSED"
                        )
                    except Exception as err:
                        logger.error("send_email_alert - error : {}".format(str(err)))
                        self.update_alerts_table(
                            logger, spark_obj, conf, status="FAILED"
                        )
                        sys.exit(1)
            else:
                logger.info("No alerts to send email.")
        except Exception as e:
            logger.error("send_alert_notification - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: send_alert_notification" + "*" * 20)

    def generate_alerts_dictionary(
        self, logger: object, conf, priority: str, err: str
    ) -> dict:
        """
        Function Name: generate_alerts_dictionary\n
        Purpose: generates a dictionary of alerts to be sent\n
        Params:
        :param logger: object\n
        :param conf: dict\n
        :param priority: string\n
        :param err: string\n
        Returns: alerts_dict: dict
        """
        try:
            logger.info("*" * 20 + " START: generate_alerts_dictionary" + "*" * 20)
            ## add the slack alert details to the config dictionary ##
            conf["alert_type"] = "slack_and_email"
            conf["alert_severity"] = priority
            conf["alert_summary"] = f"Error In - {conf['function_name']}()"
            conf["alert_description"] = f"{err}"
            conf["alert_to"] = conf["slack_channel_email"]
            conf["alert_cc"] = conf["team_email"]
            return conf
        except Exception as err:
            logger.error("generate_alerts_dictionary - error : {}".format(str(err)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: generate_alerts_dictionary" + "*" * 20)

    def send_email_alert_deprecated(
        self, logger: object, spark_obj: object, conf: dict, env: str
    ) -> None:
        """
        Function Name: send_email_alert\n
        Purpose: sends an email alert with the message body enclosed in it
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: send_email_alert" + "*" * 20)
            ## get the smtp details from config and cerberus parameters ##
            smtp_host = conf["smtp_host"]
            smtp_port = conf["smtp_port"]
            email_user = conf["smtp_username"]
            email_password = conf["smtp_password"]
            email_subject = f"SDF-ITC Automated Alert Notifications - {env}"
            ## read the email template file ##
            with open(
                os.path.join(
                    conf["email_template_dir"], conf["email_template_file_name"]
                ),
                "r",
            ) as fp:
                email_body = fp.read()

            msg = MIMEMultipart()
            ## read the alerts table to get the unprocessed and failed records ##
            unprocessed_email_records_df = spark_obj.sql(
                f"SELECT * FROM {conf['alert_complete_table_name']} WHERE alert_status in ('UNPROCESSED', 'FAILED') and alerts_from like '%a.ecorangers.{env}%'"
            )
            logger.info(
                f"Number of unprocessed records for email from alerts table: {unprocessed_email_records_df.count()}"
            )
            if unprocessed_email_records_df.count() > 0:
                ## Convert the DataFrames to pandas for easier processing ##
                email_alerts = unprocessed_email_records_df.toPandas()
                ## group the dataframe by alert_to column ##
                email_alerts_grouped = email_alerts.groupby(
                    ["alerts_to", "alerts_from"]
                )
                ## run a loop to send slack alerts for each group ##
                for name, group in email_alerts_grouped:
                    self.uuid_list = []
                    self.uuid_list = list(set(group["alert_UUID"].tolist()))
                    each_receiver = list(set(group["alerts_to"].tolist()))
                    each_sender = list(set(group["alerts_from"].tolist()))
                    msg["Subject"] = email_subject
                    msg["From"] = each_sender[0]
                    msg["To"] = ", ".join(each_receiver)
                    msg["Cc"] = ", ".join([conf["team_email"]])
                    msg["Date"] = datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
                    ## get only 300 characters for sending emails ##
                    group["alert_description"] = group["alert_description"].str[:300]
                    ## select only the required columns from the dataframe ##
                    group = group[conf["email_columns"]]
                    # converts nextline characters to HTML equivalent
                    html_msg_string = email_body.format(
                        group.to_html(index=False), conf["team_email"]
                    )
                    msg.attach(MIMEText(html_msg_string, "html"))

                    try:
                        server = smtplib.SMTP(smtp_host, smtp_port)
                        server.starttls()
                        server.ehlo()
                        server.login(user=email_user, password=email_password)
                        text = msg.as_string()
                        recipients_list = each_receiver + [conf["team_email"]]
                        server.sendmail(msg["From"], recipients_list, text)
                        logger.info(
                            f"Email alert sent successfully to receiver: {each_receiver}"
                        )

                        self.update_alerts_table(
                            logger, spark_obj, conf, status="PROCESSED"
                        )
                        server.quit()
                    except Exception as err:
                        logger.error("send_email_alert - error : {}".format(str(err)))
                        self.update_alerts_table(
                            logger, spark_obj, conf, status="FAILED"
                        )
                        sys.exit(1)
            else:
                logger.info("No alerts to send email.")
        except Exception as e:
            logger.error("send_email_alert - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: send_email_alert" + "*" * 20)

    def update_alerts_table(
        self: object,
        logger: object,
        spark_obj: object,
        conf: dict,
        status: str = "PROCESSED",
    ) -> None:
        """
        Function Name: update_alerts_table\n
        Purpose: updates the alerts table with the details of the job run
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param status: string (by default set to PROCESSED)\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: update_alerts_table" + "*" * 20)
            ## complete table name  = db + table name ##
            conf["alert_complete_table_name"] = (
                conf["alert_database_name"] + "." + conf["alert_table_name"]
            )
            if len(self.uuid_list) == 1:
                uuid_tuple = tuple(self.uuid_list + self.uuid_list)
            else:
                uuid_tuple = tuple(self.uuid_list)
            logger.info(f"Tuple list that will set to processed : {uuid_tuple}")
            sql_query = f"""UPDATE {conf['alert_complete_table_name']} SET alert_status='{status}' WHERE alert_UUID in {uuid_tuple}"""
            logger.info(f"Running SQL query: {sql_query}")
            df = self.execute_spark_sql(spark_obj, sql_query)
            logger.info("Alert table updated successfully.")
        except Exception as e:
            logger.error(
                "Issue while updating data into alerts table - error : {}".format(
                    str(e)
                )
            )
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: update_alerts_table" + "*" * 20)

    def load_alerts_table(
        self: object,
        logger: object,
        spark_obj: object,
        run_id: str,
        conf: dict,
        status: str = "UNPROCESSED",
    ) -> None:
        """
        Function Name: load_alerts_table\n
        Purpose: loads the alerts table with the details of the job run
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param run_id: str\n
        :param conf: dict\n
        :param status: string (by default set to UNPROCESSED)\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: load_alerts_table" + "*" * 20)
            alerts_dict = {}
            ## complete table name  = db + table name ##
            conf["alert_complete_table_name"] = (
                conf["alert_database_name"] + "." + conf["alert_table_name"]
            )
            ## getting current job id using dbutils ##
            conf["job_run_id"] = str(run_id)
            schema = StructType(
                [
                    StructField("alert_UUID", StringType(), nullable=False),
                    StructField("alert_type", StringType(), nullable=True),
                    StructField("alert_severity", StringType(), nullable=True),
                    StructField("object_name", StringType(), nullable=True),
                    StructField("alert_summary", StringType(), nullable=True),
                    StructField("alert_description", StringType(), nullable=True),
                    StructField("alert_status", StringType(), nullable=True),
                    StructField("alerts_from", StringType(), nullable=True),
                    StructField("alerts_to", StringType(), nullable=True),
                    StructField("alerts_cc", StringType(), nullable=True),
                    StructField("job_run_id", StringType(), nullable=True),
                    StructField("job_name", StringType(), nullable=True),
                    StructField("insert_timestamp", StringType(), nullable=True),
                ]
            )
            ## generating the alert dictionary for final load ##
            alerts_dict["alert_UUID"] = [str(uuid.uuid4())]
            alerts_dict["alert_type"] = [conf["alert_type"]]
            alerts_dict["alert_severity"] = [conf["alert_severity"].upper()]
            alerts_dict["object_name"] = [conf["object_name"]]
            alerts_dict["alert_summary"] = [conf["alert_summary"]]
            alerts_dict["alert_description"] = [conf["alert_description"]]
            alerts_dict["alert_status"] = [status.upper()]
            alerts_dict["alerts_from"] = [conf.get("alert_from")]
            alerts_dict["alerts_to"] = [conf.get("alert_to")]
            alerts_dict["alerts_cc"] = [conf.get("alert_cc")]
            alerts_dict["job_run_id"] = [conf["job_run_id"]]
            alerts_dict["job_name"] = [conf["job_name"]]
            alerts_dict["insert_timestamp"] = [datetime.now().strftime("%Y%m%d%H%M%S")]

            logger.info(
                "Created the alert dictionary, ready to load it to audit table."
            )
            ## create audit dataframe using the alert dictionary with help of spark context ##
            column_names, data = zip(*alerts_dict.items())
            alert_dataframe = spark_obj.createDataFrame(zip(*data), schema=schema)

            ## re-order the columns based on config for alert columns ##
            alert_dataframe = alert_dataframe.select(conf["alert_table_columns"])

            ## Setting write mode to append_only for alerts ##
            conf["write_mode"] = "append"

            ## write the audit dataframe to delta table ##
            self.write_dataframe_to_delta(
                logger,
                spark_obj,
                conf,
                alert_dataframe,
                conf["alert_complete_table_name"],
                tech_solution_id=conf["tech_solution_id"],
                cloudred_gid=conf["cloudred_gid"],
                do_partition=False,
                update_tags=False,
                set_not_null_constraint=False,
            )
            logger.info("Alert table loaded successfully.")

        except Exception as e:
            logger.error(
                "Issue while loading data into alerts table - error : {}".format(str(e))
            )
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: load_alerts_table" + "*" * 20)

    def send_email_deprecated(self, df, logger, conf, env, identifier):
        try:
            logger.info("*" * 20 + " START: send email functionality" + "*" * 20)
            df_new = df.toPandas()
            html_table = df_new.to_html()
            sender_email = conf["alert_from"]
            team_email = conf["team_email"]
            recipients_list = team_email.split(",")
            subject = f"SDF-ITC Info Schema Alert Notifications - {env}"
            message = MIMEMultipart()
            message["To"] = team_email
            message["From"] = sender_email
            message["Subject"] = subject
            # ---
            # Convert the DataFrame to HTML
            html = df_new.to_html(index=False)
            # Create the HTML message
            body = f"""
            <!DOCTYPE html>
            <html>
                <head>
                    <style> 
                        table, th, td {{font-size:10pt; border:1px solid black; border-collapse:collapse; text-align:left; width:100%;}}
                        th, td {{padding: 5px;}}
                    </style>
                </head>
                <body>
                    Hi Team, Please find the list of tables in {identifier} for which the ownership needs to be changed! <br/><br/>
                    {html}
                    <br/><br/>
                    Note: This is an automated email, please do not reply to this email.<br>
                    Please reach out to : {team_email} for any queries.
                </body>
            </html>
            """

            message.attach(MIMEText(body, "html"))
            smtpobj = smtplib.SMTP("smtp.office365.com", port=587)
            smtpobj.starttls()
            smtpobj.ehlo()
            smtpobj.login(user=conf["username"], password=conf["password"])
            smtpobj.sendmail(sender_email, recipients_list, message.as_string())
        except Exception as e:
            logger.error("Issue in send_email : {}".format(str(e)))
            sys.exit(1)

        finally:
            logger.info("*" * 20 + " END: send_email" + "*" * 20)

    def send_info_site_alerts(
        self, logger: object, spark: object, conf: dict, env: str
    ) -> dict:
        """
        Function Name: send_info_site_alerts\n
        Purpose: Sends alerts from the information schema
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: send_info_site_alerts" + "*" * 20)

            query = f"""SELECT distinct location_nm, location_nbr, lease_number_desc,cost_usage_data_source_nm, alert_desc,resolution_desc FROM 
            {conf['alert_database_name']}.{conf['alert_table_nmae']} 
            WHERE BATCH_LOAD_TMST IN (select batch_time from (select cost_usage_data_source_nm ,max(BATCH_LOAD_TMST) as batch_time from {conf['alert_database_name']}.{conf['alert_table_nmae']} group by cost_usage_data_source_nm)) order by 2;"""

            df_site_info = SparkUtils.execute_spark_sql(self, spark, query)

            # Convert the dataframe to pandas dataframe
            df_site_info = df_site_info.toPandas()

            if not df_site_info.empty:
                html = df_site_info.to_html(index=False)
                identifier = "multi_site_info table"
                conf["body"] = conf["body"].format(
                    identifier=identifier, html=html, team_email=conf["team_email"]
                )
                AlertUtils().send_mail(logger, conf, env)
            else:
                logger.error("No site available in site info table ")

        except Exception as e:
            logger.error("Issue in send_info_site_alerts : {}".format(str(e)))
            sys.exit(1)

        finally:
            logger.info("*" * 20 + " END: send_info_site_alerts" + "*" * 20)

    def send_Info_Schema_Alerts(
        self, logger: object, spark: object, conf: dict, env: str
    ) -> dict:
        """
        Function Name: send_Info_Schema_Alerts\n
        Purpose: Sends alerts from the information schema
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: send_Info_Schema_Alerts" + "*" * 20)

            databricks_query = f"""SELECT table_catalog, table_schema, table_name, table_owner,'databricks' as source FROM 
            {conf['databricks_catalog']}.information_schema.tables 
            WHERE table_schema = '{conf['databricks_schema']}' 
            AND table_owner LIKE '%nike.com%';"""

            df_databricks = SparkUtils.execute_spark_sql(self, spark, databricks_query)

            snowflake_query = f"""SELECT DISTINCT TABLE_CATALOG, table_Schema, table_name, table_owner,'snowflake' as source
            FROM account_usage.account_usage.tables
            WHERE
            table_catalog in ('{conf['sfdatabase']}')
            AND table_schema IN ({conf['snowflake_schema']})
            AND table_owner LIKE '%DF_%' and deleted is null;"""

            df_snowflake = SparkUtils.run_snowflake_queries_as_spark_df(
                self, logger, spark, conf, snowflake_query
            )

            # Union of databricks and snowflake dataframes
            union_df = df_databricks.union(df_snowflake)
            # Convert the union dataframe to pandas dataframe
            union_df = union_df.toPandas()

            if not union_df.empty:
                html = union_df.to_html(index=False)
                identifier = "databricks and snowflake"
                conf["body"] = conf["body"].format(
                    identifier=identifier, html=html, team_email=conf["team_email"]
                )
                AlertUtils().send_mail(logger, conf, env)
            else:
                logger.error("No error in snowflake schema")

        except Exception as e:
            logger.error("Issue in send_info_schema_alerts : {}".format(str(e)))
            sys.exit(1)

        finally:
            logger.info("*" * 20 + " END: send_info_schema_alerts" + "*" * 20)

    def alerts_wf_sla_check(
        self,
        logger: object,
        spark: object,
        conf: dict,
        env: str,
        batch_id_end: str = None,
    ) -> None:
        """
        Function Name: alerts_wf_sla_check\n
        Purpose: Sends alerts regarding SLA
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: alerts_wf_sla_check" + "*" * 20)
            batch_complete_table_name = (
                conf["target_database_name"] + "." + "sdf_batch_load_tracker"
            )
            batch_id = str(
                spark.sql(
                    f"SELECT batch_id FROM {batch_complete_table_name} where status in ('RUNNING') and env = '{env}' and project_name = '{conf['project_name']}'"
                ).head()[0]
            )
            batch_id_parsed = datetime.strptime(batch_id, "%Y%m%d%H%M%S")
            diff_minutes = int(
                (
                    (
                        datetime.now()
                        - (
                            datetime.strptime(batch_id_end, "%Y-%m-%d %H:%M:%S.%f")
                            if batch_id_end
                            else batch_id_parsed
                        )
                    ).total_seconds()
                    / 60
                )
            )
            if diff_minutes > conf["sla"]:
                logger.info("*" * 20 + " SLA Crossed " + "*" * 20)
                conf["subject"] = f"SDF-ITC SLA Alert Notifications - {env}"
                conf["body"] = conf["body"].format(
                    wf_name=conf["wf_name"],
                    env=env,
                    diff_minutes=diff_minutes,
                    sla=conf["sla"],
                    team_email=conf["team_email"],
                )
                AlertUtils().send_mail(logger, conf, env)
        except Exception as e:
            logger.error("Issue in alerts_wf_sla_check : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: alerts_wf_sla_check" + "*" * 20)

    def send_mail(
        self, logger: object, conf: dict, env: str = "dev", excel_buffer=None
    ) -> None:
        """
        Function Name: send_mail\n
        Purpose: Sends alerts. Body & subject should be be pre defined in configs else it will take default values
        Params:
        :param logger: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: send_mail" + "*" * 20)
            message = MIMEMultipart()
            message["From"] = sender_email = conf["alert_from"]
            message["To"] = team_email = conf["team_email"]
            slack_channel_email = conf.get("slack_channel_email")
            # recipients_list = team_email.split(",")
            if (
                slack_channel_email is not None
            ):  # if slack channel email is provided, then add it to the recipients list other wise send to outlook
                recipients_list = [
                    *team_email.split(","),
                    *slack_channel_email.split(","),
                ]
            else:
                recipients_list = [*team_email.split(",")]
            message["Subject"] = (
                conf.get("subject") or f"SDF-ITC Alert Notifications - {env}"
            )
            message["Date"] = datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
            body = conf.get("body") or f"SDF-ITC Alert Notifications - {env}"
            message.attach(MIMEText(body, "html"))

            if conf.get("attachment_details"):
                # Add attachment to the message
                part = MIMEBase("application", "octet-stream")
                part.set_payload(excel_buffer.read())
                encoders.encode_base64(part)
                part.add_header(
                    "Content-Disposition",
                    # 'attachment; filename="tables.xlsx"'
                    f'attachment; filename="'
                    + conf.get("attachment_details", {}).get("filename")
                    + '"',
                )
                message.attach(part)

            smtpobj = smtplib.SMTP(conf["smtp_host"], conf["smtp_port"])
            smtpobj.starttls()
            smtpobj.ehlo()
            smtpobj.login(user=conf["username"], password=conf["password"])
            smtpobj.sendmail(sender_email, recipients_list, message.as_string())
            smtpobj.quit()
        except Exception as e:
            logger.error("Issue in send_mail : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: send_mail" + "*" * 20)

    def sendmail_site_alerts(
        self,
        logger: object,
        spark: object,
        conf: dict,
        env: str,
        actual_over_extrpltion: bool = False,
    ) -> dict:
        """
        Function Name: send_info_site_alerts\n
        Purpose: Sends alerts from the information schema
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: sendmail_site_alerts" + "*" * 20)
            if actual_over_extrpltion:
                conf["alert_location_table_name"] = conf[
                    "actual_over_extpltion_table_name"
                ]
                query = f"""select 
                location_nm, location_nbr, service_type_nm, lease_number_desc, department_nm, extrapolation_ind, scope_nbr, data_prvdr
                FROM 
                {conf['alert_database_name']}.{conf['alert_location_table_name']} 
                where status = 'UNPROCESSED' order by 1,2,3 """

            else:
                query = f"""select 
                location_nm, location_nbr, service_type_nm, lease_number_desc, department_nm, extrapolation_ind, scope_nbr, data_prvdr, location_nm_ind, location_nbr_ind, service_type_nm_ind
                FROM 
                {conf['alert_database_name']}.{conf['alert_location_table_name']} 
                where status = 'UNPROCESSED' order by 1,2,3 """

            df_site_info = SparkUtils.execute_spark_sql(self, spark, query)

            # Convert the dataframe to pandas dataframe
            df_site_info = df_site_info.toPandas()

            if not df_site_info.empty:
                html = df_site_info.to_html(index=False)
                identifier = conf["alert_location_table_name"]
                conf["body"] = conf["body"].format(
                    identifier=identifier, html=html, team_email=conf["team_email"]
                )
                AlertUtils().send_mail(logger, conf, env)
                # Update the status of the alerts
                query = f"""Update
                {conf['alert_database_name']}.{conf['alert_location_table_name']} 
                set status = 'PROCESSED' where status = 'UNPROCESSED' """
                df_site_info = SparkUtils.execute_spark_sql(self, spark, query)
            else:
                logger.error(
                    "No site available in site info table for given data source"
                )

        except Exception as e:
            logger.error("Issue in sendmail_site_alerts : {}".format(str(e)))
            sys.exit(1)

        finally:
            logger.info("*" * 20 + " END: sendmail_site_alerts" + "*" * 20)

    def send_site_uom_info_alerts(
        self, logger: object, spark: object, conf: dict, env: str
    ) -> dict:
        """
        Function Name: send_site_uom_info_alerts\n
        Purpose: Sends alerts from the site uom info table
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param env: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: send_site_uom_info_alerts" + "*" * 20)

            query = f"""SELECT distinct LOCATION_NBR, LOCATION_NM, REPORTING_PERIOD_DT, SERVICE_TYPE_CD, SERVICE_USAGE_QTY, SERVICE_USAGE_QTY_UOM, SERVICE_COST, SERVICE_COST_UOM, LOCATION_AREA, LOCATION_AREA_UOM, COST_USAGE_DATA_SOURCE_NM, LOCATION_AREA_DATA_SOURCE_NM, SERVICE_USAGE_QTY_UOM_IND, SERVICE_COST_UOM_IND, LOCATION_AREA_UOM_IND,SCOPE_NBR FROM 
            {conf['alert_database_name']}.{conf['alert_uom_table_name']} 
            WHERE BATCH_LOAD_TMST IN (select batch_time from (select COST_USAGE_DATA_SOURCE_NM ,SCOPE_NBR, max(BATCH_LOAD_TMST) as batch_time from {conf['alert_database_name']}.{conf['alert_uom_table_name']} group by 1,2)) order by 2;"""

            df_site_info = SparkUtils.execute_spark_sql(self, spark, query)

            # Convert the dataframe to pandas dataframe
            df_site_info = df_site_info.toPandas()

            if not df_site_info.empty:
                html = df_site_info.to_html(index=False)
                identifier = conf["alert_uom_table_name"]
                conf["body"] = conf["body"].format(
                    identifier=identifier, html=html, team_email=conf["team_email"]
                )
                AlertUtils().send_mail(logger, conf, env)
            else:
                logger.error(
                    "No site with UOMs NULL in info table when it has values in respective columns"
                )

        except Exception as e:
            logger.error("Issue in send_site_uom_info_alerts : {}".format(str(e)))
            sys.exit(1)

        finally:
            logger.info("*" * 20 + " END: send_site_uom_info_alerts" + "*" * 20)

    def send_location_cvg_alerts(
        self,
        config_path: str,
        config_name: str,
        env: str,
        root_dir: str,
        bf_context: object,
        html_path: str,
        html_name: str,
    ) -> None:
        """
        Function Name: send_location_cvg_alerts.\n
        Params:
                :param config_path: string\n
                :param config_name: string\n
                :param sql_file_path: string\n
                :param sql_file_name: string\n
                :param env: string\n
                :param bf_context: object\n
                :param root_dir: string\n
        Returns: None
        """
        try:
            ## call the function in LoggerUtils to configure the logger object ##
            logger = LoggerUtils().get_logger_object()
            logger.info("%s START: get_site_details() %s", "*" * 20, "*" * 20)
            function_name = inspect.currentframe().f_code.co_name
            ## call the function in ConfigUtils to read the configurations present in
            #  TOML file and get dictionary of values ##
            conf = ConfigUtils().read_config_variables(
                config_path=config_path, config_name=config_name, env=env, logger=logger
            )
            product_conf = ConfigUtils().read_config_variables(
                config_path=root_dir,
                config_name="product-info.toml",
                env=env,
                logger=logger,
            )

            # call the function from common utils to get spark session object ##
            job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace(
                "/", ""
            )
            spark = SparkUtils().get_spark_session(logger, job_name)
            ## assign the config values to respective variables ##
            (
                token_username,
                token_password,
            ) = ConfigUtils().get_username_password_from_dbx_secrets(
                logger, bf_context, conf["dbx_scope"]
            )
            if token_username is None or token_password is None:
                raise ValueError("Username or Password is None")

            conf["username"] = token_username
            conf["password"] = token_password
            conf["function_name"] = function_name
            conf["tech_solution_id"] = product_conf["tech_solution_id"]
            conf["cloudred_gid"] = product_conf["nike-tagguid"]
            logger.info(
                "*" * 20 + " START: sendmail_location_coverage_alerts" + "*" * 20
            )
            query = f"""select * except(status,load_timestamp) FROM
                {conf['alert_database_name']}.{conf['location_coverage_table']} 
                where status = 'UNPROCESSED'"""

            df_lction_cvg_info = SparkUtils.execute_spark_sql(self, spark, query)

            # Convert the dataframe to pandas dataframe
            final_location_cvg_df = JSONUtils.process_map_columns(
                self, input_df=df_lction_cvg_info
            )
            location_cvg = final_location_cvg_df.toPandas()

            if not location_cvg.empty:
                html = location_cvg.to_html(index=False)
                identifier = conf["location_coverage_table"]
                with open(html_path + html_name, "r") as f:
                    conf["body"] = f.read()
                    conf["body"] = conf["body"].format(
                        identifier=identifier, html=html, team_email=conf["team_email"]
                    )
                    conf["subject"] = (
                        f"SDF - Location Coverage Alert: Missing Locations Detected - {env}"
                    )
                AlertUtils().send_mail(logger, conf, env)
                # Update the status of the alerts
                query = f"""Update
                    {conf['alert_database_name']}.{conf['location_coverage_table']} 
                    set status = 'PROCESSED' where status = 'UNPROCESSED' """
                SparkUtils.execute_spark_sql(self, spark, query)
            else:
                logger.error(
                    "No Location coverage records available in the table for given data source"
                )

        except Exception as e:
            logger.error("Issue in sendmail_site_alerts : {}".format(str(e)))
            sys.exit(1)

        finally:
            logger.info("*" * 20 + " END: sendmail_site_alerts" + "*" * 20)


class AuditUtils(QueryUtils, SparkUtils):
    """
    ClassName: AuditUtils.\
    Purpose: This class contains the methods for loading data into load_tracker (audit) Table.\n
    """

    def __init__(self) -> None: ...

    def get_partition_names_and_values(
        self: object,
        logger: object,
        spark_obj: object,
        conf: dict,
        database_name: str,
        table_name: str,
        table_type: str,
    ) -> tuple:
        """
        Function Name: get_partition_names_and_values\n
        Purpose: gets the partition names and values for a given table
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param conf: dict\n
        :param database_name: string\n
        :param table_name: string\n
        :param table_type: string (delta or snowflake)\n
        Returns: partition_names, partition_values: tuple
        """
        try:
            logger.info("*" * 20 + " START: get_partition_names_and_values" + "*" * 20)
            if table_type == "delta":
                ## get the partition names and values for the given table ##
                part_df = spark_obj.sql(f"show partitions {database_name}.{table_name}")
                ## get the max value for each partition column ##
                part_df = part_df.select(
                    *[max_(col(c)).alias(c) for c in part_df.columns]
                )
                ## convert the dataframe to list of dictionaries ##
                part_df_list = list(map(lambda row: row.asDict(), part_df.collect()))
                ## get the partition names and values as comma separated strings ##
                dfs_partition_names = ",".join(
                    [
                        str(each_key)
                        for each in part_df_list
                        for each_key, each_value in each.items()
                    ]
                )
                dfs_partition_values = ",".join(
                    [
                        str(each_value)
                        for each in part_df_list
                        for each_key, each_value in each.items()
                    ]
                )
            elif table_type == "snowflake":
                partition_query = f"""SELECT CONCAT_WS(',', column1, column2) as partition_by_cols FROM (
                                        SELECT
                                            REGEXP_SUBSTR(VALUE, '[A-Za-z_]+', 1, 2) AS column1,
                                            REGEXP_SUBSTR(VALUE, '[A-Za-z_]+', 1, 3) AS column2
                                        FROM 
                                            TABLE(FLATTEN(input => PARSE_JSON(SYSTEM$CLUSTERING_INFORMATION('{table_name}'))))
                                            WHERE KEY = 'cluster_by_keys')"""
                try:
                    part_df = self.run_snowflake_queries_as_spark_df(
                        logger, spark_obj, conf, partition_query
                    )
                    adf_dictionary = list(
                        map(lambda row: row.asDict(), part_df.collect())
                    )
                    dfs_partition_names = adf_dictionary[0]["PARTITION_BY_COLS"]
                    partition_values_query = f"""SELECT TO_VARCHAR(MAX(load_year_nbr)), TO_VARCHAR(MAX(load_month_nbr)) FROM {table_name}"""
                    part_val_df = self.run_snowflake_queries_as_spark_df(
                        logger, spark_obj, conf, partition_values_query
                    )
                    adf_val_dict = list(
                        map(lambda row: row.asDict(), part_val_df.collect())
                    )
                    dfs_partition_values = ",".join(adf_val_dict[0].values())
                except Exception as err:
                    if "is not clustered" in str(err):
                        logger.info(
                            "Table is not clustered, hence no partition values."
                        )
                        return None, None
                    logger.error(
                        "Issue while getting partition names and values - error : {}".format(
                            str(err)
                        )
                    )
            return dfs_partition_names, dfs_partition_values
        except Exception as e:
            logger.error(f"get_partition_names_and_values - error : {e}")
            raise SystemError(e)
        finally:
            logger.info("*" * 20 + " END: get_partition_names_and_values" + "*" * 20)

    def load_audit_table(
        self: object,
        logger: object,
        spark_obj: object,
        run_id: str,
        conf: dict,
        status: str,
        source_table_type: str,
        target_table_type: str,
        source_hop: str,
        target_hop: str,
    ) -> None:
        """
        Function Name: load_audit_table\n
        Purpose: loads the audit table with the details of the job run
        Params:
        :param logger: object\n
        :param spark_obj: object\n
        :param run_id: str\n
        :param conf: dict\n
        :param status: string\n
        :param source_table_type: string (delta or snowflake)\n
        :param target_table_type: string (delta or snowflake)\n
        :param source_hop: string\n
        :param target_hop: string\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: load_audit_table" + "*" * 20)
            audit_dict = {}
            ## complete table name  = db + table name ##
            conf["audit_complete_table_name"] = (
                conf["audit_database_name"] + "." + conf["audit_table_name"]
            )
            ## getting current job id using dbutils ##
            conf["job_run_id"] = str(run_id)
            ## partition values are null by default if not found in tables ##
            source_partition_names = None
            source_partition_values = None
            target_partition_names = None
            target_partition_values = None

            ## check if key 'source_database_name' and 'source_table_name' are present in config ##
            if (
                "source_database_name" in conf.keys()
                and "source_table_name" in conf.keys()
            ):
                ## get the partition names and values for the given table ##
                if source_table_type == "delta":
                    try:
                        source_partition_names, source_partition_values = (
                            self.get_partition_names_and_values(
                                logger,
                                spark_obj,
                                conf,
                                conf["source_database_name"],
                                conf["source_table_name"],
                                source_table_type,
                            )
                        )
                    except Exception as err:
                        source_partition_names = None
                        source_partition_values = None
                elif source_table_type == "snowflake":
                    try:
                        source_partition_names, source_partition_values = (
                            self.get_partition_names_and_values(
                                logger,
                                spark_obj,
                                conf,
                                conf["sfdatabase"],
                                conf["source_table_name"],
                                source_table_type,
                            )
                        )
                    except Exception as err:
                        source_partition_names = None
                        source_partition_values = None
            ## check if key 'target_database_name' and 'target_table_name' are present in config ##
            if (
                "target_database_name" in conf.keys()
                and "target_table_name" in conf.keys()
            ):
                ## get the partition names and values for the given table ##
                if target_table_type == "delta":
                    try:
                        target_partition_names, target_partition_values = (
                            self.get_partition_names_and_values(
                                logger,
                                spark_obj,
                                conf,
                                conf["target_database_name"],
                                conf["target_table_name"],
                                target_table_type,
                            )
                        )
                    except Exception as err:
                        target_partition_names = None
                        target_partition_values = None
                elif target_table_type == "snowflake":
                    try:
                        target_partition_names, target_partition_values = (
                            self.get_partition_names_and_values(
                                logger,
                                spark_obj,
                                conf,
                                conf["sfdatabase"],
                                conf["target_table_name"],
                                target_table_type,
                            )
                        )
                    except Exception as err:
                        target_partition_names = None
                        target_partition_values = None
                try:
                    if target_table_type == "delta":
                        try:
                            conf["target_data_count_after_load"] = spark_obj.sql(
                                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
                            ).head()[0]
                        except Exception as err:
                            conf["target_data_count_after_load"] = 0
                    elif target_table_type == "snowflake":
                        try:
                            target_count_query = f"""SELECT TO_VARCHAR(COUNT(*)) as table_count FROM {conf['target_table_name']}"""
                            target_count_df = self.run_snowflake_queries_as_spark_df(
                                logger, spark_obj, conf, target_count_query
                            )
                            conf["target_data_count_after_load"] = (
                                target_count_df.head()[0]
                            )
                        except Exception as err:
                            conf["target_data_count_after_load"] = 0
                except:
                    conf["target_data_count_after_load"] = 0
            else:
                raise SystemError(
                    "Target database and table names mising in configs, please add them in config and try again.."
                )

            schema = StructType(
                [
                    StructField("batch_id", StringType(), nullable=True),
                    StructField("object_name", StringType(), nullable=True),
                    StructField("source_stage", StringType(), nullable=True),
                    StructField("source_l1_detail", StringType(), nullable=True),
                    StructField("source_l2_detail", StringType(), nullable=True),
                    StructField("source_record_count", LongType(), nullable=True),
                    StructField(
                        "source_partition_column_name", StringType(), nullable=True
                    ),
                    StructField(
                        "source_partition_column_values", StringType(), nullable=True
                    ),
                    StructField("target_stage", StringType(), nullable=True),
                    StructField("target_l1_detail", StringType(), nullable=True),
                    StructField("target_l2_detail", StringType(), nullable=True),
                    StructField(
                        "target_partition_column_name", StringType(), nullable=True
                    ),
                    StructField(
                        "target_partition_column_values", StringType(), nullable=True
                    ),
                    StructField(
                        "target_data_count_before_load", LongType(), nullable=True
                    ),
                    StructField(
                        "target_data_count_after_load", LongType(), nullable=True
                    ),
                    StructField("target_record_count", LongType(), nullable=True),
                    StructField(
                        "incremental_data_count_after_load", LongType(), nullable=True
                    ),
                    StructField("status_code", StringType(), nullable=True),
                    StructField("job_run_id", StringType(), nullable=True),
                    StructField("job_name", StringType(), nullable=True),
                    StructField("insert_timestamp", StringType(), nullable=True),
                ]
            )

            ## creating the audit dictionary for final load ##
            audit_dict["batch_id"] = [conf["batch_id"]]
            audit_dict["object_name"] = [conf["object_name"]]
            audit_dict["source_stage"] = [source_hop]
            audit_dict["source_l1_detail"] = [
                conf.get("source_database_name")
                or conf.get("source_stage1_name")
                or (conf.get("sfdatabase") + "." + conf.get("sfschema"))
            ]
            audit_dict["source_l2_detail"] = [
                conf.get("source_table_name") or conf.get("source_stage2_name")
            ]
            try:
                audit_dict["source_record_count"] = [int(conf["source_record_count"])]
            except:
                audit_dict["source_record_count"] = [0]
            audit_dict["source_partition_column_name"] = [
                (
                    None
                    if source_partition_names == (None, None)
                    else source_partition_names
                )
                or (
                    ",".join(conf.get("partition_by_cols"))
                    if conf.get("partition_by_cols") is not None
                    else None
                )
            ]
            audit_dict["source_partition_column_values"] = [
                (
                    None
                    if source_partition_values == (None, None)
                    else source_partition_values
                )
            ]
            audit_dict["target_stage"] = [target_hop]
            audit_dict["target_l1_detail"] = [
                conf.get("target_database_name")
                or conf.get("target_stage1_name")
                or (conf.get("sfdatabase") + "." + conf.get("sfschema"))
            ]
            audit_dict["target_l2_detail"] = [
                conf.get("target_table_name") or conf.get("target_stage2_name")
            ]
            audit_dict["target_partition_column_name"] = [
                (
                    None
                    if target_partition_names == (None, None)
                    else target_partition_names
                )
                or (
                    ",".join(conf.get("partition_by_cols"))
                    if conf.get("partition_by_cols") is not None
                    else None
                )
            ]
            audit_dict["target_partition_column_values"] = [
                (
                    None
                    if target_partition_values == (None, None)
                    else target_partition_values
                )
            ]
            try:
                audit_dict["target_data_count_before_load"] = [
                    int(conf["target_data_count_before_load"])
                ]
            except ValueError as e:
                logger.error(
                    "target_data_count_before_load is not an integer, setting it to 0"
                )
            except Exception as e:
                logger.error(
                    "target_data_count_before_load is not found, setting it to 0"
                )
                audit_dict["target_data_count_before_load"] = [0]
            try:
                audit_dict["target_data_count_after_load"] = [
                    int(conf["target_data_count_after_load"])
                ]
            except ValueError as e:
                logger.error(
                    "target_data_count_after_load is not an integer, setting it to 0"
                )
            except Exception as e:
                logger.error(
                    "target_data_count_after_load is not found, setting it to 0"
                )
                audit_dict["target_data_count_after_load"] = [0]
            try:
                audit_dict["target_record_count"] = [int(conf["target_record_count"])]
            except:
                audit_dict["target_record_count"] = [0]
            audit_dict["incremental_data_count_after_load"] = [
                int(conf["target_data_count_after_load"])
                - int(conf["target_data_count_before_load"])
            ]
            audit_dict["status_code"] = [status]
            audit_dict["job_run_id"] = [conf["job_run_id"]]
            audit_dict["job_name"] = [conf["job_name"]]
            audit_dict["insert_timestamp"] = [datetime.now().strftime("%Y%m%d%H%M%S")]

            logger.info(
                "Created the audit dictionary, ready to load it to audit table."
            )

            ## create audit dataframe using the audit dictionary without help of spark context ##
            column_names, data = zip(*audit_dict.items())
            audit_dataframe = spark_obj.createDataFrame(zip(*data), schema=schema)

            ## re-order the columns based on config for audit columns ##
            audit_dataframe = audit_dataframe.select(conf["audit_table_columns"])

            ## Setting write mode to append_only for audits ##
            conf["write_mode"] = "append"

            ## write the audit dataframe to delta table ##
            self.write_dataframe_to_delta(
                logger,
                spark_obj,
                conf,
                audit_dataframe,
                conf["audit_complete_table_name"],
                tech_solution_id=conf["tech_solution_id"],
                cloudred_gid=conf["cloudred_gid"],
                do_partition=False,
                update_tags=False,
                set_not_null_constraint=False,
            )
            logger.info("Audit table loaded successfully.")

        except Exception as e:
            logger.error("load_audit_table - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: load_audit_table" + "*" * 20)

    def trigger_alerts_location_updates(
        self: object,
        spark_obj: object,
        logger: object,
        master_spark_df: object,
        conf: dict,
    ) -> None:
        """
        Function Name: trigger_alerts_location_updates\n
        Purpose: Loads the multi_site_info table with the details of any location changes
        Params:
        :param spark_obj: object\n
        :param logger: object\n
        :param master_spark_df: object\n
        :param conf: dict\n
        Returns: None
        """
        try:
            logger.info("*" * 20 + " START: trigger_alerts_location_updates" + "*" * 20)
            master_spark_df_in = master_spark_df
            target_complete_table_name = (
                conf["target_database_name"] + "." + conf["target_table_name"]
            )
            alert_complete_table_name = (
                conf["target_database_name"] + "." + conf["alert_location_table_name"]
            )

            if not conf.get("alert_details_conf"):
                logger.info("**** Creating Alert details conf for sdf-Ecorangers ****")
                if conf["target_table_name"].lower().find("electricity") != -1:
                    alert_cols_with_expr = {
                        "electricity_location_nm": "electricity_location_nm as location_nm",
                        "electricity_location_nbr": "electricity_location_nbr as location_nbr",
                        "service_type_cd": "service_type_cd as service_type_nm",
                    }
                    alert_filter_exp = expr(
                        f"scope_nbr='SCOPE 2' and data_prvdr='{conf['cost_usage_data_source_nm']}'"
                    )
                    alert_filter_init = expr(
                        f"scope_nbr='SCOPE 2' and cost_usage_data_source_nm='{conf['cost_usage_data_source_nm']}'"
                    )
                elif conf["target_table_name"].lower().find("fuel") != -1:
                    alert_cols_with_expr = {
                        "fuel_location_nm": "fuel_location_nm as location_nm",
                        "fuel_location_nbr": "fuel_location_nbr as location_nbr",
                        "service_type_cd": "service_type_cd as service_type_nm",
                    }
                    alert_filter_exp = expr(
                        f"scope_nbr='SCOPE 1' and data_prvdr='{conf['cost_usage_data_source_nm']}'"
                    )
                    alert_filter_init = expr(
                        f"scope_nbr='SCOPE 1' and cost_usage_data_source_nm='{conf['cost_usage_data_source_nm']}'"
                    )

                if (
                    conf.get("init_as_unprocessed")
                    and conf["init_as_unprocessed"] is True
                ):
                    init_status = "'UNPROCESSED' as status"
                else:
                    init_status = "'INITIAL LOAD' as status"

                # Create dict for alert_details_conf
                conf["alert_details_conf"] = {
                    "alert_cols_with_expr": alert_cols_with_expr,
                    "other_cols_with_expr": {
                        "lease_nbr": "lease_nbr as lease_number_desc",
                        "nike_department_type_txt": "nike_department_type_txt as department_nm",
                        "extrapolation_ind": "extrapolation_ind",
                        "scope_nbr": "scope_nbr",
                        "cost_usage_data_source_nm": "cost_usage_data_source_nm as data_prvdr",
                        "status": "'UNPROCESSED' as status",
                    },
                    "other_cols": [
                        "user_nm",
                        "load_dt",
                        "batch_load_tmst",
                        "job_nm",
                        "job_run_id",
                    ],
                    "compare_keys": ["location_nm", "location_nbr"],
                    "filters": {
                        "alert_filter_exp": alert_filter_exp,
                        "alert_filter_init": alert_filter_init,
                    },
                    "init_status": init_status,
                    "suffix": "_ind",
                    "orderBy_col_expr": desc("batch_load_tmst"),
                }
            elif conf.get("alert_details_conf"):
                logger.info("**** Alert details conf exists ****")
            else:
                raise Exception("**** Alert details conf not found ****")

            # Setting defaults
            if conf["alert_details_conf"].get("orderBy_col_expr") is None:
                conf["alert_details_conf"]["orderBy_col_expr"] = desc(lit(1))

            rename_col_select = (
                [
                    expr(conf["alert_details_conf"]["alert_cols_with_expr"][i])
                    for i in conf["alert_details_conf"]["alert_cols_with_expr"]
                ]
                + [
                    expr(conf["alert_details_conf"]["other_cols_with_expr"][i])
                    for i in conf["alert_details_conf"].get("other_cols_with_expr", [])
                ]
                + [expr(i) for i in conf["alert_details_conf"].get("other_cols", [])]
            )
            logger.info(f"alert_details_conf : {conf['alert_details_conf']}")

            master_spark_df = master_spark_df.select(*rename_col_select)
            keys = master_spark_df.columns[
                0 : len(conf["alert_details_conf"]["alert_cols_with_expr"].items())
            ]
            cols_with_expr = master_spark_df.columns[
                len(conf["alert_details_conf"]["alert_cols_with_expr"].items()) : len(
                    conf["alert_details_conf"]["alert_cols_with_expr"].items()
                )
                + len(conf["alert_details_conf"].get("other_cols_with_expr", []))
            ]
            suffix = conf["alert_details_conf"].get("suffix") or "_ind"
            chgflg_cols = [f"{c}{suffix}" for c in keys]
            other_cols = conf["alert_details_conf"].get("other_cols", [])

            # Check if alert table exists & check the count of records in alert table.
            try:
                alert_df = spark_obj.read.table(alert_complete_table_name)

                # Applying filter, if any
                if (
                    conf["alert_details_conf"].get("filters")
                    and conf["alert_details_conf"]["filters"].get("alert_filter_exp")
                    is not None
                ):
                    alert_df = alert_df.where(
                        conf["alert_details_conf"]["filters"]["alert_filter_exp"]
                    ).select(*keys, *cols_with_expr, *other_cols)

                # check for counts
                if alert_df.count() > 0:

                    # COLLECTING data for keys mentioned in compare keys to check if its new or already present
                    compare_keys = (
                        conf["alert_details_conf"].get("compare_keys") or keys
                    )
                    logger.info(f"****** {compare_keys} *****")
                    collect_non_compare_keys = [
                        collect_list(col(c)).alias(f"collect_existing_{c}")
                        for c in keys[1:]
                        if c not in compare_keys
                    ]

                    collect_cols = [f"collect_existing_{c}" for c in compare_keys[1:]]

                    df_existing_data_grouped = alert_df.select(
                        "*",
                        *[
                            expr(f"collect_list({c}) over () as collect_existing_{c}")
                            for c in compare_keys[1:]
                        ],
                    )

                    if collect_non_compare_keys != []:
                        df_existing_data_grouped = df_existing_data_grouped.groupBy(
                            *compare_keys, *collect_cols
                        ).agg(
                            *[
                                collect_list(col(c)).alias(f"collect_existing_{c}")
                                for c in keys[1:]
                                if c not in compare_keys
                            ]
                        )

                    # Removing any existing records from incoming dataset based on keys and comparison with alert table history
                    df_compare = master_spark_df.join(
                        alert_df, keys, "leftanti"
                    ).dropDuplicates()

                    ## Check for grouping after joining
                    if df_compare.count() > 0:
                        collect_cols = [
                            f"collect_existing_{c}" for c in compare_keys[1:]
                        ]

                        df_compare1_inner = (
                            df_compare.alias("df_compare")
                            .join(
                                df_existing_data_grouped.alias("existing"),
                                keys[0],
                                "inner",
                            )
                            .select(
                                "df_compare.*",
                                expr(f'"N" as {keys[0]}{suffix}'),
                                *collect_cols,
                            )
                        )
                        df_compare = df_compare.join(
                            df_compare1_inner, keys[0], "leftanti"
                        )
                        df_existing_data_grouped = df_existing_data_grouped.select(
                            *collect_cols
                        ).limit(1)

                        df_compare1_cross = (
                            df_compare.alias("df_compare")
                            .crossJoin(df_existing_data_grouped.alias("existing"))
                            .select(
                                "df_compare.*",
                                expr(f'"Y" as {keys[0]}{suffix}'),
                                *collect_cols,
                            )
                        )

                        df_compare1_union = df_compare1_inner.unionAll(
                            df_compare1_cross
                        )

                        df_compare2 = df_compare1_union.select(
                            "*",
                            *[
                                expr(
                                    f"case when array_contains({collect_cols[i]},{keys[i+1]}) then 'N' else 'Y' end"
                                ).alias(f"{keys[i+1]}{suffix}")
                                for i in range(0, len(collect_cols))
                            ],
                            *[
                                expr(f"'Y' as {keys[i]}{suffix}")
                                for i in range(len(compare_keys), len(keys))
                            ],
                        )
                        final_alert_df = df_compare2.select(
                            *keys, *cols_with_expr, *chgflg_cols, *other_cols
                        ).dropDuplicates()
                        return final_alert_df

                    else:
                        return "No new records to update"

                else:
                    raise SystemError(
                        'Alert Table does not have any data for filter condition - conf["alert_details_conf"]["filters"]'
                    )
            except Exception as e:
                logger.info(
                    "*** Alert Table does not exist or no records returned for filter ***"
                )
                logger.info(
                    "trigger_alerts_location_updates - error caught : {}".format(str(e))
                )
                if (
                    conf["alert_details_conf"].get("filters")
                    and conf["alert_details_conf"]["filters"].get("alert_filter_init")
                    is not None
                ):
                    logger.info("*** alert_filter_init exists ***")
                    final_alert_df = (
                        spark_obj.read.table(target_complete_table_name)
                        .where(
                            conf["alert_details_conf"]["filters"]["alert_filter_init"]
                        )
                        .select(*master_spark_df_in.columns)
                    )
                else:
                    print("*** No alert_filter_init exists ***")
                    final_alert_df = spark_obj.read.table(
                        target_complete_table_name
                    ).select(*master_spark_df_in.columns)

                final_alert_df = final_alert_df.unionAll(master_spark_df_in)

                # Update the alert table for initial load for a data product if no data exists in alert table
                rename_col_select1 = [
                    expr(conf["alert_details_conf"]["alert_cols_with_expr"][i])
                    for i in conf["alert_details_conf"]["alert_cols_with_expr"]
                ] + [
                    expr(conf["alert_details_conf"]["other_cols_with_expr"][i])
                    for i in conf["alert_details_conf"].get("other_cols_with_expr", [])
                    if i != "status"
                ]
                rename_col_select2 = [expr(f" 'Y' as {c}{suffix}") for c in keys] + [
                    expr(i) for i in conf["alert_details_conf"].get("other_cols", [])
                ]
                status = "'UNPROCESSED' as status_placeholder"
                if conf["alert_details_conf"].get("other_cols_with_expr") and conf[
                    "alert_details_conf"
                ]["other_cols_with_expr"].get("status"):
                    if conf["alert_details_conf"].get("init_status"):
                        status = conf["alert_details_conf"]["init_status"]
                    else:
                        status = "'UNPROCESSED' as status"

                final_alert_df = (
                    final_alert_df.select(
                        *rename_col_select1, expr(status), *rename_col_select2
                    )
                    .withColumn(
                        "rnk",
                        row_number().over(
                            Window.partitionBy(*keys).orderBy(
                                conf["alert_details_conf"]["orderBy_col_expr"]
                            )
                        ),
                    )
                    .filter(col("rnk") == 1)
                    .drop("rnk", "status_placeholder")
                )

                return final_alert_df

        except Exception as e:
            logger.error("trigger_alerts_location_updates - error : {}".format(str(e)))
            sys.exit(1)
        finally:
            logger.info("*" * 20 + " END: trigger_alerts_location_updates" + "*" * 20)
