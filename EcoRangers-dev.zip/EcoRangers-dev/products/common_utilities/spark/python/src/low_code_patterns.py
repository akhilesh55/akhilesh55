from pyspark.sql import DataFrame, SparkSession
from datetime import datetime

# from data_common_utilities.src.lib.common.spark_utils import get_spark_session
# from data_common_utilities.src.lib.common.logging_utils import logger_for_spark
from pyspark.sql.functions import *

# from data_common_utilities.src.lib.common.scd_utils import SCD2utils
from products.common_utilities.spark.python.src.scd_utils import SCD2utils
from functools import reduce
import re
from pyspark.sql import functions as f
from pyspark.sql.types import *
from time import sleep
import traceback
from logging import DEBUG
import multiprocessing
import logging
import sys
from contextlib import contextmanager
import timeit
import os
import time


def format_exception(message=None):
    try:
        if message and isinstance(message, str):
            return message + "\n" + traceback.format_exc()
        else:
            return traceback.format_exc()
    except Exception:
        return "Unable to format the underlying error"  # not expecting this ever, but just incase


def error_formatted(logger, message=None):
    logger.error(format_exception(message))


def get_extra_format(extra):
    """
    Function to get the log format with extra dictionary
    :param dict extra:
    :return:
    """
    return " - ".join("{}: %({})s".format(key, key) for key, value in extra.items())


def logger_for(name, extra=None):
    """
    Returns a logger instance depending on whether there is a spark context or not.
    :param name:
    :return:
    """
    result = logging.getLogger(name)
    return add_logger_formatting(result, extra)


def add_logger_formatting(logger, extra):
    logger.propagate = False  # necessary to avoid duplicate logging

    logger.setLevel(DEBUG)
    if logger.hasHandlers():
        logger.handlers.clear()

    stdouthandler = logging.StreamHandler(sys.stdout)

    if extra:
        format = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - "
            + get_extra_format(extra)
            + " - %(message)s"
        )
        stdouthandler.setFormatter(format)
        logger.addHandler(stdouthandler)
        logger = logging.LoggerAdapter(logger, extra)
    else:
        format = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        stdouthandler.setFormatter(format)
        logger.addHandler(stdouthandler)

    logger.error_formatted = lambda m: error_formatted(logger, m)
    return logger


def logger_for_spark(spark, name=__name__):
    """
    This logger helps in spark job to write log messages with additional context which may help later in splunk

    :param name: Name of the module where this function is called
    :param SparkSession spark: spark session
    :return:
    """
    return logger_for(
        name,
        dict(
            spark_job_id=spark.conf.get("spark.app.id"),
            spark_job_name=spark.conf.get("spark.app.name"),
            user=spark.conf.get("spark.app.name"),
        ),
    )


def logger_for_threads(name, extra=None):
    """
    Logger that helps in multi threading
    :param name:
    :param extra:
    :return:
    """
    multiprocessing.log_to_stderr()
    result = multiprocessing.get_logger()
    return add_logger_formatting(result, extra)


def metric_key(basename, **kwargs):
    if len(kwargs) == 0:
        return basename
    else:
        return "%s.%s" % (
            basename,
            ".".join(["%s.%s" % (k, v) for k, v in kwargs.items()]),
        )


"""
Log Metrics to stdout with a standard formatting so that they can be picked by Splunk or other tools.
"""
metrics_logger = logger_for("metrics")


@contextmanager
def timer(basename, **kwargs):
    start = timeit.default_timer()
    try:
        yield
    finally:
        elapsed = timeit.default_timer() - start
        metrics_logger.info(
            "{}={:.3f} seconds".format(metric_key(basename, **kwargs), elapsed)
        )


def get_spark_session(
    spark_app_name: str, options: dict = None, custom_listener_meta_data: dict = None
):
    """
    Spark session with option overridable
    :param custom_listener_meta_data: DEPRECATED - use spark conf to add listener metadata
    :param spark_app_name:
    :param options: SparkConf params
    add metadata to listener  with metadata like
        {"spark.nike.tech_solution_id": "test_product_id} in spark conf
    :return:
    """
    if options:
        spark = (
            SparkSession.builder.config(map=options)
            .enableHiveSupport()
            .appName(spark_app_name)
            .getOrCreate()
        )
    else:
        spark = (
            SparkSession.builder.enableHiveSupport()
            .appName(spark_app_name)
            .config("spark.databricks.delta.merge.enableLowShuffle", "true")
            .getOrCreate()
        )
    return spark


class SCD2DeltaTableWriter:
    """
    Usage: This class acts can be used to implement SCD Type 2\n
        SCD type 2 can be implemented using this function based on either of the below two criteria
            1. There should only a single record corresponding to a given set of primary keys
            2. If there are multiple records for a given set of primary keys, a sequencing/sorting column should also be provided so that the correct linkage can be maintained between records and identify any missed or out of sync records.
    Arguments description:
    source = "Should be the source table or dataframe which has the new incoming data",
    keys = "List of primary key columns",
    target_table = "Target table name which will maintain or already has scd data",
    include_columns = "List of columns to be used for comparison to generate the hash & identify changes. Default is an empty list. Takes priority over exclude_columns. Should not include any of the keys. Applicable only for criteria 1",
    exclude_columns = "List of columns to be excluded from comparison while generating the hash to identify changes. Default is an empty list. Will be ignored if include_columns is passed. Should not include any of the keys. Applicable only for criteria 1",
    apply_as_deletes = "Flag to identify deletes exist",
    sequence_by = "Timestamp column that can be used to identify the sequence of records when multiple records are available for the same primarry key. Applicable only for criteria 2"
    delta_tbl_flag = "Values can be either delta or any other column name which may need to be optionally dropped",
    target_start_col_name = "Column name which will be present in target table to identify the start date of a record",
    target_end_col_name = "Column name which will be present in target table to identify the end date of a record",
    end_date_expr: str = "Expression that can be used to set the end date.",
    ins_ignore_cols: list = "List of columns in the source dataframe or table that should be skipped while inserting into the target table. This is useful when there are columns that are not required in the target table but are present in the source data. This might be used to update past records already present in the table.",
    updt_cols_existing_rec: list = "List of lists where each where each nested list has two elements. The first element is the column name in the target table and the second element is the column name from the source. Can be used to update any columns of the existing records in the target table. Can be useful to identify by whom the previous record was changed.",
    spark = "SparkSession object to be used. If not provided, a new SparkSession will be created internally",
    logger = "Logger object to log the messages. If not provided, a logger will be created internally"

    """

    def __init__(
        self,
        source,
        keys: list,
        target_table: str,
        include_columns: list = [],
        exclude_columns: list = [],
        apply_as_deletes=None,
        sequence_by=False,
        delta_tbl_flag: bool = False,
        target_is_current_col_name: str = "is_current",
        target_start_col_name: str = "__start_at",
        target_end_col_name: str = "__end_at",
        end_date_expr: str = "current_timestamp()",
        ins_ignore_cols: list = [],
        updt_cols_existing_rec: list = [],
        spark: object = None,
        logger=None,
    ):
        self.source = source
        self.keys = keys
        self.target_table = target_table
        self.include_columns = include_columns
        self.exclude_columns = exclude_columns
        self.apply_as_deletes = apply_as_deletes
        self.delta_tbl_flag = delta_tbl_flag
        self.sequence_by = sequence_by
        self.target_is_current_col_name = target_is_current_col_name
        self.target_start_col_name = target_start_col_name
        self.target_end_col_name = target_end_col_name

        if spark is None:
            # self.spark = SparkSession.builder.enableHiveSupport().appName("SCD_Type_2").getOrCreate()
            self.spark = get_spark_session("SCD_Type_2")
        else:
            self.spark = spark

        if logger is None:
            # self.spark = SparkSession.builder.enableHiveSupport().appName("SCD_Type_2").getOrCreate()
            self.logger = logger_for_spark(self.spark, __name__)
        else:
            self.logger = logger
        # Creating logger for test use
        # logger = logging.getLogger('SCD2DeltaTableWriter')
        # logger.setLevel(logging.INFO)
        # self.logger = logger
        self.end_date_expr = end_date_expr
        self.ins_ignore_cols = ins_ignore_cols
        self.updt_cols_existing_rec = "".join(
            f"tgt_scd.{c[0]}=src_upserts.{c[1]}," for c in updt_cols_existing_rec
        )

    def run_scd(self):
        self.logger.info("*" * 20 + " SCD2DeltaTableWriter Start " + "*" * 20)
        scd_obj = SCD2utils(
            self.source,
            self.keys,
            self.target_table,
            self.include_columns,
            self.exclude_columns,
            self.apply_as_deletes,
            self.sequence_by,
            self.delta_tbl_flag,
            self.target_is_current_col_name,
            self.target_start_col_name,
            self.target_end_col_name,
            self.spark,
            self.logger,
            self.end_date_expr,
        )

        # Start with reading source and target table, columns to be considered, delete flags
        scd_obj.get_scd_details()

        # Inserts
        scd_obj.scd_inserts()

        # Updates
        scd_obj.scd_updates()

        # Deletes
        if self.apply_as_deletes is not None or self.delta_tbl_flag is True:
            scd_obj.scd_deletes()

        # Merge
        df_src_upserts_list = scd_obj.scd_union_list()

        df_src_upserts = reduce(DataFrame.unionAll, df_src_upserts_list).drop(
            "hash_col_src"
        )

        # .withColumnRenamed('hash_col_src', self.hash_col_nm or 'drop_hash_col_src') \
        # .drop('drop_hash_col_src')

        merge_cols = [
            re.sub(r"^([^/]*)/+(.*)$", r"`\1/\2`", cols) for cols in self.keys
        ]
        merge_condition = " and ".join(
            [f"tgt_scd.{c} <=> src_upserts.{c}" for c in merge_cols]
            + [
                f"tgt_scd.{self.target_is_current_col_name} = src_upserts.old_current and tgt_scd.{self.target_is_current_col_name} = 1"
            ]
        )

        if self.apply_as_deletes is not None or self.delta_tbl_flag is True:
            merge_match_stmt = f"""WHEN MATCHED and tgt_scd.is_delete = 1 THEN
		                            UPDATE SET
			                        tgt_scd.{self.target_is_current_col_name} = 0 
                                 """
            update_set_del_str = ",tgt_scd.is_delete = src_upserts.is_delete "
        else:
            update_set_del_str = merge_match_stmt = ""
            df_src_upserts = df_src_upserts.drop("is_delete")

        update_set_del_str = ""
        df_src_upserts.createOrReplaceTempView("src_upserts")

        ins_stmnt = ",".join(
            [
                re.sub(r"^([^/]*)/+(.*)$", r"`\1/\2`", c)
                for c in df_src_upserts.columns
                if c not in ["old_current"] + self.ins_ignore_cols
            ]
        )
        ins_val_stmnt = ",".join([f"src_upserts.{c}" for c in ins_stmnt.split(",")])

        self.spark.sql(
            f"""
		      MERGE INTO {self.target_table} AS tgt_scd
		      USING src_upserts AS src_upserts
		      ON {merge_condition}
              {merge_match_stmt}
		      WHEN MATCHED THEN
		          UPDATE SET
                          {self.updt_cols_existing_rec}
			              tgt_scd.{self.target_is_current_col_name} = 0,
			              tgt_scd.{self.target_end_col_name} = greatest({self.end_date_expr}, tgt_scd.{self.target_start_col_name})
			              {update_set_del_str} 
		      WHEN NOT MATCHED THEN
		          INSERT ({ins_stmnt})
		          VALUES ({ins_val_stmnt})
		            """
        )
        self.logger.info("*" * 20 + " SCD2DeltaTableWriter End " + "*" * 20)

    def run_scd_seq(self):
        """sequencing column will be used with the delta feed to get the sequence of the data.
        This will be helpful to identify the right order of records when they are being inserted into the target table.
        The sequencing column should be a timestamp column in the source table which is also present in the target.
        if _commit_timestamp is the sequencing column, then the start_date column in the target table will be used.
        """
        self.logger.info("*" * 20 + " SCD2DeltaTableWriter Start " + "*" * 20)
        scd_obj = SCD2utils(
            self.source,
            self.keys,
            self.target_table,
            self.include_columns,
            self.exclude_columns,
            self.apply_as_deletes,
            self.sequence_by,
            self.delta_tbl_flag,
            self.target_is_current_col_name,
            self.target_start_col_name,
            self.target_end_col_name,
            self.spark,
            self.logger,
        )

        df_join_sorted = scd_obj.scd_seq()

        merge_cols = [
            re.sub(r"^([^/]*)/+(.*)$", r"`\1/\2`", cols) for cols in self.keys
        ]
        merge_condition = " and ".join(
            [f"tgt_scd.{c} = df_join_sorted.{c}" for c in merge_cols]
            + [
                f'coalesce(tgt_scd.{self.target_start_col_name},"1900-01-01") = coalesce(df_join_sorted.sequence_by,"1900-01-01")'
            ]
        )

        if self.apply_as_deletes is not None or (
            self.delta_tbl_flag is True and self.apply_as_deletes is True
        ):
            merge_condition = (
                merge_condition
                + f" and concat(tgt_scd.{self.target_is_current_col_name},tgt_scd.is_delete) = concat(df_join_sorted.old_is_current,df_join_sorted.is_delete) "
            )
            del_merge_cond_str = f"""WHEN MATCHED and tgt_scd.is_delete=1 and tgt_scd.{self.target_end_col_name}<=df_join_sorted.{self.target_end_col_name} THEN
                            UPDATE SET
                            tgt_scd.{self.target_is_current_col_name} = df_join_sorted.{self.target_is_current_col_name},
                            tgt_scd.{self.target_start_col_name} = df_join_sorted.{self.target_start_col_name} """
        else:
            df_join_sorted = df_join_sorted.drop("is_delete")
            del_merge_cond_str = ""

        df_join_sorted.createOrReplaceTempView("df_join_sorted")

        ins_stmnt = ",".join(
            [
                re.sub(r"^([^/]*)/+(.*)$", r"`\1/\2`", c)
                for c in df_join_sorted.columns
                if c not in ["sequence_by", "old_is_current"]
            ]
        )
        ins_val_stmnt = ",".join([f"df_join_sorted.{c}" for c in ins_stmnt.split(",")])

        self.spark.sql(
            f"""
                MERGE INTO {self.target_table} AS tgt_scd
                USING df_join_sorted AS df_join_sorted
                ON {merge_condition}
                {del_merge_cond_str}
                WHEN MATCHED THEN
                    UPDATE SET
                            tgt_scd.{self.target_is_current_col_name} = df_join_sorted.{self.target_is_current_col_name},
                            tgt_scd.{self.target_start_col_name} = df_join_sorted.{self.target_start_col_name},
                            tgt_scd.{self.target_end_col_name} = df_join_sorted.{self.target_end_col_name}
                WHEN NOT MATCHED THEN
                    INSERT ({ins_stmnt})
                    VALUES ({ins_val_stmnt})
                        """
        )
        self.logger.info("*" * 20 + " SCD2DeltaTableWriter End " + "*" * 20)

    def execute(self):
        if self.sequence_by is False:
            self.run_scd()
        else:
            self.run_scd_seq()
