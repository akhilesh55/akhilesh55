from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
import inspect
from products.common_utilities.spark.python.src import mapper
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    AuditUtils,
    AlertUtils,
)


def util_ingest_raw_to_stage(
    config_path: str,
    config_name: str,
    source_table: str,
    business_group: str,
    target_table: str,
    sql_file_path: str,
    sql_file_name: str,
    env,
    bf_context,
    root_dir,
) -> int:

    logger = LoggerUtils().get_logger_object()

    ## call the function in LoggerUtils to configure the logger object ##
    logger = LoggerUtils().get_logger_object()
    logger.info("*" * 20 + " START: run_ingest_curated_to_integrated()" + "*" * 20)
    function_name = inspect.currentframe().f_code.co_name
    ## call the function in ConfigUtils to read the configurations present in TOML
    # file and get dictionary of values ##
    conf = ConfigUtils().read_config_variables(
        config_path=config_path, config_name=config_name, env=env, logger=logger
    )
    product_conf = ConfigUtils().read_config_variables(
        config_path=root_dir,
        config_name="product-info.toml",
        env=env,
        logger=logger,
    )

    job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
    spark = SparkUtils().get_spark_session(logger, job_name)

    sql_file_contents = SparkUtils().get_sql_file_content(
        logger, sql_file_path, sql_file_name
    )

    sql_query = SparkUtils().format_sql_query_with_variables(
        logger, sql_file_contents, kwargs=conf.get("delta_tables_mapping_dict")
    )

    query_result_df = SparkUtils().run_spark_sql_query_as_spark_df(
        logger, spark, sql_query
    )
    Business_group = "retail"
    target_table = "development.global_sustainability_dev.staging_location_mapped"
    # Mapper = ColumnMapper(df_source, Business_group, target_table)
    df_mapped = mapper.ColumnMapper(
        query_result_df, Business_group, target_table
    ).mapper()
    df_mapped = df_mapped.withColumn("source_table", lit(f"{Business_group}"))
    df_mapped.write.mode("append").saveAsTable(
        "development.global_sustainability_dev.staging_location_mapped"
    )
    return df_mapped
