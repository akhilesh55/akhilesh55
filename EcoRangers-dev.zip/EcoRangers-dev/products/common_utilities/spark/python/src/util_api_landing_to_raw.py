"""
Module: UTIL_API_LANDING_TO_RAW
Purpose: This module is responsible for processing data from the API landing layer to the raw layer.

The function `run_api_landing_to_raw` performs the following steps:
1. Configures the logger.
2. Reads configuration variables from TOML files.
3. Initializes a Spark session.
4. Fetches data from the API landing layer.
5. Processes the data and converts it to Spark DataFrames.
6. Writes the DataFrames to a Delta table.
7. Updates the batch load tracker and audit tables.
8. Handles errors and generates alerts if necessary.

Modification History:
=================================================================================
Date         Version  Created/Modified By               Comments
-----------  -------  ----------------------         -------------------------------
25-JUN-2024  v1.00    Bryan Almeida                  Initial Development (SDF- 2178)
==================================================================================
"""

import sys
import os
from datetime import datetime
import inspect
from functools import reduce
import pyspark
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    JSONUtils,
    AuditUtils,
    AlertUtils,
)
from pyspark.sql.functions import col, explode
from pyspark.sql import DataFrame
from pyspark.sql.types import StringType, StructField, StructType, ArrayType, MapType
import pandas as pd

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_api_landing_to_raw(
    config_path: str, config_name: str, env: str, bf_context: object, root_dir: str
) -> None:
    """
    Function Name: run_api_landing_to_raw.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param root_dir: string\n
    Returns: None
    """
    try:
        function_name = inspect.currentframe().f_code.co_name
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_api_landing_to_raw()" + "*" * 20)

        ## call the function in ConfigUtils to read the configurations
        # present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        ## call the function in ConfigUtils to read the configurations
        # present in TOML file and get dictionary of values ##
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        job_id = str(
            bf_context.get_parameter(key="brickflow_job_id", debug="987987987987987")
        )

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        batch_complete_table_name = (
            conf["source_database_name"] + "." + "sdf_batch_load_tracker"
        )
        conf["data_completeness_tbl"] = (
            conf["target_database_name"] + "." + conf["data_completeness_tbl"]
        )
        ## assign the config values to respective variables ##
        source_complete_table_name = (
            conf["source_database_name"] + "." + conf["source_table_name"]
        )
        target_complete_table_name = (
            conf["target_database_name"] + "." + conf["target_table_name"]
        )
        predicates = conf.get("predicates")
        custom_starting_timestamp = conf.get("custom_starting_timestamp")
        if "nan_replacement" in conf.keys():
            nan_replacement = conf["nan_replacement"]
        else:
            nan_replacement = [{}]

        conf["batch_id"] = str(
            spark.sql(
                f"""SELECT batch_id FROM {batch_complete_table_name}
            where status in ('RUNNING', 'FAILURE')
            and env = '{env}' and project_name = '{product_conf['product_name']}'"""
            ).head()[0]
        )
        status = ""
        conf["function_name"] = function_name
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        latest_timestamp = datetime.strptime(conf["batch_id"], "%Y%m%d%H%M%S")

        ## based on common_cols and table_cols params, set the select statement ##
        df_cols = None
        if conf.get("common_cols") and conf.get("table_cols"):
            df_cols = conf.get("common_cols") + conf.get("table_cols")
        elif conf.get("common_cols") and not conf.get("table_cols"):
            df_cols = conf.get("common_cols")
        elif not conf.get("common_cols") and conf.get("table_cols"):
            df_cols = conf.get("table_cols")

        try:
            conf["target_data_count_before_load"] = spark.sql(
                f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
            ).head()[0]
        except Exception as e:
            conf["target_data_count_before_load"] = 0

        try:
            ## based on predicates and custom starting timestamp, reading
            #  the CDC incremental dataset from source ##
            if predicates and custom_starting_timestamp:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                    predicates=predicates,
                    custom_starting_timestamp=custom_starting_timestamp,
                )
            elif predicates and not custom_starting_timestamp:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                    predicates=predicates,
                )
            elif custom_starting_timestamp and not predicates:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                    custom_starting_timestamp=custom_starting_timestamp,
                )
            else:
                incremental_df = QueryUtils(spark=spark).read_cdc_batch(
                    logger,
                    source_complete_table_name,
                    latest_timestamp=latest_timestamp,
                )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "LOW",
                "Minor error during reading of the CDC incremental dataset: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)

        ## count the incremental dataframe
        conf["source_record_count"] = incremental_df.count()
        if incremental_df.count() == 0:
            raise Exception(
                """No incremental data fetched from earlier hop, 
                raising exception to abort further execution of the script."""
            )

        ## based on select statement, get only the required columns ##
        if df_cols:
            incremental_df = incremental_df.select(*df_cols)

        ## calling the required function to convert spark df to pandas
        # df with help of payload column via config ##
        df_pandas = JSONUtils().convert_spark_df_to_pandas_df(
            logger, incremental_df, conf.get("payload_col")
        )

        ## normalizing the first layer of the payload column ##
        try:
            if "pay_load_sep" in conf.keys():
                delim = conf["pay_load_sep"]
            else:
                delim = "_"
            df_pandas_norm_first = pd.json_normalize(
                df_pandas[conf.get("payload_col")], sep=delim
            )
            ## replace every numpy/pandas NAN objects with proper nulls ##
            df_pandas_norm_first = df_pandas_norm_first.where(
                pd.notnull(df_pandas_norm_first), nan_replacement
            )

        except Exception as err:
            conf = AlertUtils().generate_alerts_dictionary(
                logger, conf, "CRITICAL", err
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)
            logger.error(f"Issue while normalizing the first layer of JSON: {err}")
            raise SystemError(err)
        # logger.info(df_pandas_norm_first.to_string())
        if conf.get("drop_empty_array", False) == "true":
            df_pandas_norm_first = df_pandas_norm_first[
                df_pandas_norm_first.astype(bool)
            ]
        if conf.get("drop_null", False) == "true":
            df_pandas_norm_first.dropna(axis=1, inplace=True)
            logger.info("Dropped Null data from daatframe")
        if conf.get("concat_with_source", False) == "true":
            nested_cols = [
                str(col) + "." + i
                for col in list(df_pandas_norm_first.columns)
                for i in conf["parse_cols"]
            ]
            # flatten_json_df = JSONUtils().recursive_explode(logger,
            # df_pandas_norm_first, str(df_pandas_norm_first.columns))
            df_pandas_concat = pd.concat(
                [df_pandas, df_pandas_norm_first], sort=False, axis=1
            )
            logger.info("Concatenated the dataframe with source dataframe")
            schema = StructType(
                [
                    (
                        StructField(key, StringType(), True)
                        if key not in list(df_pandas_norm_first.columns)
                        else StructField(
                            key, ArrayType(MapType(StringType(), StringType())), True
                        )
                    )
                    for key in df_pandas_concat.columns
                ]
            )
            master_spark_df = spark.createDataFrame(df_pandas_concat, schema)
            for col_name in df_pandas_norm_first.columns:
                spark_df = master_spark_df.withColumn(col_name, explode(col(col_name)))
            master_spark_df = spark_df.selectExpr("*", *nested_cols)

            # res = spark_df.select("*",explode(",".join(
            # list(df_pandas_norm_first.columns))).alias("flattened"))
            # json_col_name = 'flattened'
            # keys = res.select(f"{json_col_name}.*").columns
            # jsonFields= [f"{json_col_name}.{key} {key}" for key in keys]
            # main_fields = [key for key in res.columns if key not in (json_col_name,
            # conf.get('payload_col'), ",".join(list(df_pandas_norm_first.columns)))]
            # master_spark_df = res.selectExpr(main_fields + jsonFields)

        else:
            ## flatten the json based on the root and child nodes mentioned in the param file ##
            if "root_node" not in conf.keys():
                conf["root_node"] = None
            if "children_nodes" not in conf.keys():
                conf["children_nodes"] = None

            if conf.get("object_name") == "jenkins_report":
                required_data = JSONUtils().pandas_flatten_nested_json(
                    logger,
                    df_pandas_norm_first,
                    list(df_pandas_norm_first.columns),
                    conf.get("children_nodes"),
                    conf,
                )
            else:
                parent_node = conf.get("root_node") or conf.get("parent_node")
                required_data = JSONUtils().pandas_flatten_nested_json(
                    logger,
                    df_pandas_norm_first,
                    parent_node,
                    conf.get("children_nodes"),
                    conf,
                )
            logger.info(
                "Flattening of dictionary done,\
             returning the simplified list for creating dataframe."
            )
            ## create the pandas dataframe from flattened json ##
            master_pandas_df = pd.DataFrame(required_data)

            ## pivot
        if "pivot" in conf.keys() and conf["pivot"] is True:
            if (
                "pivot_intermediate_save" in conf.keys()
                and conf.get("pivot_intermediate_save") is True
            ):
                logger.info("*" * 20 + " Intermediate table save : True " + "*" * 20)
                QueryUtils(spark=spark).pivot_dataframe(
                    logger,
                    master_pandas_df.loc[:, conf["pivot_column"]],
                    conf["unpivot_cols"],
                    conf["pivot_id_col"],
                    conf["pivot_value_col"],
                    conf=conf,
                    target_complete_table_name=target_complete_table_name,
                )
                master_spark_df = spark.read.table(target_complete_table_name + "_temp")

            else:
                df_pivot_list = []
                df_pivot_list = QueryUtils(spark=spark).pivot_dataframe(
                    logger,
                    master_pandas_df.loc[:, conf["pivot_column"]],
                    conf["unpivot_cols"],
                    conf["pivot_id_col"],
                    conf["pivot_value_col"],
                    conf=conf,
                )
                logger.info(
                    "*" * 20 + " Merging the list of pivoted dataframes " + "*" * 20
                )
                master_spark_df = reduce(DataFrame.unionAll, df_pivot_list)

        ## check if master_spark_df is already a spark dataframe. create the
        # spark dataframe from pandas dataframe ##
        if "master_spark_df" in locals() and isinstance(
            master_spark_df, pyspark.sql.dataframe.DataFrame
        ):
            logger.info("Master dataframe is already a spark dataframe")
        else:
            logger.info("Creating dataframe from pandas dataframe")
            schema = StructType(
                [
                    StructField(key, StringType(), True)
                    for key in master_pandas_df.columns
                ]
            )
            master_spark_df = spark.createDataFrame(master_pandas_df, schema)

        logger.info("Dataframe created")

        ## rename the columns for raw layer where there is no root node
        master_spark_df = SparkUtils().rename_columns_for_raw_having_dots(
            logger, master_spark_df
        )

        # data completeness checks
        try:
            master_spark_df.select(conf["source_mandatory_cols"])
            logger.info("data completeness checks passed")
            QueryUtils(spark=spark).load_data_completeness_tracker(
                conf["data_product"],
                "N/A",
                "N/A",
                "True",
                env,
                conf["data_completeness_tbl"],
            )
        except Exception as err:
            logger.error(
                "Error In - run_api_landing_to_raw()\
                 --> mandatory columns not present in source layer"
            )
            QueryUtils(spark=spark).load_data_completeness_tracker(
                conf["data_product"],
                "N/A",
                "N/A",
                "False",
                env,
                conf["data_completeness_tbl"],
            )
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "CRITICAL",
                """Issue with curated layer source mandatory 
                columns:required columns not found on source layer"""
                + str(err),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)
            sys.exit(
                "Error In - run_api_landing_to_raw()\
             --> mandatory columns not present in source layer"
            )

        try:
            ## generate the operational attributes using common_utils ##
            master_spark_df = SparkUtils().add_operational_attributes(
                logger,
                spark,
                master_spark_df,
                job_name=job_name,
                run_id=job_id,
                hop_name=conf["target_hop_name"],
            )
        except Exception as e:
            conf = AlertUtils().generate_alerts_dictionary(
                logger,
                conf,
                "MEDIUM",
                "Issue with adding operational attributes: " + str(e),
            )
            AlertUtils().load_alerts_table(logger, spark, job_id, conf)

        ## rename the columns for raw layer ##
        master_spark_df = SparkUtils().rename_columns_for_raw(logger, master_spark_df)

        ## count master dataframe
        conf["target_record_count"] = master_spark_df.count()

        # #Casting all the columns to String
        master_spark_df = master_spark_df.select(
            [col(each_col).cast("string") for each_col in master_spark_df.columns]
        )

        ## Replace all occurrences of 'NaN' with null values in all columns ##
        master_spark_df = master_spark_df.select(
            [col(each_col).alias(each_col) for each_col in master_spark_df.columns]
        ).na.replace("NaN", None)

        # ## writing the dataframe to final raw layer tables ##
        QueryUtils(spark=spark).write_dataframe_to_delta(
            logger,
            spark,
            conf,
            master_spark_df,
            target_complete_table_name,
            tech_solution_id=conf["tech_solution_id"],
            cloudred_gid=conf["cloudred_gid"],
        )

        ##change status and get the count of delta table
        status = "SUCCESS"
        conf["target_data_count_after_load"] = spark.sql(
            f"SELECT COUNT(*) FROM {conf['target_database_name']}.{conf['target_table_name']}"
        ).head()[0]

    except Exception as err:
        logger.error(f"Error In - run_api_landing_to_raw() : {err}")
        conf["target_record_count"] = 0
        status = "FAILURE"
        conf = AlertUtils().generate_alerts_dictionary(logger, conf, "HIGH", err)
        QueryUtils(spark=spark).update_batch_load_tracker(
            project_name=product_conf["product_name"],
            env=bf_context.env,
            batch_tracker_table=batch_complete_table_name,
            status=status,
        )
        AlertUtils().load_alerts_table(logger, spark, job_id, conf)
        if conf["source_record_count"] == 0:
            logger.error(
                "No incremental data fetched from earlier hop, exiting the script."
            )
        else:
            raise SystemError(err)
    finally:
        # load data in audit table
        AuditUtils().load_audit_table(
            logger,
            spark,
            job_id,
            conf,
            status,
            source_table_type="delta",
            target_table_type="delta",
            source_hop=conf["source_hop_name"],
            target_hop=conf["target_hop_name"],
        )
        logger.info("*" * 20 + " END: run_api_landing_to_raw()" + "*" * 20)
        spark.sql(f"DROP TABLE IF EXISTS {target_complete_table_name}_temp")
