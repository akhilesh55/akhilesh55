"""
Module: UTIL_EMAIL_AND_SLACK_ALERTS
Purpose: This module is responsible for sending email and Slack alerts.

The function `run_email_and_slack_alerts` performs the following steps:
1. Reads configuration settings from a specified path.
2. Utilizes the configuration to send email and Slack alerts.
3. Leverages utility functions from the common utilities package.

Modification History:
=================================================================================
Date         Version  Created/Modified By               Comments
-----------  -------  ----------------------         -------------------------------
13-DEC-2023  v1.00    Shwetha Bc (sbc)               Initial Development (SDF-716)
05-JAN-2024  v1.01    Prasad Nadiger (pnadig)        Added AlertUtils from common (SDF-962)
19-MAR-2024  v1.02    Aditya kumar (aku231)      Added Information schema alerts function (SDF-1676)
==================================================================================
"""

import sys
import os
from products.common_utilities.spark.python.src.common_utilities import (
    LoggerUtils,
    ConfigUtils,
    AlertUtils,
    SparkUtils,
)
from io import BytesIO
import pandas as pd

## adding the current directory of the file to the sys path list ##
sys.path.append(os.path.abspath(os.getcwd()))


def run_email_and_slack_alerts(
    config_path: str,
    config_name: str,
    env: str,
    email_template_path: str,
    email_template_file: str,
    root_dir: str,
    bf_context: object,
) -> None:
    """
    Function Name: run_email_and_slack_alerts.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param email_template_path: string\n
            :param email_template_file: string\n
            :param root_dir: string\n
            :param bf_context: object\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("*" * 20 + " START: run_email_and_slack_alerts()" + "*" * 20)

        ## call the function in ConfigUtils to read the configurations present
        # in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        token_username = None
        token_password = None

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password
        conf["email_template_dir"] = email_template_path
        conf["email_template_file_name"] = email_template_file
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]

        AlertUtils().send_alert_notification(logger, spark, conf, env)

    except Exception as err:
        logger.error(f"Error In - run_email_and_slack_alerts() : {err}")
        raise SystemError(err) from err
    finally:
        logger.info("*" * 20 + " END: run_email_and_slack_alerts()" + "*" * 20)


# def run_info_schema_alerts(config_path: str, config_name: str, env: str,
#  root_dir: str, bf_context: object) -> None:
def run_info_schema_alerts(
    config_path: str,
    config_name: str,
    env: str,
    root_dir: str,
    bf_context: object,
    html_path: str,
    html_name: str,
) -> None:
    """
    Function Name: run_info_schema_alerts.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param email_template_path: string\n
            :param email_template_file: string\n
            :param root_dir: string\n
            :param bf_context: object\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info(f"{'*' * 20} START: run_info_schema_alerts() {'*' * 20}")

        ## call the function in ConfigUtils to read the configurations present in
        # TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        token_username = None
        token_password = None

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        # conf["body"] = open(html_path + html_name, "r").read()
        with open(html_path + html_name, "r") as f:
            conf["body"] = f.read()
        conf["subject"] = f"SDF-ITC Info Schema Alert Notifications - {env}"

        AlertUtils().send_Info_Schema_Alerts(logger, spark, conf, env)

    except Exception as err:
        logger.error(f"Error In - run_info_schema_alerts() : {err}")
        raise SystemError(err) from err
    finally:
        logger.info("*" * 20 + " END: run_info_schema_alerts()" + "*" * 20)


def run_sla_alerts(
    config_path: str,
    config_name: str,
    env: str,
    bf_context: object,
    project_name: str,
    wf_name: str,
    html_path: str,
    html_name: str,
    batch_id_end: str = None,
) -> None:
    """
    Function Name: run_sla_alerts.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param bf_context: object\n
            :param project_name: string\n
            :param wf_name: string\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info(f"{'*' * 20} START: sla_alerts() {'*' * 20}")

        logger.info("%s %s", "??" * 10, batch_id_end)

        ## call the function in ConfigUtils to read the configurations
        #  present in TOML file and get dictionary of values ##
        logger.info(config_path)
        conf = ConfigUtils().read_config_variables(
            config_path=config_path,
            config_name=config_name,
            env=env,
            logger=logger,
            wf_name=wf_name,
        )
        token_username = None
        token_password = None

        ## call the function in ConfigUtils to read the configurations
        #  present in TOML file and get dictionary of values ##
        logger.info(config_path)
        conf = ConfigUtils().read_config_variables(
            config_path=config_path,
            config_name=config_name,
            env=env,
            logger=logger,
            wf_name=wf_name,
        )
        token_username = None
        token_password = None

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf.get("dbx_scope")
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password
        conf["project_name"] = project_name
        conf["wf_name"] = wf_name
        # conf["body"] = open(html_path + html_name, "r").read()
        with open(html_path + html_name, "r") as f:
            conf["body"] = f.read()
        AlertUtils().alerts_wf_sla_check(logger, spark, conf, env, batch_id_end)

    except Exception as err:
        logger.error(f"Error In - run_sla_alerts() : {err}")
        raise SystemError(err) from err
    finally:
        logger.info("%s END: run_sla_alerts() %s", "*" * 20, "*" * 20)


def send_site_alerts(
    config_path: str,
    config_name: str,
    env: str,
    root_dir: str,
    bf_context: object,
    html_path: str,
    html_name: str,
) -> None:
    """
    Function Name: send_site_alerts.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param email_template_path: string\n
            :param email_template_file: string\n
            :param root_dir: string\n
            :param bf_context: object\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: send_site_alerts() %s", "*" * 20, "*" * 20)

        ## call the function in ConfigUtils to read the configurations
        #  present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        token_username = None
        token_password = None

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        with open(html_path + html_name, "r") as f:
            conf["body"] = f.read()
        conf["subject"] = f"SDF-ITC Info Duplicate Site Alert Notifications - {env}"

        AlertUtils().send_info_site_alerts(logger, spark, conf, env)

    except Exception as err:
        logger.error("Error In - send_site_alerts() : %s", err)
        raise SystemError(err) from err
    finally:
        logger.info("%s END: send_site_alerts() %s", "*" * 20, "*" * 20)


def send_location_chg_alerts(
    config_path: str,
    config_name: str,
    env: str,
    root_dir: str,
    bf_context: object,
    html_path: str,
    html_name: str,
    actual_ovr_extpt: bool = False,
) -> None:
    """
    Function Name: send_site_alerts.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param email_template_path: string\n
            :param email_template_file: string\n
            :param root_dir: string\n
            :param bf_context: object\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: send_site_alerts() %s", "*" * 20, "*" * 20)

        ## call the function in ConfigUtils to read the configurations
        #  present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        token_username = None
        token_password = None

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        with open(html_path + html_name, "r") as f:
            conf["body"] = f.read()
        if actual_ovr_extpt:
            conf["subject"] = (
                f"SDF-ITC Alerts for Actual Over Extrapolation Data - {env}"
            )
            AlertUtils().sendmail_site_alerts(
                logger, spark, conf, env, actual_ovr_extpt
            )

        else:
            conf["subject"] = f"SDF-ITC Alerts for Location Changes - {env}"
            AlertUtils().sendmail_site_alerts(logger, spark, conf, env)

    except Exception as err:
        logger.error("Error In - send_site_alerts() : %s", err)
        raise SystemError(err) from err
    finally:
        logger.info("%s END: send_site_alerts() %s", "*" * 20, "*" * 20)


def send_location_uom_info_alerts(
    config_path: str,
    config_name: str,
    env: str,
    root_dir: str,
    bf_context: object,
    html_path: str,
    html_name: str,
) -> None:
    """
    Function Name: send_location_uom_info_alerts.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param email_template_path: string\n
            :param email_template_file: string\n
            :param root_dir: string\n
            :param bf_context: object\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: send_location_uom_info_alerts() %s", "*" * 20, "*" * 20)

        ## call the function in ConfigUtils to read the configurations
        #  present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        token_username = None
        token_password = None
        subject = conf.get("subject_msg")

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        with open(html_path + html_name, "r") as f:
            conf["body"] = f.read()
        conf["subject"] = f"{subject} - {env}"

        AlertUtils().send_site_uom_info_alerts(logger, spark, conf, env)

    except Exception as err:
        logger.error("Error In - send_location_uom_info_alerts() : %s", err)
        raise SystemError(err) from err
    finally:
        logger.info("%s END: send_location_uom_info_alerts() %s", "*" * 20, "*" * 20)


def send_email_alerts(
    config_path: str,
    config_name: str,
    env: str,
    root_dir: str,
    bf_context: object,
    sql_file_path: str,
    sql_file_name: str,
    html_path: str = None,
    html_name: str = None,
) -> None:
    """
    Function Name: send_location_uom_info_alerts.\n
    Params:
            :param config_path: string\n
            :param config_name: string\n
            :param env: string\n
            :param email_template_path: string\n
            :param email_template_file: string\n
            :param root_dir: string\n
            :param bf_context: object\n
    Returns: None
    """
    try:
        ## call the function in LoggerUtils to configure the logger object ##
        logger = LoggerUtils().get_logger_object()
        logger.info("%s START: send_location_uom_info_alerts() %s", "*" * 20, "*" * 20)

        ## call the function in ConfigUtils to read the configurations
        #  present in TOML file and get dictionary of values ##
        conf = ConfigUtils().read_config_variables(
            config_path=config_path, config_name=config_name, env=env, logger=logger
        )
        logger.info("Config Variables: %s", conf)
        product_conf = ConfigUtils().read_config_variables(
            config_path=root_dir,
            config_name="product-info.toml",
            env=env,
            logger=logger,
        )
        token_username = None
        token_password = None
        excel_buffer = None
        subject = conf.get("subject_msg")

        # call the function from common utils to get spark session object ##
        job_name = conf.get("job_name") or str(__name__).split(".")[-2].replace("/", "")
        spark = SparkUtils().get_spark_session(logger, job_name)

        (
            token_username,
            token_password,
        ) = ConfigUtils().get_username_password_from_dbx_secrets(
            logger, bf_context, conf["dbx_scope"]
        )
        if token_username is None or token_password is None:
            raise ValueError("Username or Password is None")

        conf["username"] = token_username
        conf["password"] = token_password
        conf["tech_solution_id"] = product_conf["tech_solution_id"]
        conf["cloudred_gid"] = product_conf["nike-tagguid"]
        # with open(html_path + html_name, "r") as f:
        #     conf["body"] = f.read()
        conf["subject"] = f"{subject} - {env}"

        if conf.get("attachment_details"):
            logger.info(f"**** Adding attachment details ****")
            sql_file_contents = SparkUtils().get_sql_file_content(
                logger, sql_file_path, sql_file_name
            )

            # Formats the sql query with variables ##
            sql_query = SparkUtils().format_sql_query_with_variables(
                logger,
                sql_file_contents,
                kwargs=conf.get("attachment_details", {}).get("sql_variables"),
            )
            # Initialize excel buffer
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="xlsxwriter") as writer:
                # Check for multiple sql queries in the file
                if conf.get("attachment_details", {}).get("sql_separator"):
                    sql_query_list = sql_query.split(
                        conf.get("attachment_details", {}).get("sql_separator")
                    )
                    # Loop through each sql query and write to excel
                    for n in range(1, len(sql_query_list), 2):
                        df_sql_info = SparkUtils().execute_spark_sql(
                            spark, sql_query_list[n + 1]
                        )
                        df_sql_info.display()
                        df_sql_info = df_sql_info.toPandas()
                        df_sql_info.to_excel(
                            writer, sheet_name=sql_query_list[n], index=False
                        )

                else:
                    df_sql_info = (
                        SparkUtils().execute_spark_sql(spark, sql_query).toPandas()
                    )
                    df_sql_info.to_excel(
                        writer,
                        sheet_name=conf.get("attachment_details", {}).get(
                            "sheet_name", "sheet1"
                        ),
                        index=False,
                    )

            excel_buffer.seek(0)

        with open(html_path + html_name, "r") as f:
            conf["body"] = f.read()
        conf["body"] = conf["body"].format(
            env=env,
            team_email=conf.get("team_email", ""),
            **conf.get("attachment_details", {}).get("html_variables", {}),
        )
        AlertUtils().send_mail(logger, conf, env, excel_buffer)

    except Exception as err:
        logger.error("Error In - send_location_uom_info_alerts() : %s", err)
        raise SystemError(err) from err
    finally:
        logger.info("%s END: send_location_uom_info_alerts() %s", "*" * 20, "*" * 20)
