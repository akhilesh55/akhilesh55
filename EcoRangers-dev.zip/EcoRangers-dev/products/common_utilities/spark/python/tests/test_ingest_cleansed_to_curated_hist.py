import pytest
from unittest.mock import MagicMock, patch
from pyspark.sql import DataFrame
from products.common_utilities.spark.python.src.util_ingest_cleansed_to_curatedhist import (
    run_ingest_cleansed_to_curatedhist,
)


@patch(
    "products.common_utilities.spark.python.src.util_ingest_cleansed_to_curatedhist.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_cleansed_to_curatedhist.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_cleansed_to_curatedhist.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_cleansed_to_curatedhist.QueryUtils"
)
def test_run_ingest_cleansed_to_curatedhist_success(
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "target_database_name": "test_db",
        "target_table_name": "test_table",
        "source_tables_list": ["source_table1", "source_table2"],
        "source_database_name": "source_db",
        "predicates": "test_predicates",
        "custom_starting_timestamp": "2021-01-01T00:00:00",
        "source_hop_name": "test_hop_name",
        "target_hop_name": "test_target_hop_name",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "tech_solution_id": "test_tech_solution_id",
        "nike-tagguid": "test_nike_tagguid",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    # Mock the read_cdc_batch method
    mock_query_utils.return_value.read_cdc_batch = MagicMock()

    # Call the function
    with pytest.raises(SystemExit):
        run_ingest_cleansed_to_curatedhist(
            "config_path",
            "config_name",
            "sql_file_path",
            "sql_file_name",
            "dev",
            mock_bf_context,
            "root_dir",
        )

    # Assertions
    mock_logger.info.assert_any_call(
        "%s START: run_ingest_cleansed_to_curatedhist() %s", "*" * 20, "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.read_config_variables.assert_any_call(
        config_path="config_path",
        config_name="config_name",
        env="dev",
        logger=mock_logger,
    )
    mock_config_utils.return_value.read_config_variables.assert_any_call(
        config_path="root_dir",
        config_name="product-info.toml",
        env="dev",
        logger=mock_logger,
    )
    mock_bf_context.get_parameter.assert_called_once_with(
        key="brickflow_job_id", debug="987987987987987"
    )
    # mock_query_utils.return_value.read_cdc_batch.assert_called()

    # mock_logger.info.assert_any_call(
    #     "%s END: run_ingest_cleansed_to_curatedhist() %s", "*" * 20, "*" * 20
    # )
    # mock_logger.error.assert_any_call("Error In - run_autoloader_to_raw() --> File format not supported")
    # mock_alert_utils.return_value.load_alerts_table.assert_called_once()
    # mock_audit_utils.return_value.load_audit_table.assert_called_once()
    # mock_logger.info.assert_any_call(
    #     "%s END: run_ingest_cleansed_to_curatedhist() %s", "*" * 20, "*" * 20

    # )
