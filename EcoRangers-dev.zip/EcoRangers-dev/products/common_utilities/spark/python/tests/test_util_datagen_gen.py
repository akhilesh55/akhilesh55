# import unittest
# from datetime import datetime
# from pyspark.sql import SparkSession
# import dbldatagen as dg
# from products.common_utilities.spark.python.src.util_datagen_gen import (
#     generate_orders_data,
# )
# from pyspark.sql import DataFrame


# class TestGenerateOrdersData(unittest.TestCase):

#     @classmethod
#     def setUpClass(cls):
#         cls.spark = SparkSession.builder.appName("DataGenTest").getOrCreate()

#     @classmethod
#     def tearDownClass(cls):
#         cls.spark.stop()

#     def test_generate_orders_data_runs(self):
#         try:
#             generate_orders_data()
#         except Exception as e:
#             self.fail(f"generate_orders_data() raised an exception: {e}")

#     def test_generate_orders_data_schema(self):
#         generation_spec = (
#             dg.DataGenerator(
#                 self.spark, name="test_data_set1", rows=1000000, partitions=4
#             )
#             .withColumn("/1DH/CDS_VIEW", "string", values=["SCD_TYPE2_TEST_DATASET"])
#             .withColumn("/1DH/OPERATION", "string", values=["I", "U", "D"], random=True)
#             .withColumn(
#                 "PLANT",
#                 "int",
#                 minValue=9999990,
#                 maxValue=111999990,
#                 step=1,
#                 random=True,
#             )
#             .withColumn(
#                 "MATERIALDOCUMENTKEY1",
#                 "double",
#                 minValue=1000000,
#                 maxValue=9000000,
#                 random=True,
#             )
#             .withColumn(
#                 "MATERIALDOCUMENTKEY2",
#                 "string",
#                 values=["IAA", "UAAAA", "DEEEE"],
#                 random=True,
#             )
#             .withColumn(
#                 "MATERIALDOCUMENTKEY3",
#                 "double",
#                 minValue=100000,
#                 maxValue=9000000,
#                 random=True,
#             )
#             .withColumn(
#                 "MATERIALDOCUMENTKEY4",
#                 "double",
#                 minValue=100000,
#                 maxValue=9000000,
#                 random=True,
#             )
#             .withColumn(
#                 "MATERIALDOCUMENTKEY5",
#                 "double",
#                 minValue=100000,
#                 maxValue=9000000,
#                 random=True,
#             )
#             .withColumn(
#                 "MATERIALDOCUMENTKEY6",
#                 "double",
#                 minValue=100000,
#                 maxValue=9000000,
#                 random=True,
#             )
#             .withColumn(
#                 "POSTINGDATE",
#                 "timestamp",
#                 begin=datetime(2020, 1, 1),
#                 end=datetime(2024, 12, 31),
#                 random=True,
#             )
#             .withColumn(
#                 "CREATIONDATE",
#                 "timestamp",
#                 begin=datetime(2020, 1, 1),
#                 end=datetime(2024, 12, 31),
#                 random=True,
#             )
#             .withColumn(
#                 "DOCUMENTDATE",
#                 "timestamp",
#                 begin=datetime(2020, 1, 1),
#                 end=datetime(2024, 12, 31),
#                 random=True,
#             )
#             .withColumn(
#                 "DI_TIMESTAMP",
#                 "timestamp",
#                 begin=datetime(2020, 1, 1),
#                 end=datetime(2024, 12, 31),
#                 random=True,
#             )
#             .withColumn(
#                 "CANCELLEDITEMINDICATOR", "string", values=["Y", "N"], random=True
#             )
#             .withColumn(
#                 "CREATIONTIME",
#                 "timestamp",
#                 begin=datetime(2019, 1, 1),
#                 end=datetime(2020, 12, 31),
#                 random=True,
#             )
#             .withColumn("DI_SEQNO", "int", minValue=1, maxValue=9999)
#             .withColumn("FISCALYEARVARIANT", "string", values=["2024"])
#             .withColumn(
#                 "GOODSMOVEMENTREFDOCTYPE",
#                 "string",
#                 values=["AD", "AC", "BA", "BC"],
#                 random=True,
#             )
#             .withColumn(
#                 "INVENTORYSPECIALSTOCKTYPE", "string", values=["I", "O"], random=True
#             )
#             .withColumn(
#                 "INVENTORYSPECIALSTOCKVALNTYPE",
#                 "string",
#                 values=["0", "1"],
#                 random=True,
#             )
#             .withColumn(
#                 "INVENTORYTRANSACTIONTYPE",
#                 "string",
#                 values=["Real", "Unreal"],
#                 random=True,
#             )
#             .withColumn("MATERIALBASEUNIT", "string", minValue=1, maxValue=20, step=0.5)
#             .withColumn(
#                 "MATERIALDOCUMENTITEMTEXT", "string", values=["A", "C"], random=True
#             )
#             .withColumn(
#                 "QUANTITYINBASEUNIT", "double", minValue=1.0, maxValue=1000.0, step=0.5
#             )
#             .withColumn(
#                 "QUANTITYINENTRYUNIT", "double", minValue=1.0, maxValue=1000.0, step=0.5
#             )
#             .withColumn("RECEIPTINDICATOR", "string", values=["Y", "N"], random=True)
#             .withColumn(
#                 "REFMATERIALDOCUMENTYEAR",
#                 "string",
#                 values=["2023", "2024"],
#                 random=True,
#             )
#             .withColumn("TOTALGOODSMVTAMTINCCCRCY", "double", minValue=1.0)
#         )
#         df = generation_spec.build()
#         self.assertIsNotNone(df)
#         self.assertEqual(len(df.columns), 28)
