import pytest
import asyncio
import asyncssh
from unittest.mock import AsyncMock, patch, MagicMock
from products.common_utilities.spark.python.src.util_sftp_to_s3 import (
    run_sftp_to_s3,
    ConnectionFailureException,
    PermissionDeniedException,
)
from pyspark.sql import DataFrame

# @pytest.mark.asyncio
# async def test_run_sftp_to_s3_success():
#     # Mock dependencies
#     mock_logger = MagicMock()
#     mock_bf_context = MagicMock()
#     mock_bf_context.get_parameter.return_value = "987987987987987"
#     mock_bf_context.dbutils.secrets.get.side_effect = ["sftp_server", "sftp_user", "sftp_scrt"]
#     mock_config_utils = MagicMock()
#     mock_conf = {
#         "config_path": "config_path",
#         "config_name": "config_name",
#         "env": "env",
#         "bf_context": MagicMock(),
#         "root_dir": "root_dir",
#         "dbx_scope": "ecorangers-enterprise-box",
#         "src_box_id": ["237107982158"],
#         "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
#         "function_name": "sftp_to_s3",
#     }
#     mock_product_conf = {
#         "product_name": "test_product",
#         "team_name": "SDF-ITC",
#         "org_name": "da",
#         "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
#         "product_type": "data-product",
#         "product_documentation": (
#             "This data product template contains common files for SDF-ITC and SEAM-ITC"
#         ),
#         "product_owners": ["sonali.patnaik@nike.com"],
#         "programming_languages": ["python"],
#         "tags": ["Global", "SDF-ITC"],
#         "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
#         "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
#     }

#     mock_config_utils.return_value.read_config_variables.side_effect = [
#         mock_conf,
#         mock_product_conf,
#     ]

#     mock_sftp_client = AsyncMock()
#     mock_sftp_client.listdir.return_value = ["file1.csv", "file2.csv"]
#     mock_sftp_client.stat.return_value = MagicMock(mtime=1609459200, size=1024)  # Mock file stat

#     mock_conn = AsyncMock()
#     mock_conn.start_sftp_client.return_value = mock_sftp_client

#     async def mock_connect(*_, **__):
#         return  mock_conn

#     # mock_conn.__aenter__ = AsyncMock(return_value=mock_conn)
#     # mock_conn.__aexit__ = AsyncMock(return_value=None)

#     with patch(
#         "products.common_utilities.spark.python.src.LoggerUtils.get_logger_object",
#         return_value=mock_logger
#     ), patch(
#         "products.common_utilities.spark.python.src.ConfigUtils.read_config_variables",
#         return_value=mock_config_utils
#     ), patch(
#         "products.common_utilities.spark.python.src.SparkUtils.get_spark_session",
#         return_value=MagicMock()
#     ), patch(
#         "asyncssh.connect", new= asyncssh.get_event_loop().run_until_complete):

#         result = run_sftp_to_s3(
#             project_name="test_project",
#             config_path="config_path",
#             config_name="config_name",
#             env="test_env",
#             bf_context=mock_bf_context,
#             root_dir="root_dir",
#             timestamp_to_pull_from="20210101000000"
#         )

#         assert await result == "20210101000000"
#         mock_logger.info.assert_called_with("New Batch ID: %s", "20210101000000")


@pytest.mark.asyncio
async def test_run_sftp_to_s3_connection_failure():
    # Mock dependencies
    mock_logger = MagicMock()
    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"
    mock_bf_context.dbutils.secrets.get.side_effect = [
        "sftp_server",
        "sftp_user",
        "sftp_scrt",
    ]
    mock_config_utils = MagicMock()
    mock_conf = {
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "dbx_scope": "ecorangers-enterprise-box",
        "src_box_id": ["237107982158"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "function_name": "sftp_to_s3",
        "max_retries": 3,  # Ensure this is an integer
        "target_database_name": "test_db",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": (
            "This data product template contains common files for SDF-ITC and SEAM-ITC"
        ),
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    with patch(
        "products.common_utilities.spark.python.src.LoggerUtils.get_logger_object",
        return_value=mock_logger,
    ), patch(
        "products.common_utilities.spark.python.src.ConfigUtils.read_config_variables",
        return_value={
            "max_retries": 1,
            "target_database_name": "test_db",
            "target_path": "test_path",
            "tech_solution_id": "test_tech_solution_id",
            "nike-tagguid": "test_nike_tagguid",
            "dbx_scope": "test_scope",
            "function_name": "test_function_name",
        },
    ), patch(
        "products.common_utilities.spark.python.src.SparkUtils.get_spark_session",
        return_value=MagicMock(),
    ), patch(
        "asyncssh.connect",
        side_effect=asyncssh.Error(code=1, reason="Connection failed"),
    ):

        with pytest.raises((ConnectionFailureException)):
            await run_sftp_to_s3(
                project_name="test_project",
                config_path="config_path",
                config_name="config_name",
                env="test_env",
                bf_context=mock_bf_context,
                root_dir="root_dir",
                timestamp_to_pull_from="20210101000000",
            )


@pytest.mark.asyncio
async def test_run_sftp_to_s3_permission_denied():
    # Mock dependencies
    mock_logger = MagicMock()
    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"
    mock_bf_context.dbutils.secrets.get.side_effect = [
        "sftp_server",
        "sftp_user",
        "sftp_scrt",
    ]
    mock_config_utils = MagicMock()
    mock_conf = {
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "dbx_scope": "ecorangers-enterprise-box",
        "src_box_id": ["237107982158"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "function_name": "sftp_to_s3",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": (
            "This data product template contains common files for SDF-ITC and SEAM-ITC"
        ),
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    with patch(
        "products.common_utilities.spark.python.src.LoggerUtils.get_logger_object",
        return_value=mock_logger,
    ), patch(
        "products.common_utilities.spark.python.src.ConfigUtils.read_config_variables",
        return_value=mock_config_utils,
    ), patch(
        "products.common_utilities.spark.python.src.SparkUtils.get_spark_session",
        return_value=MagicMock(),
    ), patch(
        "asyncssh.connect", side_effect=PermissionError
    ):

        with pytest.raises(PermissionDeniedException):
            await run_sftp_to_s3(
                project_name="test_project",
                config_path="config_path",
                config_name="config_name",
                env="test_env",
                bf_context=mock_bf_context,
                root_dir="root_dir",
                timestamp_to_pull_from="20210101000000",
            )
        mock_logger.info.assert_called_with("New Batch ID: %s", "20210101000000")
