import unittest
from unittest.mock import patch, MagicMock
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    AuditUtils,
    AlertUtils,
)
from products.common_utilities.spark.python.src.util_ingest_one_box_metrics import (
    run_ingest_one_box_metrics,
)
from pyspark.sql import DataFrame


class TestIngestOneBoxMetrics(unittest.TestCase):

    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_spark_session"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.LoggerUtils.get_logger_object"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.read_config_variables"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.get_username_password_from_dbx_secrets"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_sql_file_content"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.format_sql_query_with_variables"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.run_snowflake_queries_as_spark_df"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.run_spark_sql_query_as_spark_df"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.add_operational_attributes"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.QueryUtils.write_dataframe_to_delta"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.AuditUtils.load_audit_table"
    )
    # @patch('products.common_utilities.spark.python.src.common_utilities.AlertUtils.generate_alerts_dictionary')
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.AlertUtils.load_alerts_table"
    )
    def test_run_ingest_one_box_metrics(
        self,
        mock_load_alerts_table,
        # mock_generate_alerts_dictionary,
        mock_load_audit_table,
        mock_write_dataframe_to_delta,
        mock_add_operational_attributes,
        mock_run_spark_sql_query_as_spark_df,
        mock_run_snowflake_queries_as_spark_df,
        mock_format_sql_query_with_variables,
        mock_get_sql_file_content,
        mock_get_username_password_from_dbx_secrets,
        mock_read_config_variables,
        mock_get_logger_object,
        mock_get_spark_session,
    ):
        # Mocking the logger
        mock_logger = MagicMock()
        mock_get_logger_object.return_value = mock_logger

        # Mocking the Spark session
        mock_spark = MagicMock()
        mock_get_spark_session.return_value = mock_spark

        # Mocking the configuration
        mock_conf = {
            "job_name": "test_job",
            "audit_database_name": "test_audit_db",
            "target_database_name": "test_target_db",
            "target_table_name": "test_target_table",
            "delta_tables_mapping_dict": {},
            "sf_tables_mapping_dict": {"temp_view": "complete_table"},
            "target_hop_name": "test_hop",
            "source_hop_name": "test_source_hop",
            "dbx_scope": "test_scope",
            "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
            "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
            "do_partition": False,
            "update_tags": False,
        }
        mock_product_conf = {
            "product_name": "test_product",
            "team_name": "SDF-ITC",
            "org_name": "da",
            "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
            "product_type": "data-product",
            "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
            "product_owners": ["sonali.patnaik@nike.com"],
            "programming_languages": ["python"],
            "tags": ["Global", "SDF-ITC"],
            "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
            "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
        }
        mock_read_config_variables.side_effect = [mock_conf, mock_product_conf]

        # Mocking the bf_context
        mock_bf_context = MagicMock()
        mock_bf_context.get_parameter.return_value = "test_job_id"

        # Mocking the SQL file content
        mock_get_sql_file_content.return_value = "SELECT * FROM test_table"

        # Mocking the formatted SQL query
        mock_format_sql_query_with_variables.return_value = "SELECT * FROM test_table"

        # Mocking the Snowflake query result
        mock_snowflake_df = MagicMock()
        mock_run_snowflake_queries_as_spark_df.return_value = mock_snowflake_df

        # Mocking the Spark SQL query result
        mock_query_result_df = MagicMock()
        mock_run_spark_sql_query_as_spark_df.return_value = mock_query_result_df

        # Mocking the master Spark DataFrame
        mock_master_spark_df = MagicMock()
        mock_add_operational_attributes.return_value = mock_master_spark_df

        # Mocking the username and password
        mock_get_username_password_from_dbx_secrets.return_value = (
            "username",
            "password",
        )

        # Running the function
        run_ingest_one_box_metrics(
            config_path="test_config_path",
            config_name="test_config_name",
            sql_file_path="test_sql_file_path",
            sql_file_name="test_sql_file_name",
            env="test_env",
            bf_context=mock_bf_context,
            root_dir="test_root_dir",
        )

        # Assertions
        mock_get_logger_object.assert_called_once()
        mock_get_spark_session.assert_called_once_with(mock_logger, "test_job")
        mock_read_config_variables.assert_called()
        mock_get_username_password_from_dbx_secrets.assert_called_once_with(
            mock_logger, mock_bf_context, "test_scope"
        )
        mock_get_sql_file_content.assert_called_once_with(
            mock_logger, "test_sql_file_path", "test_sql_file_name"
        )
        mock_format_sql_query_with_variables.assert_called_once_with(
            mock_logger, "SELECT * FROM test_table", kwargs={}
        )
        mock_run_snowflake_queries_as_spark_df.assert_called_once_with(
            mock_logger, mock_spark, mock_conf, "select * from complete_table"
        )
        mock_run_spark_sql_query_as_spark_df.assert_called_once_with(
            mock_logger, mock_spark, "SELECT * FROM test_table"
        )
        mock_add_operational_attributes.assert_called_once_with(
            mock_logger,
            mock_spark,
            mock_query_result_df,
            job_name="test_job",
            run_id="test_job_id",
            hop_name="test_hop",
        )
        mock_write_dataframe_to_delta.assert_called_once_with(
            mock_logger,
            mock_spark,
            mock_conf,
            mock_master_spark_df,
            "test_target_db.test_target_table",
            tech_solution_id=mock_conf["tech_solution_id"],
            cloudred_gid=mock_conf["cloudred_gid"],
        )
        mock_load_audit_table.assert_called_once()
        # mock_load_alerts_table.assert_called_once()
        mock_logger.info.assert_any_call(
            "%s END: run_ingest_one_box_metrics() %s", "*" * 20, "*" * 20
        )
