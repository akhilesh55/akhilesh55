import unittest
import pytest
from unittest.mock import patch, MagicMock
from products.common_utilities.spark.python.src.util_multi_site_info_to_table import (
    get_site_details,
)
from pyspark.sql import DataFrame


class TestGetSiteDetails(unittest.TestCase):
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_spark_session"
    # )
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.read_config_variables"
    # )
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_sql_file_content"
    # )
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.SparkUtils.format_sql_query_with_variables"
    # )
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.SparkUtils.run_spark_sql_query_as_spark_df"
    # )
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.SparkUtils.add_operational_attributes"
    # )
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.LoggerUtils.get_logger_object"
    # )
    # @patch(
    #     "products.common_utilities.spark.python.src.common_utilities.QueryUtils.write_dataframe_to_delta"
    # )
    # @patch("products.common_utilities.spark.python.src.common_utilities.ConfigUtils")
    # @patch("products.common_utilities.spark.python.src.common_utilities.SparkUtils")
    # @patch("products.common_utilities.spark.python.src.common_utilities.QueryUtils")
    # def test_get_site_details_all_configs_present(
    #     self,
    #     mock_query_utils,
    #     mock_spark_utils,
    #     mock_config_utils,
    #     mock_write_dataframe_to_delta,
    #     mock_get_logger_object,
    #     mock_add_operational_attributes,
    #     mock_run_spark_sql_query_as_spark_df,
    #     mock_format_sql_query_with_variables,
    #     mock_get_sql_file_content,
    #     mock_read_config_variables,
    #     mock_get_spark_session,
    # ):
    #     # Setup mocks
    #     mock_logger = MagicMock()
    #     mock_get_logger_object.return_value = mock_logger

    #     # Mocking the Spark session
    #     mock_spark = MagicMock()
    #     mock_get_spark_session.return_value = mock_spark

    #     # Mocking the configuration
    #     mock_conf = {
    #         "job_name": "test_job",
    #         "audit_database_name": "test_audit_db",
    #         "target_database_name": "test_target_db",
    #         "target_table_name": "test_target_table",
    #         "delta_tables_mapping_dict": {},
    #         "sf_tables_mapping_dict": {"temp_view": "complete_table"},
    #         "target_hop_name": "test_hop",
    #         "source_hop_name": "test_source_hop",
    #         "dbx_scope": "test_scope",
    #         "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
    #         "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    #         "do_partition": False,
    #         "update_tags": False,
    #     }
    #     mock_product_conf = {
    #         "product_name": "test_product",
    #         "team_name": "SDF-ITC",
    #         "org_name": "da",
    #         "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
    #         "product_type": "data-product",
    #         "product_documentation": (
    #             "This data product template contains common files for "
    #             "SDF-ITC and SEAM-ITC"
    #         ),
    #         "product_owners": ["sonali.patnaik@nike.com"],
    #         "programming_languages": ["python"],
    #         "tags": ["Global", "SDF-ITC"],
    #         "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
    #         "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    #     }
    #     mock_read_config_variables.side_effect = [mock_conf, mock_product_conf]

    #     # Mocking the bf_context
    #     mock_bf_context = MagicMock()
    #     mock_bf_context.get_parameter.return_value = "test_job_id"

    #     # Mocking the SQL file content
    #     # mock_get_sql_file_content.return_value.read_config_variables.return_value = [mock_conf, mock_product_conf]
    #     mock_get_sql_file_content.return_value.read_config_variables.return_value = [mock_conf, mock_product_conf]

    #     # Mocking the formatted SQL query
    #     mock_format_sql_query_with_variables.return_value = "SELECT * FROM test_table"

    #     # Mocking the Spark SQL query result
    #     mock_query_result_df = MagicMock()
    #     mock_run_spark_sql_query_as_spark_df.return_value = mock_query_result_df

    #     # Mocking the master Spark DataFrame
    #     mock_master_spark_df = MagicMock()
    #     mock_add_operational_attributes.return_value = mock_master_spark_df

    #     # Running the function
    #     with pytest.raises(SystemError):
    #         get_site_details(
    #             config_path="test_config_path_1",
    #             config_name="test_config_name",
    #             sql_file_path="test_sql_file_path",
    #             sql_file_name="test_sql_file_name",
    #             env="test_env",
    #             bf_context=mock_bf_context,
    #             root_dir="test_root_dir",
    #         )

    #     # Assertions
    #     mock_get_logger_object.assert_called_once()
    #     mock_get_spark_session.return_value.get_spark_session.return_value = mock_spark

    #     # mock_read_config_variables.assert_called()
    #     # mock_read_config_variables.assert_called_with("test_config_path_1", "test_config_name")
    #     # mock_read_config_variables.assert_any_call("test_config_path_1", "test_config_name")
    #     mock_read_config_variables.assert_any_call([mock_conf, mock_product_conf])
    #     # mock_get_sql_file_content.assert_called_once_with(
    #     #     mock_logger, "test_sql_file_path", "test_sql_file_name"
    #     # )
    #     # mock_format_sql_query_with_variables.assert_called_once_with(
    #     #     mock_logger, "SELECT * FROM test_table", kwargs={}
    #     # )
    #     # mock_run_spark_sql_query_as_spark_df.assert_called_once_with(
    #     #     mock_logger, mock_spark, "SELECT * FROM test_table"
    #     # )
    #     # mock_add_operational_attributes.assert_called_once_with(
    #     #     mock_logger,
    #     #     mock_spark,
    #     #     mock_query_result_df,
    #     #     job_name="test_job",
    #     #     run_id="test_job_id",
    #     #     hop_name="test_hop",
    #     # )
    #     # mock_write_dataframe_to_delta.assert_called_once_with(
    #     #     mock_logger,
    #     #     mock_spark,
    #     #     mock_conf,
    #     #     mock_master_spark_df,
    #     #     "test_target_db.test_target_table",
    #     #     tech_solution_id=mock_conf["tech_solution_id"],
    #     #     cloudred_gid=mock_conf["cloudred_gid"],
    #     # )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_spark_session"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.read_config_variables"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_sql_file_content"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.format_sql_query_with_variables"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.run_spark_sql_query_as_spark_df"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.add_operational_attributes"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.LoggerUtils.get_logger_object"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.QueryUtils.write_dataframe_to_delta"
    )
    @patch("products.common_utilities.spark.python.src.common_utilities.ConfigUtils")
    @patch("products.common_utilities.spark.python.src.common_utilities.SparkUtils")
    @patch("products.common_utilities.spark.python.src.common_utilities.QueryUtils")
    def test_get_site_details_all_configs_present(
        self,
        mock_query_utils,
        mock_spark_utils,
        mock_config_utils,
        mock_write_dataframe_to_delta,
        mock_get_logger_object,
        mock_add_operational_attributes,
        mock_run_spark_sql_query_as_spark_df,
        mock_format_sql_query_with_variables,
        mock_get_sql_file_content,
        mock_read_config_variables,
        mock_get_spark_session,
    ):
        # Setup mocks
        mock_logger = MagicMock()
        mock_get_logger_object.return_value = mock_logger

        # Mocking the Spark session
        mock_spark = MagicMock()
        mock_get_spark_session.return_value = mock_spark

        # Mocking the configuration
        mock_conf = {
            "job_name": "test_job",
            "audit_database_name": "test_audit_db",
            "target_database_name": "test_target_db",
            "target_table_name": "test_target_table",
            "delta_tables_mapping_dict": {},
            "sf_tables_mapping_dict": {"temp_view": "complete_table"},
            "target_hop_name": "test_hop",
            "source_hop_name": "test_source_hop",
            "dbx_scope": "test_scope",
            "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
            "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
            "do_partition": False,
            "update_tags": False,
        }
        mock_product_conf = {
            "product_name": "test_product",
            "team_name": "SDF-ITC",
            "org_name": "da",
            "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
            "product_type": "data-product",
            "product_documentation": (
                "This data product template contains common files for "
                "SDF-ITC and SEAM-ITC"
            ),
            "product_owners": ["sonali.patnaik@nike.com"],
            "programming_languages": ["python"],
            "tags": ["Global", "SDF-ITC"],
            "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
            "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
        }
        mock_read_config_variables.side_effect = [mock_conf, mock_product_conf]

        # Mocking the bf_context
        mock_bf_context = MagicMock()
        mock_bf_context.get_parameter.return_value = "test_job_id"

        # Mocking the SQL file content
        mock_get_sql_file_content.return_value = "SELECT * FROM test_table"

        # Mocking the formatted SQL query
        mock_format_sql_query_with_variables.return_value = "SELECT * FROM test_table"

        # Mocking the Spark SQL query result
        mock_query_result_df = MagicMock()
        mock_run_spark_sql_query_as_spark_df.return_value = mock_query_result_df

        # Mocking the master Spark DataFrame
        mock_master_spark_df = MagicMock()
        mock_add_operational_attributes.return_value = mock_master_spark_df

        # Running the function
        with pytest.raises(SystemError):
            get_site_details(
                config_path="test_config_path_1",
                config_name="test_config_name",
                sql_file_path="test_sql_file_path",
                sql_file_name="test_sql_file_name",
                env="test_env",
                bf_context=mock_bf_context,
                root_dir="test_root_dir",
            )

        # Assertions
        mock_get_logger_object.assert_called_once()
        mock_get_spark_session.return_value.get_spark_session.return_value = mock_spark
        mock_read_config_variables.return_value.read_config_variables.return_value = (
            "test_config_path_1",
            "test_config_name",
        )

        # mock_read_config_variables.assert_any_call("test_config_path_1", "test_config_name")
        # mock_get_sql_file_content.assert_called_once_with(
        #     mock_logger, "test_sql_file_path", "test_sql_file_name"
        # )
        # mock_get_sql_file_content.return_value = "SELECT * FROM test_table"

        # mock_format_sql_query_with_variables.assert_called_once_with(
        #     mock_logger, "SELECT * FROM test_table", {}
        # )
        # mock_run_spark_sql_query_as_spark_df.assert_called_once_with(
        #     mock_logger, mock_spark, "SELECT * FROM test_table"
        # )
        # mock_add_operational_attributes.assert_called_once_with(
        #     mock_logger,
        #     mock_spark,
        #     mock_query_result_df,
        #     job_name="test_job",
        #     run_id="test_job_id",
        #     hop_name="test_hop",
        # )
        # mock_write_dataframe_to_delta.assert_called_once_with(
        #     mock_logger,
        #     mock_spark,
        #     mock_conf,
        #     mock_master_spark_df,
        #     "test_target_db.test_target_table",
        #     tech_solution_id=mock_conf["tech_solution_id"],
        #     cloudred_gid=mock_conf["cloudred_gid"],
        # )

    @patch("products.common_utilities.spark.python.src.common_utilities.LoggerUtils")
    @patch("products.common_utilities.spark.python.src.common_utilities.ConfigUtils")
    def test_get_site_details_missing_config(
        self, mock_config_utils, mock_logger_utils
    ):
        # Setup mocks
        mock_logger = MagicMock()
        mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

        # Simulate missing configuration
        mock_conf = {
            "target_table_name": "test_table",
            "target_hop_name": "test_hop",
            "job_name": "test_job",
            "delta_tables_mapping_dict": {},
        }
        mock_config_utils.return_value.read_config_variables.return_value = mock_conf

        # Call the function and expect a SystemError
        with self.assertRaises(SystemError):
            get_site_details(
                config_path="test_path",
                config_name="test_config",
                sql_file_path="test_sql_path",
                sql_file_name="test_sql_file",
                env="test_env",
                bf_context=MagicMock(),
                root_dir="test_root_dir",
            )

        # Assertions
        # self.assertIn("Missing 'target_database_name' in configuration", str(context.exception))
        # mock_logger.error.assert_called_with(
        #     "Error In - get_site_details() : %s",
        #     "Missing 'target_database_name' in configuration",
        # )

    @patch("products.common_utilities.spark.python.src.common_utilities.LoggerUtils")
    @patch("products.common_utilities.spark.python.src.common_utilities.ConfigUtils")
    @patch("products.common_utilities.spark.python.src.common_utilities.SparkUtils")
    @patch("products.common_utilities.spark.python.src.common_utilities.QueryUtils")
    def test_get_site_details_no_duplicates(
        self, mock_query_utils, mock_spark_utils, mock_config_utils, mock_logger_utils
    ):
        # Setup mocks
        mock_logger = MagicMock()
        mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

        mock_conf = {
            "target_database_name": "test_db",
            "target_table_name": "test_table",
            "target_hop_name": "test_hop",
            "job_name": "test_job",
            "delta_tables_mapping_dict": {},
        }
        mock_product_conf = {
            "tech_solution_id": "test_tech_id",
            "nike-tagguid": "test_guid",
        }
        mock_config_utils.return_value.read_config_variables.side_effect = [
            mock_conf,
            mock_product_conf,
        ]

        mock_spark = MagicMock()
        mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

        mock_bf_context = MagicMock()
        mock_bf_context.get_parameter.return_value = "test_job_id"

        mock_query_result_df = MagicMock()
        mock_query_result_df.count.return_value = 1
        mock_spark_utils.return_value.run_spark_sql_query_as_spark_df.return_value = (
            mock_query_result_df
        )

        # Call the function
        with pytest.raises(SystemError):
            get_site_details(
                config_path="test_path",
                config_name="test_config",
                sql_file_path="test_sql_path",
                sql_file_name="test_sql_file",
                env="test_env",
                bf_context=mock_bf_context,
                root_dir="test_root_dir",
            )
