# import unittest
# from unittest.mock import patch, MagicMock
# from products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl import (
#     run_ingest_curatedhist_to_bcl,
# )
# from pyspark.sql import DataFrame


# class TestRunIngestCuratedhistToBcl(unittest.TestCase):

#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.SparkUtils.get_spark_session"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.ConfigUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.LoggerUtils"
#     )
#     def test_run_ingest_curatedhist_to_bcl_success(
#         self, mock_logger_utils, mock_config_utils, mock_spark_session
#     ):
#         # Setup mocks
#         mock_logger = MagicMock()
#         mock_logger_utils.return_value.get_logger_object.return_value = mock_logger
#         mock_spark = MagicMock()
#         mock_spark_session.return_value = mock_spark

#         # Simulate configuration
#         mock_conf = {
#             "delta_table_database": "development.global_sustainability_dev",
#             "sfurl": "https://nike.snowflakecomputing.com/",
#             "cerberus_endpoint": "https://prod.cerberus.nikecloud.com",
#             "cerberus_sdb_path": "app/ecorangers/common_gid/dev",
#             "dbx_scope": "ecorangers-dev",
#             "sfdatabase": "GLOBAL_SUSTAINABILITY_DEV",
#             "sfschema": "BCL_SUSTAINABILITY_FOUNDATION",
#             "sfrole": "APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE",
#             "sfwarehouse": "EDAI_GLOBAL_SUSTAINABILITY_PREPROD",
#             "checkpoint_basepath": "/Volumes/development/global_sustainability_dev/gps_landing_dev_vol/_checkpoint/dev/snowflake",
#             "env": "dev",
#             "source_hop_name": "curated_hist",
#             "key_columns": [
#                 "reporting_month_mos",
#                 "reporting_fiscal_year_yrs",
#             ],
#             "source": "sdf_gps_hq_usage_metrics_hist",
#             "target": "sdf_gps_hq_usage_metrics_hist",
#             "target_hop_name": "snowflake_BCL",
#             "partition_by_cols": ["load_year_nbr", "load_month_nbr"],
#             "audit_database_name": "development.global_sustainability_dev",
#             "audit_table_name": "sdf_load_tracker_table",
#             "audit_table_columns": [
#                 "batch_id",
#                 "object_name",
#                 "source_stage",
#                 "source_l1_detail",
#                 "source_l2_detail",
#                 "source_record_count",
#                 "source_partition_column_name",
#                 "source_partition_column_values",
#             ],
#             "alert_database_name": "development.global_sustainability_dev",
#             "alert_from": "a.ecorangers.dev@nike.com",
#             "team_email": "Lst-Technology.EDAI.Ecorangers@nike.com",
#             "slack_channel_email": "dev_sdf-itc-alerts-aaaaobnw7vngl4wa3lhu5gpzgq@nike.org.slack.com",
#             "alert_table_name": "sdf_alerts_tracker_table",
#             "alert_table_columns": [
#                 "alert_UUID",
#                 "alert_type",
#                 "alert_severity",
#             ],
#             "function_name": "test_run_ingest_curatedhist_to_bcl_success",
#             "object_name": "sdf_gps_hq_usage_metrics_hist",
#             "job_name": "sdf_gps_hq_usage_metrics_hist",
#             "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
#             "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
#             "merge_schema": "true",
#             "batch_id": 1,
#         }
#         mock_product_conf = {
#             "product_name": "test_product",
#             "tech_solution_id": "test_tech_solution_id",
#             "nike-tagguid": "test_nike_tagguid",
#         }
#         mock_config_utils.return_value.read_config_variables.side_effect = [
#             mock_conf,
#             mock_product_conf,
#         ]

#         # Simulate bf_context
#         mock_bf_context = MagicMock()
#         mock_bf_context.get_parameter.return_value = {"env": "development"}

#         # Simulate get_username_password_from_dbx_secrets
#         mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
#             "username",
#             "password",
#         )

#         # Simulate Spark SQL queries
#         mock_spark.sql.return_value.head.side_effect = "1"

#         # Call the function
#         # with self.assertRaises(SystemError):
#         #     #
#         #     run_ingest_curatedhist_to_bcl(
#         #         config_path="test_path",
#         #         config_name="test_config",
#         #         env="dev",
#         #         bf_context=mock_bf_context,
#         #         root_dir="test_root_dir",
#         #     )

#         # # Assertions
#         # mock_logger.info.assert_any_call(
#         #     "%s START: run_ingest_curatedhist_to_bcl() %s", "*" * 20, "*" * 20
#         # )
#         # mock_logger.error.assert_not_called()

#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.SparkUtils.get_spark_session"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.ConfigUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.LoggerUtils"
#     )
#     def test_run_ingest_curatedhist_to_bcl_value_error(
#         self, mock_logger_utils, mock_config_utils, mock_spark_session
#     ):
#         # Setup mocks
#         mock_logger = MagicMock()
#         mock_logger_utils.return_value.get_logger_object.return_value = mock_logger
#         mock_spark = MagicMock()
#         mock_spark_session.return_value = mock_spark

#         # Simulate configuration
#         mock_conf = {
#             "delta_table_database": "global_sustainability_dev",
#             "sfurl": "https://nike.snowflakecomputing.com/",
#             "cerberus_endpoint": "https://prod.cerberus.nikecloud.com",
#             "cerberus_sdb_path": "app/ecorangers/common_gid/dev",
#             "dbx_scope": "ecorangers-dev",
#             "sfdatabase": "GLOBAL_SUSTAINABILITY_DEV",
#             "sfschema": "BCL_SUSTAINABILITY_FOUNDATION",
#             "sfrole": "APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE",
#             "sfwarehouse": "EDAI_GLOBAL_SUSTAINABILITY_PREPROD",
#             "checkpoint_basepath": "/Volumes/development/global_sustainability_dev/gps_landing_dev_vol/_checkpoint/dev/snowflake",
#             "env": "dev",
#             "source_hop_name": "curated_hist",
#             "key_columns": [
#                 "reporting_month_mos",
#                 "reporting_fiscal_year_yrs",
#             ],
#             "source": "sdf_gps_hq_usage_metrics_hist",
#             "target": "sdf_gps_hq_usage_metrics_hist",
#             "target_hop_name": "snowflake_BCL",
#             "partition_by_cols": ["load_year_nbr", "load_month_nbr"],
#             "audit_database_name": "global_sustainability_dev",
#             "audit_table_name": "sdf_load_tracker_table",
#             "audit_table_columns": [
#                 "batch_id",
#                 "object_name",
#                 "source_stage",
#                 "source_l1_detail",
#                 "source_l2_detail",
#                 "source_record_count",
#                 "source_partition_column_name",
#                 "source_partition_column_values",
#             ],
#             "alert_database_name": "global_sustainability_dev",
#             "alert_from": "a.ecorangers.dev@nike.com",
#             "team_email": "Lst-Technology.EDAI.Ecorangers@nike.com",
#             "slack_channel_email": "dev_sdf-itc-alerts-aaaaobnw7vngl4wa3lhu5gpzgq@nike.org.slack.com",
#             "alert_table_name": "sdf_alerts_tracker_table",
#             "alert_table_columns": [
#                 "alert_UUID",
#                 "alert_type",
#                 "alert_severity",
#             ],
#             "function_name": "test_run_ingest_curatedhist_to_bcl_success",
#             "object_name": "sdf_gps_hq_usage_metrics_hist",
#             "job_name": "sdf_gps_hq_usage_metrics_hist",
#             "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
#             "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
#             "merge_schema": "true",
#             "batch_id": "sdasdsadsa",
#         }
#         mock_product_conf = {
#             "product_name": "test_product",
#             "tech_solution_id": "test_tech_solution_id",
#             "nike-tagguid": "test_nike_tagguid",
#         }
#         mock_config_utils.return_value.read_config_variables.side_effect = [
#             mock_conf,
#             mock_product_conf,
#         ]

#         # Simulate bf_context
#         mock_bf_context = MagicMock()
#         mock_bf_context.get_parameter.return_value = {"env": "development"}

#         # Simulate get_username_password_from_dbx_secrets returning None
#         mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
#             None,
#             None,
#         )

#         # Call the function and expect a ValueError
#         with self.assertRaises(SystemExit) as context:
#             run_ingest_curatedhist_to_bcl(
#                 config_path="test_path",
#                 config_name="test_config",
#                 env="dev",
#                 bf_context=mock_bf_context,
#                 root_dir="test_root_dir",
#             )

#         # Assertions
#         self.assertEqual(str(context.exception), "1")
#         # mock_logger.error.assert_called_with("Error In - run_ingest_curatedhist_to_bcl() : %s", "Username or Password is None")

#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.SparkUtils.get_spark_session"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.ConfigUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_curatedhist_to_bcl.LoggerUtils"
#     )
#     def test_run_ingest_curatedhist_to_bcl_source_count_error(
#         self, mock_logger_utils, mock_config_utils, mock_spark_session
#     ):
#         # Setup mocks
#         mock_logger = MagicMock()
#         mock_logger_utils.return_value.get_logger_object.return_value = mock_logger
#         mock_spark = MagicMock()
#         mock_spark_session.return_value = mock_spark

#         # Simulate configuration
#         mock_conf = {
#             "delta_table_database": "global_sustainability_dev",
#             "sfurl": "https://nike.snowflakecomputing.com/",
#             "cerberus_endpoint": "https://prod.cerberus.nikecloud.com",
#             "cerberus_sdb_path": "app/ecorangers/common_gid/dev",
#             "dbx_scope": "ecorangers-dev",
#             "sfdatabase": "GLOBAL_SUSTAINABILITY_DEV",
#             "sfschema": "BCL_SUSTAINABILITY_FOUNDATION",
#             "sfrole": "APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE",
#             "sfwarehouse": "EDAI_GLOBAL_SUSTAINABILITY_PREPROD",
#             "checkpoint_basepath": (
#                 "/Volumes/development/global_sustainability_dev/"
#                 "gps_landing_dev_vol/_checkpoint/dev/snowflake"
#             ),
#             "env": "dev",
#             "source_hop_name": "curated_hist",
#             "key_columns": [
#                 "reporting_month_mos",
#                 "reporting_fiscal_year_yrs",
#             ],
#             "source": "sdf_gps_hq_usage_metrics_hist",
#             "target": "sdf_gps_hq_usage_metrics_hist",
#             "target_hop_name": "snowflake_BCL",
#             "partition_by_cols": ["load_year_nbr", "load_month_nbr"],
#             "audit_database_name": "global_sustainability_dev",
#             "audit_table_name": "sdf_load_tracker_table",
#             "audit_table_columns": [
#                 "batch_id",
#                 "object_name",
#                 "source_stage",
#                 "source_l1_detail",
#                 "source_l2_detail",
#                 "source_record_count",
#                 "source_partition_column_name",
#                 "source_partition_column_values",
#             ],
#             "alert_database_name": "global_sustainability_dev",
#             "alert_from": "a.ecorangers.dev@nike.com",
#             "team_email": "Lst-Technology.EDAI.Ecorangers@nike.com",
#             "slack_channel_email": (
#                 "dev_sdf-itc-alerts-aaaaobnw7vngl4wa3lhu5gpzgq@nike.org.slack.com"
#             ),
#             "alert_table_name": "sdf_alerts_tracker_table",
#             "alert_table_columns": [
#                 "alert_UUID",
#                 "alert_type",
#                 "alert_severity",
#             ],
#             "function_name": "test_run_ingest_curatedhist_to_bcl_success",
#             "object_name": "sdf_gps_hq_usage_metrics_hist",
#             "job_name": "sdf_gps_hq_usage_metrics_hist",
#             "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
#             "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
#             "merge_schema": "true",
#             "batch_id": "sdasdsadsa",
#         }
#         mock_product_conf = {
#             "product_name": "test_product",
#             "tech_solution_id": "test_tech_solution_id",
#             "nike-tagguid": "test_nike_tagguid",
#         }
#         mock_config_utils.return_value.read_config_variables.side_effect = [
#             mock_conf,
#             mock_product_conf,
#         ]

#         # Simulate bf_context
#         mock_bf_context = MagicMock()
#         mock_bf_context.get_parameter.return_value = {"env": "development"}

#         # Simulate get_username_password_from_dbx_secrets
#         mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
#             "username",
#             "password",
#         )

#         # Simulate Spark SQL queries throwing an exception
#         mock_spark.sql.side_effect = Exception("SQL Error")

#         try:
#             # Call the function
#             run_ingest_curatedhist_to_bcl(
#                 config_path="test_path",
#                 config_name="test_config",
#                 env="dev",
#                 bf_context=mock_bf_context,
#                 root_dir="test_root_dir",
#             )
#         except SystemExit as err:
#             mock_logger.error(
#                 "Error In - run_ingest_curatedhist_to_bcl() : %s", str(err)
#             )

#         # Assertions
#         mock_logger.error.assert_any_call(
#             "Error In - run_ingest_curatedhist_to_bcl() : SQL Error"
#         )
