# import unittest, pytest
# from unittest.mock import patch, MagicMock
# from products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated import (
#     run_ingest_bcl_to_integrated,
# )
# from pyspark.sql import DataFrame


# class TestRunIngestBclToIntegrated(unittest.TestCase):

#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.LoggerUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.ConfigUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.SparkUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.SnowflakeGenericUtils"
#     )
#     def test_run_ingest_bcl_to_integrated_success(
#         self,
#         mock_snowflake_utils,
#         mock_spark_utils,
#         mock_config_utils,
#         mock_logger_utils,
#     ):
#         # Mocking logger
#         mock_logger = MagicMock()
#         mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

#         # Mocking ConfigUtils
#         mock_conf = {
#             "delta_table_database": "global_sustainability_dev",
#             "sfurl": "https://nike.snowflakecomputing.com/",
#             "cerberus_endpoint": "https://prod.cerberus.nikecloud.com",
#             "cerberus_sdb_path": "app/ecorangers/common_gid/dev",
#             "dbx_scope": "ecorangers-dev",
#             "sfdatabase": "GLOBAL_SUSTAINABILITY_DEV",
#             "sfschema": "BCL_SUSTAINABILITY_FOUNDATION",
#             "sfrole": "APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE",
#             "sfwarehouse": "EDAI_GLOBAL_SUSTAINABILITY_PREPROD",
#             "source_hop_name": "integrated",
#             "checkpoint_basepath": (
#                 "/Volumes/development/global_sustainability_dev/"
#                 "engie_landing_dev_vol/_checkpoint/dev/"
#                 "electricity_site_integrated_to_bcl"
#             ),
#             "env": "development",
#             "key_columns": [
#                 "electricity_consumption_uuid",
#                 "electricity_location_nbr",
#                 "electricity_location_nm",
#             ],
#             "source": "ELECTRICITY_USAGE_LOCATION_INTEGRATED",
#             "target": "ELECTRICITY_USAGE_LOCATION_INTEGRATED_T",
#             "target_hop_name": "snowflake_BCL",
#             "partition_by_cols": ["load_year_nbr", "load_month_nbr"],
#             "audit_database_name": "global_sustainability_dev",
#             "audit_table_name": "sdf_load_tracker_table",
#             "object_name": "electricity_site_integrated_to_bcl",
#             "audit_table_columns": [
#                 "batch_id",
#                 "object_name",
#                 "source_stage",
#                 "source_l1_detail",
#                 "source_l2_detail",
#                 "source_record_count",
#                 "source_partition_column_name",
#                 "source_partition_column_values",
#                 "target_stage",
#                 "target_l1_detail",
#                 "target_l2_detail",
#                 "target_partition_column_name",
#                 "target_partition_column_values",
#                 "target_data_count_before_load",
#                 "target_data_count_after_load",
#                 "target_record_count",
#                 "incremental_data_count_after_load",
#                 "status_code",
#                 "job_run_id",
#                 "job_name",
#                 "insert_timestamp",
#             ],
#             "alert_database_name": "development.global_sustainability_dev",
#             "alert_from": "a.ecorangers.dev@nike.com",
#             "team_email": "Lst-Technology.EDAI.Ecorangers@nike.com",
#             "slack_channel_email": (
#                 "dev_sdf-itc-alerts-aaaaobnw7vngl4wa3lhu5gpzgq@nike.org.slack.com"
#             ),
#             "alert_table_name": "sdf_alerts_tracker_table",
#             "alert_table_columns": [
#                 "alert_UUID",
#                 "alert_type",
#                 "alert_severity",
#                 "object_name",
#                 "alert_summary",
#                 "alert_description",
#                 "alert_status",
#                 "alerts_from",
#                 "alerts_to",
#                 "alerts_cc",
#                 "job_run_id",
#                 "job_name",
#                 "insert_timestamp",
#             ],
#             "job_name": "electricity_site_integrated_to_bcl",
#             "merge_schema": "true",
#         }
#         mock_product_conf = {
#             "product_name": "test_product",
#             "tech_solution_id": "test_tech_solution_id",
#             "nike-tagguid": "test_nike_tagguid",
#             "job_name": "test_job_name",
#         }
#         mock_config_utils.return_value.read_config_variables.side_effect = [
#             mock_conf,
#             mock_product_conf,
#         ]
#         mock_config_utils.return_value.read_config_variables.side_effect = [
#             mock_conf,
#             mock_product_conf,
#         ]
#         mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
#             "test_user",
#             "test_pass",
#         )

#         # Mocking SparkUtils
#         mock_spark = MagicMock()
#         mock_spark_utils.return_value.get_spark_session.return_value = mock_spark
#         mock_spark.sql.return_value.head.return_value = [1]
#         mock_spark_utils.return_value.run_snowflake_queries_as_spark_df.return_value.head.return_value = [
#             100
#         ]

#         # Mocking SnowflakeGenericUtils
#         mock_snowflake_utils.return_value.get_snowflake_options.return_value = {}

#         # Mocking bf_context
#         mock_bf_context = MagicMock()
#         mock_bf_context.get_parameter.return_value = "test_job_id"

#         # Call the function
#         with pytest.raises(SystemExit):
#             run_ingest_bcl_to_integrated(
#                 config_path="test_path",
#                 config_name="test_config",
#                 sql_file_path="test_sql_path",
#                 sql_file_name="test_sql_file",
#                 env="test_env",
#                 bf_context=mock_bf_context,
#                 root_dir="test_root_dir",
#             )

#         # Assertions
#         # mock_logger.info.assert_called_with("%s START: run_ingest_bcl_to_integrated() %s", "*" * 20, "*" * 20)
#         mock_spark_utils.return_value.get_spark_session.assert_called_once()
#         # mock_snowflake_utils.return_value.get_snowflake_options.assert_called_once()

#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.LoggerUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.ConfigUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.SparkUtils"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.util_ingest_bcl_to_integrated.SnowflakeGenericUtils"
#     )
#     def test_run_ingest_bcl_to_integrated_failure(
#         self,
#         mock_snowflake_utils,
#         mock_spark_utils,
#         mock_config_utils,
#         mock_logger_utils,
#     ):
#         # Mocking logger
#         mock_logger = MagicMock()
#         mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

#         # Mocking ConfigUtils
#         mock_conf = {
#             "delta_table_database": "global_sustainability_dev",
#             "sfurl": "https://nike.snowflakecomputing.com/",
#             "cerberus_endpoint": "https://prod.cerberus.nikecloud.com",
#             "cerberus_sdb_path": "app/ecorangers/common_gid/dev",
#             "dbx_scope": "ecorangers-dev",
#             "sfdatabase": "GLOBAL_SUSTAINABILITY_DEV",
#             "sfschema": "BCL_SUSTAINABILITY_FOUNDATION",
#             "sfrole": "APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE",
#             "sfwarehouse": "EDAI_GLOBAL_SUSTAINABILITY_PREPROD",
#             "source_hop_name": "integrated",
#             "checkpoint_basepath": (
#                 "/Volumes/development/global_sustainability_dev/"
#                 "engie_landing_dev_vol/_checkpoint/dev/"
#                 "electricity_site_integrated_to_bcl"
#             ),
#             "env": "development",
#             "key_columns": [
#                 "electricity_consumption_uuid",
#                 "electricity_location_nbr",
#                 "electricity_location_nm",
#             ],
#             "source": "ELECTRICITY_USAGE_LOCATION_INTEGRATED",
#             "target": "ELECTRICITY_USAGE_LOCATION_INTEGRATED_T",
#             "target_hop_name": "snowflake_BCL",
#             "partition_by_cols": ["load_year_nbr", "load_month_nbr"],
#             "audit_database_name": "global_sustainability_dev",
#             "audit_table_name": "sdf_load_tracker_table",
#             "object_name": "electricity_site_integrated_to_bcl",
#             "audit_table_columns": [
#                 "batch_id",
#                 "object_name",
#                 "source_stage",
#                 "source_l1_detail",
#                 "source_l2_detail",
#                 "source_record_count",
#                 "source_partition_column_name",
#                 "source_partition_column_values",
#                 "target_stage",
#                 "target_l1_detail",
#                 "target_l2_detail",
#                 "target_partition_column_name",
#                 "target_partition_column_values",
#                 "target_data_count_before_load",
#                 "target_data_count_after_load",
#                 "target_record_count",
#                 "incremental_data_count_after_load",
#                 "status_code",
#                 "job_run_id",
#                 "job_name",
#                 "insert_timestamp",
#             ],
#             "alert_database_name": "development.global_sustainability_dev",
#             "alert_from": "a.ecorangers.dev@nike.com",
#             "team_email": "Lst-Technology.EDAI.Ecorangers@nike.com",
#             "slack_channel_email": (
#                 "dev_sdf-itc-alerts-aaaaobnw7vngl4wa3lhu5gpzgq@nike.org.slack.com"
#             ),
#             "alert_table_name": "sdf_alerts_tracker_table",
#             "alert_table_columns": [
#                 "alert_UUID",
#                 "alert_type",
#                 "alert_severity",
#                 "object_name",
#                 "alert_summary",
#                 "alert_description",
#                 "alert_status",
#                 "alerts_from",
#                 "alerts_to",
#                 "alerts_cc",
#                 "job_run_id",
#                 "job_name",
#                 "insert_timestamp",
#             ],
#             "job_name": "electricity_site_integrated_to_bcl",
#             "merge_schema": "true",
#         }
#         mock_product_conf = {
#             "product_name": "test_product",
#             "tech_solution_id": "test_tech_solution_id",
#             "nike-tagguid": "test_nike_tagguid",
#             "job_name": "test_job_name",
#         }
#         mock_config_utils.return_value.read_config_variables.side_effect = [
#             mock_conf,
#             mock_product_conf,
#         ]
#         mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
#             None,
#             None,
#         )

#         # Mocking SparkUtils
#         mock_spark = MagicMock()
#         mock_spark_utils.return_value.get_spark_session.return_value = mock_spark
#         mock_spark.sql.return_value.head.return_value = [1]
#         mock_spark_utils.return_value.run_snowflake_queries_as_spark_df.return_value.head.return_value = [
#             100
#         ]

#         # Mocking SnowflakeGenericUtils
#         mock_snowflake_utils.return_value.get_snowflake_options.return_value = {}

#         # Mocking bf_context
#         mock_bf_context = MagicMock()
#         mock_bf_context.get_parameter.return_value = "test_job_id"

#         # Call the function and expect ValueError
#         with self.assertRaises((SystemExit, AssertionError)):
#             run_ingest_bcl_to_integrated(
#                 config_path="test_path",
#                 config_name="test_config",
#                 sql_file_path="test_sql_path",
#                 sql_file_name="test_sql_file",
#                 env="test_env",
#                 bf_context=mock_bf_context,
#                 root_dir="test_root_dir",
#             )

#         # Assertions
#         # mock_logger.info.assert_called_with("%s START: run_ingest_bcl_to_integrated() %s", "*" * 20, "*" * 20)
#         # mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
