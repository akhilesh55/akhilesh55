import pytest, sys
from unittest.mock import MagicMock, patch, call
from datetime import datetime
from products.common_utilities.spark.python.src.util_api_landing_to_raw import (
    run_api_landing_to_raw,
)
from pyspark.sql import DataFrame

# sys.path.insert(0, '/Users/aku213/EcoRangers-5')


@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.LoggerUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.ConfigUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.SparkUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.QueryUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.AlertUtils")
def test_run_api_landing_to_raw_success(
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    datetime_obj = datetime.strptime("20231130000000", "%Y%m%d%H%M%S")
    mock_spark.sql.return_value.head.return_value.__getitem__.return_value = (
        datetime_obj.strftime("%Y%m%d%H%M%S")
    )

    mock_conf = {
        "job_name": "test_job",
        "source_database_name": "test_source_db",
        "source_table_name": "test_source_table",
        "target_database_name": "test_target_db",
        "target_table_name": "test_target_table",
        "data_product": "test_data_product",
        "source_mandatory_cols": ["col1", "col2"],
        "data_completeness_tbl": "test_data_completeness_tbl",
        "common_cols": ["col1", "col2"],
        "table_cols": ["col3", "col4"],
        "predicates": ["col1 = 1"],
        "target_hop_name": "test_hop",
        "source_hop_name": "source_hop",
        "custom_starting_timestamp": "20231130000000",
        "data_completeness_tbl": "test_data_completeness_tbl",
        "batch_id": "20231130000000",
        "function_name": "run_api_landing_to_raw",
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
        "audit_database_name": "test_audit_db",
        "audit_table_name": "test_audit_table",
        "object_name": "test_object_name",
        "audit_table_columns": ["col1", "col2"],
        "merge_schema": "test_merge_schema",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    # Call the function
    run_api_landing_to_raw(
        "config_path", "config_name", "dev", mock_bf_context, "root_dir"
    )

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_api_landing_to_raw()" + "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    # mock_query_utils.return_value.read_cdc_batch.assert_called_once()
    mock_spark.sql.assert_called_with(
        "DROP TABLE IF EXISTS test_target_db.test_target_table_temp"
    )
    mock_logger.error.assert_called_with(
        "Unable to change the owner for the table, try it manually. Error: 'group_name'"
    )


@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.LoggerUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.ConfigUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.SparkUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.QueryUtils")
@patch("products.common_utilities.spark.python.src.util_api_landing_to_raw.AlertUtils")
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.AuditUtils"
)
def test_run_api_landing_to_raw_failure(
    mock_audit_utils,
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    datetime_obj = datetime.strptime("20231130000000", "%Y%m%d%H%M%S")
    mock_spark.sql.return_value.head.return_value.__getitem__.return_value = (
        datetime_obj.strftime("%Y%m%d%H%M%S")
    )

    mock_conf = {
        "job_name": "test_job",
        "source_database_name": "test_source_db",
        "source_table_name": "test_source_table",
        "target_database_name": "test_target_db",
        "target_table_name": "test_target_table",
        "predicates": ["col1 = 1"],
        "custom_starting_timestamp": "20231130000000",
        "data_completeness_tbl": "test_data_completeness_tbl",
        "batch_id": "20231130000000",
        "function_name": "run_api_landing_to_raw",
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"
    # Call the function and expect SystemError
    with pytest.raises(SystemExit) as e:
        run_api_landing_to_raw(
            "config_path", "config_name", "dev", mock_bf_context, "root_dir"
        )

    assert e.type == SystemExit
    assert e.value.code == 1

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_api_landing_to_raw()" + "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_query_utils.return_value.read_cdc_batch.assert_called_once()
    mock_alert_utils.return_value.generate_alerts_dictionary.assert_called_once()
    mock_alert_utils.return_value.load_alerts_table.assert_called_once()
    expected_calls = [
        call(
            "Error In - run_api_landing_to_raw()                 --> mandatory columns not present in source layer"
        ),
        call("Error In - run_api_landing_to_raw() : 'data_product'"),
        call(
            "load_audit_table - error : Target database and table names mising in configs, please add them in config and try again.."
        ),
    ]
    mock_logger.error.assert_has_calls(expected_calls, any_order=True)
    # mock_logger.error.assert_called_once_with('load_audit_table - error : Target database and table names mising in configs, please add them in config and try again..')
