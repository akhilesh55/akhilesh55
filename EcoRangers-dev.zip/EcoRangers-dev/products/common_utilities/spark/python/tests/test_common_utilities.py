# import sys
# import json
# import os
# from datetime import datetime
# import inspect
# import requests
# from pyspark.sql.functions import col
# import pytest, sys
# from pyspark.sql import SparkSession, DataFrame, Row
# from unittest.mock import MagicMock, Mock, patch
# from datetime import datetime
# from dateutil.relativedelta import relativedelta
# from products.common_utilities.spark.python.src.common_utilities import *
# import unittest
# import logging
# from pyspark.sql.functions import (
#     col,
#     lit,
#     when,
#     month,
#     year,
#     current_timestamp,
#     current_date,
#     reverse,
#     split,
#     max as max_,
#     md5,
#     concat_ws,
#     regexp_replace,
#     hash,
#     explode,
#     collect_list,
#     expr,
#     to_json,
#     struct,
#     count,
#     round,
#     row_number,
#     sum,
#     to_timestamp,
#     from_unixtime,
#     map_keys,
#     concat,
# )
# from pyspark.sql.types import (
#     StructType,
#     StructField,
#     StringType,
#     LongType,
#     ArrayType,
#     MapType,
# )


# class TestSparkUtils(unittest.TestCase):

#     def setUp(self):
#         self.logger = Mock()
#         self.mock_spark = Mock()
#         self.spark_utils = SparkUtils()
#         self.spark = SparkSession.builder.master("local").appName("test").getOrCreate()

#     def test_get_spark_session(self):
#         app_name = "test_app"
#         spark = self.spark_utils.get_spark_session(self.logger, app_name)
#         self.logger.info.assert_called()
#         self.assertIsInstance(spark, SparkSession)
#         self.assertIsNotNone(spark)

#     @patch("pyspark.sql.SparkSession.builder")
#     def test_get_spark_session_exception(self, mock_builder):
#         # Mock the builder to raise an exception
#         mock_builder.appName.return_value.enableHiveSupport.return_value.getOrCreate.side_effect = Exception(
#             "Test Exception"
#         )
#         app_name = "test_app"

#         with self.assertRaises(Exception) as context:
#             self.spark_utils.get_spark_session(self.logger, app_name)

#         self.assertTrue("Test Exception" in str(context.exception))
#         self.logger.info.assert_called()

#     @patch("pyspark.sql.SparkSession.read")
#     def test_run_snowflake_queries_as_spark_df(self, mock_read):
#         snowflake_config = {
#             "username": "test_user",
#             "password": "test_password",
#             "sfurl": "test_url",
#             "sfdatabase": "test_database",
#             "sfschema": "test_schema",
#             "sfwarehouse": "test_warehouse",
#             "sfrole": "test_role",
#         }
#         query = "SELECT * FROM test_table"
#         result = self.spark_utils.run_snowflake_queries_as_spark_df(
#             self.logger, SparkSession.builder.getOrCreate(), snowflake_config, query
#         )
#         self.logger.info.assert_called()
#         mock_read.format.assert_called_with("snowflake")
#         self.assertIsNotNone(result)

#     @patch("pyspark.sql.SparkSession.read")
#     def test_run_snowflake_queries_as_spark_df_failure(self, mock_read):
#         snowflake_config = {
#             "username": "test_user",
#             "password": "test_password",
#             "sfurl": "test_url",
#             "sfdatabase": "test_database",
#             "sfwarehouse": "test_warehouse",
#             "sfrole": "test_role",
#         }
#         query = "SELECT * FROM test_table"
#         with pytest.raises(SystemError) as error:
#             self.spark_utils.run_snowflake_queries_as_spark_df(
#                 self.logger, SparkSession.builder.getOrCreate(), snowflake_config, query
#             )
#         assert "sfschema" in str(
#             error.value
#         )  # Since schema value has been removed from config

#     @patch("pyspark.sql.SparkSession.sql")
#     def test_run_spark_sql_query_as_spark_df(self, mock_sql):
#         # def test_run_spark_sql_query_as_spark_df(self):
#         mock_df = Mock()
#         mock_sql.return_value = mock_df
#         query = "SELECT * FROM test_table"
#         result = self.spark_utils.run_spark_sql_query_as_spark_df(
#             self.logger, SparkSession.builder.getOrCreate(), query
#         )
#         self.logger.info.assert_called()
#         mock_sql.assert_called_with(query)
#         self.assertEqual(result, mock_df)

#     @patch("pyspark.sql.SparkSession.sql")
#     def test_run_spark_sql_query_as_spark_df_exception(self, mock_sql):
#         # Mock the sql method to raise an exception
#         mock_sql.side_effect = Exception("Test Exception")

#         query = "SELECT * FROM test_table"

#         with self.assertRaises(SystemError) as context:
#             self.spark_utils.run_spark_sql_query_as_spark_df(
#                 self.logger, self.spark, query
#             )

#         self.assertTrue("Test Exception" in str(context.exception))
#         self.logger.info.assert_called()
#         self.logger.error.assert_called_with(
#             "Issue while running the sql query: Test Exception"
#         )

#     @patch("pyspark.sql.SparkSession.sql")
#     def test_get_username(self, mock_sql):
#         # def test_run_spark_sql_query_as_spark_df(self):
#         mock_user = "test_user"
#         mock_sql.return_value.head.return_value = [mock_user]
#         result = self.spark_utils.get_username(
#             self.logger, SparkSession.builder.getOrCreate()
#         )
#         self.logger.info.assert_called()
#         self.assertEqual(result, "test_user")

#     @patch("pyspark.sql.SparkSession.sql")
#     def test_get_username_exception(self, mock_sql):
#         # Mock the sql method to raise an exception
#         mock_sql.side_effect = Exception("Test Exception")

#         with self.assertRaises(SystemError) as context:
#             self.spark_utils.get_username(self.logger, self.spark)

#         self.assertTrue("Test Exception" in str(context.exception))
#         self.logger.info.assert_any_call("*" * 20 + " START: get_username" + "*" * 20)
#         self.logger.info.assert_any_call("*" * 20 + " END: get_username" + "*" * 20)

#     @patch("pyspark.sql.SparkSession.readStream")
#     def test_read_streaming_dataframe_from_external_volume(self, mock_readStream):
#         mock_format = mock_readStream.return_value.format.return_value
#         mock_option = mock_format.option.return_value
#         mock_load = mock_option.load.return_value
#         mock_withColumn = mock_load.withColumn.return_value
#         mock_withColumnRenamed = mock_withColumn.withColumnRenamed.return_value
#         mock_filter = mock_withColumnRenamed.filter.return_value
#         mock_drop = mock_filter.drop.return_value
#         mock_dropDuplicates = mock_drop.dropDuplicates.return_value

#         conf = {
#             "input_file_format": "json",
#             "checkpoint_path": "/path/to/checkpoint",
#             "src_volume_path": "/path/to/src",
#             "file_name_col": "file_path",
#             "multiline": "true",
#             "encoding": "UTF-8",
#             "table_type": "umd",
#             "file_nm_pattern": "pattern",
#             "predicates": "some_predicate",
#         }
#         result = self.spark_utils.read_streaming_dataframe_from_external_volume(
#             self.logger, SparkSession.builder.getOrCreate(), conf
#         )
#         self.logger.info.assert_called()
#         mock_readStream.format.assert_called_with("cloudFiles")
#         mock_readStream.format.return_value.option.assert_any_call(
#             "cloudFiles.format", conf["input_file_format"]
#         )
#         mock_readStream.format.return_value.option.return_value.option.assert_any_call(
#             "cloudFiles.schemaLocation", conf["checkpoint_path"]
#         )
#         mock_readStream.format.return_value.option.return_value.option.return_value.option.assert_any_call(
#             "escape", '"'
#         )
#         mock_readStream.format.return_value.option.return_value.option.return_value.option.return_value.option.assert_any_call(
#             "multiLine", True
#         )
#         mock_readStream.format.return_value.option.return_value.option.return_value.option.return_value.option.return_value.option.assert_any_call(
#             "charset", conf["encoding"]
#         )
#         mock_readStream.format.return_value.option.return_value.option.return_value.option.return_value.option.return_value.option.return_value.load.assert_called_with(
#             conf["src_volume_path"]
#         )

#         conf["table_type"] = ""
#         result = self.spark_utils.read_streaming_dataframe_from_external_volume(
#             self.logger, SparkSession.builder.getOrCreate(), conf
#         )

#         conf["input_file_format"] = ""
#         result = self.spark_utils.read_streaming_dataframe_from_external_volume(
#             self.logger, SparkSession.builder.getOrCreate(), conf
#         )
#         mock_readStream.format.return_value.option.return_value.option.return_value.option.return_value.option.return_value.option.return_value.load.assert_called_with(
#             conf["src_volume_path"]
#         )

#         conf.pop("file_name_col", None)
#         with pytest.raises(SystemError) as error:
#             self.spark_utils.read_streaming_dataframe_from_external_volume(
#                 self.logger, SparkSession.builder.getOrCreate(), conf
#             )
#         assert "file_name_col" in str(error.value)

#     @patch("datetime.datetime")
#     @patch("os.path.join")
#     def test_get_streaming_df_rows_count(self, mock_os_path_join, mock_datetime):
#         # Mocking dependencies
#         logger = Mock()
#         spark_obj = Mock()
#         streaming_df = Mock()
#         bf_context = Mock()

#         # Mocking datetime and os.path.join
#         mock_datetime.now.return_value.strftime.return_value = "20230101123000"
#         mock_os_path_join.return_value = "/path/to/checkpoint/temp/count_df/_chkp"

#         # Configuration dictionary
#         conf = {
#             "target_database_name": "test_db",
#             "object_name": "test_object",
#             "checkpoint_path": "/path/to/checkpoint",
#         }

#         # Mocking the behavior of the streaming dataframe writeStream
#         query = Mock()
#         streaming_df.writeStream.option.return_value.trigger.return_value.toTable.return_value = (
#             query
#         )
#         query.awaitTermination.return_value = None

#         # Mocking the behavior of the Spark SQL query
#         spark_obj.sql.return_value.head.return_value = [100]

#         # Creating an instance of the class containing the method
#         spark_utils = SparkUtils()

#         # Calling the method
#         result = spark_utils.get_streaming_df_rows_count(
#             logger, spark_obj, streaming_df, conf, bf_context
#         )

#         # Assertions
#         logger.info.assert_called()
#         streaming_df.writeStream.option.assert_called_with(
#             "checkpointLocation", "/path/to/checkpoint/temp/count_df/_chkp"
#         )
#         query.awaitTermination.assert_called()
#         spark_obj.sql.assert_called()
#         bf_context.dbutils.fs.rm.assert_called_with(
#             "/path/to/checkpoint/temp/count_df/_chkp", True
#         )
#         self.assertEqual(result, 100)

#     @patch("pyspark.sql.streaming.StreamingQuery.awaitTermination")
#     def test_get_streaming_df_rows_count_exception(self, mock_await_termination):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         streaming_df = Mock()
#         conf = {
#             "target_database_name": "test_db",
#             "object_name": "test_object",
#             "checkpoint_path": "/tmp",
#         }
#         bf_context = Mock()
#         # Mock the awaitTermination method to raise an exception
#         mock_await_termination.side_effect = Exception("Test Exception")
#         self.spark_utils.get_streaming_df_rows_count(
#             self.logger, spark, streaming_df, conf, bf_context
#         )

#     @patch("pyspark.sql.functions.hash")
#     def test_merge_dataframe_using_spark_sql(self, mock_hash):
#         # Mocking dependencies
#         logger = Mock()
#         spark_obj = Mock()
#         master_df = Mock()
#         conf = {"some_key": "some_value"}
#         target_complete_table = "test_db.test_table"

#         # Mocking the return values of generate_merge_conditions
#         self.generate_merge_conditions = Mock(
#             return_value=(
#                 "source.id = target.id",
#                 "target.name = source.name",
#                 "id, name",
#                 "source.id, source.name",
#                 ["id", "name"],
#             )
#         )

#         # Mocking the hash function
#         mock_hash.return_value = "hashed_value"

#         # Mocking the withColumn method
#         master_df.withColumn.return_value = master_df

#         # Creating an instance of the class containing the method
#         spark_utils = SparkUtils()
#         spark_utils.generate_merge_conditions = self.generate_merge_conditions
#         spark_utils.execute_spark_sql = Mock()

#         # Calling the method
#         spark_utils.merge_dataframe_using_spark_sql(
#             logger, spark_obj, master_df, conf, target_complete_table
#         )

#         # Assertions
#         logger.info.assert_any_call(
#             "*" * 20 + " START: merge_dataframe_using_spark_sql" + "*" * 20
#         )
#         self.generate_merge_conditions.assert_called_with(logger, master_df, conf)
#         master_df.createOrReplaceTempView.assert_called_with("source")
#         expected_merge_query = """
#             MERGE INTO test_db.test_table as target
#             USING source
#             ON source.id = target.id
#             WHEN MATCHED THEN
#                 UPDATE SET target.name = source.name,
#                 created_at_tmst = target.created_at_tmst,
#                 batch_load_tmst = current_timestamp(),
#                 updated_at_tmst =   CASE
#                                         WHEN target.hash_col <> source.hash_col THEN current_timestamp()
#                                         ELSE target.updated_at_tmst
#                                     END
#             WHEN NOT MATCHED THEN
#                 INSERT (id, name, batch_load_tmst, created_at_tmst, updated_at_tmst)
#                 VALUES (source.id, source.name, current_timestamp(), current_timestamp(), current_timestamp())
#             """
#         spark_utils.execute_spark_sql.assert_called_with(
#             spark_obj, expected_merge_query
#         )
#         logger.info.assert_any_call("Completed merging the dataframe using Spark SQL.")

#     @patch.object(SparkUtils, "execute_spark_sql")
#     def test_merge_dataframe_using_spark_sql_exception(self, mock_execute_spark_sql):
#         master_df = Mock()
#         conf = {"some_key": "some_value"}
#         target_complete_table = "test_table"
#         # Mock the execute_spark_sql method to raise an exception
#         mock_execute_spark_sql.side_effect = Exception("Test Exception")

#         with self.assertRaises(SystemError) as context:
#             self.spark_utils.merge_dataframe_using_spark_sql(
#                 self.logger, self.spark, master_df, conf, target_complete_table
#             )

#     def test_generate_merge_conditions(self):
#         master_df = Mock(
#             columns=[
#                 "id",
#                 "name",
#                 "batch_load_tmst",
#                 "created_at_tmst",
#                 "updated_at_tmst",
#             ]
#         )
#         conf = {"merge_key_cols": ["id"]}

#         expected_on_condition = "target.id = source.id"
#         expected_update_condition = "id = source.id, name = source.name"
#         expected_insert_condition = "id, name"
#         expected_insert_values = "source.id, source.name"
#         expected_columns_without_tmst = ["id", "name"]

#         result = self.spark_utils.generate_merge_conditions(
#             self.logger, master_df, conf
#         )

#         self.assertEqual(result[0], expected_on_condition)
#         self.assertEqual(result[1], expected_update_condition)
#         self.assertEqual(result[2], expected_insert_condition)
#         self.assertEqual(result[3], expected_insert_values)
#         self.assertEqual(result[4], expected_columns_without_tmst)

#     @patch("pyspark.sql.streaming.DataStreamWriter.toTable")
#     def test_write_streaming_dataframe_to_delta(self, mock_toTable):
#         logger = Mock()
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         streaming_df = Mock()
#         streaming_df.columns = ["id", "name"]
#         table_name = "test_table"
#         conf = {
#             "input_file_format": "json",
#             "checkpoint_path": "/tmp/checkpoint",
#             "merge_schema": "true",
#             "partition_by_cols": ["id"],
#             "group_name": "test_group",
#             "tech_solution_id": "test_tech_solution_id",
#             "cloudred_gid": "test_cloudred_gid",
#         }

#         # Mock the writeStream method and its chained methods
#         mock_write_stream = Mock()
#         streaming_df.writeStream = mock_write_stream
#         mock_write_stream.option.return_value = mock_write_stream
#         mock_write_stream.partitionBy.return_value = mock_write_stream
#         mock_write_stream.trigger.return_value = mock_write_stream

#         # Call the function
#         self.spark_utils.write_streaming_dataframe_to_delta(
#             logger, self.mock_spark, streaming_df, table_name, conf
#         )

#         # Verify that the methods were called with the correct parameters
#         # mock_write_stream.option.assert_any_call("checkpointLocation", conf["checkpoint_path"])
#         # mock_write_stream.option.assert_any_call("mergeSchema", conf["merge_schema"])
#         # mock_write_stream.partitionBy.assert_called_with(conf["partition_by_cols"])
#         # mock_write_stream.trigger.assert_called_with(availableNow=True)
#         # mock_toTable.assert_called_with(table_name)

#     @patch("pyspark.sql.streaming.DataStreamWriter.toTable")
#     def test_write_streaming_dataframe_to_delta_exception(self, mock_toTable):
#         logger = Mock()
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         streaming_df = Mock()
#         streaming_df.columns = ["id", "name"]
#         table_name = "test_table"
#         conf = {
#             "input_file_format": "json",
#             "checkpoint_path": "/tmp/checkpoint",
#             "merge_schema": "true",
#             "partition_by_cols": ["id"],
#             "cloudred_gid": "test_cloudred_gid",
#         }

#         # Mock the writeStream method and its chained methods
#         mock_write_stream = Mock()
#         streaming_df.writeStream = mock_write_stream
#         mock_write_stream.option.return_value = mock_write_stream
#         mock_write_stream.partitionBy.return_value = mock_write_stream
#         mock_write_stream.trigger.return_value = mock_write_stream

#         # Call the function
#         self.spark_utils.write_streaming_dataframe_to_delta(
#             logger, self.mock_spark, streaming_df, table_name, conf
#         )

#     @patch("pyspark.sql.streaming.DataStreamWriter.toTable")
#     def test_write_streaming_dataframe_to_delta_exception_2(self, mock_toTable):
#         logger = Mock()
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         streaming_df = Mock()
#         streaming_df.columns = ["id", "name"]
#         table_name = "test_table"
#         conf = {
#             "checkpoint_path": "/tmp/checkpoint",
#             "merge_schema": "true",
#             "partition_by_cols": ["id"],
#             "cloudred_gid": "test_cloudred_gid",
#         }

#         # Mock the writeStream method and its chained methods
#         mock_write_stream = Mock()
#         streaming_df.writeStream = mock_write_stream
#         mock_write_stream.option.return_value = mock_write_stream
#         mock_write_stream.partitionBy.return_value = mock_write_stream
#         mock_write_stream.trigger.return_value = mock_write_stream

#         # Call the function
#         with pytest.raises(SystemError) as error:
#             self.spark_utils.write_streaming_dataframe_to_delta(
#                 logger, self.mock_spark, streaming_df, table_name, conf
#             )
#         assert "input_file_format" in str(error.value)

#     def test_rename_columns_for_raw(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         master_spark_df = spark.createDataFrame(
#             [(1, "value1"), (2, "value2")], ["id", "name"]
#         )
#         result_df = self.spark_utils.rename_columns_for_raw(
#             self.logger, master_spark_df
#         )
#         expected_columns = ["id", "name"]
#         self.assertEqual(result_df.columns, expected_columns)

#     def test_rename_columns_for_raw_exception(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         master_spark_df = Mock()
#         master_spark_df.columns = ["id", "name"]

#         # Mock the select method to raise an exception
#         master_spark_df.select.side_effect = Exception("Test Exception")

#         with self.assertRaises(SystemError) as context:
#             SparkUtils().rename_columns_for_raw(self.logger, master_spark_df)

#         self.assertTrue("Test Exception" in str(context.exception))
#         self.logger.error.assert_any_call(
#             "Issue while renaming the table as per raw STM: Test Exception"
#         )
#         self.logger.info.assert_any_call(
#             "*" * 20 + " END: rename_columns_for_raw" + "*" * 20
#         )

#     def test_rename_columns_for_raw_having_dots(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         master_spark_df = spark.createDataFrame(
#             [(1, "value1"), (2, "value2")], ["table.id", "table.name"]
#         )
#         result_df = self.spark_utils.rename_columns_for_raw_having_dots(
#             self.logger, master_spark_df
#         )
#         expected_columns = ["id", "name"]
#         self.assertEqual(result_df.columns, expected_columns)

#     def test_rename_columns_for_raw_having_dots_exception(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         master_spark_df = Mock()
#         master_spark_df.columns = ["table.id", "table.name"]

#         # Mock the select method to raise an exception
#         master_spark_df.select.side_effect = Exception("Test Exception")

#         with self.assertRaises(SystemError) as context:
#             self.spark_utils.rename_columns_for_raw_having_dots(
#                 self.logger, master_spark_df
#             )

#         self.assertTrue("Test Exception" in str(context.exception))
#         self.logger.error.assert_any_call(
#             "Issue while renaming the table as per raw STM: Test Exception"
#         )
#         self.logger.info.assert_any_call(
#             "*" * 20 + " END: rename_columns_for_raw_having_dots" + "*" * 20
#         )

#     def test_union_dataframes(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         df1 = spark.createDataFrame([(1, "value1"), (2, "value2")], ["id", "name"])
#         df2 = spark.createDataFrame([(3, "value3"), (4, "value4")], ["id", "name"])
#         result_df = self.spark_utils.union_dataframes(self.logger, df1, df2)
#         expected_data = [(1, "value1"), (2, "value2"), (3, "value3"), (4, "value4")]
#         result_data = [tuple(row) for row in result_df.collect()]
#         self.assertEqual(result_data, expected_data)

#     def test_union_dataframes_exception(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         df1 = Mock()
#         df2 = Mock()
#         df1.unionByName.side_effect = Exception("Test Exception")
#         with self.assertRaises(SystemExit) as context:
#             self.spark_utils.union_dataframes(self.logger, df1, df2)
#         self.assertTrue("Test Exception" in str(context.exception))

#     def test_calculate_uuid_from_pk_cols(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         query_result_df = spark.createDataFrame(
#             [(1, "value1"), (2, "value2")], ["id", "name"]
#         )
#         conf = {"uuid_col": "uuid", "primary_keys_cols": ["id", "name"]}
#         result_df = self.spark_utils.calculate_uuid_from_pk_cols(
#             self.logger, query_result_df, conf
#         )
#         result_data = result_df.select("uuid").collect()
#         self.assertEqual(len(result_data), 2)
#         self.assertTrue(all(len(row["uuid"]) == 36 for row in result_data))

#     def test_calculate_uuid_from_pk_cols_exception(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         query_result_df = Mock()
#         conf = {"primary_keys_cols": ["id", "name"]}
#         query_result_df.withColumn.side_effect = Exception("Test Exception")
#         with self.assertRaises(SystemExit):
#             self.spark_utils.calculate_uuid_from_pk_cols(
#                 self.logger, query_result_df, conf
#             )

#     def test_add_operational_attributes_raw(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         spark_df = spark.createDataFrame([(1, "value1"), (2, "value2")], ["id", "name"])
#         job_name = "test_job"
#         run_id = "12345"
#         hop_name_raw = "raw"
#         result_df = self.spark_utils.add_operational_attributes(
#             self.logger, spark, spark_df, job_name, run_id, hop_name_raw
#         )
#         result_data = result_df.collect()
#         self.assertEqual(len(result_data), 2)
#         self.assertTrue("user_nm" in result_df.columns)
#         self.assertTrue("load_dt" in result_df.columns)
#         self.assertTrue("load_month_nbr" in result_df.columns)
#         self.assertTrue("load_year_nbr" in result_df.columns)
#         self.assertTrue("created_at_tmst" in result_df.columns)
#         self.assertTrue("batch_load_tmst" in result_df.columns)
#         self.assertTrue("job_nm" in result_df.columns)
#         self.assertTrue("job_run_id" in result_df.columns)

#     def test_add_operational_attributes_raw(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         spark_df = spark.createDataFrame([(1, "value1"), (2, "value2")], ["id", "name"])
#         job_name = "test_job"
#         run_id = "12345"
#         hop_name_raw = "raw"
#         spark_df = Mock()
#         spark_df.withColumn.side_effect = Exception("Test Exception")
#         with self.assertRaises(SystemExit):
#             self.spark_utils.add_operational_attributes(
#                 self.logger, spark, spark_df, job_name, run_id, hop_name_raw
#             )

#     def test_add_operational_attributes_other(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         spark_df = spark.createDataFrame([(1, "value1"), (2, "value2")], ["id", "name"])
#         job_name = "test_job"
#         run_id = "12345"
#         hop_name_other = "other"
#         result_df = self.spark_utils.add_operational_attributes(
#             self.logger, spark, spark_df, job_name, run_id, hop_name_other
#         )
#         result_data = result_df.collect()
#         self.assertEqual(len(result_data), 2)
#         self.assertTrue("user_nm" in result_df.columns)
#         self.assertFalse("load_dt" in result_df.columns)
#         self.assertFalse("load_month_nbr" in result_df.columns)
#         self.assertFalse("load_year_nbr" in result_df.columns)
#         self.assertFalse("created_at_tmst" in result_df.columns)
#         self.assertTrue("batch_load_tmst" in result_df.columns)
#         self.assertTrue("job_nm" in result_df.columns)
#         self.assertTrue("job_run_id" in result_df.columns)

#         self.logger = Mock()
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         spark_df = self.mock_spark.createDataFrame(
#             [("path/to/file1.txt",), ("path/to/file2.txt",)], ["file_path"]
#         )
#         file_name_col = "file_path"

#     def test_extract_file_name_from_file_path_success(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         spark_df = spark.createDataFrame(
#             [("path/to/file1.txt",), ("path/to/file2.txt",)], ["file_path"]
#         )
#         file_name_col = "file_path"
#         result_df = self.spark_utils.extract_file_name_from_file_path(
#             self.logger, spark_df, file_name_col
#         )
#         result_data = result_df.collect()
#         self.assertEqual(len(result_data), 2)
#         self.assertTrue("file_path" in result_df.columns)

#     def test_extract_file_name_from_file_path_exception(self):
#         spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         spark_df = spark.createDataFrame(
#             [("path/to/file1.txt",), ("path/to/file2.txt",)], ["file_path"]
#         )
#         invalid_col = "invalid_col"
#         with pytest.raises(SystemError) as error:
#             self.spark_utils.extract_file_name_from_file_path(
#                 self.logger, spark_df, invalid_col
#             )
#         assert (
#             "A column or function parameter with name `invalid_col` cannot be resolved"
#             in str(error.value)
#         )

#     def test_run_spark_expectations_dq_checks_success(self):
#         spark = (
#             Mock()
#         )  # SparkSession.builder.master("local").appName("test").getOrCreate()
#         incremental_df = spark.createDataFrame(
#             [("path/to/file1.txt",), ("path/to/file2.txt",)], ["file_path"]
#         )
#         conf = {
#             "merge_schema": True,
#             "source_database_name": "test_db",
#             "rules_table": "rules",
#             "stats_table": "stats",
#             "product_id": "test_product",
#             "group_name": "test_group",
#         }
#         cleansed_table = "cleansed_table"
#         WrappedDataFrameWriter_mock = Mock()
#         WrappedDataFrameWriter_mock.return_value.mode.return_value.format.return_value.option.return_value = (
#             Mock()
#         )

#         SparkExpectations_mock = Mock()
#         SparkExpectations_mock.return_value = Mock()

#         # Mock the decorator
#         mock_with_expectations = Mock()
#         mock_with_expectations.return_value = lambda x: x

#         # result_df =
#         with pytest.raises(SystemError) as error:
#             self.spark_utils.run_spark_expectations_dq_checks(
#                 self.logger, spark, conf, cleansed_table, incremental_df
#             )

#     def test_execute_spark_sql(self):
#         query = "SELECT 1"
#         df = self.spark_utils.execute_spark_sql(self.spark, query)
#         result = df.collect()
#         self.assertEqual(result[0][0], 1)

#     @patch(
#         "builtins.open",
#         new_callable=unittest.mock.mock_open,
#         read_data="SELECT * FROM table",
#     )
#     def test_get_sql_file_content(self, mock_open):
#         sql_file_path = "/path/to/sql"
#         sql_file_name = "query.sql"
#         result = self.spark_utils.get_sql_file_content(
#             self.logger, sql_file_path, sql_file_name
#         )
#         self.assertEqual(result, "SELECT * FROM table")

#     @patch("builtins.open", side_effect=Exception("File not found"))
#     def test_get_sql_file_content_exception(self, mock_open):
#         sql_file_path = "/path/to/sql"
#         sql_file_name = "query.sql"
#         with self.assertRaises(SystemError):
#             self.spark_utils.get_sql_file_content(
#                 self.logger, sql_file_path, sql_file_name
#             )
#         self.logger.error.assert_called_with(
#             "Issue while extracting contents from SQL file: File not found"
#         )

#     def test_format_sql_query_with_variables(self):
#         sql_query = "SELECT * FROM {table}"
#         kwargs = {"table": "test_table"}
#         result = self.spark_utils.format_sql_query_with_variables(
#             self.logger, sql_query, kwargs=kwargs
#         )
#         self.assertEqual(result, "SELECT * FROM test_table")

#         sql_query = "SELECT * FROM {temp_view_name}"
#         kwargs = None
#         result = self.spark_utils.format_sql_query_with_variables(
#             self.logger, sql_query, kwargs=kwargs, temp_view_name="test_table"
#         )
#         self.assertEqual(result, "SELECT * FROM test_table")

#     def test_format_sql_query_with_variables_exception(self):
#         sql_query_mock = Mock()
#         kwargs = {"table": "test_table"}
#         temp_view_name = None
#         sql_query_mock.format.side_effect = Exception("Test Exception")

#         with self.assertRaises(SystemError) as context:
#             self.spark_utils.format_sql_query_with_variables(
#                 self.logger, sql_query_mock, kwargs, temp_view_name
#             )
#         self.assertTrue("Test Exception" in str(context.exception))

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_sql_file_content"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.SparkUtils.format_sql_query_with_variables"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.SparkUtils.execute_spark_sql"
#     )
#     def test_read_spark_sql_file_success(
#         self,
#         mock_execute_spark_sql,
#         mock_format_sql_query_with_variables,
#         mock_get_sql_file_content,
#     ):
#         # self.spark = MockSparkSession.builder.getOrCreate()
#         spark_df = self.spark.createDataFrame([(1, "data")], ["id", "value"])
#         conf = {
#             "temp_view_names_list": "temp_view",
#             "tables_mapping_dict": {"table1": "temp_view1"},
#         }
#         sql_file_path = "path/to/sql"
#         sql_file_name = "query.sql"
#         mock_get_sql_file_content.return_value = "SELECT * FROM temp_view"
#         mock_format_sql_query_with_variables.return_value = "SELECT * FROM temp_view"
#         mock_execute_spark_sql.return_value = spark_df

#         # Call the method
#         result = self.spark_utils.read_spark_sql_file(
#             self.logger, self.spark, sql_file_path, sql_file_name, spark_df, conf
#         )

#         # Assertions
#         self.assertIsNotNone(result)
#         self.logger.info.assert_called()

#         spark_df = [spark_df, spark_df]
#         conf["temp_view_names_list"] = ["a", "b"]
#         result = self.spark_utils.read_spark_sql_file(
#             self.logger, self.spark, sql_file_path, sql_file_name, spark_df, conf
#         )

#         # Assertions
#         self.assertIsNotNone(result)

#     @patch("builtins.open", side_effect=Exception("File not found"))
#     def test_read_spark_sql_file_exception(self, mock_open):
#         sql_file_path = "/path/to/sql"
#         sql_file_name = "query.sql"
#         spark_df = self.spark.createDataFrame([(1,)], ["id"])
#         conf = {"temp_view_names_list": "temp_view"}
#         with self.assertRaises(SystemError):
#             self.spark_utils.read_spark_sql_file(
#                 self.logger, self.spark, sql_file_path, sql_file_name, spark_df, conf
#             )
#         self.logger.error.assert_called_with(
#             "Issue while extracting file name from file path: File not found"
#         )

#     @patch("pyspark.sql.SparkSession.sql")
#     def test_check_schema_mismatch_stream_no_mismatch(self, mock_sql):
#         master_spark_df = self.spark.createDataFrame([(1, "file1")], ["id", "file_nm"])
#         existing_tbl_schema = self.spark.createDataFrame(
#             [(1, "file1")], ["id", "file_nm"]
#         )
#         mock_sql.return_value = existing_tbl_schema

#         result = SparkUtils().check_schema_mismatch_stream(
#             self.spark,
#             self.logger,
#             master_spark_df,
#             "target_table",
#             schema_mismatch_check=True,
#         )

#         self.assertFalse(result)
#         self.logger.info.assert_called()

#     @patch("pyspark.sql.SparkSession.sql")
#     def test_check_schema_mismatch_stream_with_mismatch(self, mock_sql):
#         master_spark_df = self.spark.createDataFrame([(1, "file1")], ["id", "file_nm"])
#         existing_tbl_schema = self.spark.createDataFrame(
#             [(1, "file1", "extra_column")], ["id", "file_nm", "extra_column"]
#         )
#         mock_sql.return_value = existing_tbl_schema

#         result = SparkUtils().check_schema_mismatch_stream(
#             self.spark,
#             self.logger,
#             master_spark_df,
#             "target_table",
#             schema_mismatch_check=True,
#         )

#         self.assertTrue(result)
#         self.logger.info.assert_called()

#     def test_check_schema_mismatch_stream_no_check(self):
#         master_spark_df = self.spark.createDataFrame([(1, "file1")], ["id", "file_nm"])
#         result = SparkUtils().check_schema_mismatch_stream(
#             self.spark,
#             self.logger,
#             master_spark_df,
#             "target_table",
#             schema_mismatch_check=False,
#         )
#         self.assertFalse(result)

#     @patch("pyspark.sql.SparkSession.sql")
#     def test_check_schema_mismatch_stream_exception(self, mock_sql):
#         mock_sql.side_effect = SystemError("Simulated exception")

#         master_spark_df = self.spark.createDataFrame([(1, "file1")], ["id", "file_nm"])

#         result = SparkUtils().check_schema_mismatch_stream(
#             self.spark,
#             self.logger,
#             master_spark_df,
#             "target_table",
#             schema_mismatch_check=True,
#         )

#         self.assertFalse(result)
#         self.logger.error.assert_called_with(
#             "Error while checking schema mismatch (table not created a.k.a first run): Simulated exception"
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_reject_table_load_success(self, MockSparkSession):
#         spark = MockSparkSession.builder.getOrCreate()

#         incremental_df = spark.createDataFrame(
#             [(1, "user1", "2021-01-01", "2021-01-01", "job1", "run1")],
#             [
#                 "id",
#                 "user_nm",
#                 "created_at_tmst",
#                 "batch_load_tmst",
#                 "job_nm",
#                 "job_run_id",
#             ],
#         )
#         cleansed_df = spark.createDataFrame(
#             [(1, "user1", "2021-01-01", "2021-01-01", "job1", "run1")],
#             [
#                 "id",
#                 "user_nm",
#                 "created_at_tmst",
#                 "batch_load_tmst",
#                 "job_nm",
#                 "job_run_id",
#             ],
#         )
#         conf = {
#             "target_database_name": "db",
#             "reject_table_name": "reject_table",
#             "predicate_rej_default": "load_dt >= add_months(current_date(), -12)",
#             "source_record_count": 100,
#         }
#         product_name = "product"
#         source_complete_table_name = "source_table"
#         target_complete_table_name = "target_table"

#         # Mock the read.table method
#         spark.read.table.return_value.where.return_value.count.return_value = 0

#         # Call the method
#         result = self.spark_utils.reject_table_load(
#             spark,
#             self.logger,
#             incremental_df,
#             cleansed_df,
#             conf,
#             product_name,
#             source_complete_table_name,
#             target_complete_table_name,
#         )
#         # Assertions
#         self.assertIsNotNone(result)

#         conf["predicate_rej"] = "load_dt >= add_months(current_date(), -12)"
#         result = self.spark_utils.reject_table_load(
#             spark,
#             self.logger,
#             incremental_df,
#             cleansed_df,
#             conf,
#             product_name,
#             source_complete_table_name,
#             target_complete_table_name,
#         )
#         # Assertions
#         self.assertIsNotNone(result)

#     @patch("pyspark.sql.SparkSession")
#     def test_reject_table_load_exception(self, MockSparkSession):
#         spark = MockSparkSession.builder.getOrCreate()

#         incremental_df = spark.createDataFrame(
#             [(1, "user1", "2021-01-01", "2021-01-01", "job1", "run1")],
#             [
#                 "id",
#                 "user_nm",
#                 "created_at_tmst",
#                 "batch_load_tmst",
#                 "job_nm",
#                 "job_run_id",
#             ],
#         )
#         cleansed_df = spark.createDataFrame(
#             [(1, "user1", "2021-01-01", "2021-01-01", "job1", "run1")],
#             [
#                 "id",
#                 "user_nm",
#                 "created_at_tmst",
#                 "batch_load_tmst",
#                 "job_nm",
#                 "job_run_id",
#             ],
#         )
#         conf = {
#             "target_database_name": "db",
#             "reject_table_name": "reject_table",
#             "predicate_rej_default": "load_dt >= add_months(current_date(), -12)",
#             "source_record_count": 100,
#         }
#         product_name = "product"
#         source_complete_table_name = "source_table"
#         target_complete_table_name = "target_table"
#         # Mock the read.table method to raise an exception
#         spark.read.table.side_effect = Exception("Test Exception")

#         # Call the method
#         with self.assertRaises(SystemError):
#             self.spark_utils.reject_table_load(
#                 spark,
#                 self.logger,
#                 incremental_df,
#                 cleansed_df,
#                 conf,
#                 product_name,
#                 source_complete_table_name,
#                 target_complete_table_name,
#             )

#         # Assertions
#         self.logger.error.assert_called()


# class TestLoggerUtils(unittest.TestCase):

#     def test_get_logger_object(self):
#         logger_utils = LoggerUtils()
#         logger = logger_utils.get_logger_object()

#         # Check if the logger is an instance of logging.Logger
#         self.assertIsInstance(logger, logging.Logger)

#         # Check if the logger has handlers
#         self.assertTrue(logger.hasHandlers())

#         # Check if the logger has the correct number of handlers
#         self.assertEqual(len(logger.handlers), 2)

#         # Check if the handlers are of the correct type
#         self.assertIsInstance(logger.handlers[0], logging.StreamHandler)
#         self.assertIsInstance(logger.handlers[1], logging.StreamHandler)

#         # Check if the second handler uses a StringIO buffer
#         self.assertIsInstance(logger.handlers[1].stream, io.StringIO)


# class TestConfigUtils(unittest.TestCase):

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.read_config_variables"
#     )
#     def test_read_config_variables(self, mock_read):
#         mock_logger = Mock()
#         config_utils = ConfigUtils()
#         mock_read.return_value = {
#             "product_name": "test_product",
#             "object_name": "test_obj",
#             "sfurl": "test_sfurl",
#         }
#         result = config_utils.read_config_variables(
#             "products/common_utilities/spark/python/tests/test_conf/",
#             "common_utils_test_config.toml",
#             "dev",
#             mock_logger,
#         )

#         self.assertIsInstance(result, dict)
#         self.assertIn("object_name", result)
#         self.assertIn("sfurl", result)
#         self.assertEqual(result["product_name"], "test_product")

#     def test_get_username_password_from_dbx_secrets(self):
#         mock_logger = Mock()
#         mock_bf_context = Mock()
#         username, password = ConfigUtils().get_username_password_from_dbx_secrets(
#             mock_logger, mock_bf_context, "dev"
#         )
#         self.assertIsNotNone(username)
#         self.assertIsNotNone(password)
#         mock_logger.info.assert_called()

#     # def test_cerberus_read(self):
#     # mock_logger = Mock()
#     #     mock_cerberus_client_instance = Mock()
#     #     mock_cerberus_client.return_value = mock_cerberus_client_instance
#     #     mock_cerberus_client_instance.get_secrets_data.return_value = {'key': 'value'}

#     #         config_utils = ConfigUtils()
#     #         result = config_utils.cerberus_read(mock_logger, {'key': 'key'}, 'secrets_path', 'url')

#     #         self.assertIsInstance(result, dict)
#     #         self.assertIn('key', result)
#     #         self.assertEqual(result['key'], 'value')
#     #         mock_logger.info.assert_called()

#     def test_set_start_end_date(self):
#         mock_logger = Mock()
#         now = datetime.now()

#         # Check daily dates
#         conf = {"frequency": "daily", "duration_prior": 1}
#         result = ConfigUtils().set_start_end_date(mock_logger, conf)
#         self.assertIsInstance(result, list)
#         self.assertEqual(len(result), 2)
#         self.assertEqual(
#             result[0], (datetime.now() - relativedelta(days=1)).strftime("%Y-%m-%d")
#         )
#         self.assertEqual(
#             result[1], (datetime.now() - relativedelta(days=1)).strftime("%Y-%m-%d")
#         )

#         # Check weekly dates
#         conf = {"frequency": "weekly", "duration_prior": 3}
#         if now.weekday() == 6:
#             now = now + relativedelta(days=1)
#         result = ConfigUtils().set_start_end_date(mock_logger, conf)
#         self.assertIsInstance(result, list)
#         self.assertEqual(len(result), 2)
#         self.assertEqual(
#             result[0],
#             (now - relativedelta(days=now.weekday() + 1 + 3 * 7)).strftime("%Y-%m-%d"),
#         )
#         self.assertEqual(
#             result[1],
#             (now + relativedelta(days=5 - now.weekday() - 7 * 3)).strftime("%Y-%m-%d"),
#         )

#         # Check monthly dates
#         conf = {"frequency": "monthly", "duration_prior": 2}
#         result = ConfigUtils().set_start_end_date(mock_logger, conf)
#         self.assertIsInstance(result, list)
#         self.assertEqual(len(result), 2)
#         self.assertEqual(
#             result[0], (now - relativedelta(months=2)).strftime("%Y-%m-01")
#         )
#         self.assertEqual(
#             result[1],
#             (
#                 (now + relativedelta(months=1 - 2)).replace(day=1)
#                 - relativedelta(days=1)
#             ).strftime("%Y-%m-%d"),
#         )

#         # Check historical_flag dates
#         conf = {
#             "historical_flag": True,
#         }
#         result = ConfigUtils().set_start_end_date(mock_logger, conf)
#         self.assertIsInstance(result, list)
#         self.assertEqual(len(result), 2)
#         self.assertEqual(result[0], "2018-01-01")
#         self.assertIn(
#             result[1],
#             [
#                 now.strftime("%Y-%m-%d"),
#                 (now - relativedelta(days=1)).strftime("%Y-%m-%d"),
#             ],
#         )

#         # Check when no frequency is provided and no dates
#         conf = {"frequency": "adhoc"}
#         result = ConfigUtils().set_start_end_date(mock_logger, conf)
#         self.assertIsInstance(result, list)
#         self.assertEqual(len(result), 2)
#         self.assertIn(
#             result[0],
#             [
#                 now.strftime("%Y-%m-%d"),
#                 (now - relativedelta(days=1)).strftime("%Y-%m-%d"),
#             ],
#         )
#         self.assertIn(
#             result[1],
#             [
#                 now.strftime("%Y-%m-%d"),
#                 (now - relativedelta(days=1)).strftime("%Y-%m-%d"),
#             ],
#         )

#         # Check when no frequency is provided but dates are provided
#         conf = {"start_date": "2018-08-08", "end_date": "2020-10-08"}
#         result = ConfigUtils().set_start_end_date(mock_logger, conf)
#         self.assertIsInstance(result, list)
#         self.assertEqual(len(result), 2)
#         self.assertEqual(result[0], "2018-08-08")
#         self.assertEqual(result[1], "2020-10-08")

#         # Check when no frequency is provided and no dates
#         conf = {}
#         result = ConfigUtils().set_start_end_date(mock_logger, conf)
#         self.assertIsInstance(result, list)
#         self.assertEqual(len(result), 2)
#         self.assertIn(
#             result[0],
#             [
#                 now.strftime("%Y-%m-%d"),
#                 (now - relativedelta(days=1)).strftime("%Y-%m-%d"),
#             ],
#         )
#         self.assertIn(
#             result[1],
#             [
#                 now.strftime("%Y-%m-%d"),
#                 (now - relativedelta(days=1)).strftime("%Y-%m-%d"),
#             ],
#         )

#         mock_logger.info.assert_called()


# class TestQueryUtils(unittest.TestCase):
#     def setUp(self):
#         self.spark = SparkSession.builder.master("local").appName("test").getOrCreate()
#         self.logger = MagicMock()
#         self.mock_spark = MagicMock()
#         self.mock_spark_df = MagicMock()

#     @patch("pyspark.sql.DataFrame")
#     @patch("pyspark.sql.SparkSession.read")
#     def test_read_cdc_batch(self, mock_read, mock_df):
#         logger = MagicMock()
#         query_utils = QueryUtils(self.spark)
#         table_name = "test_table"
#         latest_timestamp = datetime(2021, 1, 1)
#         predicates = "some_column = 'some_value'"
#         custom_starting_timestamp = datetime(2020, 12, 31)

#         mock_df.columns = [
#             "_change_type",
#             "_commit_version",
#             "_commit_timestamp",
#             "data",
#         ]
#         mock_df.filter.return_value = mock_df
#         mock_df.drop.return_value = mock_df
#         mock_read.format.return_value.option.return_value.option.return_value.table.return_value.where.return_value = (
#             mock_df
#         )

#         result_df = query_utils.read_cdc_batch(
#             logger, table_name, latest_timestamp, predicates, custom_starting_timestamp
#         )

#         self.assertEqual(result_df, mock_df)

#         mock_read.format.return_value.option.return_value.option.return_value.table.return_value = (
#             mock_df
#         )
#         result_df = query_utils.read_cdc_batch(logger, table_name, latest_timestamp)
#         self.assertEqual(result_df, mock_df)

#         mock_read.format.return_value.option.return_value.option.return_value.table.return_value = Exception(
#             "Simulated exception"
#         )
#         with self.assertRaises(SystemError) as error:
#             query_utils.read_cdc_batch(
#                 self.logger, table_name, latest_timestamp, custom_starting_timestamp
#             )
#         self.logger.error.assert_called()
#         self.logger.error.assert_called_with(
#             "Issue while fetching the incremental CDC data: 'Exception' object has no attribute 'where'"
#         )

#     @patch("pandas.DataFrame")
#     @patch("pyspark.sql.SparkSession")
#     def test_pivot_dataframe_success_1(self, mock_spark, mock_df):
#         input_df = [{"col1": "value1", "col2": "value2"}]
#         unpivot_cols = ["col1"]
#         id_col = "id"
#         value_col = "value"
#         df_pivot_list = []
#         conf = {}
#         target_complete_table_name = "test_table"
#         write_mode = "append"

#         mock_df.return_value = pd.DataFrame(input_df)
#         mock_spark_df = MagicMock()
#         mock_spark.createDataFrame.return_value = mock_spark_df
#         mock_spark_df.columns = ["col1", "col2"]
#         mock_spark_df.select.return_value = mock_spark_df
#         mock_spark_df.union.return_value = mock_spark_df

#         result = QueryUtils(mock_spark).pivot_dataframe(
#             self.logger,
#             input_df,
#             unpivot_cols,
#             id_col,
#             value_col,
#             df_pivot_list,
#             conf,
#             target_complete_table_name,
#             write_mode,
#         )
#         self.logger.info.assert_called()

#     @patch("pandas.DataFrame")
#     @patch("pyspark.sql.SparkSession")
#     def test_pivot_dataframe_success_2(self, mock_spark, mock_df):
#         input_df = [{"col1": "value1", "col2": "value2"}]
#         unpivot_cols = ["col1"]
#         id_col = "id"
#         value_col = "value"
#         df_pivot_list = []
#         conf = {"pivot_intermediate_save": True}
#         target_complete_table_name = "test_table"
#         write_mode = "append"

#         mock_df.return_value = pd.DataFrame(input_df)
#         mock_spark_df = MagicMock()
#         mock_spark.createDataFrame.return_value = mock_spark_df
#         mock_spark_df.columns = ["col1", "col2"]
#         mock_spark_df.select.return_value = mock_spark_df
#         mock_spark_df.union.return_value = mock_spark_df

#         input_df = Row(
#             Row([{"col1": "value1", "col2": "value2"}]),
#             Row([{"col1": "value1", "col2": "value2"}]),
#         )
#         result = QueryUtils(mock_spark).pivot_dataframe(
#             self.logger,
#             input_df,
#             unpivot_cols,
#             id_col,
#             value_col,
#             df_pivot_list,
#             conf,
#             target_complete_table_name,
#             write_mode,
#         )
#         self.logger.info.assert_called()

#     @patch("pandas.DataFrame")
#     @patch("pyspark.sql.SparkSession")
#     def test_pivot_dataframe_exception(self, mock_spark, mock_df):
#         input_df = [{"col1": "value1", "col2": "value2"}]
#         unpivot_cols = ["col1"]
#         id_col = "id"
#         value_col = "value"
#         df_pivot_list = []
#         conf = {"pivot_intermediate_save": True}
#         target_complete_table_name = "test_table"
#         write_mode = "append"
#         mock_df.return_value = pd.DataFrame(input_df)
#         mock_spark.createDataFrame.return_value = Exception("Simulated exception")

#         with self.assertRaises(SystemError) as error:
#             QueryUtils(mock_spark).pivot_dataframe(
#                 self.logger,
#                 input_df,
#                 unpivot_cols,
#                 id_col,
#                 value_col,
#                 df_pivot_list,
#                 conf,
#                 target_complete_table_name,
#                 write_mode,
#             )
#         self.logger.error.assert_called_with(
#             "Issue while pivoting the dataframe: 'Exception' object has no attribute 'columns'"
#         )

#     @patch("datetime.datetime")
#     def test_update_batch_load_tracker_running(self, mock_datetime):
#         mock_datetime.now.return_value = datetime(2023, 10, 1, 12, 0, 0)
#         batch_id = mock_datetime.now().strftime("%Y%m%d%H%M%S")

#         QueryUtils(self.mock_spark).update_batch_load_tracker(
#             project_name="test_project",
#             env="test_env",
#             batch_tracker_table="test_table",
#             status="RUNNING",
#         )
#         self.mock_spark.sql.assert_called()

#     @patch("datetime.datetime")
#     def test_update_batch_load_tracker_failure(self, mock_datetime):
#         mock_datetime.now.return_value = datetime(2023, 10, 1, 12, 0, 0)
#         batch_id = mock_datetime.now().strftime("%Y%m%d%H%M%S")

#         QueryUtils(self.mock_spark).update_batch_load_tracker(
#             project_name="test_project",
#             env="test_env",
#             batch_tracker_table="test_table",
#             status="FAILURE",
#         )
#         self.mock_spark.sql.assert_called()

#     @patch("pyspark.sql.SparkSession")
#     def test_update_batch_load_tracker_exception(self, mock_spark):
#         mock_spark_instance = mock_spark.return_value
#         mock_spark_instance.sql.side_effect = Exception("Simulated exception")

#         with self.assertRaises(SystemError) as error:
#             QueryUtils(mock_spark_instance).update_batch_load_tracker(
#                 project_name="test_project",
#                 env="test_env",
#                 batch_tracker_table="test_table",
#                 status="RUNNING",
#             )
#         self.assertTrue(
#             str(error.exception).startswith("Simulated exception"),
#             "Expected exception message to start with 'Simulated exception'",
#         )

#     def test_update_checkpoint_table(self):
#         QueryUtils(self.mock_spark).update_checkpoint_table(
#             job_run_id=123, checkpoint_table="checkpoint_table"
#         )

#         self.mock_spark.sql.assert_called_with(
#             f"""INSERT INTO checkpoint_table (job_run_id, updated_at_tmst)
#                 SELECT 123, current_timestamp()
#                 WHERE NOT  EXISTS (SELECT 1 FROM checkpoint_table
#                 WHERE updated_at_tmst >= current_timestamp() - INTERVAL 30 DAY)"""
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_update_checkpoint_exception(self, mock_spark):
#         mock_spark_instance = mock_spark.return_value
#         mock_spark_instance.sql.side_effect = Exception("Simulated exception")

#         with self.assertRaises(SystemError) as error:
#             QueryUtils(mock_spark_instance).update_checkpoint_table(
#                 job_run_id=123, checkpoint_table="checkpoint_table"
#             )
#         self.assertTrue(
#             str(error.exception).startswith("Simulated exception"),
#             "Expected exception message to start with 'Simulated exception'",
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_load_data_completeness_tracker_success(self, mock_spark):
#         mock_spark_instance = mock_spark.return_value
#         mock_spark_instance.createDataFrame.return_value = MagicMock()

#         QueryUtils(self.mock_spark).load_data_completeness_tracker(
#             data_product="test_product",
#             file_ext_check="csv",
#             delim_check=",",
#             cols_check="col1,col2",
#             env="test_env",
#             data_completeness_table="test_table",
#         )

#         self.mock_spark.sql.assert_called_with(
#             """
#                 CREATE TABLE IF NOT EXISTS test_table (
#                     data_product STRING,
#                     env STRING,
#                     file_ext_check STRING,
#                     delim_check STRING,
#                     cols_check STRING,
#                     batch_load_tmst STRING
#                 ) TBLPROPERTIES (delta.enableChangeDataFeed = true)
#             """
#         )
#         self.mock_spark.createDataFrame.assert_called()
#         self.mock_spark.createDataFrame.return_value.write.mode.assert_called_with(
#             "append"
#         )
#         self.mock_spark.createDataFrame.return_value.write.mode.return_value.option.assert_called_with(
#             "mergeSchema", "true"
#         )
#         self.mock_spark.createDataFrame.return_value.write.mode.return_value.option.return_value.format.assert_called_with(
#             "delta"
#         )
#         self.mock_spark.createDataFrame.return_value.write.mode.return_value.option.return_value.format.return_value.saveAsTable.assert_called_with(
#             "test_table"
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_load_data_completeness_tracker_exception(self, mock_spark):
#         mock_spark_instance = mock_spark.return_value
#         mock_spark_instance.sql.side_effect = Exception("Simulated exception")

#         with self.assertRaises(SystemError) as error:
#             QueryUtils(mock_spark_instance).load_data_completeness_tracker(
#                 data_product="test_product",
#                 file_ext_check="csv",
#                 delim_check=",",
#                 cols_check="col1,col2",
#                 env="test_env",
#                 data_completeness_table="test_table",
#             )

#         self.assertTrue(
#             str(error.exception).startswith("Simulated exception"),
#             "Expected exception message to start with 'Simulated exception'",
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_write_dataframe_to_delta_with_partition(self, mock_spark):
#         conf = {
#             "write_mode": "append",
#             "merge_schema": "true",
#             "partition_by_cols": ["col1"],
#             "group_name": "test_group",
#         }
#         QueryUtils(mock_spark).write_dataframe_to_delta(
#             logger=self.logger,
#             spark=mock_spark,
#             conf=conf,
#             spark_df=self.mock_spark_df,
#             table_name="test_table",
#             tech_solution_id="test_tech_id",
#             cloudred_gid="test_gid",
#         )

#         self.mock_spark_df.write.partitionBy.assert_called_with(["col1"])
#         self.mock_spark_df.write.partitionBy.return_value.mode.assert_called_with(
#             "append"
#         )
#         self.mock_spark_df.write.partitionBy.return_value.mode.return_value.option.assert_called_with(
#             "mergeSchema", "true"
#         )
#         self.mock_spark_df.write.partitionBy.return_value.mode.return_value.option.return_value.format.assert_called_with(
#             "delta"
#         )
#         self.mock_spark_df.write.partitionBy.return_value.mode.return_value.option.return_value.format.return_value.saveAsTable.assert_called_with(
#             "test_table"
#         )
#         mock_spark.sql.assert_any_call("alter table test_table owner to `test_group`")
#         mock_spark.sql.assert_any_call(
#             'ALTER TABLE test_table SET TAGS ("nike_techsolution" = "test_tech_id")'
#         )
#         mock_spark.sql.assert_any_call(
#             'ALTER TABLE test_table SET TAGS ("nike_tagguid" = "test_gid")'
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_write_dataframe_to_delta_without_partition(self, mock_spark):
#         conf = {
#             "write_mode": "append",
#             "merge_schema": "true",
#             "partition_by_cols": None,
#             "group_name": "test_group",
#         }
#         QueryUtils(mock_spark).write_dataframe_to_delta(
#             logger=self.logger,
#             spark=mock_spark,
#             conf=conf,
#             spark_df=self.mock_spark_df,
#             table_name="test_table",
#             tech_solution_id="test_tech_id",
#             cloudred_gid="test_gid",
#         )

#         self.mock_spark_df.write.mode.assert_called_with("append")
#         self.mock_spark_df.write.mode.return_value.option.assert_called_with(
#             "mergeSchema", "true"
#         )
#         self.mock_spark_df.write.mode.return_value.option.return_value.format.assert_called_with(
#             "delta"
#         )
#         self.mock_spark_df.write.mode.return_value.option.return_value.format.return_value.saveAsTable.assert_called_with(
#             "test_table"
#         )
#         mock_spark.sql.assert_any_call("alter table test_table owner to `test_group`")
#         mock_spark.sql.assert_any_call(
#             'ALTER TABLE test_table SET TAGS ("nike_techsolution" = "test_tech_id")'
#         )
#         mock_spark.sql.assert_any_call(
#             'ALTER TABLE test_table SET TAGS ("nike_tagguid" = "test_gid")'
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_write_dataframe_to_delta_exception_during_write(self, mock_spark):
#         conf = {
#             "write_mode": "append",
#             "merge_schema": "true",
#             "partition_by_cols": ["col1"],
#             "group_name": "test_group",
#         }
#         self.mock_spark_df.write.partitionBy.side_effect = Exception(
#             "Simulated write exception"
#         )

#         with self.assertRaises(SystemError):
#             QueryUtils(mock_spark).write_dataframe_to_delta(
#                 logger=self.logger,
#                 spark=mock_spark,
#                 conf=conf,
#                 spark_df=self.mock_spark_df,
#                 table_name="test_table",
#                 tech_solution_id="test_tech_id",
#                 cloudred_gid="test_gid",
#             )
#         self.logger.error.assert_called_with(
#             "Issue while writing spark dataframe to delta table: Simulated write exception"
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_write_dataframe_to_delta_exception_during_owner_change(self, mock_spark):
#         conf = {
#             "write_mode": "append",
#             "merge_schema": "true",
#             "partition_by_cols": ["col1"],
#         }

#         QueryUtils(mock_spark).write_dataframe_to_delta(
#             logger=self.logger,
#             spark=mock_spark,
#             conf=conf,
#             spark_df=self.mock_spark_df,
#             table_name="test_table",
#             tech_solution_id="test_tech_id",
#             cloudred_gid="test_gid",
#         )

#         self.logger.error.assert_called_with(
#             "Unable to change the owner for the table, try it manually. Error: 'group_name'"
#         )

#     @patch("pyspark.sql.SparkSession")
#     def test_write_dataframe_to_delta_exception_during_tag_update(self, mock_spark):
#         conf = {
#             "write_mode": "append",
#             "merge_schema": "true",
#             "partition_by_cols": ["col1"],
#         }
#         mock_spark.sql.side_effect = [
#             None,
#             Exception("Simulated tech_solution_id exception"),
#         ]

#         QueryUtils(mock_spark).write_dataframe_to_delta(
#             logger=self.logger,
#             spark=mock_spark,
#             conf=conf,
#             spark_df=self.mock_spark_df,
#             table_name="test_table",
#             tech_solution_id="test_tech_id",
#             cloudred_gid="test_gid",
#         )
#         self.logger.error.assert_called_with(
#             "Unable to set tech_solution_id and cloudred GID for the table, try it manually. Error: Simulated tech_solution_id exception"
#         )

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.read_config_variables"
#     )
#     def test_run_delta_table_optimisation_success(self, mock_read_config):
#         mock_bf_context = MagicMock()
#         mock_read_config.return_value = {
#             "vacuum_database_name": "test_db",
#             "vacuum_table_name": ["table1", "table2"],
#         }

#         QueryUtils(self.mock_spark).run_delta_table_optimisation(
#             logger=self.logger,
#             config_path="test_path",
#             config_name="test_config",
#             env="test_env",
#             bf_context=mock_bf_context,
#         )

#         self.logger.info.assert_any_call(
#             "*" * 20 + " START: run_delta_table_optimisation " + "*" * 20
#         )
#         self.logger.info.assert_any_call("Execution started for table table1")
#         self.logger.info.assert_any_call("Execution started for table table2")
#         self.mock_spark.sql.assert_any_call("VACUUM test_db.table1")
#         self.mock_spark.sql.assert_any_call(
#             "ANALYZE TABLE test_db.table1 COMPUTE STATISTICS"
#         )
#         self.mock_spark.sql.assert_any_call("OPTIMIZE test_db.table1")
#         self.mock_spark.sql.assert_any_call("VACUUM test_db.table2")
#         self.mock_spark.sql.assert_any_call(
#             "ANALYZE TABLE test_db.table2 COMPUTE STATISTICS"
#         )
#         self.mock_spark.sql.assert_any_call("OPTIMIZE test_db.table2")
#         self.logger.info.assert_any_call(
#             "*" * 20 + " END: run_delta_table_optimisation " + "*" * 20
#         )

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.read_config_variables"
#     )
#     def test_run_delta_table_optimisation_exception(self, mock_read_config):
#         mock_bf_context = MagicMock()
#         mock_read_config.return_value = {
#             "vacuum_database_name": "test_db",
#             "vacuum_table_name": ["table1"],
#         }
#         self.mock_spark.sql.side_effect = Exception("Simulated SQL exception")

#         with self.assertRaises(SystemError):
#             QueryUtils(self.mock_spark).run_delta_table_optimisation(
#                 logger=self.logger,
#                 config_path="test_path",
#                 config_name="test_config",
#                 env="test_env",
#                 bf_context=mock_bf_context,
#             )

#         self.logger.error.assert_called_with(
#             "Issue occurred while processing optimisation on delta table : Simulated SQL exception"
#         )
#         self.logger.info.assert_any_call(
#             "*" * 20 + " END: run_delta_table_optimisation " + "*" * 20
#         )


# class TestJSONUtils(unittest.TestCase):

#     def setUp(self):
#         self.logger = Mock()
#         self.mock_spark = Mock()
#         self.spark_utils = SparkUtils()
#         self.spark = SparkSession.builder.master("local").appName("test").getOrCreate()

#     def test_convert_spark_df_to_pandas_df(self):
#         data = [{"payload": json.dumps({"key": "value"})}]
#         spark_df = self.spark.createDataFrame(data)
#         pandas_df = JSONUtils().convert_spark_df_to_pandas_df(
#             self.logger, spark_df, "payload"
#         )
#         self.assertEqual(pandas_df["payload"][0], {"key": "value"})

#     def test_convert_spark_df_to_pandas_df_exception(self):
#         data = [{"payload": json.dumps({"key": "value"})}]
#         spark_df = Mock()
#         spark_df.toPandas.side_effect = Exception("Error")
#         with self.assertRaises(Exception):
#             JSONUtils().convert_spark_df_to_pandas_df(self.logger, spark_df, "payload")
#         # self.assertEqual(pandas_df["payload"][0], {"key": "value"})

#     def test_extract_required_nested_data(self):
#         data_obj = {"child": [{"key": "value"}]}
#         required_data = []
#         JSONUtils().extract_required_nested_data(
#             self.logger, data_obj, required_data, "child"
#         )
#         self.assertEqual(required_data, [{"key": "value"}])

#     def test_pandas_flatten_nested_json(self):
#         data = [{"parent": {"child": "value"}}]
#         pandas_df = pd.DataFrame(data)
#         conf = {"children_nodes": ["child"]}
#         result = JSONUtils().pandas_flatten_nested_json(
#             self.logger, pandas_df, ["parent"], conf=conf
#         )
#         expected_result = ["value"]
#         self.assertEqual(result, expected_result)

#     # def test_pandas_flatten_nested_json_format_keys(self):
#     #     data = [{"parent": {"child": "value"}}]
#     #     pandas_df = pd.DataFrame(data)
#     #     conf = {"children_nodes": ["child"], 'json_fields_multiple_format_keys': ['a', 'b']}
#     #     result = JSONUtils().pandas_flatten_nested_json(self.logger, pandas_df, ["parent"], conf=conf)
#     #     expected_result = ["value"]
#     #     self.assertEqual(result, expected_result)

#     def test_list_flatten_nested_json_without_children_nodes(self):
#         # json.loads.return_value = {"parent": [{"child1": "value1"}, {"child1": "value2"}]}
#         list_obj_str = '{"parent": [{"child1": "value1"}, {"child1": "value2"}]}'
#         parent_node = "parent"
#         children_nodes = ["child1"]
#         expected_result = [{"child1": "value1"}, {"child1": "value2"}]
#         result = JSONUtils().list_flatten_nested_json(
#             self.logger, list_obj_str, parent_node, children_nodes=None
#         )
#         self.assertEqual(result, expected_result)

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.JSONUtils.extract_required_nested_data"
#     )
#     def test_list_flatten_nested_json_with_children_nodes(
#         self, mock_extract_required_nested_data
#     ):
#         list_obj_str = '{"parent": [{"child1": "value1"}, {"child1": "value2"}]}'
#         parent_node = "parent"
#         children_nodes = ["child1"]
#         expected_result = []  # ["value1", "value2"]
#         mock_extract_required_nested_data.return_value = []
#         result = JSONUtils().list_flatten_nested_json(
#             self.logger, list_obj_str, parent_node, children_nodes=children_nodes
#         )
#         self.assertEqual(result, expected_result)

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.JSONUtils.extract_required_nested_data"
#     )
#     def test_list_flatten_nested_json_exception(
#         self, mock_extract_required_nested_data
#     ):
#         list_obj_str = '{"parent": [{"child1": "value1"}, {"child1": "value2"}]}'
#         parent_node = "parent"
#         children_nodes = ["child1"]
#         mock_extract_required_nested_data.side_effect = Exception(
#             "Issue while flattening nested json"
#         )

#         with self.assertRaises(SystemError) as error:
#             JSONUtils().list_flatten_nested_json(
#                 self.logger, list_obj_str, parent_node, children_nodes
#             )
#         self.logger.error.assert_called()

#     def test_json_dict_to_spark_df(self):
#         records_json_dict = {"key": "value"}
#         spark_df = JSONUtils().json_dict_to_spark_df(
#             self.logger, records_json_dict, self.spark
#         )
#         self.assertEqual(spark_df.collect()[0].asDict(), {"key": "value"})

#     @patch("pyspark.sql.types.StructType")
#     def test_json_dict_to_spark_df_exception(self, mock_struct_type):
#         spark = Mock()
#         spark.createDataFrame.side_effect = Exception("Error")
#         records_json_dict = {"key": "value"}
#         with self.assertRaises(SystemExit):
#             JSONUtils().json_dict_to_spark_df(
#                 self.logger, records_json_dict, self.spark
#             )

#     def test_array_of_json_to_spark_df(self):
#         array_of_json_dict_list = [{"key": "value"}]
#         spark_df = JSONUtils().array_of_json_to_spark_df(
#             self.logger, array_of_json_dict_list, self.spark
#         )
#         self.assertEqual(spark_df.collect()[0].asDict(), {"key": "value"})

#     def test_array_of_json_to_spark_df_exception(self):
#         spark = Mock()
#         spark.createDataFrame.side_effect = Exception("Error")
#         array_of_json_dict_list = [{"key": "value"}]
#         # JSONUtils().array_of_json_to_spark_df(self.logger, array_of_json_dict_list, spark)
#         with self.assertRaises(SystemExit):
#             JSONUtils().array_of_json_to_spark_df(
#                 self.logger, array_of_json_dict_list, spark
#             )

#     @patch("pyspark.sql.functions.explode")
#     def test_recursive_explode_array_type(self, mock_explode):
#         df = self.spark.createDataFrame([{"col": [{"key": "value"}]}])
#         mock_explode.return_value = df

#         result_df = JSONUtils().recursive_explode(self.logger, df, col_name="col")

#         self.assertIsNotNone(result_df)


# class TestAPIUtils(unittest.TestCase):

#     def setUp(self):
#         self.api_utils = APIUtils()
#         self.logger = MagicMock()
#         self.conf = {
#             "authentication_endpoint": "http://example.com/auth",
#             "api_endpoint": "http://example.com/api",
#             "job_name": "test_job",
#             "object_name": "test_object",
#         }

#     @patch("requests.request")
#     def test_get_token_from_api(self, mock_request):
#         mock_response = MagicMock()
#         mock_response.status_code = 200
#         mock_request.return_value = mock_response

#         response = self.api_utils.get_token_from_api(
#             self.logger, "username", "password", self.conf
#         )
#         self.assertEqual(response.status_code, 200)
#         self.logger.info.assert_called()
#         mock_request.assert_called()

#         # Check for else
#         response = self.api_utils.get_token_from_api(
#             self.logger, "username", "password", self.conf, auth_param=True
#         )
#         self.assertEqual(response.status_code, 200)
#         self.logger.info.assert_called()
#         mock_request.assert_called()

#         # Exception check
#         self.conf.pop("authentication_endpoint")
#         with pytest.raises(SystemError) as error:
#             self.api_utils.get_token_from_api(
#                 self.logger, "username", "password", self.conf, auth_param=True
#             )
#         assert "authentication_endpoint" in str(
#             error.value
#         )  # Since schema value has been removed from config

#     @patch("requests.request")
#     def test_api_call_basic_auth(self, mock_request):
#         mock_response = MagicMock()
#         mock_response.status_code = 200
#         mock_response.json.return_value = {"offset": "N/A"}
#         mock_request.return_value = mock_response

#         response = self.api_utils.api_call_basic_auth(
#             self.logger, "http://example.com/api", "token", conf=self.conf
#         )
#         self.assertEqual(response.status_code, 200)
#         self.logger.info.assert_called()
#         mock_request.assert_called_once()

#         response = self.api_utils.api_call_basic_auth(
#             self.logger,
#             "http://example.com/api",
#             "token",
#             conf=self.conf,
#             offset="test123",
#         )

#         self.conf.pop("api_endpoint")
#         with pytest.raises(SystemError) as error:
#             self.api_utils.api_call_basic_auth(
#                 self.logger,
#                 "http://example.com/api",
#                 "token",
#                 conf=self.conf,
#                 offset="test123",
#             )
#         assert "api_endpoint" in str(
#             error.value
#         )  # Since schema value has been removed from config

#     @patch("requests.request")
#     def test_fetch_api_without_id(self, mock_request):
#         mock_response = MagicMock()
#         mock_response.status_code = 200
#         mock_response.json.return_value = {"offset": "N/A"}
#         mock_request.return_value = mock_response

#         response = self.api_utils.fetch_api_without_id(
#             self.logger,
#             "http://example.com/api",
#             "2021-01-01",
#             "2021-01-01T00:00:00Z",
#             "token",
#             self.conf,
#             "job_id",
#             MagicMock(),
#         )

#         self.assertIsInstance(response, list)
#         self.logger.info.assert_called()
#         mock_request.assert_called()

#         response = self.api_utils.fetch_api_without_id(
#             self.logger,
#             "http://example.com/api",
#             "2021-01-01",
#             "2021-01-01T00:00:00Z",
#             "token",
#             self.conf,
#             "job_id",
#             MagicMock(),
#             offset="test123",
#         )

#         self.assertIsInstance(response, list)
#         mock_request.assert_called()

#     # @patch('products.common_utilities.spark.python.src.common_utilities.APIUtils.api_call_basic_auth')
#     # @patch('requests.request')
#     # def test_fetch_api_without_id_http_error(self, mock_response, mock_api_call_basic_auth):
#     #     mock_api_call_basic_auth.return_value = 400
#     #     self.api_utils.fetch_api_without_id(
#     #         self.logger, "http://example.com/api", "2021-01-01", "2021-01-01T00:00:00Z", "token", self.conf, "job_id", MagicMock()
#     #     )
#     #     mock_api_call_basic_auth.assert_called()

#     @patch("requests.request")
#     def test_fetch_api_with_id(self, mock_request):
#         mock_response = MagicMock()
#         mock_response.status_code = 200
#         mock_request.return_value = mock_response

#         response = self.api_utils.fetch_api_with_id(
#             self.logger,
#             "http://example.com/api/{id}",
#             "123",
#             "2021-01-01",
#             "2021-01-01T00:00:00Z",
#             "token",
#             "job_id",
#             self.conf,
#             MagicMock(),
#         )
#         self.assertIsInstance(response, dict)
#         self.logger.info.assert_called()
#         mock_request.assert_called_once()

#     @patch("requests.request")
#     def test_fetch_api_with_id_http_error(self, mock_response):
#         mock_response.side_effect = requests.exceptions.HTTPError("HTTPError")
#         with self.assertRaises(SystemError):
#             self.api_utils.fetch_api_with_id(
#                 self.logger,
#                 "http://example.com/api/{id}",
#                 "123",
#                 "2021-01-01",
#                 "2021-01-01T00:00:00Z",
#                 "token",
#                 "job_id",
#                 self.conf,
#                 MagicMock(),
#             )
#         self.logger.error.assert_called()


# class TestFetchApiWithoutId(unittest.TestCase):

#     def setUp(self):
#         self.logger = Mock()
#         self.url = "http://example.com/api"
#         self.load_date = "2023-01-01"
#         self.current_timestamp = "2023-01-01T00:00:00Z"
#         self.api_token = "dummy_token"
#         self.conf = {"job_name": "test_job", "object_name": "test_object"}
#         self.job_id = "12345"
#         self.spark_obj = Mock()
#         self.payload = {}
#         self.req_method = "POST"
#         self.bearer_auth = False
#         self.offset = "N/A"
#         self.your_class_instance = APIUtils()

#     @patch.object(APIUtils, "api_call_basic_auth")
#     @patch.object(APIUtils, "get_username")
#     def test_fetch_api_without_id_success(
#         self, mock_get_username, mock_api_call_basic_auth
#     ):
#         mock_response = Mock()
#         mock_response.status_code = 200
#         mock_response.text = '{"key": "value"}'
#         mock_api_call_basic_auth.return_value = mock_response
#         mock_get_username.return_value = "test_user"

#         result = self.your_class_instance.fetch_api_without_id(
#             self.logger,
#             self.url,
#             self.load_date,
#             self.current_timestamp,
#             self.api_token,
#             self.conf,
#             self.job_id,
#             self.spark_obj,
#             self.payload,
#             self.req_method,
#             self.bearer_auth,
#             self.offset,
#         )

#         self.assertEqual(len(result), 1)
#         self.assertEqual(result[0]["batch_id"], self.current_timestamp)
#         self.assertEqual(result[0]["payload"], '{"key": "value"}')

#     @patch.object(APIUtils, "api_call_basic_auth")
#     def test_fetch_api_without_id_non_2xx(self, mock_api_call_basic_auth):
#         mock_response = Mock()
#         mock_response.status_code = 400
#         mock_response.text = "Bad Request"
#         mock_api_call_basic_auth.return_value = mock_response

#         result = self.your_class_instance.fetch_api_without_id(
#             self.logger,
#             self.url,
#             self.load_date,
#             self.current_timestamp,
#             self.api_token,
#             self.conf,
#             self.job_id,
#             self.spark_obj,
#             self.payload,
#             self.req_method,
#             self.bearer_auth,
#             self.offset,
#         )

#         self.assertEqual(result, [])
#         self.logger.error.assert_called()

#     # @patch.object(APIUtils, 'api_call_basic_auth')
#     # def test_fetch_api_without_id_http_error(self, mock_api_call_basic_auth):
#     #     mock_api_call_basic_auth.side_effect = requests.exceptions.HTTPError("HTTP Error")

#     #     with self.assertRaises(SystemExit):
#     #         self.your_class_instance.fetch_api_without_id(
#     #             self.logger, self.url, self.load_date, self.current_timestamp, self.api_token,
#     #             self.conf, self.job_id, self.spark_obj, self.payload, self.req_method, self.bearer_auth, self.offset
#     #         )
#     #     self.logger.error.assert_called_with("*" * 20 + " Error occured HTTPErrorHTTP Error" + "*" * 20)

#     # @patch.object(APIUtils, 'api_call_basic_auth')
#     # def test_fetch_api_without_id_connection_error(self, mock_api_call_basic_auth):
#     #     mock_api_call_basic_auth.side_effect = requests.exceptions.ConnectionError("Connection Error")

#     #     with self.assertRaises(SystemExit):
#     #         self.your_class_instance.fetch_api_without_id(
#     #             self.logger, self.url, self.load_date, self.current_timestamp, self.api_token,
#     #             self.conf, self.job_id, self.spark_obj, self.payload, self.req_method, self.bearer_auth, self.offset
#     #         )

#     #     self.logger.error.assert_called_with("util_api_to_landing:Error Connecting:", "Connection Error")

#     # @patch.object(APIUtils, 'api_call_basic_auth')
#     # def test_fetch_api_without_id_timeout_error(self, mock_api_call_basic_auth):
#     #     mock_api_call_basic_auth.side_effect = requests.exceptions.Timeout("Timeout Error")

#     #     with self.assertRaises(SystemExit):
#     #         self.your_class_instance.fetch_api_without_id(
#     #             self.logger, self.url, self.load_date, self.current_timestamp, self.api_token,
#     #             self.conf, self.job_id, self.spark_obj, self.payload, self.req_method, self.bearer_auth, self.offset
#     #         )

#     #     self.logger.error.assert_called_with("util_api_to_landing:Timeout Error:", "Timeout Error")

#     # @patch.object(APIUtils, 'api_call_basic_auth')
#     # def test_fetch_api_without_id_request_exception(self, mock_api_call_basic_auth):
#     #     mock_api_call_basic_auth.side_effect = requests.exceptions.RequestException("Request Exception")

#     #     with self.assertRaises(SystemExit):
#     #         self.your_class_instance.fetch_api_without_id(
#     #             self.logger, self.url, self.load_date, self.current_timestamp, self.api_token,
#     #             self.conf, self.job_id, self.spark_obj, self.payload, self.req_method, self.bearer_auth, self.offset
#     #         )

#     #     self.logger.error.assert_called_with("util_api_to_landing:RequestException")


# class TestBoxToS3Utils(unittest.TestCase):

#     def setUp(self):
#         self.utils = BoxToS3Utils()
#         self.logger = Mock()
#         self.bf_context = Mock()
#         self.client = Mock()
#         self.conf = {
#             "last_run": "20220101000000",
#             "sub_folders_flag": "no",
#             "timestamp": "20220101000000",
#             "file_name_separator": "_",
#             "input_file_pattern": ["*.csv"],
#             "target_path": "/tmp",
#             "archive_flag": "yes",
#             "handle_duplicates": "yes",
#         }

#         # current_datetime = datetime.now()
#         # formatted_datetime = current_datetime.strftime("%Y%m%d%H%M%S")
#         # return formatted_datetime

#     def test_get_timestamp(self):
#         timestamp = self.utils.get_timestamp(self.logger)
#         self.assertAlmostEqual(timestamp, datetime.now().strftime("%Y%m%d%H%M%S"))

#     def test_get_secrets_from_databricks(self):
#         self.bf_context.dbutils.secrets.get.side_effect = [
#             "client_id",
#             "client_secret",
#             "enterprise_id",
#             "jwt_key_id",
#             "rsa_private_key_data",
#             "rsa_private_key_passphrase",
#         ]
#         secrets = self.utils.get_secrets_from_databricks(
#             self.logger, self.bf_context, "scope"
#         )
#         self.assertEqual(
#             secrets,
#             (
#                 "client_id",
#                 "client_secret",
#                 "enterprise_id",
#                 "jwt_key_id",
#                 "rsa_private_key_data",
#                 "rsa_private_key_passphrase",
#             ),
#         )

#     @patch("dateutil.parser.parse")
#     def test_get_files_list_with_last_run(self, mock_parse):
#         mock_parse.side_effect = lambda x: datetime.strptime(x, "%Y-%m-%dT%H:%M:%S")
#         file1 = Mock(
#             type="file",
#             get=Mock(
#                 return_value={
#                     "id": "file1",
#                     "name": "file1.csv",
#                     "modified_at": "2022-01-02T00:00:00-00:00",
#                 }
#             ),
#         )
#         file2 = Mock(
#             type="file",
#             get=Mock(
#                 return_value={
#                     "id": "file2",
#                     "name": "file2.csv",
#                     "modified_at": "2021-12-31T00:00:00-00:00",
#                 }
#             ),
#         )
#         folder = Mock(type="folder", get=Mock(return_value={"id": "folder1"}))
#         self.client.folder().get_items.return_value = [file1, file2, folder]

#         files_dict = self.utils.get_files_list(
#             self.logger, self.conf, self.client, "src_box_id"
#         )
#         expected_files_dict = {
#             "file1": ["src_box_id", "file1.csv", "2022-01-02T00:00:00-00:00"]
#         }
#         self.assertEqual(files_dict, expected_files_dict)

#     @patch("dateutil.parser.parse")
#     def test_get_files_list_without_last_run(self, mock_parse):
#         self.conf.pop("last_run")
#         file1 = Mock(
#             type="file",
#             get=Mock(
#                 return_value={
#                     "id": "file1",
#                     "name": "file1.csv",
#                     "modified_at": "2022-01-02T00:00:00-00:00",
#                 }
#             ),
#         )
#         file2 = Mock(
#             type="file",
#             get=Mock(
#                 return_value={
#                     "id": "file2",
#                     "name": "file2.csv",
#                     "modified_at": "2021-12-31T00:00:00-00:00",
#                 }
#             ),
#         )
#         folder = Mock(type="folder", get=Mock(return_value={"id": "folder1"}))
#         self.client.folder().get_items.return_value = [file1, file2, folder]

#         files_dict = self.utils.get_files_list(
#             self.logger, self.conf, self.client, "src_box_id"
#         )
#         expected_files_dict = {
#             "file1": ["src_box_id", "file1.csv", "2022-01-02T00:00:00-00:00"],
#             "file2": ["src_box_id", "file2.csv", "2021-12-31T00:00:00-00:00"],
#         }
#         self.assertEqual(files_dict, expected_files_dict)

#     @patch("dateutil.parser.parse")
#     def test_get_files_list_with_sub_folders(self, mock_parse):
#         mock_parse.side_effect = lambda x: datetime.strptime(x, "%Y-%m-%dT%H:%M:%S")
#         file1 = Mock(
#             type="file",
#             get=Mock(
#                 return_value={
#                     "id": "file1",
#                     "name": "file1.csv",
#                     "modified_at": "2022-01-02T00:00:00-00:00",
#                 }
#             ),
#         )
#         folder = Mock(type="folder", get=Mock(return_value={"id": "folder1"}))
#         file2 = Mock(
#             type="file",
#             get=Mock(
#                 return_value={
#                     "id": "file2",
#                     "name": "file2.csv",
#                     "modified_at": "2022-01-03T00:00:00-00:00",
#                 }
#             ),
#         )
#         self.client.folder().get_items.side_effect = [[file1, folder], [file2]]

#         files_dict = self.utils.get_files_list(
#             self.logger, self.conf, self.client, "src_box_id"
#         )
#         expected_files_dict = {
#             "file1": ["src_box_id", "file2.csv", "2022-01-02T00:00:00-00:00"],
#             "file2": ["src_box_id", "file2.csv", "2022-01-03T00:00:00-00:00"],
#         }
#         self.assertEqual(files_dict["file2"], expected_files_dict["file2"])

#     def test_parse_files(self):
#         conf = self.conf.copy()
#         files_dict = {"file1": ["src_box_id", "file1.csv", "2022-01-01T00:00:00-00:00"]}
#         self.utils.copy_box_to_s3 = Mock()
#         self.utils.parse_files(
#             self.logger, self.conf, self.client, files_dict, "archive_id"
#         )
#         self.utils.copy_box_to_s3.assert_called_once_with(
#             self.logger,
#             self.conf,
#             self.client,
#             "file1",
#             "file1.csv",
#             "20220101000000_src_box_id_file1.csv",
#         )

#     def test_copy_box_to_s3(self):  # , mock_pd, mock_os):
#         self.client.file().content.return_value = b"file_content"
#         self.file_path = "/tmp/20220101000000_file1.csv"
#         self.utils.copy_box_to_s3(
#             self.logger,
#             self.conf,
#             self.client,
#             "file1",
#             "file1.csv",
#             "20220101000000_file1.csv",
#         )
#         self.logger.info.assert_called()
#         # os.path.exists.return_value = False
#         # self.utils.copy_box_to_s3(self.logger, self.conf, self.client, "file1", "file1.csv", "20220101000000_file1.csv")

#     def test_get_files_list_exception(self):
#         self.client.folder().get_items.side_effect = Exception("Test exception")
#         with self.assertRaises(SystemExit):
#             self.utils.get_files_list(self.logger, self.conf, self.client, "src_box_id")
#         self.logger.error.assert_called_with("get_files_list - error : Test exception")


# class TestAlertUtils(unittest.TestCase):

#     def setUp(self):
#         self.utils = AlertUtils()
#         self.logger = Mock()

#     @patch("products.common_utilities.spark.python.src.common_utilities.PrettyTable")
#     def test_get_table_content(self, MockPrettyTable):
#         # Mock PrettyTable instance
#         mock_table = MockPrettyTable.return_value
#         mock_table.get_string.return_value = "Mocked Table String"

#         # Test normal execution
#         column_names = ["Column1", "Column2"]
#         row_values = ["Value1", "Value2"]
#         result = self.utils.get_table_content(self.logger, column_names, row_values)
#         self.assertEqual(result, "Mocked Table String")
#         self.logger.info.assert_any_call(
#             "*" * 20 + " START: get_table_content" + "*" * 20
#         )
#         self.logger.info.assert_any_call(
#             "*" * 20 + " END: get_table_content" + "*" * 20
#         )

#         # Test exception handling
#         mock_table.add_rows.side_effect = Exception("Test Exception")
#         with self.assertRaises(SystemExit):
#             self.utils.get_table_content(self.logger, column_names, row_values)
#         self.logger.error.assert_called_with(
#             "get_table_content - error : Test Exception"
#         )

#     def test_get_detailed_payload_for_slack_alert(self):
#         # Test with count_and_headers_flag = True
#         result = self.utils.get_detailed_payload_for_slack_alert(self.logger, True)
#         expected_payload = {
#             "blocks": [
#                 {
#                     "type": "section",
#                     "text": {"type": "mrkdwn", "text": "{}\n```{}```\n"},
#                 }
#             ]
#         }
#         self.assertEqual(result, expected_payload)
#         self.logger.info.assert_any_call(
#             "*" * 20 + " START: get_detailed_payload_for_slack_alert" + "*" * 20
#         )
#         self.logger.info.assert_any_call(
#             "*" * 20 + " END: get_detailed_payload_for_slack_alert" + "*" * 20
#         )

#         # Test with count_and_headers_flag = False
#         result = self.utils.get_detailed_payload_for_slack_alert(self.logger, False)
#         expected_payload["blocks"][0]["text"]["text"] = "```{}```\n"
#         self.assertEqual(result, expected_payload)

#         # Test exception handling
#         # with patch.dict(result["blocks"][0], {"text": {"text": None}}):
#         #     with self.assertRaises(SystemExit):
#         #         self.utils.get_detailed_payload_for_slack_alert(self.logger)
#         # self.logger.error.assert_called()

#     # @patch('requests.post')
#     # def test_send_slack_alert_success_with_records(self, mock_requests_post):
#     #     mock_logger = MagicMock()
#     #     mock_spark = MagicMock()
#     #     instance = AlertUtils()
#     #     conf = {
#     #         'alert_complete_table_name': 'test_alert_table'
#     #     }
#     #     # Mock the Spark DataFrame and its methods
#     #     mock_df = MagicMock()
#     #     mock_df.count.return_value = 2
#     #     mock_df.toPandas.return_value = pd.DataFrame({
#     #         'alert_to': ['receiver1', 'receiver2'],
#     #         'alert_UUID': ['uuid1', 'uuid2']
#     #     })
#     #     mock_spark.sql.return_value = mock_df
#     #     Mock().uuid.return_value = ['uuid1', 'uuid2']

#     #     # Mock the get_table_content and get_detailed_payload_for_slack_alert methods
#     #     instance.get_table_content = MagicMock(return_value="table_content")
#     #     instance.get_detailed_payload_for_slack_alert = MagicMock(return_value={
#     #         "blocks": [{"text": {"text": "{0}{1}"}}]
#     #     })

#     #     instance.send_slack_alert(mock_logger, mock_spark, conf)

#     #     mock_logger.info.assert_any_call("*" * 20 + " START: send_slack_alert" + "*" * 20)
#     #     mock_logger.info.assert_any_call("Number of unprocessed records for slack from alerts table: 2")
#     #     mock_requests_post.assert_any_call('receiver1', json={
#     #         "blocks": [{"text": {"text": "Alerts generated for the latest workflow execution: \ntable_content"}}]
#     #     })
#     #     mock_requests_post.assert_any_call('receiver2', json={
#     #         "blocks": [{"text": {"text": "Alerts generated for the latest workflow execution: \ntable_content"}}]
#     #     })
#     #     mock_logger.info.assert_any_call(f"Slack alert sent successfully to receiver: receiver1")
#     #     mock_logger.info.assert_any_call(f"Slack alert sent successfully to receiver: receiver2")
#     #     mock_logger.info.assert_any_call("*" * 20 + " END: send_slack_alert" + "*" * 20)

#     # @patch('os.path.join')
#     # @patch('builtins.open', new_callable=unittest.mock.mock_open, read_data="email template content")
#     # def test_send_alert_notification(self, mock_open, mock_path_join):
#     #     # Mock logger
#     #     logger = MagicMock()

#     #     # Mock Spark object
#     #     spark_obj = MagicMock()
#     #     spark_obj.sql.count.return_value = 2
#     #     # spark_obj.sql.return_value.toPandas.return_value = pd.DataFrame({
#     #     #     'alerts_to': ['receiver1', 'receiver2'],
#     #     #     'alerts_from': ['sender1', 'sender2'],
#     #     #     'alert_UUID': ['uuid1', 'uuid2'],
#     #     #     'alert_status': ['UNPROCESSED', 'FAILED'],
#     #     #     'alert_description': ['description1', 'description2']
#     #     # })

#     #     # Mock configuration
#     #     conf = {
#     #         'alert_database_name': 'db',
#     #         'alert_table_name': 'alerts_table',
#     #         'email_template_dir': '/path/to/templates',
#     #         'email_template_file_name': 'template.html',
#     #         'email_columns': ['alerts_to', 'alerts_from', 'alert_description'],
#     #         'team_email': 'team@example.com'
#     #     }

#     #     # Create an instance of the class containing the methods
#     #     alert_instance = AlertUtils()  # Replace with actual class name

#     #     # Call the method
#     #     alert_instance.send_alert_notification(logger, spark_obj, conf, 'env')

#     #     # Assertions
#     #     logger.info.assert_called()
#     #     mock_open.assert_called()
#     #     self.assertTrue(spark_obj.sql.called)

#     def test_generate_alerts_dictionary(self):
#         # Mock logger
#         logger = MagicMock()

#         # Configuration dictionary
#         conf = {
#             "function_name": "test_function",
#             "slack_channel_email": "alerts@example.com",
#             "team_email": "team@example.com",
#         }

#         # Parameters
#         priority = "High"
#         err = "Test error message"

#         # Create an instance of the class containing the method
#         alert_instance = AlertUtils()

#         # Call the method
#         result = alert_instance.generate_alerts_dictionary(logger, conf, priority, err)

#         # Expected result
#         expected_result = {
#             "function_name": "test_function",
#             "slack_channel_email": "alerts@example.com",
#             "team_email": "team@example.com",
#             "alert_type": "slack_and_email",
#             "alert_severity": "High",
#             "alert_summary": "Error In - test_function()",
#             "alert_description": "Test error message",
#             "alert_to": "alerts@example.com",
#             "alert_cc": "team@example.com",
#         }

#         # Assertions
#         self.assertEqual(result, expected_result)
#         logger.info.assert_any_call(
#             "*" * 20 + " START: generate_alerts_dictionary" + "*" * 20
#         )
#         logger.info.assert_any_call(
#             "*" * 20 + " END: generate_alerts_dictionary" + "*" * 20
#         )

#     @patch(
#         "builtins.open",
#         new_callable=unittest.mock.mock_open,
#         read_data="Email body template",
#     )
#     @patch("smtplib.SMTP")
#     def test_send_email_alert_deprecated(self, mock_smtp, mock_file):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark object and DataFrame
#         spark_obj = MagicMock()
#         mock_df = MagicMock()
#         mock_df.count.return_value = 1
#         mock_df.toPandas.return_value = pd.DataFrame(
#             {
#                 "alert_UUID": ["uuid1"],
#                 "alerts_to": ["receiver@example.com"],
#                 "alerts_from": ["sender@example.com"],
#                 "alert_description": ["Test alert description"],
#             }
#         )
#         spark_obj.sql.return_value = mock_df

#         # Configuration dictionary
#         conf = {
#             "smtp_host": "smtp.example.com",
#             "smtp_port": 587,
#             "smtp_username": "user@example.com",
#             "smtp_password": "password",
#             "email_template_dir": "/path/to/templates",
#             "email_template_file_name": "template.html",
#             "alert_database_name": "db",
#             "alert_table_name": "alerts_table",
#             "alert_complete_table_name": "alerts_table",
#             "team_email": "team@example.com",
#             "email_columns": [
#                 "alert_UUID",
#                 "alerts_to",
#                 "alerts_from",
#                 "alert_description",
#             ],
#         }

#         # Parameters
#         env = "test_env"

#         # Create an instance of the class containing the method
#         alert_instance = AlertUtils()

#         # Call the method
#         alert_instance.send_email_alert_deprecated(logger, spark_obj, conf, env)

#         # Assertions
#         logger.info.assert_any_call("*" * 20 + " START: send_email_alert" + "*" * 20)
#         logger.info.assert_any_call("*" * 20 + " END: send_email_alert" + "*" * 20)
#         mock_smtp.assert_called_with("smtp.example.com", 587)
#         mock_smtp().sendmail.assert_called()
#         mock_file.assert_called_with("/path/to/templates/template.html", "r")

#     @patch.object(AlertUtils, "execute_spark_sql")
#     def test_update_alerts_table(self, mock_execute_spark_sql):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark object
#         spark_obj = MagicMock()

#         # Configuration dictionary
#         conf = {"alert_database_name": "test_db", "alert_table_name": "alerts_table"}

#         # Mock UUID list
#         alert_instance = AlertUtils()
#         alert_instance.uuid_list = ["uuid1", "uuid2"]

#         # Call the method
#         alert_instance.update_alerts_table(logger, spark_obj, conf, status="PROCESSED")

#         # Assertions
#         logger.info.assert_any_call("*" * 20 + " START: update_alerts_table" + "*" * 20)
#         logger.info.assert_any_call("*" * 20 + " END: update_alerts_table" + "*" * 20)
#         mock_execute_spark_sql.assert_called_once_with(
#             spark_obj,
#             "UPDATE test_db.alerts_table SET alert_status='PROCESSED' WHERE alert_UUID in ('uuid1', 'uuid2')",
#         )
#         logger.info.assert_any_call("Alert table updated successfully.")

#     @patch.object(AlertUtils, "write_dataframe_to_delta")
#     def test_load_alerts_table(self, mock_write_dataframe_to_delta):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark object
#         spark_obj = MagicMock()

#         # Configuration dictionary
#         conf = {
#             "alert_database_name": "test_db",
#             "alert_table_name": "alerts_table",
#             "alert_type": "type1",
#             "alert_severity": "high",
#             "object_name": "object1",
#             "alert_summary": "summary1",
#             "alert_description": "description1",
#             "alert_from": "from1",
#             "alert_to": "to1",
#             "alert_cc": "cc1",
#             "job_name": "job1",
#             "alert_table_columns": [
#                 "alert_UUID",
#                 "alert_type",
#                 "alert_severity",
#                 "object_name",
#                 "alert_summary",
#                 "alert_description",
#                 "alert_status",
#                 "alerts_from",
#                 "alerts_to",
#                 "alerts_cc",
#                 "job_run_id",
#                 "job_name",
#                 "insert_timestamp",
#             ],
#             "tech_solution_id": "tech1",
#             "cloudred_gid": "cloud1",
#         }

#         # Mock UUID list
#         alert_instance = AlertUtils()

#         # Call the method
#         alert_instance.load_alerts_table(
#             logger, spark_obj, "run1", conf, status="UNPROCESSED"
#         )

#         # Assertions
#         logger.info.assert_any_call("*" * 20 + " START: load_alerts_table" + "*" * 20)
#         logger.info.assert_any_call("*" * 20 + " END: load_alerts_table" + "*" * 20)
#         logger.info.assert_any_call(
#             "Created the alert dictionary, ready to load it to audit table."
#         )
#         logger.info.assert_any_call("Alert table loaded successfully.")
#         mock_write_dataframe_to_delta.assert_called_once()

#     @patch("smtplib.SMTP")
#     def test_send_email_deprecated(self, mock_smtp):
#         # Mock logger
#         logger = MagicMock()
#         spark = SparkSession.builder.getOrCreate()
#         df = spark.createDataFrame(
#             [("value1", "value2"), ("value3", "value4")], ["column1", "column2"]
#         )

#         # Mock DataFrame
#         # df = MagicMock()
#         # df.toPandas.return_value = pd.DataFrame({
#         #     'column1': ['value1', 'value2'],
#         #     'column2': ['value3', 'value4']
#         # })

#         # Configuration dictionary
#         conf = {
#             "alert_from": "sender@example.com",
#             "team_email": "team@example.com",
#             "username": "user",
#             "password": "pass",
#         }

#         # Environment and identifier
#         env = "test_env"
#         identifier = "test_identifier"

#         # Call the method
#         AlertUtils().send_email_deprecated(df, logger, conf, env, identifier)

#         # Assertions
#         mock_smtp.assert_called_once_with("smtp.office365.com", port=587)
#         mock_smtp_instance = mock_smtp.return_value
#         mock_smtp_instance.starttls.assert_called_once()
#         mock_smtp_instance.ehlo.assert_called_once()
#         mock_smtp_instance.login.assert_called_once_with(user="user", password="pass")
#         mock_smtp_instance.sendmail.assert_called_once()

#     @patch("smtplib.SMTP")
#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.SparkUtils.execute_spark_sql"
#     )
#     def test_send_info_site_alerts(self, mock_execute_spark_sql, mock_smtp):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark DataFrame
#         spark_df = MagicMock()
#         spark_df.toPandas.return_value = pd.DataFrame(
#             {
#                 "location_nm": ["loc1", "loc2"],
#                 "location_nbr": ["nbr1", "nbr2"],
#                 "lease_number_desc": ["desc1", "desc2"],
#                 "data_source_nm": ["source1", "source2"],
#                 "alert_desc": ["alert1", "alert2"],
#                 "resolution_desc": ["res1", "res2"],
#             }
#         )
#         mock_execute_spark_sql.return_value = spark_df

#         # Configuration dictionary
#         conf = {
#             "alert_from": "sender@example.com",
#             "team_email": "team@example.com",
#             "username": "user",
#             "password": "pass",
#             "alert_database_name": "alert_db",
#             "alert_table_nmae": "alert_table",
#             "smtp_host": "smtp.office365.com",
#             "smtp_port": 587,
#             "body": "Alert: {identifier}\n{html}\nTeam: {team_email}",
#         }

#         # Environment
#         env = "test_env"

#         # Call the method
#         AlertUtils().send_info_site_alerts(logger, MagicMock(), conf, env)

#         # Assertions
#         logger.info.assert_any_call(
#             "*" * 20 + " START: send_info_site_alerts" + "*" * 20
#         )
#         logger.info.assert_any_call("*" * 20 + " END: send_info_site_alerts" + "*" * 20)
#         mock_smtp.assert_called_once_with("smtp.office365.com", 587)
#         mock_smtp_instance = mock_smtp.return_value
#         mock_smtp_instance.starttls.assert_called_once()
#         mock_smtp_instance.ehlo.assert_called_once()
#         mock_smtp_instance.login.assert_called_once_with(user="user", password="pass")
#         mock_smtp_instance.sendmail.assert_called_once()

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.SparkUtils.run_snowflake_queries_as_spark_df"
#     )
#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.SparkUtils.execute_spark_sql"
#     )
#     def test_send_Info_Schema_Alerts(
#         self, mock_execute_spark_sql, mock_run_snowflake_queries_as_spark_df
#     ):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark DataFrame for Databricks
#         databricks_df = MagicMock()
#         databricks_df.toPandas.return_value = pd.DataFrame(
#             {
#                 "table_catalog": ["catalog1"],
#                 "table_schema": ["schema1"],
#                 "table_name": ["table1"],
#                 "table_owner": ["owner1"],
#                 "source": ["databricks"],
#             }
#         )
#         mock_execute_spark_sql.return_value = databricks_df

#         # Mock Spark DataFrame for Snowflake
#         snowflake_df = MagicMock()
#         snowflake_df.toPandas.return_value = pd.DataFrame(
#             {
#                 "table_catalog": ["catalog2"],
#                 "table_schema": ["schema2"],
#                 "table_name": ["table2"],
#                 "table_owner": ["owner2"],
#                 "source": ["snowflake"],
#             }
#         )
#         mock_run_snowflake_queries_as_spark_df.return_value = snowflake_df

#         # Configuration dictionary
#         conf = {
#             "databricks_catalog": "databricks_catalog",
#             "databricks_schema": "databricks_schema",
#             "sfdatabase": "sfdatabase",
#             "snowflake_schema": "'schema1', 'schema2'",
#             "team_email": "team@example.com",
#             "body": "Alert: {identifier}\n{html}\nTeam: {team_email}",
#         }

#         # Environment
#         env = "test_env"

#         # Call the method
#         AlertUtils().send_Info_Schema_Alerts(logger, MagicMock(), conf, env)

#         # Assertions
#         logger.info.assert_called()
#         logger.error.assert_called()
#         mock_execute_spark_sql.assert_called_once()
#         mock_run_snowflake_queries_as_spark_df.assert_called_once()

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.AlertUtils.send_mail"
#     )
#     @patch("datetime.datetime")
#     def test_alerts_wf_sla_check(self, mock_datetime, mock_send_mail):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark session
#         spark = MagicMock()
#         spark.sql.return_value.head.return_value = [
#             datetime.now().strftime("%Y%m%d%H%M%S")
#         ]

#         # Mock datetime
#         mock_datetime.now.return_value = datetime.now()

#         # Configuration dictionary
#         conf = {
#             "target_database_name": "target_db",
#             "project_name": "project_name",
#             "sla": 10,
#             "wf_name": "workflow_name",
#             "team_email": "team@example.com",
#             "body": "Alert: {wf_name}\nEnvironment: {env}\nMinutes: {diff_minutes}\nSLA: {sla}\nTeam: {team_email}",
#         }

#         # Environment
#         env = "test_env"

#         # Call the method
#         AlertUtils().alerts_wf_sla_check(logger, spark, conf, env)

#         # Assertions
#         logger.info.assert_any_call("*" * 20 + " START: alerts_wf_sla_check" + "*" * 20)
#         logger.info.assert_any_call("*" * 20 + " END: alerts_wf_sla_check" + "*" * 20)
#         logger.error.assert_not_called()
#         spark.sql.assert_called_once()
#         mock_send_mail.assert_not_called()

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.AlertUtils.send_mail"
#     )
#     @patch("datetime.datetime")
#     def test_alerts_wf_sla_check_sla_crossed(self, mock_datetime, mock_send_mail):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark session
#         spark = MagicMock()
#         # spark.head().return_value = ((datetime.now()).strftime("%Y%m%d%H%M%S"),)
#         # spark.sql.head.return_value = 'dateime' #((datetime.now() - relativedelta(minutes=20)).strftime("%Y%m%d%H%M%S"),)
#         spark.sql.return_value.head.return_value = [
#             datetime.now().strftime("%Y%m%d%H%M%S")
#         ]
#         # self.assertIsInstance(spark.sql.return_value.head.return_value, list)

#         # Mock datetime
#         mock_datetime.now.return_value = datetime.now()

#         # Configuration dictionary
#         conf = {
#             "target_database_name": "target_db",
#             "project_name": "project_name",
#             "sla": 10,
#             "wf_name": "workflow_name",
#             "team_email": "team@example.com",
#             "body": "Alert: {wf_name}\nEnvironment: {env}\nMinutes: {diff_minutes}\nSLA: {sla}\nTeam: {team_email}",
#         }

#         # Environment
#         env = "test_env"

#         # Call the method
#         AlertUtils().alerts_wf_sla_check(logger, spark, conf, env)

#         # Assertions
#         logger.info.assert_any_call("*" * 20 + " START: alerts_wf_sla_check" + "*" * 20)
#         # logger.info.assert_any_call("*" * 20 + " SLA Crossed " + "*" * 20)
#         logger.info.assert_any_call("*" * 20 + " END: alerts_wf_sla_check" + "*" * 20)
#         logger.error.assert_not_called()
#         spark.sql.assert_called_once()
#         #

#         conf["sla"] = -1
#         AlertUtils().alerts_wf_sla_check(logger, spark, conf, env)
#         mock_send_mail.assert_called_once()

#         conf.pop("sla")
#         with self.assertRaises(SystemExit) as error:
#             AlertUtils().alerts_wf_sla_check(logger, spark, conf, env)
#         logger.error.assert_called()

#     @patch("smtplib.SMTP")
#     @patch("datetime.datetime")
#     def test_send_mail(self, mock_datetime, mock_smtp):
#         # Mock logger
#         logger = MagicMock()

#         # Mock datetime
#         mock_datetime.now.return_value = datetime(2023, 1, 1, 12, 0, 0)

#         # Configuration dictionary
#         conf = {
#             "alert_from": "alert@example.com",
#             "team_email": "team@example.com",
#             "slack_channel_email": "slack@example.com",
#             "subject": "Test Subject",
#             "body": "Test Body",
#             "smtp_host": "smtp.example.com",
#             "smtp_port": 587,
#             "username": "user",
#             "password": "pass",
#         }

#         # Environment
#         env = "test_env"

#         # Call the method
#         AlertUtils().send_mail(logger, conf, env)

#         # Assertions
#         logger.info.assert_any_call("*" * 20 + " START: send_mail" + "*" * 20)
#         logger.info.assert_any_call("*" * 20 + " END: send_mail" + "*" * 20)
#         logger.error.assert_not_called()

#         mock_smtp.assert_called_once_with("smtp.example.com", 587)
#         smtp_instance = mock_smtp.return_value
#         smtp_instance.starttls.assert_called_once()
#         smtp_instance.ehlo.assert_called_once()
#         smtp_instance.login.assert_called_once_with(user="user", password="pass")
#         smtp_instance.sendmail.assert_called_once()
#         smtp_instance.quit.assert_called_once()

#         conf.pop("slack_channel_email")
#         AlertUtils().send_mail(logger, conf, env)

#         conf.pop("alert_from")
#         with self.assertRaises(SystemExit) as error:
#             AlertUtils().send_mail(logger, conf, env)
#         logger.error.assert_called()


# class TestAuditUtils(unittest.TestCase):
#     def setUp(self):
#         self.logger = Mock()
#         self.spark = SparkSession.builder.master("local").appName("test").getOrCreate()

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.AuditUtils.run_snowflake_queries_as_spark_df"
#     )
#     @patch("pyspark.sql.SparkSession.sql")
#     def test_get_partition_names_and_values_delta(
#         self, mock_spark_sql, mock_run_snowflake_queries
#     ):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark session
#         spark_obj = SparkSession.builder.getOrCreate()

#         part_df = spark_obj.createDataFrame(
#             [("202301", "01")], ["partition_col1", "partition_col2"]
#         )
#         spark_obj.sql.return_value = part_df

#         # Configuration dictionary
#         conf = {}

#         # Call the method
#         audit_utils = AuditUtils()
#         partition_names, partition_values = audit_utils.get_partition_names_and_values(
#             logger, spark_obj, conf, "database_name", "table_name", "delta"
#         )

#         # Assertions
#         self.assertEqual(partition_names, "partition_col1,partition_col2")
#         self.assertEqual(partition_values, "202301,01")
#         logger.info.assert_any_call(
#             "*" * 20 + " START: get_partition_names_and_values" + "*" * 20
#         )
#         logger.info.assert_any_call(
#             "*" * 20 + " END: get_partition_names_and_values" + "*" * 20
#         )
#         logger.error.assert_not_called()

#     @patch(
#         "products.common_utilities.spark.python.src.common_utilities.AuditUtils.run_snowflake_queries_as_spark_df"
#     )
#     @patch("pyspark.sql.SparkSession.sql")
#     def test_get_partition_names_and_values_snowflake(
#         self, mock_spark_sql, mock_run_snowflake_queries
#     ):
#         # Mock logger
#         logger = MagicMock()

#         # Mock Spark session
#         spark_obj = MagicMock()

#         # Mock the SQL query result for snowflake table
#         mock_run_snowflake_queries.side_effect = [
#             MagicMock(
#                 collect=MagicMock(
#                     return_value=[Row(PARTITION_BY_COLS="column1,column2")]
#                 )
#             ),
#             MagicMock(
#                 collect=MagicMock(
#                     return_value=[Row(MAX_LOAD_YEAR="2023", MAX_LOAD_MONTH="01")]
#                 )
#             ),
#         ]

#         # Configuration dictionary
#         conf = {}

#         # Call the method
#         audit_utils = AuditUtils()
#         partition_names, partition_values = audit_utils.get_partition_names_and_values(
#             logger, spark_obj, conf, "database_name", "table_name", "snowflake"
#         )

#         # Assertions
#         self.assertEqual(partition_names, "column1,column2")
#         self.assertEqual(partition_values, "2023,01")
#         logger.info.assert_any_call(
#             "*" * 20 + " START: get_partition_names_and_values" + "*" * 20
#         )
#         logger.info.assert_any_call(
#             "*" * 20 + " END: get_partition_names_and_values" + "*" * 20
#         )
#         logger.error.assert_not_called()

#     @patch.object(AuditUtils(), "run_snowflake_queries_as_spark_df")
#     def test_get_partition_names_and_values_exception(
#         self, mock_run_snowflake_queries_as_spark_df
#     ):
#         conf = {}
#         database_name = "test_db"
#         table_name = "test_table"
#         table_type = "delta"
#         mock_run_snowflake_queries_as_spark_df.side_effect = Exception(
#             "Simulated exception"
#         )

#         with self.assertRaises(SystemError):
#             AuditUtils().get_partition_names_and_values(
#                 self.logger, self.spark, conf, database_name, table_name, table_type
#             )

#         self.logger.error.assert_called()

#     def test_load_audit_table(self):
#         self.logger = MagicMock()
#         self.spark_obj = MagicMock()
#         self.run_id = "test_run_id"
#         self.conf = {
#             "audit_database_name": "test_db",
#             "audit_table_name": "test_table",
#             "batch_id": "test_batch_id",
#             "object_name": "test_object",
#             "source_record_count": "100",
#             "target_data_count_before_load": "50",
#             "target_data_count_after_load": "150",
#             "target_record_count": "200",
#             "job_name": "test_job",
#             "source_stage1_name": "test_source_stage1",
#             "target_table_name": "test_target_table",
#             "target_database_name": "test_target_db",
#             "source_database_name": "test_source_db",
#             "sfschema": "test_sfschema",
#             "sfdatabase": "test_sfdatabase",
#             "merge_schema": True,
#             "audit_table_columns": [
#                 "batch_id",
#                 "object_name",
#                 "source_stage",
#                 "source_l1_detail",
#                 "source_l2_detail",
#                 "source_record_count",
#                 "source_partition_column_name",
#                 "source_partition_column_values",
#                 "target_stage",
#                 "target_l1_detail",
#                 "target_l2_detail",
#                 "target_partition_column_name",
#                 "target_partition_column_values",
#                 "target_data_count_before_load",
#                 "target_data_count_after_load",
#                 "target_record_count",
#                 "incremental_data_count_after_load",
#                 "status_code",
#                 "job_run_id",
#                 "job_name",
#                 "insert_timestamp",
#             ],
#             "tech_solution_id": "test_tech_solution_id",
#             "cloudred_gid": "test_cloudred_gid",
#         }
#         self.status = "SUCCESS"
#         self.source_table_type = "delta"
#         self.target_table_type = "delta"
#         self.source_hop = "source_hop"
#         self.target_hop = "target_hop"
#         AuditUtils().load_audit_table(
#             self.logger,
#             self.spark_obj,
#             self.run_id,
#             self.conf,
#             self.status,
#             self.source_table_type,
#             self.target_table_type,
#             self.source_hop,
#             self.target_hop,
#         )

#         # Assertions to verify expected behavior
#         self.logger.info.assert_called()
#         self.spark_obj.createDataFrame.assert_called()

#         self.conf.pop("audit_database_name")
#         with self.assertRaises(SystemExit):
#             AuditUtils().load_audit_table(
#                 self.logger,
#                 self.spark_obj,
#                 self.run_id,
#                 self.conf,
#                 self.status,
#                 self.source_table_type,
#                 self.target_table_type,
#                 self.source_hop,
#                 self.target_hop,
#             )
#         self.logger.error.assert_called()

#     @patch("sys.exit")
#     def test_trigger_alerts_location_updates_ele(self, mock_exit):
#         self.loader = AuditUtils()  # Replace with actual class name
#         self.QueryUtils = MagicMock()
#         # self.spark_obj = SparkSession.builder.master("local").appName("test").getOrCreate()
#         self.spark_obj = MagicMock()
#         self.logger = MagicMock()
#         self.master_spark_df = self.spark_obj.createDataFrame(
#             [
#                 Row(
#                     location_nm="loc1",
#                     location_nbr="loc_nbr1",
#                     service_type_nm="service1",
#                     data_source_nm="source1",
#                     user_nm="user1",
#                     batch_load_tmst="2021-01-01",
#                     job_nm="job1",
#                     job_run_id="run1",
#                 ),
#                 Row(
#                     location_nm="loc2",
#                     location_nbr="loc_nbr2",
#                     service_type_nm="service2",
#                     data_source_nm="source2",
#                     user_nm="user2",
#                     batch_load_tmst="2021-01-02",
#                     job_nm="job2",
#                     job_run_id="run2",
#                 ),
#             ]
#         )
#         self.tgt_table_name = "target_table"
#         self.conf = {
#             "target_table_name": "electricity_table",
#             "data_source_nm": "source1",
#             "target_database_name": "test_db",
#             "tech_solution_id": "test_tech_solution_id",
#             "cloudred_gid": "test_cloudred_gid",
#         }
#         self.loader.trigger_alerts_location_updates(
#             self.QueryUtils,
#             self.spark_obj,
#             self.logger,
#             self.master_spark_df,
#             self.tgt_table_name,
#             self.conf,
#         )

#         # Assertions to verify expected behavior
#         self.logger.info.assert_called()

#     @patch("sys.exit")
#     def test_trigger_alerts_location_updates_fuel(self, mock_exit):
#         QueryUtils = MagicMock()
#         # spark_obj = SparkSession.builder.master("local").appName("test").getOrCreate()
#         spark_obj = MagicMock()
#         logger = MagicMock()
#         master_spark_df = spark_obj.createDataFrame(
#             [
#                 Row(
#                     location_nm="loc1",
#                     location_nbr="loc_nbr1",
#                     service_type_nm="service1",
#                     data_source_nm="source1",
#                     user_nm="user1",
#                     batch_load_tmst="2021-01-01",
#                     job_nm="job1",
#                     job_run_id="run1",
#                 ),
#                 Row(
#                     location_nm="loc2",
#                     location_nbr="loc_nbr2",
#                     service_type_nm="service2",
#                     data_source_nm="source2",
#                     user_nm="user2",
#                     batch_load_tmst="2021-01-02",
#                     job_nm="job2",
#                     job_run_id="run2",
#                 ),
#             ]
#         )
#         tgt_table_name = "target_table"
#         conf = {
#             "target_table_name": "fuel_table",
#             "data_source_nm": "source1",
#             "target_database_name": "test_db",
#             "tech_solution_id": "test_tech_solution_id",
#             "cloudred_gid": "test_cloudred_gid",
#         }
#         AuditUtils().trigger_alerts_location_updates(
#             QueryUtils(), spark_obj, logger, master_spark_df, tgt_table_name, conf
#         )

#         # Assertions to verify expected behavior
#         logger.info.assert_called()
