import pytest, sys
from unittest.mock import MagicMock, patch, mock_open
from pydantic import SecretStr
from products.common_utilities.spark.python.src.util_email_and_slack_alerts import (
    run_sla_alerts,
    run_email_and_slack_alerts,
    run_info_schema_alerts,
    send_site_alerts,
)
from pyspark.sql import DataFrame

# sys.path.insert(0, '/Users/aku213/EcoRangers-5')


# run_sla_alerts function test cases
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_run_sla_alerts_success(
    mock_json_load,
    mock_open,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "test_scope",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function
    run_sla_alerts(
        "config_path",
        "config_name",
        "env",
        mock_bf_context,
        "project_name",
        "wf_name",
        "path/to/",
        "config.json",
        "batch_id_end",
    )

    # Assertions
    mock_logger.info.assert_any_call(f"{'*' * 20} START: sla_alerts() {'*' * 20}")
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.alerts_wf_sla_check.assert_called_once()
    mock_open.assert_called_once_with("path/to/config.json", "r")
    mock_logger.error.assert_not_called()


@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_run_sla_alerts_failure(
    mock_json_load,
    mock_open,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "myenergy_sftp_v2",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "logger": "mock_logger",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        None,
        None,
    )

    # Call the function and expect ValueError
    with pytest.raises(SystemError) as exc_info:
        run_sla_alerts(
            "config_path",
            "config_name",
            "env",
            mock_bf_context,
            "project_name",
            "wf_name",
            "path/to/",
            "config.json",
            "batch_id_end",
        )

    # Assertions
    assert str(exc_info.value) == "Username or Password is None"
    mock_logger.info.assert_any_call(f"{'*' * 20} START: sla_alerts() {'*' * 20}")
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.alerts_wf_sla_check.assert_not_called()
    mock_logger.error.assert_called_with(
        "Error In - run_sla_alerts() : Username or Password is None"
    )


# run_email_and_slack_alerts function test cases
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_run_email_and_slack_alerts_success(
    mock_json_load,
    mock_open,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "test_scope",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function
    run_email_and_slack_alerts(
        "config_path",
        "config_name",
        "env",
        "path/to/",
        "config.json",
        "root_dir",
        mock_bf_context,
    )

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_email_and_slack_alerts()" + "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.send_alert_notification.assert_called_once()
    mock_logger.error.assert_not_called()


@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_run_email_and_slack_alerts_failure(
    mock_json_load,
    mock_open,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "myenergy_sftp_v2",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "logger": "mock_logger",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        None,
        None,
    )

    # Call the function and expect ValueError
    with pytest.raises(SystemError) as exc_info:
        run_email_and_slack_alerts(
            "config_path",
            "config_name",
            "env",
            "path/to/",
            "config.json",
            "root_dir",
            mock_bf_context,
        )

    # Assertions
    assert str(exc_info.value) == "Username or Password is None"
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_email_and_slack_alerts()" + "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.send_alert_notification.assert_not_called()
    mock_logger.error.assert_called_with(
        "Error In - run_email_and_slack_alerts() : Username or Password is None"
    )


# run_info_schema_alerts function test cases
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_run_info_schema_alerts_success(
    mock_json_load,
    mock_open1,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "test_scope",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function
    run_info_schema_alerts(
        "config_path",
        "config_name",
        "env",
        "path/to/",
        "config1.json",
        "root_dir",
        mock_bf_context,
    )

    # Assertions
    mock_logger.info.assert_any_call(
        f"{'*' * 20} START: run_info_schema_alerts() {'*' * 20}"
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.send_Info_Schema_Alerts.assert_called_once()
    # mock_open1.assert_called_once_with('path/to/config1.json', 'r')
    mock_logger.error.assert_not_called()


@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_run_info_schema_alerts_failure(
    mock_json_load,
    mock_open,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "myenergy_sftp_v2",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "logger": "mock_logger",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        None,
        None,
    )

    # Call the function and expect ValueError
    with pytest.raises(SystemError) as exc_info:
        run_info_schema_alerts(
            "config_path",
            "config_name",
            "env",
            "path/to/",
            "config.json",
            "root_dir",
            mock_bf_context,
        )

    # Assertions
    assert str(exc_info.value) == "Username or Password is None"
    mock_logger.info.assert_any_call(
        f"{'*' * 20} START: run_info_schema_alerts() {'*' * 20}"
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.send_Info_Schema_Alerts.assert_not_called()
    mock_logger.error.assert_called_with(
        "Error In - run_info_schema_alerts() : Username or Password is None"
    )

    # run_info_schema_alerts function test cases


@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_send_site_alerts_success(
    mock_json_load,
    mock_open1,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "test_scope",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function
    send_site_alerts(
        "config_path",
        "config_name",
        "env",
        "path/to/",
        "config1.json",
        "root_dir",
        mock_bf_context,
    )

    # Assertions
    mock_logger.info.assert_any_call(
        "%s START: send_site_alerts() %s", "*" * 20, "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.send_info_site_alerts.assert_called_once()
    mock_logger.error.assert_not_called()


@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_email_and_slack_alerts.AlertUtils"
)
@patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
@patch("json.load")
def test_send_site_alerts_failure(
    mock_json_load,
    mock_open,
    mock_alert_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "dbx_scope": "myenergy_sftp_v2",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "logger": "mock_logger",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        None,
        None,
    )

    # Call the function and expect ValueError
    with pytest.raises(SystemError) as exc_info:
        send_site_alerts(
            "config_path",
            "config_name",
            "env",
            "path/to/",
            "config.json",
            "root_dir",
            mock_bf_context,
        )

    # Assertions
    assert str(exc_info.value) == "Username or Password is None"
    mock_logger.info.assert_any_call(
        "%s START: send_site_alerts() %s", "*" * 20, "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.assert_called_once()
    mock_alert_utils.return_value.send_Info_Schema_Alerts.assert_not_called()
    error_message = "Username or Password is None"
    assert any(
        error_message in str(call) for call in mock_logger.error.call_args_list
    ), "Expected error message not found in mock_logger.error calls"
