import unittest
from unittest.mock import patch, MagicMock
from products.common_utilities.spark.python.src.tigo_api_source_to_landing import (
    run_api_source_to_landing,
)
from products.common_utilities.spark.python.src.common_utilities import *
import inspect, json
from pyspark.sql import DataFrame
from pyspark.sql.functions import *


class TestRunApiSourceToLanding(unittest.TestCase):
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.AuditUtils.load_audit_table"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.AlertUtils.generate_alerts_dictionary"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.QueryUtils.write_dataframe_to_delta"
    )
    @patch("products.common_utilities.spark.python.src.tigo_api_source_to_landing.col")
    @patch(
        "products.common_utilities.spark.python.src.tigo_api_source_to_landing.run_api_source_to_landing"
    )
    @patch("json.loads")
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.JSONUtils.json_dict_to_spark_df"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.APIUtils.fetch_api_without_id"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.APIUtils.api_call_basic_auth"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.APIUtils.get_token_from_api"
    )
    @patch("inspect.currentframe")
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.SparkUtils.get_spark_session"
    )
    @patch(
        "products.common_utilities.spark.python.src.common_utilities.ConfigUtils.read_config_variables"
    )
    @patch("products.common_utilities.spark.python.src.common_utilities.LoggerUtils")
    def test_run_api_source_to_landing_success(
        self,
        mock_logger_utils,
        mock_config,
        mock_spark,
        mock_currentframe,
        mock_api_token,
        mock_api_call_auth,
        mock_fetch_api_list,
        mock_json_dict,
        mock_json_loads,
        mock_run_api_source_to_landing,
        mock_col,
        mock_query_utils,
        mock_alert_utils,
        mock_audit_utils,
    ):
        mock_run_api_source_to_landing.logger = LoggerUtils().get_logger_object()

        mock_frame = MagicMock()
        mock_frame.f_code.co_name = "mocked_function_name"
        mock_currentframe.return_value = mock_frame
        mock_spark.return_value = MagicMock()
        mock_config.return_value = {
            "product_name": "test_product",
            "tech_solution_id": "test_tech_solution_id",
            "nike-tagguid": "test-nike-tagguid",
            "source_hop_name": "source",
            "target_hop_name": "landing",
            "target_database_name": "test_db",
            "target_table_name": "test_table",
            "request_method": "GET",
            "bearer_auth": "Bearer token",
            "dbx_scope": "test_scope",
            "authentication_endpoint": "http://api.test.com/auth",
            "system_id_api_endpoint": "http://api.test.com/system_id",
            "api_endpoints": {
                "endpoint1": "http://api.test.com/{system_id}",
                "endpoint2": "http://api.test.com/{system_id}",
                "objects": "http://api.test.com/{system_id}",
            },
        }

        # mock_logger_obj = mock_logger.get_logger_object
        # mock_logger_obj.return_value = MagicMock()
        # mock_logger = MagicMock()
        # mock_logger_utils.return_value.get_logger_object.return_value = LoggerUtils().get_logger_object()

        # Mocking the current frame
        inspect.currentframe.f_code.co_name.return_value = (
            "test_run_api_source_to_landing_success"
        )

        # Mocking API token response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"user": {"auth": "test_token"}}
        mock_api_token.return_value = mock_response
        mock_api_call_auth.return_value = MagicMock()
        # mock_fetch_api_list.return_value = [{'payload' : '{"data1": "value1"}'}]

        # MOCK JSON return response
        # mock_json_dict.return_value = '{"data1": "value1"}'
        # mock_json_loads.return_value = {'objects': 'value1'}

        mock_run_api_source_to_landing.object_id_list_of_json = [
            {"value1": [{"id": 1, "name": "object1"}, {"id": 2, "name": "object2"}]}
        ]
        mock_df = MagicMock(DataFrame)
        mock_run_api_source_to_landing.final_data_dt.withColumn.return_value = mock_df

        # Mocking the col function
        mock_col.return_value.cast.return_value = "mocked_column"

        # Mocking QueryUtils write
        mock_query_utils.return_value = MagicMock(DataFrame)

        # Mock Generate AlertUtils
        mock_alert_utils.return_value = None

        # Mocking AuditUtils load
        mock_audit_utils.return_value = None

        run_api_source_to_landing(
            "config_path", "config_name", "env", MagicMock(), "root_dir"
        )
        mock_query_utils.assert_called_once()
        self.assertEqual(mock_query_utils.call_count, 1)
