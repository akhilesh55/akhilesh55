import unittest, pytest
from unittest.mock import patch, MagicMock

# from products.common_utilities.spark.python.src import run_ingest_curated_to_integrated
from products.common_utilities.spark.python.src.util_ingest_curated_to_integrated import (
    run_ingest_curated_to_integrated,
)
from pyspark.sql import DataFrame


@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.SparkUtils"
)
@patch("products.common_utilities.spark.python.src.util_api_source_to_landing.APIUtils")
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.JSONUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.QueryUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.AuditUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.AlertUtils"
)
@patch("json.load")
def test_ingest_curated_to_integrated_success(
    mock_json_load,
    mock_alert_utils,
    mock_audit_utils,
    mock_query_utils,
    mock_json_utils,
    mock_api_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "target_table_name": "test_target_table",
        "request_method": "GET",
        "bearer_auth": "Bearer",
        "api_endpoints": {
            "objects": "https://api.example.com/objects",
            "properties": "https://api.example.com/properties",
        },
        "aggregate_api_endpoint": "https://api.example.com/aggregate?system_id={system_id}&start_date={start_date}&end_date={end_date}&object_ids={object_ids}",
        "id": "25324366246",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "target_database_name": "target_database_name",
        "invoice_api_endpoint": "invoice_api_endpoint",
        "property_api_endpoint": "property_api_endpoint",
        "root_node": "root_node",
        "children_node": "children_node",
        "dbx_scope": "dbx_scope",
        "source_hop_name": "source_hop_name",
        "target_hop_name": "target_hop_name",
        "audit_database_name": "audit_db",
        "function_name": "test_function",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function
    with pytest.raises(KeyError):
        run_ingest_curated_to_integrated(
            "config_path",
            "config_name",
            "sql_path",
            "sql_name",
            "dev",
            mock_bf_context,
            "root_dir",
        )

    # Assertions
    # mock_logger.info.assert_any_call(
    #     "*" * 20 + " START: run_api_source_to_landing()" + "*" * 20
    # )
    # mock_spark_utils.return_value.get_spark_session.assert_called_once()


@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.SparkUtils"
)
def test_run_api_source_to_landing_failure(
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "target_database_name": "test_target_db",
        "target_table_name": "test_target_table",
        "request_method": "GET",
        "bearer_auth": "Bearer",
        "api_endpoints": {
            "objects": "https://api.example.com/objects",
            "properties": "https://api.example.com/properties",
        },
        "aggregate_api_endpoint": (
            "https://api.example.com/aggregate?system_id={system_id}"
            "&start_date={start_date}&end_date={end_date}&object_ids={object_ids}"
        ),
        "invoice_api_endpoint": "https://api.example.com/invoice",
        "dbx_scope": "test_scope",
        "id": "test_id",
        "source_hop_name": "test_source_hop_name",
        "target_hop_name": "test_target_hop_name",
        "function_name": "test_function",
        "audit_database_name": "test_audit_db",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": (
            "This data product template contains common files for SDF-ITC and SEAM-ITC"
        ),
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function and expect KeyError
    with pytest.raises(KeyError):
        run_ingest_curated_to_integrated(
            "config_path",
            "config_name",
            "sql_path",
            "sql_name",
            "dev",
            mock_bf_context,
            "root_dir",
        )

    # Debugging: Print all calls to mock_logger.info
    print(mock_logger.info.call_args_list)

    # Assertions
    # mock_logger.info.assert_any_call(
    #    "*" * 20 + " START: run_ingest_curated_to_integrated()" + "*" * 20
    # )
    # mock_spark_utils.return_value.get_spark_session.assert_called_once()
    # mock_audit_utils.return_value.load_audit_table.assert_called_once()
    # mock_alert_utils.return_value.load_alerts_table.assert_called_once()
    # mock_logger.error.assert_called_with(
    #     "Error In - run_api_source_to_landing() : Username or Password is None"
    # )


import unittest, pytest
from unittest.mock import patch, MagicMock

# from products.common_utilities.spark.python.src import run_ingest_curated_to_integrated
from products.common_utilities.spark.python.src.util_ingest_curated_to_integrated import (
    run_ingest_curated_to_integrated,
)


@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.SparkUtils"
)
@patch("products.common_utilities.spark.python.src.util_api_source_to_landing.APIUtils")
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.JSONUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.QueryUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.AuditUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.AlertUtils"
)
@patch("json.load")
def test_ingest_curated_to_integrated_success(
    mock_json_load,
    mock_alert_utils,
    mock_audit_utils,
    mock_query_utils,
    mock_json_utils,
    mock_api_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "target_table_name": "test_target_table",
        "request_method": "GET",
        "bearer_auth": "Bearer",
        "api_endpoints": {
            "objects": "https://api.example.com/objects",
            "properties": "https://api.example.com/properties",
        },
        "aggregate_api_endpoint": "https://api.example.com/aggregate?system_id={system_id}&start_date={start_date}&end_date={end_date}&object_ids={object_ids}",
        "id": "25324366246",
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "target_database_name": "target_database_name",
        "invoice_api_endpoint": "invoice_api_endpoint",
        "property_api_endpoint": "property_api_endpoint",
        "root_node": "root_node",
        "children_node": "children_node",
        "dbx_scope": "dbx_scope",
        "source_hop_name": "source_hop_name",
        "target_hop_name": "target_hop_name",
        "audit_database_name": "audit_db",
        "function_name": "test_function",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function
    with pytest.raises(KeyError):
        run_ingest_curated_to_integrated(
            "config_path",
            "config_name",
            "sql_path",
            "sql_name",
            "dev",
            mock_bf_context,
            "root_dir",
        )

    # Assertions
    # mock_logger.info.assert_any_call(
    #     "*" * 20 + " START: run_api_source_to_landing()" + "*" * 20
    # )
    # mock_spark_utils.return_value.get_spark_session.assert_called_once()


@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_api_source_to_landing.SparkUtils"
)
def test_run_api_source_to_landing_failure(
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "target_database_name": "test_target_db",
        "target_table_name": "test_target_table",
        "request_method": "GET",
        "bearer_auth": "Bearer",
        "api_endpoints": {
            "objects": "https://api.example.com/objects",
            "properties": "https://api.example.com/properties",
        },
        "aggregate_api_endpoint": (
            "https://api.example.com/aggregate?system_id={system_id}"
            "&start_date={start_date}&end_date={end_date}&object_ids={object_ids}"
        ),
        "invoice_api_endpoint": "https://api.example.com/invoice",
        "dbx_scope": "test_scope",
        "id": "test_id",
        "source_hop_name": "test_source_hop_name",
        "target_hop_name": "test_target_hop_name",
        "function_name": "test_function",
        "audit_database_name": "test_audit_db",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": (
            "This data product template contains common files for SDF-ITC and SEAM-ITC"
        ),
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]
    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    # Call the function and expect KeyError
    with pytest.raises(KeyError):
        run_ingest_curated_to_integrated(
            "config_path",
            "config_name",
            "sql_path",
            "sql_name",
            "dev",
            mock_bf_context,
            "root_dir",
        )

    # Debugging: Print all calls to mock_logger.info
    print(mock_logger.info.call_args_list)

    # Assertions
    # mock_logger.info.assert_any_call(
    #    "*" * 20 + " START: run_ingest_curated_to_integrated()" + "*" * 20
    # )
    # mock_spark_utils.return_value.get_spark_session.assert_called_once()
    # mock_audit_utils.return_value.load_audit_table.assert_called_once()
    # mock_alert_utils.return_value.load_alerts_table.assert_called_once()
    # mock_logger.error.assert_called_with(
    #     "Error In - run_api_source_to_landing() : Username or Password is None"
    # )
