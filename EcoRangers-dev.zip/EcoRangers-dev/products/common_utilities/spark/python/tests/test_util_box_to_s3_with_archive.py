import pytest, sys
from unittest.mock import MagicMock, patch
from datetime import datetime
from boxsdk import JWTAuth, Client
from products.common_utilities.spark.python.src.util_box_to_s3_with_archive import (
    run_box_to_s3,
)
from pyspark.sql import DataFrame

# sys.path.insert(0, '/Users/aku213/EcoRangers-5')


@patch(
    "products.common_utilities.spark.python.src.util_box_to_s3_with_archive.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_box_to_s3_with_archive.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_box_to_s3_with_archive.BoxToS3Utils"
)
@patch("products.common_utilities.spark.python.src.util_box_to_s3_with_archive.JWTAuth")
@patch("products.common_utilities.spark.python.src.util_box_to_s3_with_archive.Client")
def test_run_box_to_s3_success(
    mock_client,
    mock_jwt_auth,
    mock_box_to_s3_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_box_to_s3_utils.return_value.get_secrets_from_databricks.return_value = (
        "mock_client_id",
        "mock_client_secret",
        "mock_enterprise_id",
        "mock_jwt_key_id",
        "mock_rsa_private_key_data",
        "mock_rsa_private_key_passphrase",
    )

    mock_conf = {
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "dbx_scope": "ecorangers-enterprise-box",
        "src_box_id": ["237107982158"],
        "archive_flag": "True",
        "archive_box_id": ["237108028075"],
    }
    mock_product_conf = {
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    # Call the function
    run_box_to_s3("config_path", "config_name", "env", MagicMock(), "root_dir")

    # Assertions
    mock_logger.info.assert_any_call("*" * 20 + " START: run_box_to_s3()" + "*" * 20)
    # mock_config_utils.return_value.read_config_variables.assert_called_once()
    # mock_jwt_auth.assert_called_once()
    mock_jwt_auth.assert_called_once_with(
        client_id="mock_client_id",
        client_secret="mock_client_secret",
        enterprise_id="mock_enterprise_id",
        jwt_key_id="mock_jwt_key_id",
        rsa_private_key_data="mock_rsa_private_key_data",
        rsa_private_key_passphrase="mock_rsa_private_key_passphrase",
    )
    mock_client.assert_called_once()
    mock_box_to_s3_utils.return_value.parse_files.assert_called()
    # assert mock_conf['archive_box_id'] == ["237108028075"]


@patch(
    "products.common_utilities.spark.python.src.util_box_to_s3_with_archive.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_box_to_s3_with_archive.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_box_to_s3_with_archive.BoxToS3Utils"
)
@patch("products.common_utilities.spark.python.src.util_box_to_s3_with_archive.JWTAuth")
@patch("products.common_utilities.spark.python.src.util_box_to_s3_with_archive.Client")
def test_run_box_to_s3_failure(
    mock_client,
    mock_jwt_auth,
    mock_box_to_s3_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_box_to_s3_utils.return_value.get_secrets_from_databricks.return_value = (
        "mock_client_id",
        "mock_client_secret",
        "mock_enterprise_id",
        "mock_jwt_key_id",
        "mock_rsa_private_key_data",
        "mock_rsa_private_key_passphrase",
    )

    mock_conf = {
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "dbx_scope": "ecorangers-enterprise-box",
        "src_box_id": ["237107982158"],
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    # Call the function and expect SystemError
    with pytest.raises(SystemError):
        run_box_to_s3("config_path", "config_name", "env", MagicMock(), "root_dir")

    # Assertions
    mock_logger.info.assert_any_call("*" * 20 + " START: run_box_to_s3()" + "*" * 20)
    mock_jwt_auth.assert_called_once_with(
        client_id="mock_client_id",
        client_secret="mock_client_secret",
        enterprise_id="mock_enterprise_id",
        jwt_key_id="mock_jwt_key_id",
        rsa_private_key_data="mock_rsa_private_key_data",
        rsa_private_key_passphrase="mock_rsa_private_key_passphrase",
    )
    mock_client.assert_called_once()
    mock_box_to_s3_utils.return_value.parse_files.assert_not_called()
    mock_logger.error.assert_called_with("Error In - run_box_to_s3() : 'archive_flag'")
    mock_logger.info.assert_any_call("*" * 20 + " END: run_box_to_s3()" + "*" * 20)
