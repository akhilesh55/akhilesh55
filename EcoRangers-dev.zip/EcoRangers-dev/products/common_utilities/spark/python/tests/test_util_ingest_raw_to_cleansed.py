from unittest.mock import MagicMock, patch
import pytest
from datetime import datetime
from products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed import (
    run_ingest_raw_to_cleansed,
)
from pyspark.sql import DataFrame


# sys.path.insert(0, '/Users/aku213/EcoRangers-5')
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.QueryUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.AlertUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.AuditUtils"
)
def test_run_ingest_raw_to_cleansed_success(
    mock_audit_utils,
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark
    datetime_obj = datetime.strptime("20231130000000", "%Y%m%d%H%M%S")
    mock_spark.sql.return_value.head.return_value.__getitem__.return_value = (
        datetime_obj.strftime("%Y%m%d%H%M%S")
    )

    mock_conf = {
        "job_name": "test_job",
        "source_database_name": "test_source_db",
        "source_table_name": "test_source_table",
        "target_database_name": "test_target_db",
        "target_table_name": "test_target_table",
        "predicates": ["col1 = 1"],
        "custom_starting_timestamp": "20231130000000",
        "reject_table_name": "test_reject_table",
        "source_hop_name": "test_source_hop",
        "target_hop_name": "test_target_hop",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    # Call the function
    run_ingest_raw_to_cleansed(
        "config_path",
        "config_name",
        "sql_file_path",
        "sql_file_name",
        "dev",
        mock_bf_context,
        "root_dir",
    )

    # Assertions
    mock_logger.info.assert_any_call(
        "%s START: run_api_landing_to_raw() %s", "*" * 20, "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    # mock_audit_utils.return_value.load_audit_table.assert_called_once()
    mock_spark.sql.assert_called_with(
        "SELECT COUNT(*) FROM test_target_db.test_target_table"
    )
    mock_logger.error.assert_not_called()


@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.QueryUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.AlertUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_ingest_raw_to_cleansed.AuditUtils"
)
def test_run_ingest_raw_to_cleansed_failure(
    mock_audit_utils,
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark
    datetime_obj = datetime.strptime("20231130000000", "%Y%m%d%H%M%S")
    mock_spark.sql.return_value.head.return_value.__getitem__.return_value = (
        datetime_obj.strftime("%Y%m%d%H%M%S")
    )

    mock_conf = {
        "job_name": "test_job",
        "source_database_name": "test_source_db",
        "source_table_name": "test_source_table",
        "target_database_name": "test_target_db",
        "target_table_name": "test_target_table",
        "predicates": ["col1 = 1"],
        "custom_starting_timestamp": "20231130000000",
        "reject_table_name": "test_reject_table",
        "source_hop_name": "test_source_hop",
        "tech_solution_id": "some_tech_solution_id",  # Added missing key
        # Intentionally missing 'target_hop_name' to trigger the error
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    # Call the function and expect SystemError due to missing 'target_hop_name'
    with pytest.raises(SystemError):
        run_ingest_raw_to_cleansed(
            "config_path",
            "config_name",
            "sql_file_path",
            "sql_file_name",
            "dev",
            mock_bf_context,
            "root_dir",
        )

    # Assertions
    mock_logger.info.assert_any_call(
        "%s START: run_api_landing_to_raw() %s", "*" * 20, "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_audit_utils.return_value.load_audit_table.assert_called_once()
    mock_alert_utils.return_value.load_alerts_table.assert_called_once()
    # mock_logger.error.assert_any_call(
    #     "Error In - run_api_raw_ro_cleansed() : 'target_hop_name'"
    # )
    # mock_logger.error.assert_any_call(
    #     "Error In - run_api_raw_ro_cleansed() : No incremental data fetched from "
    #     "earlier hop, raising exception to abort further execution of the script."
    # )
