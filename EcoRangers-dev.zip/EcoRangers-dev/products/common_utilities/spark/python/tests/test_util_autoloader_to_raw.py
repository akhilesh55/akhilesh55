import sys
import os
import pytest

# sys.path.insert(0, 'C:\\Users\\AKu231\\SEAM\\UMD-Sole_Integration\\EcoRangers')
from unittest.mock import MagicMock, patch
from products.common_utilities.spark.python.src.common_utilities import (
    SparkUtils,
    LoggerUtils,
    ConfigUtils,
    QueryUtils,
    JSONUtils,
    APIUtils,
    AuditUtils,
    AlertUtils,
)
from products.common_utilities.spark.python.src.util_autoloader_to_raw import (
    run_autoloader_to_raw,
)
from pyspark.sql import DataFrame


@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.LoggerUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.ConfigUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.SparkUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.QueryUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.AlertUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.AuditUtils")
def test_run_autoloader_to_raw_success(
    mock_audit_utils,
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "object_name": "test_object",
        "target_database_name": "test_db",
        "target_table_name": "test_table",
        "input_file_format": "csv",
        "source_mandatory_cols": ["col1", "col2"],
        "data_completeness_tbl": "test_data_completeness_tbl",
        "common_cols": ["col1", "col2"],
        "table_cols": ["col3", "col4"],
        "target_hop_name": "test_hop",
        "source_hop_name": "source_hop",
        "file_name_col": "file_name_test",
        "data_product": "test_product",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-SEAM-ITC",
        "org_name": "da",
        "data_owners": [
            "prasad.nadiger@nike.com",
            "kaushik.periwal@nike.com",
        ],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-SEAM-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    # Call the function
    run_autoloader_to_raw(
        "config_path", "config_name", "dev", mock_bf_context, "root_dir"
    )

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_autoloader_to_raw()" + "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_spark_utils.return_value.read_streaming_dataframe_from_external_volume.assert_called_once()
    mock_spark_utils.return_value.rename_columns_for_raw.assert_called_once()
    mock_spark_utils.return_value.add_operational_attributes.assert_called_once()
    mock_spark_utils.return_value.write_streaming_dataframe_to_delta.assert_called_once()
    mock_audit_utils.return_value.load_audit_table.assert_called_once()
    mock_logger.info.assert_any_call(
        "*" * 20 + " END: run_autoloader_to_raw()" + "*" * 20
    )


@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.LoggerUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.ConfigUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.SparkUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.QueryUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.AlertUtils")
@patch("products.common_utilities.spark.python.src.util_autoloader_to_raw.AuditUtils")
def test_run_autoloader_to_raw_failure(
    mock_audit_utils,
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "object_name": "test_object",
        "target_database_name": "test_db",
        #'target_table_name': 'test_table',
        "input_file_format": "txt",
        "source_mandatory_cols": ["col1", "col2"],
        "data_completeness_tbl": "test_data_completeness_tbl",
        "common_cols": ["col1", "col2"],
        "table_cols": ["col3", "col4"],
        "target_hop_name": "test_hop",
        "source_hop_name": "source_hop",
        "file_name_col": "file_name_test",
        "data_product": "test_product",
        "src_volume_path": "",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-SEAM-ITC",
        "org_name": "da",
        "data_owners": [
            "prasad.nadiger@nike.com",
            "kaushik.periwal@nike.com",
        ],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-SEAM-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    # Call the function and expect SystemExit due to unsupported file format
    with pytest.raises(SystemError):
        run_autoloader_to_raw(
            "config_path", "config_name", "dev", mock_bf_context, "root_dir"
        )

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_autoloader_to_raw()" + "*" * 20
    )
    # mock_logger.error.assert_any_call("Error In - run_autoloader_to_raw() --> File format not supported")
    mock_alert_utils.return_value.load_alerts_table.assert_called_once()
    mock_audit_utils.return_value.load_audit_table.assert_called_once()
    mock_logger.info.assert_any_call(
        "*" * 20 + " END: run_autoloader_to_raw()" + "*" * 20
    )
