def test_version():
    assert 1 == 1
