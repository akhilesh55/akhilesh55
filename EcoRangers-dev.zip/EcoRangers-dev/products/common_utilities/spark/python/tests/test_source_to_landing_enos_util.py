import pytest, sys
from unittest.mock import MagicMock, patch
from datetime import datetime
from products.common_utilities.spark.python.src.source_to_landing_enos_util import (
    run_api_source_to_landing,
)
from pyspark.sql import DataFrame


# sys.path.insert(0, '/Users/aku213/EcoRangers-5')
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.QueryUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.AlertUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.AuditUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.APIUtils"
)
def test_run_api_source_to_landing_success(
    mock_api_utils,
    mock_audit_utils,
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "target_database_name": "test_db",
        "target_table_name": "test_table",
        "batch_id": "123456789",
        "function_name": "run_api_source_to_landing",
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
        "source_hop_name": "source_hop",
        "target_hop_name": "test_hop",
        "authentication_endpoint": "https://example.com/auth",
        "solar_api_endpoint": "https://example.com/api/{start_date}/{end_date}",
        "dbx_scope": "test_scope",
        "target_record_count": 0,
        "token_username": "test_username",
        "token_password": "test_password",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "test_username",
        "test_password",
    )
    # mock_api_utils.return_value.get_token_from_api.return_value = 'mock_token'

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    mock_response_object = MagicMock()
    mock_response_object.status_code = 200
    mock_api_utils.return_value.get_token_from_api.return_value = mock_response_object

    # Call the function
    with pytest.raises(SystemError):
        run_api_source_to_landing(
            "config_path", "config_name", "dev", mock_bf_context, "root_dir"
        )
    # run_api_source_to_landing('config_path', 'config_name', 'dev', mock_bf_context, 'root_dir')

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_api_source_to_landing()" + "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.read_config_variables.assert_called_with(
        config_path="root_dir",
        config_name="product-info.toml",
        env="dev",
        logger=mock_logger,
    )
    # mock_api_utils.return_value.get_token_from_api.assert_called_with(
    #     logger=mock_logger,
    #     token_username='test_username',
    #     token_password='test_password',
    #     conf=mock_conf
    # )


@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.QueryUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.AlertUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.AuditUtils"
)
@patch(
    "products.common_utilities.spark.python.src.source_to_landing_enos_util.APIUtils"
)
def test_run_api_source_to_landing_failure(
    mock_api_utils,
    mock_audit_utils,
    mock_alert_utils,
    mock_query_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_conf = {
        "job_name": "test_job",
        "target_database_name": "test_db",
        "target_table_name": "test_table",
        "batch_id": "123456789",
        "function_name": "run_api_source_to_landing",
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "cloudred_gid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
        "source_hop_name": "source_hop",
        "target_hop_name": "test_hop",
        "authentication_endpoint": "https://example.com/auth",
        "solar_api_endpoint": "https:wrong-example.com/api/{start_date}/{end_date}",
        "dbx_scope": "test_scope",
        "target_record_count": 0,
        "token_username": "test_username",
        "token_password": "test_password",
    }
    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }
    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "test_username",
        "test_password",
    )

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    mock_response_object = MagicMock()
    mock_response_object.status_code = 200
    mock_api_utils.return_value.get_token_from_api.return_value = mock_response_object

    # Call the function and expect SystemError
    with pytest.raises(SystemError) as error:
        run_api_source_to_landing(
            "config_path", "config_name", "dev", mock_bf_context, "root_dir"
        )
    # assert str(error.value) == "Expecting value: line 1 column 1 (char 0)"

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_api_source_to_landing()" + "*" * 20
    )
    mock_spark_utils.return_value.get_spark_session.assert_called_once()
    mock_config_utils.return_value.read_config_variables.assert_called_with(
        config_path="root_dir",
        config_name="product-info.toml",
        env="dev",
        logger=mock_logger,
    )
    mock_audit_utils.return_value.load_audit_table.assert_called_once()
    mock_alert_utils.return_value.load_alerts_table.assert_called_once()
