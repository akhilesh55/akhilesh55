from unittest.mock import MagicMock, patch

# from pyspark.sql import SparkSession, DataFrame
# from pyspark.sql.functions import col
# from datetime import datetime
import pytest
from products.common_utilities.spark.python.src.util_airtable_source_to_landing import (
    run_source_to_landing_airtable,
)
from pyspark.sql import DataFrame


# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.LoggerUtils"
# )
# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.ConfigUtils"
# )
# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.SparkUtils"
# )
# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.APIUtils"
# )
# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.QueryUtils"
# )
# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.JSONUtils"
# )
# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.AuditUtils"
# )
# @patch(
#     "products.common_utilities.spark.python.src.util_airtable_source_to_landing.AlertUtils"
# )
# def test_run_source_to_landing_airtable_success(
#     mock_alert_utils,
#     mock_audit_utils,
#     mock_json_utils,
#     mock_query_utils,
#     mock_api_utils,
#     mock_spark_utils,
#     mock_config_utils,
#     mock_logger_utils,
# ):
#     # Mocking dependencies
#     mock_logger = MagicMock()
#     mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

#     mock_conf = {
#         "config_path": "config_path",
#         "config_name": "config_name",
#         "env": "env",
#         "bf_context": MagicMock(),
#         "root_dir": "root_dir",
#         "job_name": "job_name",
#         "target_database_name": "target_database_name",
#         "target_table_name": "target_table_name",
#         "base_id": "base_id",
#         "api_endpoint": "api_endpoint",
#         "table_dict": {
#             "table_name": {
#                 "table_id": "table_id",
#                 "url_condition": "url_condition",
#                 "url_sql_statement": "url_sql_statement",
#             }
#         },
#         "request_method": "GET",
#         "bearer_auth": "True",
#         "scope": "scope",
#         "airtable_secret": "airtable_secret",
#         "source_hop_name": "source_hop_name",
#         "target_hop_name": "target_hop_name",
#         "tech_solution_id": "tech_solution_id",
#         "cloudred_gid": "cloudred_gid",
#         "dbx_scope": "dbx_scope",
#     }

#     mock_product_conf = {
#         "product_name": "test_product",
#         "team_name": "SDF-ITC",
#         "org_name": "da",
#         "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
#         "product_type": "data-product",
#         "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
#         "product_owners": ["sonali.patnaik@nike.com"],
#         "programming_languages": ["python"],
#         "tags": ["Global", "SDF-ITC"],
#         "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
#         "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
#     }

#     mock_config_utils.return_value.read_config_variables.side_effect = [
#         mock_conf,
#         mock_product_conf,
#     ]

#     mock_spark = MagicMock()
#     mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

#     mock_bf_context = MagicMock()
#     mock_bf_context.get_parameter.return_value = "987987987987987"

#     mock_config_utils.get_username_password_from_dbx_secrets(
#         mock_logger_utils, mock_bf_context, mock_conf["dbx_scope"]
#     )
#     mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
#         "mock_username",
#         "mock_password",
#     )

#     # mock_spark.sql.return_value.head.return_value = [0]
#     mock_df = MagicMock(spec=DataFrame)
#     mock_spark.sql.return_value = mock_df
#     mock_df.head.return_value = [0]

#     # Mock DataFrame methods
#     mock_df.select.return_value = mock_df
#     mock_df.withColumn.return_value = mock_df

#     mock_api_utils.return_value.fetch_api_without_id.return_value = (
#         [{"id": 1}],
#         "offset",
#     )

#     run_source_to_landing_airtable(
#         "config_path", "config_name", "env", mock_bf_context, "root_dir"
#     )

#     # Call the function
#     # with pytest.raises(SystemError):
#     #     run_source_to_landing_airtable('config_path', 'config_name', 'env', mock_bf_context, 'root_dir')

#     # Assertions
#     mock_logger.info.assert_called()
#     mock_spark.sql.assert_called()


@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.LoggerUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.ConfigUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.SparkUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.APIUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.QueryUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.JSONUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.AuditUtils"
)
@patch(
    "products.common_utilities.spark.python.src.util_airtable_source_to_landing.AlertUtils"
)
def test_run_source_to_landing_airtable_failure(
    mock_alert_utils,
    mock_audit_utils,
    mock_json_utils,
    mock_query_utils,
    mock_api_utils,
    mock_spark_utils,
    mock_config_utils,
    mock_logger_utils,
):
    # Mocking dependencies
    mock_logger = MagicMock()
    mock_logger_utils.return_value.get_logger_object.return_value = mock_logger

    mock_conf = {
        "config_path": "config_path",
        "config_name": "config_name",
        "env": "env",
        "bf_context": MagicMock(),
        "root_dir": "root_dir",
        "job_name": "job_name",
        "target_database_name": "target_database_name",
        "target_table_name": "target_table_name",
        "base_id": "base_id",
        "api_endpoint": "api_endpoint",
        "table_dict": {
            "table_name": {
                "table_id": "table_id",
                "url_condition": "url_condition",
                "url_sql_statement": "url_sql_statement",
            }
        },
        "request_method": "request_method",
        "bearer_auth": "bearer_auth",
        "scope": "scope",
        "airtable_secret": "airtable_secret",
        "source_hop_name": "source_hop_name",
        "target_hop_name": "target_hop_name",
        "tech_solution_id": "tech_solution_id",
        "cloudred_gid": "cloudred_gid",
        "dbx_scope": "dbx_scope",
    }

    mock_product_conf = {
        "product_name": "test_product",
        "team_name": "SDF-ITC",
        "org_name": "da",
        "data_owners": ["prasad.nadiger@nike.com", "kaushik.periwal@nike.com"],
        "product_type": "data-product",
        "product_documentation": "This data product template contains common files for SDF-ITC and SEAM-ITC",
        "product_owners": ["sonali.patnaik@nike.com"],
        "programming_languages": ["python"],
        "tags": ["Global", "SDF-ITC"],
        "tech_solution_id": "ab904b7ea2ed99911942bac6b5e46031fc48e746",
        "nike-tagguid": "a68d9d07-43b1-4c4c-bdc3-64b7f2ba5a5e",
    }

    mock_config_utils.return_value.read_config_variables.side_effect = [
        mock_conf,
        mock_product_conf,
    ]

    mock_spark = MagicMock()
    mock_spark_utils.return_value.get_spark_session.return_value = mock_spark

    mock_bf_context = MagicMock()
    mock_bf_context.get_parameter.return_value = "987987987987987"

    mock_config_utils.get_username_password_from_dbx_secrets(
        mock_logger_utils, mock_bf_context, mock_conf["dbx_scope"]
    )
    mock_config_utils.return_value.get_username_password_from_dbx_secrets.return_value = (
        "mock_username",
        "mock_password",
    )

    mock_spark.sql.return_value.head.return_value = [0]

    mock_api_utils.return_value.fetch_api_without_id.return_value = Exception(
        "Simulated exception"
    )  # ([{'id': 1}], 'offset')

    # Call the function and expect SystemError
    with pytest.raises(SystemError):
        run_source_to_landing_airtable(
            "config_path", "config_name", "env", mock_bf_context, "root_dir"
        )

    # Assertions
    mock_logger.info.assert_any_call(
        "*" * 20 + " START: run_source_to_landing_airtable()" + "*" * 20
    )
    mock_logger.info.assert_any_call(
        "*" * 20 + " END: run_source_to_landing_airtable() " + "*" * 20
    )
    mock_spark.sql.assert_called_with("url_sql_statement")
    mock_query_utils.return_value.write_dataframe_to_delta.assert_not_called()
    mock_audit_utils.return_value.load_audit_table.assert_called()
    mock_logger.error.assert_called()  # ('Error In - run_source_to_landing_airtable() : ')
    mock_alert_utils.return_value.generate_alerts_dictionary.assert_called()
    mock_alert_utils.return_value.load_alerts_table.assert_called()
