# Create External Volumes for Sole Workspace from Waffleiron S3 Bucket (Read + Write Access)

- Create an S3 bucket in your waffleiron account.
- Create an IAM Role in Waffleiron account that provides read and write access to bucket. Example: [S3Policy](https://github.com/nike-data-engineering/EcoRangers/blob/72187411ad7a602f7982bd96ee66cc5cbf5b287b/products/common_utilities/aws/s3/s3_write_access.json)
- Raise a request to Databricks Sole Support team to create `External Location` for your databricks workspace using this IAM role created in previous step. <br>
  Example request: [JIRA Link (Outdated)](https://jira.nike.com/browse/EPAE-12018) <br>
- Once the `External Location` is created by Platform team, you can manually run the following command to create the external volume: `CREATE EXTERNAL VOLUME <Volume_name> USING LOCATION <external_location_name>`

## Points to be noted while raising this intake request

1. Note down the Canonical ID under bucket management settings.
2. Note down the IAM ARN once created.
3. We need to provide the IAM ARN, Canonical ID, AWS Region, Sole workspace region, Team name in the intake request for creating the external location to platform team.
