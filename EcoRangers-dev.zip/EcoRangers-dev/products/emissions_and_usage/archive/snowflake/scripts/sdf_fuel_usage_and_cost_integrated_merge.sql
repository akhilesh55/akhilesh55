MERGE INTO {target_complete_name} AS FD_DEST_T USING(
    WITH BUILDING_COMBINE AS(
        WITH BUILDING_COMBINE_PART AS (
            SELECT
                B_COMBINE_PART.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
                B_COMBINE_PART.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
                B_COMBINE_PART.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
                B_COMBINE_PART.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
                B_COMBINE_PART.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
                B_COMBINE_PART.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
                B_COMBINE_PART.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
                B_COMBINE_PART.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
                B_COMBINE_PART.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
                B_COMBINE_PART.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
                B_COMBINE_PART."Building Type" AS "Building Type",
                B_COMBINE_PART."Location Type" AS "Location Type",
                B_COMBINE_PART."Nike Key City" AS "Nike Key City",
                B_COMBINE_PART.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
                B_COMBINE_PART."Business Group" AS "Business Group",
                B_COMBINE_PART."Campus - Corporate Park" AS "Campus - Corporate Park",
                B_COMBINE_PART.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
                B_COMBINE_PART.CITY_CODE_MAIN AS CITY_CODE_MAIN,
                B_COMBINE_PART.CONTINENT_CODE AS CONTINENT_CODE,
                B_COMBINE_PART.CONTINENT_NAME AS CONTINENT_NAME,
                B_COMBINE_PART.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
                B_COMBINE_PART.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
                B_COMBINE_PART.LOCATION_REGION AS LOCATION_REGION,
                B_COMBINE_PART.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
                B_COMBINE_PART."NIKE GEO" AS "NIKE GEO",
                B_COMBINE_PART."Primary Use" AS "Primary Use",
                B_COMBINE_PART.REPORT_DATE AS REPORT_DATE,
                B_COMBINE_PART.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
                B_COMBINE_PART.STATE_PROV_MAIN AS STATE_PROV_MAIN,
                B_COMBINE_PART.STATE_CODE_MAIN AS STATE_CODE_MAIN,
                B_COMBINE_PART.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
                B_COMBINE_PART."Tririga Brand" AS "Tririga Brand",
                B_COMBINE_PART.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
                B_COMBINE_PART.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
                B_COMBINE_PART.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
                B_COMBINE_PART.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
                B_COMBINE_PART.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
                B_COMBINE_PART."Tririga Contract Status" AS "Tririga Contract Status",
                B_COMBINE_PART.TRIRIGA_GEO AS TRIRIGA_GEO,
                B_COMBINE_PART.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
                B_COMBINE_PART.LATITUDE_MAIN AS LATITUDE_MAIN,
                B_COMBINE_PART.LONGITUDE_MAIN AS LONGITUDE_MAIN,
                B_COMBINE_PART."Tririga GIS LAT" AS "Tririga GIS LAT",
                B_COMBINE_PART."Tririga GIS LON" AS "Tririga GIS LON",
                CASE
                    WHEN LENGTH(B_COMBINE_PART."Tririga POS Store ID") < 2 THEN CONCAT('00', B_COMBINE_PART."Tririga POS Store ID")
                    WHEN LENGTH(B_COMBINE_PART."Tririga POS Store ID") < 3 THEN CONCAT('0', B_COMBINE_PART."Tririga POS Store ID")
                    ELSE B_COMBINE_PART."Tririga POS Store ID"
                END AS "Tririga POS Store ID",
                B_COMBINE_PART.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
                CASE
                    WHEN length(B_COMBINE_PART.TRIRIGA_ZIP_POSTAL_CODE) > 7 THEN REGEXP_SUBSTR(
                        TRIM(B_COMBINE_PART.TRIRIGA_ZIP_POSTAL_CODE),
                        '([0-9]+)',
                        1
                    )
                    ELSE TRIRIGA_ZIP_POSTAL_CODE
                END AS TRIRIGA_ZIP_POSTAL_CODE,
                B_COMBINE_PART.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
                B_COMBINE_PART.WDC_REGION_MAIN AS WDC_REGION_MAIN,
                B_COMBINE_PART."Zip Code Main" AS "Zip Code Main",
                B_COMBINE_PART.ARCHIBUS_USF AS ARCHIBUS_USF,
                B_COMBINE_PART.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
                B_COMBINE_PART.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
                B_COMBINE_PART."Max. Bldg. Capacity" AS "Max. Bldg. Capacity",
                B_COMBINE_PART."Number of Floors" AS "Number of Floors",
                ROW_NUMBER() OVER(
                    PARTITION BY B_COMBINE_PART.BUILDING_CODE_MAIN,
                    B_COMBINE_PART.TRIRIGA_ZIP_POSTAL_CODE
                    ORDER BY
                        B_COMBINE_PART.report_date DESC
                ) AS COMBINE_PART
            FROM
                {building_table_name} B_COMBINE_PART
            WHERE
                B_COMBINE_PART.CONTINENT_NAME = 'North America'
                AND B_COMBINE_PART.DISPLAY_LATEST_MAIN='LATEST'
        )
        SELECT
            B_COMBINE.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
            B_COMBINE.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
            B_COMBINE.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
            B_COMBINE.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
            B_COMBINE.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
            B_COMBINE.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
            B_COMBINE.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
            B_COMBINE.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
            B_COMBINE.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
            B_COMBINE.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
            B_COMBINE."Building Type" AS "Building Type",
            B_COMBINE."Location Type" AS "Location Type",
            B_COMBINE."Nike Key City" AS "Nike Key City",
            B_COMBINE.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
            B_COMBINE."Business Group" AS "Business Group",
            B_COMBINE."Campus - Corporate Park" AS "Campus - Corporate Park",
            B_COMBINE.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
            B_COMBINE.CITY_CODE_MAIN AS CITY_CODE_MAIN,
            B_COMBINE.CONTINENT_CODE AS CONTINENT_CODE,
            B_COMBINE.CONTINENT_NAME AS CONTINENT_NAME,
            B_COMBINE.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
            B_COMBINE.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
            B_COMBINE.LOCATION_REGION AS LOCATION_REGION,
            B_COMBINE.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
            B_COMBINE."NIKE GEO" AS "NIKE GEO",
            B_COMBINE."Primary Use" AS "Primary Use",
            B_COMBINE.REPORT_DATE AS REPORT_DATE,
            B_COMBINE.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
            B_COMBINE.STATE_PROV_MAIN AS STATE_PROV_MAIN,
            B_COMBINE.STATE_CODE_MAIN AS STATE_CODE_MAIN,
            B_COMBINE.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
            B_COMBINE."Tririga Brand" AS "Tririga Brand",
            B_COMBINE.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
            B_COMBINE.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
            B_COMBINE.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
            B_COMBINE.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
            B_COMBINE.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
            B_COMBINE."Tririga Contract Status" AS "Tririga Contract Status",
            B_COMBINE.TRIRIGA_GEO AS TRIRIGA_GEO,
            B_COMBINE.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
            B_COMBINE.LATITUDE_MAIN AS LATITUDE_MAIN,
            B_COMBINE.LONGITUDE_MAIN AS LONGITUDE_MAIN,
            B_COMBINE."Tririga GIS LAT" AS "Tririga GIS LAT",
            B_COMBINE."Tririga GIS LON" AS "Tririga GIS LON",
            B_COMBINE."Tririga POS Store ID" AS "Tririga POS Store ID",
            B_COMBINE.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
            B_COMBINE.TRIRIGA_ZIP_POSTAL_CODE AS TRIRIGA_ZIP_POSTAL_CODE,
            B_COMBINE.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
            B_COMBINE.WDC_REGION_MAIN AS WDC_REGION_MAIN,
            B_COMBINE."Zip Code Main" AS "Zip Code Main",
            B_COMBINE.ARCHIBUS_USF AS ARCHIBUS_USF,
            B_COMBINE.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
            B_COMBINE.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
            B_COMBINE."Max. Bldg. Capacity" AS "Max. Bldg. Capacity",
            B_COMBINE."Number of Floors" AS "Number of Floors"
        FROM
            BUILDING_COMBINE_PART B_COMBINE
        WHERE
            B_COMBINE.COMBINE_PART = 1
    ),
    EMISSION_AND_USAGE AS(
        SELECT
            U_METRICS_PART.location_nm AS location_nm,
            U_METRICS_PART.location_nbr AS location_nbr,
            U_METRICS_PART.location_address_1_nm AS location_address_1_nm,
            U_METRICS_PART.location_address_2_nm AS location_address_2_nm,
            U_METRICS_PART.location_city_nm AS location_city_nm,
            U_METRICS_PART.location_state_or_province_nm AS location_state_or_province_nm,
            U_METRICS_PART.location_postal_cd AS location_postal_cd,
            U_METRICS_PART.location_country_nm AS location_country_nm,
            U_METRICS_PART.location_status_desc AS location_status_desc,
            U_METRICS_PART.location_size_sqft AS location_size_sqft,
            U_METRICS_PART.misc_information_desc AS misc_information_desc,
            U_METRICS_PART.vendor_nm AS vendor_nm,
            U_METRICS_PART.vendor_address_1_nm AS vendor_address_1_nm,
            U_METRICS_PART.vendor_address_2_nm AS vendor_address_2_nm,
            U_METRICS_PART.vendor_city_nm AS vendor_city_nm,
            U_METRICS_PART.vendor_state_or_province_nm AS vendor_state_or_province_nm,
            U_METRICS_PART.vendor_postal_cd AS vendor_postal_cd,
            U_METRICS_PART.vendor_country_nm AS vendor_country_nm,
            U_METRICS_PART.account_nbr AS account_nbr,
            U_METRICS_PART.summary_account_nbr AS summary_account_nbr,
            U_METRICS_PART.account_address_1_nm AS account_address_1_nm,
            U_METRICS_PART.account_address_2_nm AS account_address_2_nm,
            U_METRICS_PART.account_city_nm AS account_city_nm,
            U_METRICS_PART.account_state_or_province_nm AS account_state_or_province_nm,
            U_METRICS_PART.account_postal_cd AS account_postal_cd,
            U_METRICS_PART.account_country_nm AS account_country_nm,
            U_METRICS_PART.clean_account_number_desc AS clean_account_number_desc,
            U_METRICS_PART.supplier_only_account_ind AS supplier_only_account_ind,
            U_METRICS_PART.audit_only_ind AS audit_only_ind,
            U_METRICS_PART.customer_gl_nbr AS customer_gl_nbr,
            U_METRICS_PART.gl_desc AS gl_desc,
            U_METRICS_PART.gl_allocation_pct AS gl_allocation_pct,
            U_METRICS_PART.meter_number_desc AS meter_number_desc,
            U_METRICS_PART.service_point_location_nm AS service_point_location_nm,
            U_METRICS_PART.rate_schedule_desc AS rate_schedule_desc,
            U_METRICS_PART.month_dt AS month_dt,
            U_METRICS_PART.begin_dt AS begin_dt,
            U_METRICS_PART.end_dt AS end_dt,
            U_METRICS_PART.service_days AS service_days,
            U_METRICS_PART.cost AS cost,
            U_METRICS_PART.service_type_nm AS service_type_nm,
            U_METRICS_PART.uom AS uom,
            U_METRICS_PART.usage_qty AS usage_qty,
            U_METRICS_PART.billed_qty AS billed_qty,
            U_METRICS_PART.cost_per_unit_uom AS cost_per_unit_uom,
            U_METRICS_PART.cost_per_day AS cost_per_day,
            U_METRICS_PART.cost_per_sqft AS cost_per_sqft,
            U_METRICS_PART.usage_per_day AS usage_per_day,
            U_METRICS_PART.usage_per_sqft AS usage_per_sqft,
            U_METRICS_PART.kbtus_qty AS kbtus_qty,
            U_METRICS_PART.kbtus_per_sqft AS kbtus_per_sqft,
            U_METRICS_PART.max_demand_qty AS max_demand_qty,
            U_METRICS_PART.load_factor_qty AS load_factor_qty,
            U_METRICS_PART.power_factor_qty AS power_factor_qty,
            U_METRICS_PART.cost_per_billed_qty AS cost_per_billed_qty,
            U_METRICS_PART.bill_estimated_ind AS bill_estimated_ind,
            U_METRICS_PART.open_exceptions_ind AS open_exceptions_ind,
            U_METRICS_PART.bill_image_desc AS bill_image_desc,
            U_METRICS_PART.department_nm AS department_nm,
            U_METRICS_PART.lease_number_desc AS lease_number_desc,
            U_METRICS_PART.audit_status_dt AS audit_status_dt,
            U_METRICS_PART.contract_expiration_dt AS contract_expiration_dt,
            U_METRICS_PART.contract_nm AS contract_nm,
            U_METRICS_PART.contract_status_desc AS contract_status_desc,
            U_METRICS_PART.floor_nbr AS floor_nbr,
            U_METRICS_PART.alternate_nm AS alternate_nm,
            U_METRICS_PART.baseline_note_desc AS baseline_note_desc,
            U_METRICS_PART.better_buildings_challenge_ind AS better_buildings_challenge_ind,
            U_METRICS_PART.district_inline_desc AS district_inline_desc,
            U_METRICS_PART.district_outlet_desc AS district_outlet_desc,
            U_METRICS_PART.footprint_sqft AS footprint_sqft,
            U_METRICS_PART.in_line_outlet_desc AS in_line_outlet_desc,
            U_METRICS_PART.ems_desc AS ems_desc,
            U_METRICS_PART.ems_install_dt AS ems_install_dt,
            U_METRICS_PART.global_sustainability_energy_plus_carbon_target_group_desc AS global_sustainability_energy_plus_carbon_target_group_desc,
            U_METRICS_PART.location_opened_dt AS location_opened_dt,
            U_METRICS_PART.site_cd_siterra_desc AS site_cd_siterra_desc,
            U_METRICS_PART.total_bldg_sqft AS total_bldg_sqft,
            U_METRICS_PART.wd_and_c_geo AS wd_and_c_geo,
            U_METRICS_PART.whq_campus_nm AS whq_campus_nm,
            U_METRICS_PART.leed_desc AS leed_desc,
            U_METRICS_PART.location_crc_nbr AS location_crc_nbr,
            U_METRICS_PART.new_building_nm AS new_building_nm,
            U_METRICS_PART.ownership_desc AS ownership_desc,
            U_METRICS_PART.principle_building_activity_desc AS principle_building_activity_desc,
            U_METRICS_PART.seated_occupancy_qty AS seated_occupancy_qty,
            U_METRICS_PART.sub_concept_desc AS sub_concept_desc,
            U_METRICS_PART.brand_nm AS brand_nm
        FROM
            {curated_table_name} U_METRICS_PART
        WHERE
            (
                U_METRICS_PART.DEPARTMENT_NM IN(
                    'Retail Factory',
                    'Retail Inline',
                    'Retail Other',
                    'WHQ',
                    'Other Offices and Building Construction'
                )
                OR U_METRICS_PART.DEPARTMENT_NM ILIKE '%Air MI%'
                OR U_METRICS_PART.DEPARTMENT_NM IS NULL
            )
            AND U_METRICS_PART.SERVICE_TYPE_NM IN('Natural Gas', 'Fuel Oil')
            AND U_METRICS_PART.LOCATION_NM NOT ILIKE '%!0%'
    ),
    DETAIL_INTEGRATION AS(
        WITH RETAIL_PARTITION AS(
            SELECT
                COALESCE(
                    CAST(EAU.LOCATION_NBR AS STRING),
                    BCM."Tririga POS Store ID"
                ) AS fuel_location_nbr,
                EAU.LOCATION_NM AS fuel_location_nm,
                EAU.MONTH_DT AS reporting_period_dt,
                EAU.SERVICE_TYPE_NM AS SERVICE_TYPE_CD,
                EAU.BEGIN_DT AS BILLING_MONTH_START_DT,
                EAU.END_DT AS BILLING_MONTH_END_DT,
                DENSE_RANK() OVER(
                    PARTITION BY EAU.location_nbr,
                    EAU.location_nm,
                    EAU.service_type_nm,
                    EAU.month_dt,
                    EAU.begin_dt,
                    EAU.END_DT
                    ORDER BY
                        BCM."Tririga POS Store ID" ASC
                ) AS RETAIL_PART,
                cd.FISCAL_YEAR_NM AS REPORTING_FISCAL_YEAR_NBR,
                cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
                cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
                cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
                cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
                cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
                COALESCE(
                    EAU.SITE_CD_SITERRA_DESC,
                    BCM.TRIRIGA_BUILDING_ID
                ) AS building_id,
                EAU.SERVICE_TYPE_NM AS fuel_type_txt,
                NULL AS saf_pct,
                NULL AS saf_density_uom,
                12 AS DATA_FREQUENCY_CD,
                EAU.USAGE_QTY AS SERVICE_USAGE_QTY,
                EAU.UOM AS SERVICE_USAGE_QTY_UOM,
                EAU.COST AS SERVICE_COST,
                'USD' AS SERVICE_COST_UOM,
                'NO' AS extrapolation_ind
            FROM
                EMISSION_AND_USAGE EAU
                LEFT JOIN BUILDING_COMBINE BCM ON CONCAT_WS(
                    '-',
                    SUBSTRING(
                        REGEXP_REPLACE(EAU.LOCATION_NBR, '[^\\w]'),
                        -3,
                        3
                    ),
                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                ) = CONCAT_WS(
                    '-',
                    LPAD(
                        SUBSTRING(
                            COALESCE(
                                REGEXP_REPLACE(BCM."Tririga POS Store ID", '[^\\w]'),
                                REGEXP_REPLACE(BCM.BUILDING_CODE_MAIN, '[^\\w]')
                            ),
                            -3,
                            3
                        ),
                        3,
                        '0'
                    ),
                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]')
                )
                OR TRIM(EAU.LEASE_NUMBER_DESC) = TRIM(BCM.TRIRIGA_BUILDING_ID)
                LEFT JOIN {calendar_table_name} cd ON TO_VARCHAR(EAU.MONTH_DT, 'MM/dd/yyyy') = TO_VARCHAR(cd.calendar_dt, 'MM/dd/yyyy')
            WHERE
                EAU.DEPARTMENT_NM IN(
                    'Retail Factory',
                    'Retail Inline',
                    'Retail Other',
                    'Other Offices and Building Construction'
                )
        )
        SELECT
            RETAIL_U.fuel_location_nbr,
            RETAIL_U.fuel_location_nm,
            RETAIL_U.reporting_period_dt,
            RETAIL_U.SERVICE_TYPE_CD,
            RETAIL_U.BILLING_MONTH_START_DT,
            RETAIL_U.BILLING_MONTH_END_DT,
            RETAIL_U.REPORTING_FISCAL_YEAR_NBR,
            RETAIL_U.REPORTING_CALENDAR_YEAR_NBR,
            RETAIL_U.REPORTING_MONTH_LONG_NM,
            RETAIL_U.REPORTING_MONTH_OF_YEAR_NBR,
            RETAIL_U.REPORTING_QUARTER_NBR,
            RETAIL_U.REPORTING_WEEK_OF_YEAR_NBR,
            RETAIL_U.building_id,
            RETAIL_U.fuel_type_txt,
            RETAIL_U.saf_pct,
            RETAIL_U.saf_density_uom,
            RETAIL_U.DATA_FREQUENCY_CD,
            RETAIL_U.SERVICE_USAGE_QTY,
            RETAIL_U.SERVICE_USAGE_QTY_UOM,
            RETAIL_U.SERVICE_COST,
            RETAIL_U.SERVICE_COST_UOM,
            RETAIL_U.extrapolation_ind
        FROM
            RETAIL_PARTITION RETAIL_U
        WHERE
            RETAIL_PART = 1
        UNION ALL
        SELECT
            COALESCE(
                CAST(EAU.LOCATION_NBR AS STRING),
                BCM."Tririga POS Store ID",AIRMI.LOCATION_NUMBER
            ) AS fuel_location_nbr,
            EAU.LOCATION_NM AS fuel_location_nm,
            EAU.MONTH_DT AS reporting_period_dt,
            EAU.SERVICE_TYPE_NM AS SERVICE_TYPE_CD,
            EAU.BEGIN_DT AS BILLING_MONTH_START_DT,
            EAU.END_DT AS BILLING_MONTH_END_DT,
            cd.FISCAL_YEAR_NM AS REPORTING_FISCAL_YEAR_NBR,
            cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
            cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
            cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
            cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
            cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
            COALESCE(
                EAU.SITE_CD_SITERRA_DESC,
                BCM.TRIRIGA_BUILDING_ID
            ) AS building_id,
            EAU.SERVICE_TYPE_NM AS fuel_type_txt,
            NULL AS saf_pct,
            NULL AS saf_density_uom,
            12 AS DATA_FREQUENCY_CD,
            EAU.USAGE_QTY AS SERVICE_USAGE_QTY,
            EAU.UOM AS SERVICE_USAGE_QTY_UOM,
            EAU.COST AS SERVICE_COST,
            'USD' AS SERVICE_COST_UOM,
            'NO' AS extrapolation_ind
        FROM
            EMISSION_AND_USAGE EAU
            LEFT JOIN {air_mi_mapping_table_name} AIRMI ON EAU.LOCATION_NM = AIRMI.LOCATION_NAME
            LEFT JOIN {calendar_table_name} cd ON TO_VARCHAR(EAU.MONTH_DT, 'MM/dd/yyyy') = TO_VARCHAR(cd.calendar_dt, 'MM/dd/yyyy')
            LEFT JOIN BUILDING_COMBINE BCM ON AIRMI.BUILDING_ID = BCM.TRIRIGA_BUILDING_ID
        WHERE
            EAU.DEPARTMENT_NM ILIKE '%Air MI%' AND AIRMI.OPERATION_ACTION IN ('XOVERWRITE','XMERGE')
        UNION ALL
            (
                WITH WHQ_INTEGRATION AS (
                    WITH WHQ_TRANSFORM AS(
                        SELECT
                            CASE
                                WHEN CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(BCM.building_code_main, '[^\\w]'),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                ) THEN '01_joined by siterra and Building code main match'
                                WHEN REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                    '[^\\w]'
                                ) = REGEXP_REPLACE(LOWER(BCM.building_code_main), '[^\\w]') THEN '03_joined by location split and Building code main match'
                                WHEN CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]'),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                ) THEN '02_joined by siterra and tririga building_id match'
                                WHEN REGEXP_REPLACE(EAU.LEASE_NUMBER_DESC, '[^\\w]') = REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]') THEN '04_joined by lease number and tririga building_id match'
                                WHEN CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                        '[^\\w]'
                                    ),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                        '[^\\w]'
                                    ),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                ) THEN '05_joined by location split and building name main'
                                WHEN CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(LOWER(EAU.location_address_1_nm), '[^\\w]'),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        REGEXP_REPLACE(LOWER(BCM.BUILDING_ADDRESS_MAIN), '[^\\w]'),
                                        '.,'
                                    ),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                ) THEN '06_joined by Address from both tables'
                                WHEN CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(LOWER(EAU.LEASE_NUMBER_DESC), '[^\\w]'),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                        '[^\\w]'
                                    ),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                ) THEN '07_joined by lease number and building name main'
                                ELSE '08_no match'
                            END AS JOIN_CONDITION_CHECK,
                            COALESCE(
                                CAST(EAU.LOCATION_NBR AS STRING),
                                BCM."Tririga POS Store ID"
                            ) AS fuel_location_nbr,
                            EAU.LOCATION_NM AS fuel_location_nm,
                            EAU.MONTH_DT AS reporting_period_dt,
                            EAU.SERVICE_TYPE_NM AS SERVICE_TYPE_CD,
                            EAU.BEGIN_DT AS BILLING_MONTH_START_DT,
                            EAU.END_DT AS BILLING_MONTH_END_DT,
                            cd.FISCAL_YEAR_NM AS REPORTING_FISCAL_YEAR_NBR,
                            cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
                            cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
                            cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
                            cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
                            cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
                            COALESCE(
                                EAU.SITE_CD_SITERRA_DESC,
                                BCM.TRIRIGA_BUILDING_ID
                            ) AS building_id,
                            EAU.SERVICE_TYPE_NM AS fuel_type_txt,
                            NULL AS saf_pct,
                            NULL AS saf_density_uom,
                            12 AS DATA_FREQUENCY_CD,
                            EAU.USAGE_QTY AS SERVICE_USAGE_QTY,
                            EAU.UOM AS SERVICE_USAGE_QTY_UOM,
                            EAU.COST AS SERVICE_COST,
                            'USD' AS SERVICE_COST_UOM,
                            'NO' AS extrapolation_ind
                        FROM
                            EMISSION_AND_USAGE EAU
                            LEFT JOIN BUILDING_COMBINE BCM ON CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(BCM.building_code_main, '[^\\w]'),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            )
                            OR (
                                CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                        '[^\\w]'
                                    ),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                        '[^\\w]'
                                    ),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                )
                            )
                            OR (
                                REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                    '[^\\w]'
                                ) = REGEXP_REPLACE(LOWER(BCM.building_code_main), '[^\\w]')
                            )
                            OR (
                                CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]'),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                )
                            )
                            OR (
                                REGEXP_REPLACE(EAU.LEASE_NUMBER_DESC, '[^\\w]') = REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]')
                            )
                            OR (
                                CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(LOWER(EAU.location_address_1_nm), '[^\\w]'),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        REGEXP_REPLACE(LOWER(BCM.BUILDING_ADDRESS_MAIN), '[^\\w]'),
                                        '.,'
                                    ),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                )
                            )
                            OR (
                                CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(LOWER(EAU.LEASE_NUMBER_DESC), '[^\\w]'),
                                    REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                                ) = CONCAT_WS(
                                    '-',
                                    REGEXP_REPLACE(
                                        LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                        '[^\\w]'
                                    ),
                                    LPAD(
                                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                        5,
                                        '0'
                                    )
                                )
                            )
                            LEFT JOIN {calendar_table_name} cd ON TO_VARCHAR(EAU.MONTH_DT, 'MM/dd/yyyy') = TO_VARCHAR(cd.calendar_dt, 'MM/dd/yyyy')
                        WHERE
                            EAU.DEPARTMENT_NM = 'WHQ'
                    )
                    SELECT
                        DENSE_RANK() OVER(
                            PARTITION BY WHQ_TRANSFORM.fuel_location_nbr,
                            WHQ_TRANSFORM.fuel_location_nm,
                            WHQ_TRANSFORM.SERVICE_TYPE_CD,
                            WHQ_TRANSFORM.reporting_period_dt,
                            WHQ_TRANSFORM.BILLING_MONTH_START_DT,
                            WHQ_TRANSFORM.BILLING_MONTH_END_DT
                            ORDER BY
                                WHQ_TRANSFORM.JOIN_CONDITION_CHECK ASC
                        ) AS WHQ_PART,
                        WHQ_TRANSFORM.fuel_location_nbr,
                        WHQ_TRANSFORM.fuel_location_nm,
                        WHQ_TRANSFORM.reporting_period_dt,
                        WHQ_TRANSFORM.SERVICE_TYPE_CD,
                        WHQ_TRANSFORM.BILLING_MONTH_START_DT,
                        WHQ_TRANSFORM.BILLING_MONTH_END_DT,
                        WHQ_TRANSFORM.REPORTING_FISCAL_YEAR_NBR,
                        WHQ_TRANSFORM.REPORTING_CALENDAR_YEAR_NBR,
                        WHQ_TRANSFORM.REPORTING_MONTH_LONG_NM,
                        WHQ_TRANSFORM.REPORTING_MONTH_OF_YEAR_NBR,
                        WHQ_TRANSFORM.REPORTING_QUARTER_NBR,
                        WHQ_TRANSFORM.REPORTING_WEEK_OF_YEAR_NBR,
                        WHQ_TRANSFORM.building_id,
                        WHQ_TRANSFORM.fuel_type_txt,
                        WHQ_TRANSFORM.saf_pct,
                        WHQ_TRANSFORM.saf_density_uom,
                        WHQ_TRANSFORM.DATA_FREQUENCY_CD,
                        WHQ_TRANSFORM.SERVICE_USAGE_QTY,
                        WHQ_TRANSFORM.SERVICE_USAGE_QTY_UOM,
                        WHQ_TRANSFORM.SERVICE_COST,
                        WHQ_TRANSFORM.SERVICE_COST_UOM,
                        WHQ_TRANSFORM.extrapolation_ind
                    FROM
                        WHQ_TRANSFORM
                )
                SELECT
                    WHQ_INT.fuel_location_nbr,
                    WHQ_INT.fuel_location_nm,
                    WHQ_INT.reporting_period_dt,
                    WHQ_INT.SERVICE_TYPE_CD,
                    WHQ_INT.BILLING_MONTH_START_DT,
                    WHQ_INT.BILLING_MONTH_END_DT,
                    WHQ_INT.REPORTING_FISCAL_YEAR_NBR,
                    WHQ_INT.REPORTING_CALENDAR_YEAR_NBR,
                    WHQ_INT.REPORTING_MONTH_LONG_NM,
                    WHQ_INT.REPORTING_MONTH_OF_YEAR_NBR,
                    WHQ_INT.REPORTING_QUARTER_NBR,
                    WHQ_INT.REPORTING_WEEK_OF_YEAR_NBR,
                    WHQ_INT.building_id,
                    WHQ_INT.fuel_type_txt,
                    WHQ_INT.saf_pct,
                    WHQ_INT.saf_density_uom,
                    WHQ_INT.DATA_FREQUENCY_CD,
                    WHQ_INT.SERVICE_USAGE_QTY,
                    WHQ_INT.SERVICE_USAGE_QTY_UOM,
                    WHQ_INT.SERVICE_COST,
                    WHQ_INT.SERVICE_COST_UOM,
                    WHQ_INT.extrapolation_ind
                FROM
                    WHQ_INTEGRATION WHQ_INT
                WHERE
                    WHQ_PART = 1
            )
        UNION ALL
            (
                WITH RETAIL_DEPT_PART AS (
    WITH RETAIL_NULL_PART AS(
                    SELECT
                    CASE WHEN CONCAT_WS(
                        '-',
                        SUBSTRING(
                            REGEXP_REPLACE(EAU.LOCATION_NBR, '[^\\w]'),
                            -3,
                            3
                        ),
                        REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                    ) = CONCAT_WS(
                        '-',
                        LPAD(
                            SUBSTRING(
                                COALESCE(
                                    REGEXP_REPLACE(BCM."Tririga POS Store ID", '[^\\w]'),
                                    REGEXP_REPLACE(BCM.BUILDING_CODE_MAIN, '[^\\w]')
                                ),
                                -3,
                                3
                            ),
                            3,
                            '0'
                        ),
                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]')
                    ) THEN '01_location_nbr_and_tririga_pos_store_id'
                    WHEN TRIM(EAU.LEASE_NUMBER_DESC) = TRIM(BCM.TRIRIGA_BUILDING_ID) THEN '02_lease_nbr_and_building_id'
                    WHEN TRIM(EAU.location_postal_cd)=TRIM(BCM.TRIRIGA_ZIP_POSTAL_CODE) THEN '03_zip_code'
                    ELSE '04_no_match'
                    END AS dept_null_joining_key,
                        COALESCE(
                            CAST(EAU.LOCATION_NBR AS STRING),
                            BCM."Tririga POS Store ID"
                        ) AS fuel_location_nbr,
                        EAU.LOCATION_NM AS fuel_location_nm,
                        EAU.MONTH_DT AS reporting_period_dt,
                        EAU.SERVICE_TYPE_NM AS SERVICE_TYPE_CD,
                        EAU.BEGIN_DT AS BILLING_MONTH_START_DT,
                        EAU.END_DT AS BILLING_MONTH_END_DT,
                        DENSE_RANK() OVER(
                            PARTITION BY EAU.location_nbr,
                            EAU.location_nm,
                            EAU.service_type_nm,
                            EAU.month_dt,
                            EAU.begin_dt,
                            EAU.END_DT
                            ORDER BY
                                BCM."Tririga POS Store ID" ASC
                        ) AS RETAIL_PART,
                        cd.FISCAL_YEAR_NM AS REPORTING_FISCAL_YEAR_NBR,
                        cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
                        cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
                        cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
                        cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
                        cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
                        COALESCE(
                            EAU.SITE_CD_SITERRA_DESC,
                            BCM.TRIRIGA_BUILDING_ID
                        ) AS building_id,
                        EAU.SERVICE_TYPE_NM AS fuel_type_txt,
                        NULL AS saf_pct,
                        NULL AS saf_density_uom,
                        12 AS DATA_FREQUENCY_CD,
                        EAU.USAGE_QTY AS SERVICE_USAGE_QTY,
                        EAU.UOM AS SERVICE_USAGE_QTY_UOM,
                        EAU.COST AS SERVICE_COST,
                        'USD' AS SERVICE_COST_UOM,
                        'NO' AS extrapolation_ind
                    FROM
                        EMISSION_AND_USAGE EAU
                        LEFT JOIN BUILDING_COMBINE BCM ON CONCAT_WS(
                            '-',
                            SUBSTRING(
                                REGEXP_REPLACE(EAU.LOCATION_NBR, '[^\\w]'),
                                -3,
                                3
                            ),
                            REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                        ) = CONCAT_WS(
                            '-',
                            LPAD(
                                SUBSTRING(
                                    COALESCE(
                                        REGEXP_REPLACE(BCM."Tririga POS Store ID", '[^\\w]'),
                                        REGEXP_REPLACE(BCM.BUILDING_CODE_MAIN, '[^\\w]')
                                    ),
                                    -3,
                                    3
                                ),
                                3,
                                '0'
                            ),
                            REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]')
                        )
                        OR TRIM(EAU.LEASE_NUMBER_DESC) = TRIM(BCM.TRIRIGA_BUILDING_ID)
                        OR TRIM(EAU.location_postal_cd)=TRIM(BCM.TRIRIGA_ZIP_POSTAL_CODE)
                        LEFT JOIN {calendar_table_name} cd ON TO_VARCHAR(EAU.MONTH_DT, 'MM/dd/yyyy') = TO_VARCHAR(cd.calendar_dt, 'MM/dd/yyyy')
                    WHERE
                        EAU.DEPARTMENT_NM IS NULL
                )
                SELECT
                    DENSE_RANK() OVER(
                            PARTITION BY RETAIL_U.fuel_location_nbr,
                            RETAIL_U.fuel_location_nm,
                            RETAIL_U.SERVICE_TYPE_CD,
                            RETAIL_U.reporting_period_dt,
                            RETAIL_U.BILLING_MONTH_START_DT,
                            RETAIL_U.BILLING_MONTH_END_DT
                            ORDER BY
                                RETAIL_U.dept_null_joining_key ASC
                        ) AS dept_null_part,
                    RETAIL_U.fuel_location_nbr,
                    RETAIL_U.fuel_location_nm,
                    RETAIL_U.reporting_period_dt,
                    RETAIL_U.SERVICE_TYPE_CD,
                    RETAIL_U.BILLING_MONTH_START_DT,
                    RETAIL_U.BILLING_MONTH_END_DT,
                    RETAIL_U.REPORTING_FISCAL_YEAR_NBR,
                    RETAIL_U.REPORTING_CALENDAR_YEAR_NBR,
                    RETAIL_U.REPORTING_MONTH_LONG_NM,
                    RETAIL_U.REPORTING_MONTH_OF_YEAR_NBR,
                    RETAIL_U.REPORTING_QUARTER_NBR,
                    RETAIL_U.REPORTING_WEEK_OF_YEAR_NBR,
                    RETAIL_U.building_id,
                    RETAIL_U.fuel_type_txt,
                    RETAIL_U.saf_pct,
                    RETAIL_U.saf_density_uom,
                    RETAIL_U.DATA_FREQUENCY_CD,
                    RETAIL_U.SERVICE_USAGE_QTY,
                    RETAIL_U.SERVICE_USAGE_QTY_UOM,
                    RETAIL_U.SERVICE_COST,
                    RETAIL_U.SERVICE_COST_UOM,
                    RETAIL_U.extrapolation_ind
                FROM
                    RETAIL_NULL_PART RETAIL_U
                WHERE
                    RETAIL_PART = 1
                    )
               SELECT
                    RETAIL_DEPT_PART.fuel_location_nbr,
                    RETAIL_DEPT_PART.fuel_location_nm,
                    RETAIL_DEPT_PART.reporting_period_dt,
                    RETAIL_DEPT_PART.SERVICE_TYPE_CD,
                    RETAIL_DEPT_PART.BILLING_MONTH_START_DT,
                    RETAIL_DEPT_PART.BILLING_MONTH_END_DT,
                    RETAIL_DEPT_PART.REPORTING_FISCAL_YEAR_NBR,
                    RETAIL_DEPT_PART.REPORTING_CALENDAR_YEAR_NBR,
                    RETAIL_DEPT_PART.REPORTING_MONTH_LONG_NM,
                    RETAIL_DEPT_PART.REPORTING_MONTH_OF_YEAR_NBR,
                    RETAIL_DEPT_PART.REPORTING_QUARTER_NBR,
                    RETAIL_DEPT_PART.REPORTING_WEEK_OF_YEAR_NBR,
                    RETAIL_DEPT_PART.building_id,
                    RETAIL_DEPT_PART.fuel_type_txt,
                    RETAIL_DEPT_PART.saf_pct,
                    RETAIL_DEPT_PART.saf_density_uom,
                    RETAIL_DEPT_PART.DATA_FREQUENCY_CD,
                    RETAIL_DEPT_PART.SERVICE_USAGE_QTY,
                    RETAIL_DEPT_PART.SERVICE_USAGE_QTY_UOM,
                    RETAIL_DEPT_PART.SERVICE_COST,
                    RETAIL_DEPT_PART.SERVICE_COST_UOM,
                    RETAIL_DEPT_PART.extrapolation_ind
                FROM
                    RETAIL_DEPT_PART RETAIL_DEPT_PART
                WHERE
                    dept_null_part = 1
            )
    ),
    DETAILS_UUID AS(
        SELECT
            uuid_string(
                '8e884ace-bee4-11e4-8dfc-aa07a5b093db',
                md5(
                    concat(
                        FUEL_DETAIL_U.fuel_location_nbr,
                        FUEL_DETAIL_U.fuel_location_nm
                    )
                )
            ) AS fuel_consumption_uuid,
            FUEL_DETAIL_U.fuel_location_nbr,
            FUEL_DETAIL_U.fuel_location_nm,
            FUEL_DETAIL_U.reporting_period_dt,
            FUEL_DETAIL_U.SERVICE_TYPE_CD,
            FUEL_DETAIL_U.BILLING_MONTH_START_DT,
            FUEL_DETAIL_U.BILLING_MONTH_END_DT,
            FUEL_DETAIL_U.REPORTING_FISCAL_YEAR_NBR,
            FUEL_DETAIL_U.REPORTING_CALENDAR_YEAR_NBR,
            FUEL_DETAIL_U.REPORTING_MONTH_LONG_NM,
            FUEL_DETAIL_U.REPORTING_MONTH_OF_YEAR_NBR,
            FUEL_DETAIL_U.REPORTING_QUARTER_NBR,
            FUEL_DETAIL_U.REPORTING_WEEK_OF_YEAR_NBR,
            FUEL_DETAIL_U.building_id,
            FUEL_DETAIL_U.fuel_type_txt,
            FUEL_DETAIL_U.saf_pct,
            FUEL_DETAIL_U.saf_density_uom,
            FUEL_DETAIL_U.DATA_FREQUENCY_CD,
            FUEL_DETAIL_U.SERVICE_USAGE_QTY,
            FUEL_DETAIL_U.SERVICE_USAGE_QTY_UOM,
            FUEL_DETAIL_U.SERVICE_COST,
            FUEL_DETAIL_U.SERVICE_COST_UOM,
            FUEL_DETAIL_U.extrapolation_ind,
            'SCOPE 1' AS scope_nbr,
            'emission_and_usage_metrics' AS data_source_nm,
            NULL AS NET_HEAT_OF_COMBUSTION_UOM
        FROM
            DETAIL_INTEGRATION FUEL_DETAIL_U
    ),
    DETAILS_AGG AS(
        SELECT
            FUEL_DETAIL_A.fuel_consumption_uuid,
            FUEL_DETAIL_A.fuel_location_nbr,
            FUEL_DETAIL_A.fuel_location_nm,
            FUEL_DETAIL_A.reporting_period_dt,
            FUEL_DETAIL_A.SERVICE_TYPE_CD,
            FUEL_DETAIL_A.BILLING_MONTH_START_DT,
            FUEL_DETAIL_A.BILLING_MONTH_END_DT,
            FUEL_DETAIL_A.REPORTING_FISCAL_YEAR_NBR,
            FUEL_DETAIL_A.REPORTING_CALENDAR_YEAR_NBR,
            FUEL_DETAIL_A.REPORTING_MONTH_LONG_NM,
            FUEL_DETAIL_A.REPORTING_MONTH_OF_YEAR_NBR,
            FUEL_DETAIL_A.REPORTING_QUARTER_NBR,
            FUEL_DETAIL_A.REPORTING_WEEK_OF_YEAR_NBR,
            FUEL_DETAIL_A.building_id,
            FUEL_DETAIL_A.fuel_type_txt,
            FUEL_DETAIL_A.saf_pct,
            FUEL_DETAIL_A.saf_density_uom,
            FUEL_DETAIL_A.DATA_FREQUENCY_CD,
            SUM(FUEL_DETAIL_A.SERVICE_USAGE_QTY) AS SERVICE_USAGE_QTY,
            FUEL_DETAIL_A.SERVICE_USAGE_QTY_UOM,
            SUM(FUEL_DETAIL_A.SERVICE_COST) AS SERVICE_COST,
            FUEL_DETAIL_A.SERVICE_COST_UOM,
            FUEL_DETAIL_A.extrapolation_ind,
            FUEL_DETAIL_A.scope_nbr,
            FUEL_DETAIL_A.data_source_nm,
            FUEL_DETAIL_A.NET_HEAT_OF_COMBUSTION_UOM
        FROM
            DETAILS_UUID FUEL_DETAIL_A
        GROUP BY
            FUEL_DETAIL_A.fuel_consumption_uuid,
            FUEL_DETAIL_A.fuel_location_nbr,
            FUEL_DETAIL_A.fuel_location_nm,
            FUEL_DETAIL_A.reporting_period_dt,
            FUEL_DETAIL_A.SERVICE_TYPE_CD,
            FUEL_DETAIL_A.BILLING_MONTH_START_DT,
            FUEL_DETAIL_A.BILLING_MONTH_END_DT,
            FUEL_DETAIL_A.REPORTING_FISCAL_YEAR_NBR,
            FUEL_DETAIL_A.REPORTING_CALENDAR_YEAR_NBR,
            FUEL_DETAIL_A.REPORTING_MONTH_LONG_NM,
            FUEL_DETAIL_A.REPORTING_MONTH_OF_YEAR_NBR,
            FUEL_DETAIL_A.REPORTING_QUARTER_NBR,
            FUEL_DETAIL_A.REPORTING_WEEK_OF_YEAR_NBR,
            FUEL_DETAIL_A.building_id,
            FUEL_DETAIL_A.fuel_type_txt,
            FUEL_DETAIL_A.saf_pct,
            FUEL_DETAIL_A.saf_density_uom,
            FUEL_DETAIL_A.DATA_FREQUENCY_CD,
            FUEL_DETAIL_A.SERVICE_USAGE_QTY_UOM,
            FUEL_DETAIL_A.SERVICE_COST_UOM,
            FUEL_DETAIL_A.extrapolation_ind,
            FUEL_DETAIL_A.scope_nbr,
            FUEL_DETAIL_A.data_source_nm,
            FUEL_DETAIL_A.NET_HEAT_OF_COMBUSTION_UOM
    )
    SELECT
        FUEL_DETAIL.fuel_consumption_uuid AS fuel_consumption_uuid,
        FUEL_DETAIL.fuel_location_nbr AS fuel_location_nbr,
        FUEL_DETAIL.fuel_location_nm AS fuel_location_nm,
        FUEL_DETAIL.reporting_period_dt AS reporting_period_dt,
        CASE 
            WHEN FUEL_DETAIL.SERVICE_TYPE_CD ILIKE 'Electric' THEN 'Electricity'
            ELSE FUEL_DETAIL.SERVICE_TYPE_CD
        END AS SERVICE_TYPE_CD,
        MIN(FUEL_DETAIL.BILLING_MONTH_START_DT) AS BILLING_MONTH_START_DT,
        MAX(FUEL_DETAIL.BILLING_MONTH_END_DT) AS BILLING_MONTH_END_DT,
        CONCAT_WS(
            '-',
            TO_VARCHAR(MIN(FUEL_DETAIL.BILLING_MONTH_START_DT), 'MM/dd/yyyy'),
            TO_VARCHAR(MAX(FUEL_DETAIL.BILLING_MONTH_END_DT), 'MM/dd/yyyy')
        ) AS BILLING_MONTH_DATE_RANGE_TXT,
        REGEXP_REPLACE(FUEL_DETAIL.REPORTING_FISCAL_YEAR_NBR, '[^0-9]', '') AS REPORTING_FISCAL_YEAR_NBR,
        FUEL_DETAIL.REPORTING_CALENDAR_YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
        FUEL_DETAIL.REPORTING_MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
        FUEL_DETAIL.REPORTING_MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
        FUEL_DETAIL.REPORTING_QUARTER_NBR AS REPORTING_QUARTER_NBR,
        FUEL_DETAIL.REPORTING_WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
        FUEL_DETAIL.building_id AS building_id,
        FUEL_DETAIL.fuel_type_txt AS fuel_type_txt,
        FUEL_DETAIL.saf_pct AS saf_pct,
        FUEL_DETAIL.saf_density_uom AS saf_density_uom,
        FUEL_DETAIL.DATA_FREQUENCY_CD AS DATA_FREQUENCY_CD,
        SUM(FUEL_DETAIL.SERVICE_USAGE_QTY) AS SERVICE_USAGE_QTY,
        INITCAP(COALESCE(
            MAX(FUEL_DETAIL.SERVICE_USAGE_QTY_UOM),
            MIN(FUEL_DETAIL.SERVICE_USAGE_QTY_UOM))
        ) AS SERVICE_USAGE_QTY_UOM,
        SUM(FUEL_DETAIL.SERVICE_COST) AS SERVICE_COST,
        FUEL_DETAIL.SERVICE_COST_UOM AS SERVICE_COST_UOM,
        FUEL_DETAIL.extrapolation_ind AS extrapolation_ind,
        FUEL_DETAIL.scope_nbr AS scope_nbr,
        FUEL_DETAIL.data_source_nm AS data_source_nm,
        FUEL_DETAIL.NET_HEAT_OF_COMBUSTION_UOM AS NET_HEAT_OF_COMBUSTION_UOM
    FROM
        DETAILS_AGG FUEL_DETAIL
    GROUP BY
        FUEL_DETAIL.fuel_consumption_uuid,
        FUEL_DETAIL.fuel_location_nbr,
        FUEL_DETAIL.fuel_location_nm,
        FUEL_DETAIL.reporting_period_dt,
        FUEL_DETAIL.SERVICE_TYPE_CD,
        FUEL_DETAIL.REPORTING_FISCAL_YEAR_NBR,
        FUEL_DETAIL.REPORTING_CALENDAR_YEAR_NBR,
        FUEL_DETAIL.REPORTING_MONTH_LONG_NM,
        FUEL_DETAIL.REPORTING_MONTH_OF_YEAR_NBR,
        FUEL_DETAIL.REPORTING_QUARTER_NBR,
        FUEL_DETAIL.REPORTING_WEEK_OF_YEAR_NBR,
        FUEL_DETAIL.building_id,
        FUEL_DETAIL.fuel_type_txt,
        FUEL_DETAIL.saf_pct,
        FUEL_DETAIL.saf_density_uom,
        FUEL_DETAIL.DATA_FREQUENCY_CD,
        FUEL_DETAIL.SERVICE_COST_UOM,
        FUEL_DETAIL.extrapolation_ind,
        FUEL_DETAIL.scope_nbr,
        FUEL_DETAIL.data_source_nm,
        FUEL_DETAIL.NET_HEAT_OF_COMBUSTION_UOM
) FD_SOURCE_T ON CONCAT_WS(
    '_',
    FD_DEST_T.fuel_consumption_uuid,
    FD_DEST_T.fuel_location_nbr,
    FD_DEST_T.fuel_location_nm,
    FD_DEST_T.reporting_period_dt,
    FD_DEST_T.SERVICE_TYPE_CD
) = CONCAT_WS(
    '_',
    FD_SOURCE_T.fuel_consumption_uuid,
    FD_SOURCE_T.fuel_location_nbr,
    FD_SOURCE_T.fuel_location_nm,
    FD_SOURCE_T.reporting_period_dt,
    FD_SOURCE_T.SERVICE_TYPE_CD
)
WHEN MATCHED THEN
UPDATE
SET
    FD_DEST_T.BILLING_MONTH_START_DT = FD_SOURCE_T.BILLING_MONTH_START_DT,
    FD_DEST_T.BILLING_MONTH_END_DT = FD_SOURCE_T.BILLING_MONTH_END_DT,
    FD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT = FD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
    FD_DEST_T.REPORTING_FISCAL_YEAR_NBR = FD_SOURCE_T.REPORTING_FISCAL_YEAR_NBR,
    FD_DEST_T.REPORTING_CALENDAR_YEAR_NBR = FD_SOURCE_T.REPORTING_CALENDAR_YEAR_NBR,
    FD_DEST_T.REPORTING_MONTH_LONG_NM = FD_SOURCE_T.REPORTING_MONTH_LONG_NM,
    FD_DEST_T.REPORTING_MONTH_OF_YEAR_NBR = FD_SOURCE_T.REPORTING_MONTH_OF_YEAR_NBR,
    FD_DEST_T.REPORTING_QUARTER_NBR = FD_SOURCE_T.REPORTING_QUARTER_NBR,
    FD_DEST_T.REPORTING_WEEK_OF_YEAR_NBR = FD_SOURCE_T.REPORTING_WEEK_OF_YEAR_NBR,
    FD_DEST_T.building_id = FD_SOURCE_T.building_id,
    FD_DEST_T.fuel_type_txt = FD_SOURCE_T.fuel_type_txt,
    FD_DEST_T.saf_pct = FD_SOURCE_T.saf_pct,
    FD_DEST_T.saf_density_uom = FD_SOURCE_T.saf_density_uom,
    FD_DEST_T.DATA_FREQUENCY_CD = FD_SOURCE_T.DATA_FREQUENCY_CD,
    FD_DEST_T.SERVICE_USAGE_QTY = FD_SOURCE_T.SERVICE_USAGE_QTY,
    FD_DEST_T.SERVICE_USAGE_QTY_UOM = FD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
    FD_DEST_T.SERVICE_COST = FD_SOURCE_T.SERVICE_COST,
    FD_DEST_T.SERVICE_COST_UOM = FD_SOURCE_T.SERVICE_COST_UOM,
    FD_DEST_T.extrapolation_ind = FD_SOURCE_T.extrapolation_ind,
    FD_DEST_T.scope_nbr = FD_SOURCE_T.scope_nbr,
    FD_DEST_T.data_source_nm = FD_SOURCE_T.data_source_nm,
    FD_DEST_T.NET_HEAT_OF_COMBUSTION_UOM=FD_SOURCE_T.NET_HEAT_OF_COMBUSTION_UOM
    WHEN NOT MATCHED THEN
INSERT
    (
        FD_DEST_T.fuel_consumption_uuid,
        FD_DEST_T.fuel_location_nbr,
        FD_DEST_T.fuel_location_nm,
        FD_DEST_T.reporting_period_dt,
        FD_DEST_T.SERVICE_TYPE_CD,
        FD_DEST_T.BILLING_MONTH_START_DT,
        FD_DEST_T.BILLING_MONTH_END_DT,
        FD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT,
        FD_DEST_T.REPORTING_FISCAL_YEAR_NBR,
        FD_DEST_T.REPORTING_CALENDAR_YEAR_NBR,
        FD_DEST_T.REPORTING_MONTH_LONG_NM,
        FD_DEST_T.REPORTING_MONTH_OF_YEAR_NBR,
        FD_DEST_T.REPORTING_QUARTER_NBR,
        FD_DEST_T.REPORTING_WEEK_OF_YEAR_NBR,
        FD_DEST_T.building_id,
        FD_DEST_T.fuel_type_txt,
        FD_DEST_T.saf_pct,
        FD_DEST_T.saf_density_uom,
        FD_DEST_T.DATA_FREQUENCY_CD,
        FD_DEST_T.SERVICE_USAGE_QTY,
        FD_DEST_T.SERVICE_USAGE_QTY_UOM,
        FD_DEST_T.SERVICE_COST,
        FD_DEST_T.SERVICE_COST_UOM,
        FD_DEST_T.extrapolation_ind,
        FD_DEST_T.scope_nbr,
        FD_DEST_T.data_source_nm,
        FD_DEST_T.NET_HEAT_OF_COMBUSTION_UOM
    )
VALUES
    (
        FD_SOURCE_T.fuel_consumption_uuid,
        FD_SOURCE_T.fuel_location_nbr,
        FD_SOURCE_T.fuel_location_nm,
        FD_SOURCE_T.reporting_period_dt,
        FD_SOURCE_T.SERVICE_TYPE_CD,
        FD_SOURCE_T.BILLING_MONTH_START_DT,
        FD_SOURCE_T.BILLING_MONTH_END_DT,
        FD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
        FD_SOURCE_T.REPORTING_FISCAL_YEAR_NBR,
        FD_SOURCE_T.REPORTING_CALENDAR_YEAR_NBR,
        FD_SOURCE_T.REPORTING_MONTH_LONG_NM,
        FD_SOURCE_T.REPORTING_MONTH_OF_YEAR_NBR,
        FD_SOURCE_T.REPORTING_QUARTER_NBR,
        FD_SOURCE_T.REPORTING_WEEK_OF_YEAR_NBR,
        FD_SOURCE_T.building_id,
        FD_SOURCE_T.fuel_type_txt,
        FD_SOURCE_T.saf_pct,
        FD_SOURCE_T.saf_density_uom,
        FD_SOURCE_T.DATA_FREQUENCY_CD,
        FD_SOURCE_T.SERVICE_USAGE_QTY,
        FD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
        FD_SOURCE_T.SERVICE_COST,
        FD_SOURCE_T.SERVICE_COST_UOM,
        FD_SOURCE_T.extrapolation_ind,
        FD_SOURCE_T.scope_nbr,
        FD_SOURCE_T.data_source_nm,
        FD_SOURCE_T.NET_HEAT_OF_COMBUSTION_UOM
    );