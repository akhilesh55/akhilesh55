MERGE INTO {target_complete_name} AS ES_DEST_T USING(
    WITH BUILDING_COMBINE AS(
    WITH BUILDING_COMBINE_PART AS (
        SELECT
            B_COMBINE_PART.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
            B_COMBINE_PART.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
            B_COMBINE_PART.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
            B_COMBINE_PART.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
            B_COMBINE_PART.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
            B_COMBINE_PART.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
            B_COMBINE_PART.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
            B_COMBINE_PART.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
            B_COMBINE_PART.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
            B_COMBINE_PART.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
            B_COMBINE_PART."Building Type" AS "Building Type",
            B_COMBINE_PART."Location Type" AS "Location Type",
            B_COMBINE_PART."Nike Key City" AS "Nike Key City",
            B_COMBINE_PART.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
            B_COMBINE_PART."Business Group" AS "Business Group",
            B_COMBINE_PART."Campus - Corporate Park" AS "Campus - Corporate Park",
            B_COMBINE_PART.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
            B_COMBINE_PART.CITY_CODE_MAIN AS CITY_CODE_MAIN,
            B_COMBINE_PART.CONTINENT_CODE AS CONTINENT_CODE,
            B_COMBINE_PART.CONTINENT_NAME AS CONTINENT_NAME,
            B_COMBINE_PART.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
            B_COMBINE_PART.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
            B_COMBINE_PART.LOCATION_REGION AS LOCATION_REGION,
            B_COMBINE_PART.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
            B_COMBINE_PART."NIKE GEO" AS "NIKE GEO",
            B_COMBINE_PART."Primary Use" AS "Primary Use",
            B_COMBINE_PART.REPORT_DATE AS REPORT_DATE,
            B_COMBINE_PART.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
            B_COMBINE_PART.STATE_PROV_MAIN AS STATE_PROV_MAIN,
            B_COMBINE_PART.STATE_CODE_MAIN AS STATE_CODE_MAIN,
            B_COMBINE_PART.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
            B_COMBINE_PART."Tririga Brand" AS "Tririga Brand",
            B_COMBINE_PART.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
            B_COMBINE_PART.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
            B_COMBINE_PART.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
            B_COMBINE_PART.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
            B_COMBINE_PART.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
            B_COMBINE_PART."Tririga Contract Status" AS "Tririga Contract Status",
            B_COMBINE_PART.TRIRIGA_GEO AS TRIRIGA_GEO,
            B_COMBINE_PART.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
            B_COMBINE_PART.LATITUDE_MAIN AS LATITUDE_MAIN,
            B_COMBINE_PART.LONGITUDE_MAIN AS LONGITUDE_MAIN,
            B_COMBINE_PART."Tririga GIS LAT" AS "Tririga GIS LAT",
            B_COMBINE_PART."Tririga GIS LON" AS "Tririga GIS LON",
            CASE
                WHEN LENGTH(B_COMBINE_PART."Tririga POS Store ID") < 2 THEN CONCAT('00', B_COMBINE_PART."Tririga POS Store ID")
                WHEN LENGTH(B_COMBINE_PART."Tririga POS Store ID") < 3 THEN CONCAT('0', B_COMBINE_PART."Tririga POS Store ID")
                ELSE B_COMBINE_PART."Tririga POS Store ID"
            END AS "Tririga POS Store ID",
            B_COMBINE_PART.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
            CASE
                WHEN length(B_COMBINE_PART.TRIRIGA_ZIP_POSTAL_CODE) > 7 THEN REGEXP_SUBSTR(
                    TRIM(B_COMBINE_PART.TRIRIGA_ZIP_POSTAL_CODE),
                    '([0-9]+)',
                    1
                )
                ELSE TRIRIGA_ZIP_POSTAL_CODE
            END AS TRIRIGA_ZIP_POSTAL_CODE,
            B_COMBINE_PART.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
            B_COMBINE_PART.WDC_REGION_MAIN AS WDC_REGION_MAIN,
            B_COMBINE_PART."Zip Code Main" AS "Zip Code Main",
            B_COMBINE_PART.ARCHIBUS_USF AS ARCHIBUS_USF,
            B_COMBINE_PART.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
            B_COMBINE_PART.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
            B_COMBINE_PART."Max. Bldg. Capacity" AS "Max. Bldg. Capacity",
            B_COMBINE_PART."Number of Floors" AS "Number of Floors",
            ROW_NUMBER() OVER(
                PARTITION BY B_COMBINE_PART.BUILDING_CODE_MAIN,
                B_COMBINE_PART.TRIRIGA_ZIP_POSTAL_CODE
                ORDER BY
                    B_COMBINE_PART.report_date DESC
            ) AS COMBINE_PART
        FROM
            {building_table_name} B_COMBINE_PART
        WHERE
            B_COMBINE_PART.CONTINENT_NAME = 'North America'
            -- AND B_COMBINE_PART.DISPLAY_LATEST_MAIN='LATEST'
    )
    SELECT
        B_COMBINE.DISPLAY_LATEST_MAIN AS DISPLAY_LATEST_MAIN,
        B_COMBINE.ARCHIBUS_BUILDING_ADDRESS AS ARCHIBUS_BUILDING_ADDRESS,
        B_COMBINE.ARCHIBUS_BUILDING_CODE AS ARCHIBUS_BUILDING_CODE,
        B_COMBINE.ARCHIBUS_BUILDING_USE AS ARCHIBUS_BUILDING_USE,
        B_COMBINE.ARCHIBUS_BUILDING_STATUS AS ARCHIBUS_BUILDING_STATUS,
        B_COMBINE.BUILDING_ADDRESS_MAIN AS BUILDING_ADDRESS_MAIN,
        B_COMBINE.BUILDING_CODE_MAIN AS BUILDING_CODE_MAIN,
        B_COMBINE.BUILDING_NAME_MAIN AS BUILDING_NAME_MAIN,
        B_COMBINE.BUILDING_STATUS_MAIN AS BUILDING_STATUS_MAIN,
        B_COMBINE.BUSINESS_GROUP_MAIN AS BUSINESS_GROUP_MAIN,
        B_COMBINE."Building Type" AS "Building Type",
        B_COMBINE."Location Type" AS "Location Type",
        B_COMBINE."Nike Key City" AS "Nike Key City",
        B_COMBINE.BUILDING_USE_MAIN AS BUILDING_USE_MAIN,
        B_COMBINE."Business Group" AS "Business Group",
        B_COMBINE."Campus - Corporate Park" AS "Campus - Corporate Park",
        B_COMBINE.CAMPUS_NAME_MAIN AS CAMPUS_NAME_MAIN,
        B_COMBINE.CITY_CODE_MAIN AS CITY_CODE_MAIN,
        B_COMBINE.CONTINENT_CODE AS CONTINENT_CODE,
        B_COMBINE.CONTINENT_NAME AS CONTINENT_NAME,
        B_COMBINE.COUNTRY_CODE_MAIN AS COUNTRY_CODE_MAIN,
        B_COMBINE.COUNTRY_NAME_MAIN AS COUNTRY_NAME_MAIN,
        B_COMBINE.LOCATION_REGION AS LOCATION_REGION,
        B_COMBINE.NEIGHBORHOOD_NAME_MAIN AS NEIGHBORHOOD_NAME_MAIN,
        B_COMBINE."NIKE GEO" AS "NIKE GEO",
        B_COMBINE."Primary Use" AS "Primary Use",
        B_COMBINE.REPORT_DATE AS REPORT_DATE,
        B_COMBINE.REPORT_LOAD_DATE AS REPORT_LOAD_DATE,
        B_COMBINE.STATE_PROV_MAIN AS STATE_PROV_MAIN,
        B_COMBINE.STATE_CODE_MAIN AS STATE_CODE_MAIN,
        B_COMBINE.TRIRIGA_BLDG_ID_CODE AS TRIRIGA_BLDG_ID_CODE,
        B_COMBINE."Tririga Brand" AS "Tririga Brand",
        B_COMBINE.TRIRIGA_BUILDING_ADDRESS AS TRIRIGA_BUILDING_ADDRESS,
        B_COMBINE.TRIRIGA_BUILDING_ID AS TRIRIGA_BUILDING_ID,
        B_COMBINE.TRIRIGA_BUILDING_STATUS_CURRENT AS TRIRIGA_BUILDING_STATUS_CURRENT,
        B_COMBINE.TRIRIGA_CAMPUS AS TRIRIGA_CAMPUS,
        B_COMBINE.TRIRIGA_CONCEPT AS TRIRIGA_CONCEPT,
        B_COMBINE."Tririga Contract Status" AS "Tririga Contract Status",
        B_COMBINE.TRIRIGA_GEO AS TRIRIGA_GEO,
        B_COMBINE.TRIRIGA_LEASE_TYPE AS TRIRIGA_LEASE_TYPE,
        B_COMBINE.LATITUDE_MAIN AS LATITUDE_MAIN,
        B_COMBINE.LONGITUDE_MAIN AS LONGITUDE_MAIN,
        B_COMBINE."Tririga GIS LAT" AS "Tririga GIS LAT",
        B_COMBINE."Tririga GIS LON" AS "Tririga GIS LON",
        B_COMBINE."Tririga POS Store ID" AS "Tririga POS Store ID",
        B_COMBINE.TRIRIGA_TERRITORY AS TRIRIGA_TERRITORY,
        B_COMBINE.TRIRIGA_ZIP_POSTAL_CODE AS TRIRIGA_ZIP_POSTAL_CODE,
        B_COMBINE.TRIRIGA_LEASE_USE AS TRIRIGA_LEASE_USE,
        B_COMBINE.WDC_REGION_MAIN AS WDC_REGION_MAIN,
        B_COMBINE."Zip Code Main" AS "Zip Code Main",
        B_COMBINE.ARCHIBUS_USF AS ARCHIBUS_USF,
        B_COMBINE.ARCHIBUS_STRATEGIC_CAPACITY_NUMBER AS ARCHIBUS_STRATEGIC_CAPACITY_NUMBER,
        B_COMBINE.BUILDING_USF_MAIN AS BUILDING_USF_MAIN,
        B_COMBINE."Max. Bldg. Capacity" AS "Max. Bldg. Capacity",
        B_COMBINE."Number of Floors" AS "Number of Floors"
    FROM
        BUILDING_COMBINE_PART B_COMBINE
    WHERE
        B_COMBINE.COMBINE_PART = 1
),
EMISSION_AND_USAGE AS(
    WITH EMISSION_AND_USAGE_PART AS(
        SELECT
            U_METRICS_PART.location_nm AS location_nm,
            U_METRICS_PART.location_nbr AS location_nbr,
            U_METRICS_PART.location_address_1_nm AS location_address_1_nm,
            U_METRICS_PART.location_address_2_nm AS location_address_2_nm,
            U_METRICS_PART.location_city_nm AS location_city_nm,
            U_METRICS_PART.location_state_or_province_nm AS location_state_or_province_nm,
            U_METRICS_PART.location_postal_cd AS location_postal_cd,
            U_METRICS_PART.location_country_nm AS location_country_nm,
            U_METRICS_PART.location_status_desc AS location_status_desc,
            U_METRICS_PART.location_size_sqft AS location_size_sqft,
            U_METRICS_PART.misc_information_desc AS misc_information_desc,
            U_METRICS_PART.vendor_nm AS vendor_nm,
            U_METRICS_PART.vendor_address_1_nm AS vendor_address_1_nm,
            U_METRICS_PART.vendor_address_2_nm AS vendor_address_2_nm,
            U_METRICS_PART.vendor_city_nm AS vendor_city_nm,
            U_METRICS_PART.vendor_state_or_province_nm AS vendor_state_or_province_nm,
            U_METRICS_PART.vendor_postal_cd AS vendor_postal_cd,
            U_METRICS_PART.vendor_country_nm AS vendor_country_nm,
            U_METRICS_PART.account_nbr AS account_nbr,
            U_METRICS_PART.summary_account_nbr AS summary_account_nbr,
            U_METRICS_PART.account_address_1_nm AS account_address_1_nm,
            U_METRICS_PART.account_address_2_nm AS account_address_2_nm,
            U_METRICS_PART.account_city_nm AS account_city_nm,
            U_METRICS_PART.account_state_or_province_nm AS account_state_or_province_nm,
            U_METRICS_PART.account_postal_cd AS account_postal_cd,
            U_METRICS_PART.account_country_nm AS account_country_nm,
            U_METRICS_PART.clean_account_number_desc AS clean_account_number_desc,
            U_METRICS_PART.supplier_only_account_ind AS supplier_only_account_ind,
            U_METRICS_PART.audit_only_ind AS audit_only_ind,
            U_METRICS_PART.customer_gl_nbr AS customer_gl_nbr,
            U_METRICS_PART.gl_desc AS gl_desc,
            U_METRICS_PART.gl_allocation_pct AS gl_allocation_pct,
            U_METRICS_PART.meter_number_desc AS meter_number_desc,
            U_METRICS_PART.service_point_location_nm AS service_point_location_nm,
            U_METRICS_PART.rate_schedule_desc AS rate_schedule_desc,
            U_METRICS_PART.month_dt AS month_dt,
            U_METRICS_PART.begin_dt AS begin_dt,
            U_METRICS_PART.end_dt AS end_dt,
            U_METRICS_PART.service_days AS service_days,
            U_METRICS_PART.cost AS cost,
            U_METRICS_PART.service_type_nm AS service_type_nm,
            U_METRICS_PART.uom AS uom,
            U_METRICS_PART.usage_qty AS usage_qty,
            U_METRICS_PART.billed_qty AS billed_qty,
            U_METRICS_PART.cost_per_unit_uom AS cost_per_unit_uom,
            U_METRICS_PART.cost_per_day AS cost_per_day,
            U_METRICS_PART.cost_per_sqft AS cost_per_sqft,
            U_METRICS_PART.usage_per_day AS usage_per_day,
            U_METRICS_PART.usage_per_sqft AS usage_per_sqft,
            U_METRICS_PART.kbtus_qty AS kbtus_qty,
            U_METRICS_PART.kbtus_per_sqft AS kbtus_per_sqft,
            U_METRICS_PART.max_demand_qty AS max_demand_qty,
            U_METRICS_PART.load_factor_qty AS load_factor_qty,
            U_METRICS_PART.power_factor_qty AS power_factor_qty,
            U_METRICS_PART.cost_per_billed_qty AS cost_per_billed_qty,
            U_METRICS_PART.bill_estimated_ind AS bill_estimated_ind,
            U_METRICS_PART.open_exceptions_ind AS open_exceptions_ind,
            U_METRICS_PART.bill_image_desc AS bill_image_desc,
            U_METRICS_PART.department_nm AS department_nm,
            U_METRICS_PART.lease_number_desc AS lease_number_desc,
            U_METRICS_PART.audit_status_dt AS audit_status_dt,
            U_METRICS_PART.contract_expiration_dt AS contract_expiration_dt,
            U_METRICS_PART.contract_nm AS contract_nm,
            U_METRICS_PART.contract_status_desc AS contract_status_desc,
            U_METRICS_PART.floor_nbr AS floor_nbr,
            U_METRICS_PART.alternate_nm AS alternate_nm,
            U_METRICS_PART.baseline_note_desc AS baseline_note_desc,
            U_METRICS_PART.better_buildings_challenge_ind AS better_buildings_challenge_ind,
            U_METRICS_PART.district_inline_desc AS district_inline_desc,
            U_METRICS_PART.district_outlet_desc AS district_outlet_desc,
            U_METRICS_PART.footprint_sqft AS footprint_sqft,
            U_METRICS_PART.in_line_outlet_desc AS in_line_outlet_desc,
            U_METRICS_PART.ems_desc AS ems_desc,
            U_METRICS_PART.ems_install_dt AS ems_install_dt,
            U_METRICS_PART.global_sustainability_energy_plus_carbon_target_group_desc AS global_sustainability_energy_plus_carbon_target_group_desc,
            U_METRICS_PART.location_opened_dt AS location_opened_dt,
            U_METRICS_PART.site_cd_siterra_desc AS site_cd_siterra_desc,
            U_METRICS_PART.total_bldg_sqft AS total_bldg_sqft,
            U_METRICS_PART.wd_and_c_geo AS wd_and_c_geo,
            U_METRICS_PART.whq_campus_nm AS whq_campus_nm,
            U_METRICS_PART.leed_desc AS leed_desc,
            U_METRICS_PART.location_crc_nbr AS location_crc_nbr,
            U_METRICS_PART.new_building_nm AS new_building_nm,
            U_METRICS_PART.ownership_desc AS ownership_desc,
            U_METRICS_PART.principle_building_activity_desc AS principle_building_activity_desc,
            U_METRICS_PART.seated_occupancy_qty AS seated_occupancy_qty,
            U_METRICS_PART.sub_concept_desc AS sub_concept_desc,
            U_METRICS_PART.brand_nm AS brand_nm,
            ROW_NUMBER() OVER(
                PARTITION BY U_METRICS_PART.location_nbr,
                U_METRICS_PART.location_nm
                ORDER BY
                    U_METRICS_PART.begin_dt DESC
            ) AS METRICS_PART
        FROM
            {curated_table_name} U_METRICS_PART
        WHERE
            (
                U_METRICS_PART.DEPARTMENT_NM IN(
                    'Retail Factory',
                    'Retail Inline',
                    'Retail Other',
                    'WHQ',
                    'Other Offices and Building Construction'
                )
                OR U_METRICS_PART.DEPARTMENT_NM ILIKE '%Air MI%'
                OR U_METRICS_PART.DEPARTMENT_NM IS NULL
            )
            AND U_METRICS_PART.SERVICE_TYPE_NM IN('Electric')
            AND U_METRICS_PART.LOCATION_NM NOT ILIKE '!0%'
    )
    SELECT
        U_METRICS.location_nm AS location_nm,
        U_METRICS.location_nbr AS location_nbr,
        U_METRICS.location_address_1_nm AS location_address_1_nm,
        U_METRICS.location_address_2_nm AS location_address_2_nm,
        U_METRICS.location_city_nm AS location_city_nm,
        U_METRICS.location_state_or_province_nm AS location_state_or_province_nm,
        U_METRICS.location_postal_cd AS location_postal_cd,
        U_METRICS.location_country_nm AS location_country_nm,
        U_METRICS.location_status_desc AS location_status_desc,
        U_METRICS.location_size_sqft AS location_size_sqft,
        U_METRICS.misc_information_desc AS misc_information_desc,
        U_METRICS.vendor_nm AS vendor_nm,
        U_METRICS.vendor_address_1_nm AS vendor_address_1_nm,
        U_METRICS.vendor_address_2_nm AS vendor_address_2_nm,
        U_METRICS.vendor_city_nm AS vendor_city_nm,
        U_METRICS.vendor_state_or_province_nm AS vendor_state_or_province_nm,
        U_METRICS.vendor_postal_cd AS vendor_postal_cd,
        U_METRICS.vendor_country_nm AS vendor_country_nm,
        U_METRICS.account_nbr AS account_nbr,
        U_METRICS.summary_account_nbr AS summary_account_nbr,
        U_METRICS.account_address_1_nm AS account_address_1_nm,
        U_METRICS.account_address_2_nm AS account_address_2_nm,
        U_METRICS.account_city_nm AS account_city_nm,
        U_METRICS.account_state_or_province_nm AS account_state_or_province_nm,
        U_METRICS.account_postal_cd AS account_postal_cd,
        U_METRICS.account_country_nm AS account_country_nm,
        U_METRICS.clean_account_number_desc AS clean_account_number_desc,
        U_METRICS.supplier_only_account_ind AS supplier_only_account_ind,
        U_METRICS.audit_only_ind AS audit_only_ind,
        U_METRICS.customer_gl_nbr AS customer_gl_nbr,
        U_METRICS.gl_desc AS gl_desc,
        U_METRICS.gl_allocation_pct AS gl_allocation_pct,
        U_METRICS.meter_number_desc AS meter_number_desc,
        U_METRICS.service_point_location_nm AS service_point_location_nm,
        U_METRICS.rate_schedule_desc AS rate_schedule_desc,
        U_METRICS.month_dt AS month_dt,
        U_METRICS.begin_dt AS begin_dt,
        U_METRICS.end_dt AS end_dt,
        U_METRICS.service_days AS service_days,
        U_METRICS.cost AS cost,
        U_METRICS.service_type_nm AS service_type_nm,
        U_METRICS.uom AS uom,
        U_METRICS.usage_qty AS usage_qty,
        U_METRICS.billed_qty AS billed_qty,
        U_METRICS.cost_per_unit_uom AS cost_per_unit_uom,
        U_METRICS.cost_per_day AS cost_per_day,
        U_METRICS.cost_per_sqft AS cost_per_sqft,
        U_METRICS.usage_per_day AS usage_per_day,
        U_METRICS.usage_per_sqft AS usage_per_sqft,
        U_METRICS.kbtus_qty AS kbtus_qty,
        U_METRICS.kbtus_per_sqft AS kbtus_per_sqft,
        U_METRICS.max_demand_qty AS max_demand_qty,
        U_METRICS.load_factor_qty AS load_factor_qty,
        U_METRICS.power_factor_qty AS power_factor_qty,
        U_METRICS.cost_per_billed_qty AS cost_per_billed_qty,
        U_METRICS.bill_estimated_ind AS bill_estimated_ind,
        U_METRICS.open_exceptions_ind AS open_exceptions_ind,
        U_METRICS.bill_image_desc AS bill_image_desc,
        U_METRICS.department_nm AS department_nm,
        U_METRICS.lease_number_desc AS lease_number_desc,
        U_METRICS.audit_status_dt AS audit_status_dt,
        U_METRICS.contract_expiration_dt AS contract_expiration_dt,
        U_METRICS.contract_nm AS contract_nm,
        U_METRICS.contract_status_desc AS contract_status_desc,
        U_METRICS.floor_nbr AS floor_nbr,
        U_METRICS.alternate_nm AS alternate_nm,
        U_METRICS.baseline_note_desc AS baseline_note_desc,
        U_METRICS.better_buildings_challenge_ind AS better_buildings_challenge_ind,
        U_METRICS.district_inline_desc AS district_inline_desc,
        U_METRICS.district_outlet_desc AS district_outlet_desc,
        U_METRICS.footprint_sqft AS footprint_sqft,
        U_METRICS.in_line_outlet_desc AS in_line_outlet_desc,
        U_METRICS.ems_desc AS ems_desc,
        U_METRICS.ems_install_dt AS ems_install_dt,
        U_METRICS.global_sustainability_energy_plus_carbon_target_group_desc AS global_sustainability_energy_plus_carbon_target_group_desc,
        U_METRICS.location_opened_dt AS location_opened_dt,
        U_METRICS.site_cd_siterra_desc AS site_cd_siterra_desc,
        U_METRICS.total_bldg_sqft AS total_bldg_sqft,
        U_METRICS.wd_and_c_geo AS wd_and_c_geo,
        U_METRICS.whq_campus_nm AS whq_campus_nm,
        U_METRICS.leed_desc AS leed_desc,
        U_METRICS.location_crc_nbr AS location_crc_nbr,
        U_METRICS.new_building_nm AS new_building_nm,
        U_METRICS.ownership_desc AS ownership_desc,
        U_METRICS.principle_building_activity_desc AS principle_building_activity_desc,
        U_METRICS.seated_occupancy_qty AS seated_occupancy_qty,
        U_METRICS.sub_concept_desc AS sub_concept_desc,
        U_METRICS.brand_nm AS brand_nm
    FROM
        EMISSION_AND_USAGE_PART U_METRICS
    WHERE
        U_METRICS.METRICS_PART = 1
),
SITE_INTEGRATION AS (
    WITH RETAIL_PARTITION AS (
        SELECT
            COALESCE(
                CAST(EAU.LOCATION_NBR AS STRING),
                BCM."Tririga POS Store ID"
            ) AS electricity_location_nbr,
            EAU.LOCATION_NM AS electricity_location_nm,
            EAU.LEASE_NUMBER_DESC AS lease_nbr,
            ROW_NUMBER() OVER(
                PARTITION BY EAU.LOCATION_NBR,
                EAU.LOCATION_NM
                ORDER BY
                    BCM."Tririga POS Store ID"
            ) AS RETAIL_PART,
            COALESCE(
                EAU.SITE_CD_SITERRA_DESC,
                BCM.TRIRIGA_BUILDING_ID
            ) AS building_id,
            BCM.BUSINESS_GROUP_MAIN AS business_group_txt,
            EAU.BRAND_NM AS brand_nm,
            CASE
                WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction' THEN 'Other Facilities'
                WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%' THEN 'Air MI'
                WHEN EAU.DEPARTMENT_NM is null
                and BCM."Location Type" ILIKE 'Stores'
                and BCM.BUILDING_USE_MAIN ILIKE 'NSO' then 'Retail Inline'
                WHEN EAU.DEPARTMENT_NM is null
                and BCM."Location Type" ILIKE 'Stores'
                and BCM.BUILDING_USE_MAIN in ('NVS', 'FACTORY') then 'Retail Factory'
                WHEN EAU.DEPARTMENT_NM is null
                and BCM."Location Type" ILIKE 'Stores' then 'Retail Other'
                WHEN EAU.DEPARTMENT_NM is null
                and EAU.location_nm ILIKE '%clearance%' then 'Retail Factory'
                WHEN EAU.DEPARTMENT_NM is null
                and EAU.location_nm ILIKE '%store%' then 'Retail Inline'
                WHEN EAU.DEPARTMENT_NM is NULL THEN BCM."Location Type"
                ELSE EAU.DEPARTMENT_NM
            END AS nike_department_type_txt,
            COALESCE(
                EAU.whq_campus_nm,
                EAU.wd_and_c_geo,
                BCM.LOCATION_REGION,
                BCM.CAMPUS_NAME_MAIN
            ) AS property_nm,
            COALESCE(
                EAU.whq_campus_nm,
                EAU.wd_and_c_geo,
                BCM.LOCATION_REGION,
                BCM.CAMPUS_NAME_MAIN
            ) AS BUSINESS_ENTITY_GEO_REGION_CD,
            BCM.BUILDING_USE_MAIN AS ELECTRICITY_LOCATION_USE_CD,
            CASE
                WHEN (EAU.DEPARTMENT_NM IN (
                    'Retail Factory',
                    'Retail Inline',
                    'Retail Other'
                )
                or (
                    EAU.DEPARTMENT_NM is null
                    and (
                        BCM."Location Type" ILIKE 'Stores'
                        or EAU.location_nm ILIKE '%store%'
                    )
                ))
                AND EAU.BRAND_NM = 'Nike' THEN 'DTC (N)'
                WHEN (EAU.DEPARTMENT_NM IN (
                    'Retail Factory',
                    'Retail Inline',
                    'Retail Other'
                )
                or (
                    EAU.DEPARTMENT_NM is null
                    and (
                        BCM."Location Type" ILIKE 'Stores'
                        or EAU.location_nm ILIKE '%store%'
                    )
                ))
                AND EAU.BRAND_NM = 'Converse' THEN 'DTC (C)'
                WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%'
                AND EAU.BRAND_NM = 'Nike' THEN 'Air MI (Nike)'
                WHEN (
                    EAU.DEPARTMENT_NM ILIKE '%HQ%'
                    OR EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
                )
                AND EAU.BRAND_NM = 'Nike' THEN 'WD+C (N)'
                WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
                AND EAU.BRAND_NM = 'Converse' THEN 'WD+C (C)'
                ELSE NULL
            END AS business_function_nm,
            CASE
                WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
                ELSE BCM."NIKE GEO"
            END AS LOCATION_GEO_REGION_CD,
            CASE
                WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
                ELSE BCM."NIKE GEO"
            END AS continent_nm,
            COALESCE(
                EAU.location_address_1_nm,
                BCM.BUILDING_ADDRESS_MAIN
            ) AS ADDRESS_LINE_1_TXT,
            COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN) AS city_nm,
            COALESCE(
                EAU.location_state_or_province_nm,
                BCM.STATE_CODE_MAIN
            ) AS STATE_CD,
            COALESCE(EAU.location_postal_cd, BCM."Zip Code Main") AS POSTAL_CD,
            CONCAT_WS(
                '-',
                COALESCE(EAU.location_postal_cd, BCM."Zip Code Main"),
                COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN)
            ) AS geographical_axis_nm,
            EAU.location_country_nm AS COUNTRY_CD,
            COALESCE(BCM.BUILDING_USF_MAIN,EAU.location_size_sqft) AS LOCATION_AREA_IN_SQFT,
            CASE
                WHEN EAU.location_status_desc = 'Active' THEN 'Open'
                WHEN EAU.location_status_desc = 'Inactive' THEN 'Close'
                ELSE EAU.location_status_desc
            END AS LOCATION_STATUS_CD,
            BCM.LATITUDE_MAIN AS latitude_deg,
            BCM.LONGITUDE_MAIN AS longitude_deg,
            CASE
                WHEN EAU.EMS_DESC = 'EMS Sites' THEN 'EMS'
                ELSE EAU.EMS_DESC
            END AS ADDITIONAL_LOCATION_FEATURE_DESC
        FROM
            EMISSION_AND_USAGE EAU
            LEFT JOIN BUILDING_COMBINE BCM ON CONCAT_WS(
                '-',
                SUBSTRING(
                    REGEXP_REPLACE(EAU.LOCATION_NBR, '[^\\w]'),
                    -3,
                    3
                ),
                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
            ) = CONCAT_WS(
                '-',
                LPAD(
                    SUBSTRING(
                        COALESCE(
                            REGEXP_REPLACE(BCM."Tririga POS Store ID", '[^\\w]'),
                            REGEXP_REPLACE(BCM.BUILDING_CODE_MAIN, '[^\\w]')
                        ),
                        -3,
                        3
                    ),
                    3,
                    '0'
                ),
                REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]')
            )
            OR TRIM(EAU.LEASE_NUMBER_DESC) = TRIM(BCM.TRIRIGA_BUILDING_ID)
        WHERE
            EAU.DEPARTMENT_NM IN(
                'Retail Factory',
                'Retail Inline',
                'Retail Other',
                'Other Offices and Building Construction'
            )
    )
    SELECT
        RETAIL_M.electricity_location_nbr AS electricity_location_nbr,
        RETAIL_M.electricity_location_nm AS electricity_location_nm,
        RETAIL_M.lease_nbr AS lease_nbr,
        RETAIL_M.building_id AS building_id,
        RETAIL_M.business_group_txt AS business_group_txt,
        RETAIL_M.brand_nm AS brand_nm,
        RETAIL_M.nike_department_type_txt AS nike_department_type_txt,
        RETAIL_M.property_nm AS property_nm,
        RETAIL_M.BUSINESS_ENTITY_GEO_REGION_CD AS BUSINESS_ENTITY_GEO_REGION_CD,
        RETAIL_M.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
        RETAIL_M.business_function_nm AS business_function_nm,
        RETAIL_M.LOCATION_GEO_REGION_CD AS LOCATION_GEO_REGION_CD,
        RETAIL_M.continent_nm AS continent_nm,
        RETAIL_M.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
        RETAIL_M.city_nm AS city_nm,
        RETAIL_M.STATE_CD AS STATE_CD,
        RETAIL_M.POSTAL_CD AS POSTAL_CD,
        RETAIL_M.geographical_axis_nm AS geographical_axis_nm,
        RETAIL_M.COUNTRY_CD AS COUNTRY_CD,
        RETAIL_M.LOCATION_AREA_IN_SQFT AS LOCATION_AREA_IN_SQFT,
        RETAIL_M.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
        RETAIL_M.latitude_deg AS latitude_deg,
        RETAIL_M.longitude_deg AS longitude_deg,
        RETAIL_M.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC
    FROM
        RETAIL_PARTITION RETAIL_M
    WHERE
        RETAIL_PART = 1
    UNION ALL
    SELECT
        COALESCE(
            CAST(EAU.LOCATION_NBR AS STRING),
            BCM."Tririga POS Store ID",AIRMI.LOCATION_NUMBER
        ) AS electricity_location_nbr,
        EAU.LOCATION_NM AS electricity_location_nm,
        EAU.LEASE_NUMBER_DESC AS lease_nbr,
        COALESCE(
            EAU.SITE_CD_SITERRA_DESC,
            BCM.TRIRIGA_BUILDING_ID
        ) AS building_id,
        BCM.BUSINESS_GROUP_MAIN AS business_group_txt,
        EAU.BRAND_NM AS brand_nm,
        CASE
            WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction' THEN 'Other Facilities'
            WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%' THEN 'Air MI'
            WHEN EAU.DEPARTMENT_NM is null
            and BCM."Location Type" ILIKE 'Stores'
            and BCM.BUILDING_USE_MAIN ILIKE 'NSO' then 'Retail Inline'
            WHEN EAU.DEPARTMENT_NM is null
            and BCM."Location Type" ILIKE 'Stores'
            and BCM.BUILDING_USE_MAIN in ('NVS', 'FACTORY') then 'Retail Factory'
            WHEN EAU.DEPARTMENT_NM is null
            and BCM."Location Type" ILIKE 'Stores' then 'Retail Other'
            WHEN EAU.DEPARTMENT_NM is null
            and EAU.location_nm ILIKE '%clearance%' then 'Retail Factory'
            WHEN EAU.DEPARTMENT_NM is null
            and EAU.location_nm ILIKE '%store%' then 'Retail Inline'
            WHEN EAU.DEPARTMENT_NM is NULL THEN BCM."Location Type"
            ELSE EAU.DEPARTMENT_NM
        END AS nike_department_type_txt,
        COALESCE(
            EAU.whq_campus_nm,
            EAU.wd_and_c_geo,
            BCM.LOCATION_REGION,
            BCM.CAMPUS_NAME_MAIN
        ) AS property_nm,
        COALESCE(
            EAU.whq_campus_nm,
            EAU.wd_and_c_geo,
            BCM.LOCATION_REGION,
            BCM.CAMPUS_NAME_MAIN
        ) AS BUSINESS_ENTITY_GEO_REGION_CD,
        BCM.BUILDING_USE_MAIN AS ELECTRICITY_LOCATION_USE_CD,
        CASE
            WHEN (EAU.DEPARTMENT_NM IN (
                'Retail Factory',
                'Retail Inline',
                'Retail Other'
            )
            or (
                EAU.DEPARTMENT_NM is null
                and (
                    BCM."Location Type" ILIKE 'Stores'
                    or EAU.location_nm ILIKE '%store%'
                )
            ))
            AND EAU.BRAND_NM = 'Nike' THEN 'DTC (N)'
            WHEN (EAU.DEPARTMENT_NM IN (
                'Retail Factory',
                'Retail Inline',
                'Retail Other'
            )
            or (
                EAU.DEPARTMENT_NM is null
                and (
                    BCM."Location Type" ILIKE 'Stores'
                    or EAU.location_nm ILIKE '%store%'
                )
            ))
            AND EAU.BRAND_NM = 'Converse' THEN 'DTC (C)'
            WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%'
            AND EAU.BRAND_NM = 'Nike' THEN 'Air MI (Nike)'
            WHEN (
                EAU.DEPARTMENT_NM ILIKE '%HQ%'
                OR EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
            )
            AND EAU.BRAND_NM = 'Nike' THEN 'WD+C (N)'
            WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
            AND EAU.BRAND_NM = 'Converse' THEN 'WD+C (C)'
            ELSE NULL
        END AS business_function_nm,
        CASE
            WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
            ELSE BCM."NIKE GEO"
        END AS LOCATION_GEO_REGION_CD,
        CASE
            WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
            ELSE BCM."NIKE GEO"
        END AS continent_nm,
        COALESCE(
            EAU.location_address_1_nm,
            BCM.BUILDING_ADDRESS_MAIN
        ) AS ADDRESS_LINE_1_TXT,
        COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN) AS city_nm,
        COALESCE(
            EAU.location_state_or_province_nm,
            BCM.STATE_CODE_MAIN
        ) AS STATE_CD,
        COALESCE(EAU.location_postal_cd, BCM."Zip Code Main") AS POSTAL_CD,
        CONCAT_WS(
            '-',
            COALESCE(EAU.location_postal_cd, BCM."Zip Code Main"),
            COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN)
        ) AS geographical_axis_nm,
        EAU.location_country_nm AS COUNTRY_CD,
        COALESCE(BCM.BUILDING_USF_MAIN,EAU.location_size_sqft) AS LOCATION_AREA_IN_SQFT,
        CASE
            WHEN EAU.location_status_desc = 'Active' THEN 'Open'
            WHEN EAU.location_status_desc = 'Inactive' THEN 'Close'
            ELSE EAU.location_status_desc
        END AS LOCATION_STATUS_CD,
        BCM.LATITUDE_MAIN AS latitude_deg,
        BCM.LONGITUDE_MAIN AS longitude_deg,
        CASE
            WHEN EAU.EMS_DESC = 'EMS Sites' THEN 'EMS'
            ELSE EAU.EMS_DESC
        END AS ADDITIONAL_LOCATION_FEATURE_DESC
    FROM
        EMISSION_AND_USAGE EAU
        LEFT JOIN {air_mi_mapping_table_name} AIRMI ON EAU.LOCATION_NM = AIRMI.LOCATION_NAME
        LEFT JOIN BUILDING_COMBINE BCM ON AIRMI.BUILDING_ID = BCM.TRIRIGA_BUILDING_ID
    WHERE
        EAU.DEPARTMENT_NM ILIKE '%Air MI%' AND AIRMI.OPERATION_ACTION IN ('XOVERWRITE','XMERGE')
    UNION ALL
        (
            WITH WHQ_INTEGRATION AS (
                WITH WHQ_TRANSFORM AS(
                    SELECT
                        CASE
                            WHEN CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(BCM.building_code_main, '[^\\w]'),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            ) THEN '01_joined by siterra and Building code main match'
                            WHEN REGEXP_REPLACE(
                                LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                '[^\\w]'
                            ) = REGEXP_REPLACE(LOWER(BCM.building_code_main), '[^\\w]') THEN '03_joined by location split and Building code main match'
                            WHEN CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]'),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            ) THEN '02_joined by siterra and tririga building_id match'
                            WHEN REGEXP_REPLACE(EAU.LEASE_NUMBER_DESC, '[^\\w]') = REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]') THEN '04_joined by lease number and tririga building_id match'
                            WHEN CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                    '[^\\w]'
                                ),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                    '[^\\w]'
                                ),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            ) THEN '05_joined by location split and building name main'
                            WHEN CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(LOWER(EAU.location_address_1_nm), '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    REGEXP_REPLACE(LOWER(BCM.BUILDING_ADDRESS_MAIN), '[^\\w]'),
                                    '.,'
                                ),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            ) THEN '06_joined by Address from both tables'
                            WHEN CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(LOWER(EAU.LEASE_NUMBER_DESC), '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                    '[^\\w]'
                                ),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            ) THEN '07_joined by lease number and building name main'
                            ELSE '08_no match'
                        END AS JOIN_CONDITION_CHECK,
                        COALESCE(
                            CAST(EAU.LOCATION_NBR AS STRING),
                            BCM."Tririga POS Store ID"
                        ) AS electricity_location_nbr,
                        EAU.LOCATION_NM AS electricity_location_nm,
                        EAU.LEASE_NUMBER_DESC AS lease_nbr,
                        COALESCE(
                            EAU.SITE_CD_SITERRA_DESC,
                            BCM.TRIRIGA_BUILDING_ID
                        ) AS building_id,
                        BCM.BUSINESS_GROUP_MAIN AS business_group_txt,
                        EAU.BRAND_NM AS brand_nm,
                        CASE
                            WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction' THEN 'Other Facilities'
                            WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%' THEN 'Air MI'
                            WHEN EAU.DEPARTMENT_NM is null
                            and BCM."Location Type" ILIKE 'Stores'
                            and BCM.BUILDING_USE_MAIN ILIKE 'NSO' then 'Retail Inline'
                            WHEN EAU.DEPARTMENT_NM is null
                            and BCM."Location Type" ILIKE 'Stores'
                            and BCM.BUILDING_USE_MAIN in ('NVS', 'FACTORY') then 'Retail Factory'
                            WHEN EAU.DEPARTMENT_NM is null
                            and BCM."Location Type" ILIKE 'Stores' then 'Retail Other'
                            WHEN EAU.DEPARTMENT_NM is null
                            and EAU.location_nm ILIKE '%clearance%' then 'Retail Factory'
                            WHEN EAU.DEPARTMENT_NM is null
                            and EAU.location_nm ILIKE '%store%' then 'Retail Inline'
                            WHEN EAU.DEPARTMENT_NM is NULL THEN BCM."Location Type"
                            ELSE EAU.DEPARTMENT_NM
                        END AS nike_department_type_txt,
                        COALESCE(
                            EAU.whq_campus_nm,
                            EAU.wd_and_c_geo,
                            BCM.LOCATION_REGION,
                            BCM.CAMPUS_NAME_MAIN
                        ) AS property_nm,
                        COALESCE(
                            EAU.whq_campus_nm,
                            EAU.wd_and_c_geo,
                            BCM.LOCATION_REGION,
                            BCM.CAMPUS_NAME_MAIN
                        ) AS BUSINESS_ENTITY_GEO_REGION_CD,
                        BCM.BUILDING_USE_MAIN AS ELECTRICITY_LOCATION_USE_CD,
                        CASE
                            WHEN (EAU.DEPARTMENT_NM IN (
                                'Retail Factory',
                                'Retail Inline',
                                'Retail Other'
                            )
                            or (
                                EAU.DEPARTMENT_NM is null
                                and (
                                    BCM."Location Type" ILIKE 'Stores'
                                    or EAU.location_nm ILIKE '%store%'
                                )
                            ))
                            AND EAU.BRAND_NM = 'Nike' THEN 'DTC (N)'
                            WHEN (EAU.DEPARTMENT_NM IN (
                                'Retail Factory',
                                'Retail Inline',
                                'Retail Other'
                            )
                            or (
                                EAU.DEPARTMENT_NM is null
                                and (
                                    BCM."Location Type" ILIKE 'Stores'
                                    or EAU.location_nm ILIKE '%store%'
                                )
                            ))
                            AND EAU.BRAND_NM = 'Converse' THEN 'DTC (C)'
                            WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%'
                            AND EAU.BRAND_NM = 'Nike' THEN 'Air MI (Nike)'
                            WHEN (
                                EAU.DEPARTMENT_NM ILIKE '%HQ%'
                                OR EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
                            )
                            AND EAU.BRAND_NM = 'Nike' THEN 'WD+C (N)'
                            WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
                            AND EAU.BRAND_NM = 'Converse' THEN 'WD+C (C)'
                            ELSE NULL
                        END AS business_function_nm,
                        CASE
                            WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
                            ELSE BCM."NIKE GEO"
                        END AS LOCATION_GEO_REGION_CD,
                        CASE
                            WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
                            ELSE BCM."NIKE GEO"
                        END AS continent_nm,
                        COALESCE(
                            EAU.location_address_1_nm,
                            BCM.BUILDING_ADDRESS_MAIN
                        ) AS ADDRESS_LINE_1_TXT,
                        COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN) AS city_nm,
                        COALESCE(
                            EAU.location_state_or_province_nm,
                            BCM.STATE_CODE_MAIN
                        ) AS STATE_CD,
                        COALESCE(EAU.location_postal_cd, BCM."Zip Code Main") AS POSTAL_CD,
                        CONCAT_WS(
                            '-',
                            COALESCE(EAU.location_postal_cd, BCM."Zip Code Main"),
                            COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN)
                        ) AS geographical_axis_nm,
                        EAU.location_country_nm AS COUNTRY_CD,
                        COALESCE(BCM.BUILDING_USF_MAIN,EAU.location_size_sqft) AS LOCATION_AREA_IN_SQFT,
                        CASE
                            WHEN EAU.location_status_desc = 'Active' THEN 'Open'
                            WHEN EAU.location_status_desc = 'Inactive' THEN 'Close'
                            ELSE EAU.location_status_desc
                        END AS LOCATION_STATUS_CD,
                        BCM.LATITUDE_MAIN AS latitude_deg,
                        BCM.LONGITUDE_MAIN AS longitude_deg,
                        CASE
                            WHEN EAU.EMS_DESC = 'EMS Sites' THEN 'EMS'
                            ELSE EAU.EMS_DESC
                        END AS ADDITIONAL_LOCATION_FEATURE_DESC
                    FROM
                        EMISSION_AND_USAGE EAU
                        LEFT JOIN BUILDING_COMBINE BCM ON CONCAT_WS(
                            '-',
                            REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                            REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                        ) = CONCAT_WS(
                            '-',
                            REGEXP_REPLACE(BCM.building_code_main, '[^\\w]'),
                            LPAD(
                                REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                5,
                                '0'
                            )
                        )
                        OR (
                            CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                    '[^\\w]'
                                ),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                    '[^\\w]'
                                ),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            )
                        )
                        OR (
                            REGEXP_REPLACE(
                                LOWER(SPLIT_PART(EAU.LOCATION_NM, '-', 1)),
                                '[^\\w]'
                            ) = REGEXP_REPLACE(LOWER(BCM.building_code_main), '[^\\w]')
                        )
                        OR (
                            CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(EAU.SITE_CD_SITERRA_DESC, '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]'),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            )
                        )
                        OR (
                            REGEXP_REPLACE(EAU.LEASE_NUMBER_DESC, '[^\\w]') = REGEXP_REPLACE(BCM.TRIRIGA_BUILDING_ID, '[^\\w]')
                        )
                        OR (
                            CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(LOWER(EAU.location_address_1_nm), '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    REGEXP_REPLACE(LOWER(BCM.BUILDING_ADDRESS_MAIN), '[^\\w]'),
                                    '.,'
                                ),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            )
                        )
                        OR (
                            CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(LOWER(EAU.LEASE_NUMBER_DESC), '[^\\w]'),
                                REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                            ) = CONCAT_WS(
                                '-',
                                REGEXP_REPLACE(
                                    LOWER(SPLIT_PART(BCM.BUILDING_NAME_MAIN, '(', 1)),
                                    '[^\\w]'
                                ),
                                LPAD(
                                    REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]'),
                                    5,
                                    '0'
                                )
                            )
                        )
                    WHERE
                        EAU.DEPARTMENT_NM = 'WHQ'
                )
                SELECT
                    ROW_NUMBER() OVER(
                        PARTITION BY WHQ_TRANSFORM.electricity_location_nbr,
                        WHQ_TRANSFORM.electricity_location_nm
                        ORDER BY
                            WHQ_TRANSFORM.JOIN_CONDITION_CHECK ASC
                    ) AS WHQ_PART,
                    WHQ_TRANSFORM.electricity_location_nbr,
                    WHQ_TRANSFORM.electricity_location_nm,
                    WHQ_TRANSFORM.lease_nbr,
                    WHQ_TRANSFORM.building_id,
                    WHQ_TRANSFORM.business_group_txt,
                    WHQ_TRANSFORM.brand_nm,
                    WHQ_TRANSFORM.nike_department_type_txt,
                    WHQ_TRANSFORM.property_nm,
                    WHQ_TRANSFORM.BUSINESS_ENTITY_GEO_REGION_CD,
                    WHQ_TRANSFORM.ELECTRICITY_LOCATION_USE_CD,
                    WHQ_TRANSFORM.business_function_nm,
                    WHQ_TRANSFORM.LOCATION_GEO_REGION_CD,
                    WHQ_TRANSFORM.continent_nm,
                    WHQ_TRANSFORM.ADDRESS_LINE_1_TXT,
                    WHQ_TRANSFORM.city_nm,
                    WHQ_TRANSFORM.STATE_CD,
                    WHQ_TRANSFORM.POSTAL_CD,
                    WHQ_TRANSFORM.geographical_axis_nm,
                    WHQ_TRANSFORM.COUNTRY_CD,
                    WHQ_TRANSFORM.LOCATION_AREA_IN_SQFT,
                    WHQ_TRANSFORM.LOCATION_STATUS_CD,
                    WHQ_TRANSFORM.latitude_deg,
                    WHQ_TRANSFORM.longitude_deg,
                    WHQ_TRANSFORM.ADDITIONAL_LOCATION_FEATURE_DESC
                FROM
                    WHQ_TRANSFORM WHQ_TRANSFORM
            )
            SELECT
                WHQ_INT.electricity_location_nbr,
                WHQ_INT.electricity_location_nm,
                WHQ_INT.lease_nbr,
                WHQ_INT.building_id,
                WHQ_INT.business_group_txt,
                WHQ_INT.brand_nm,
                WHQ_INT.nike_department_type_txt,
                WHQ_INT.property_nm,
                WHQ_INT.BUSINESS_ENTITY_GEO_REGION_CD,
                WHQ_INT.ELECTRICITY_LOCATION_USE_CD,
                WHQ_INT.business_function_nm,
                WHQ_INT.LOCATION_GEO_REGION_CD,
                WHQ_INT.continent_nm,
                WHQ_INT.ADDRESS_LINE_1_TXT,
                WHQ_INT.city_nm,
                WHQ_INT.STATE_CD,
                WHQ_INT.POSTAL_CD,
                WHQ_INT.geographical_axis_nm,
                WHQ_INT.COUNTRY_CD,
                WHQ_INT.LOCATION_AREA_IN_SQFT,
                WHQ_INT.LOCATION_STATUS_CD,
                WHQ_INT.latitude_deg,
                WHQ_INT.longitude_deg,
                WHQ_INT.ADDITIONAL_LOCATION_FEATURE_DESC
            FROM
                WHQ_INTEGRATION WHQ_INT
            WHERE
                WHQ_PART = 1
        )
    UNION ALL
        (
            WITH RETAIL_DEPT_PART AS (
            WITH RETAIL_NULL_PART AS (
                SELECT
                    CASE WHEN CONCAT_WS(
                        '-',
                        SUBSTRING(
                            REGEXP_REPLACE(EAU.LOCATION_NBR, '[^\\w]'),
                            -3,
                            3
                        ),
                        REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                    ) = CONCAT_WS(
                        '-',
                        LPAD(
                            SUBSTRING(
                                COALESCE(
                                    REGEXP_REPLACE(BCM."Tririga POS Store ID", '[^\\w]'),
                                    REGEXP_REPLACE(BCM.BUILDING_CODE_MAIN, '[^\\w]')
                                ),
                                -3,
                                3
                            ),
                            3,
                            '0'
                        ),
                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]')
                    ) THEN '01_location_nbr_and_tririga_pos_store_id'
                    WHEN TRIM(EAU.LEASE_NUMBER_DESC) = TRIM(BCM.TRIRIGA_BUILDING_ID) THEN '02_lease_nbr_and_building_id'
                    WHEN TRIM(EAU.location_postal_cd)=TRIM(BCM.TRIRIGA_ZIP_POSTAL_CODE) THEN '03_zip_code'
                    ELSE '04_no_match'
                    END AS dept_null_joining_key,
                    COALESCE(
                        CAST(EAU.LOCATION_NBR AS STRING),
                        BCM."Tririga POS Store ID"
                    ) AS electricity_location_nbr,
                    EAU.LOCATION_NM AS electricity_location_nm,
                    EAU.LEASE_NUMBER_DESC AS lease_nbr,
                    ROW_NUMBER() OVER(
                        PARTITION BY EAU.LOCATION_NBR,
                        EAU.LOCATION_NM
                        ORDER BY
                            BCM."Tririga POS Store ID"
                    ) AS RETAIL_PART,
                    COALESCE(
                        EAU.SITE_CD_SITERRA_DESC,
                        BCM.TRIRIGA_BUILDING_ID
                    ) AS building_id,
                    BCM.BUSINESS_GROUP_MAIN AS business_group_txt,
                    EAU.BRAND_NM AS brand_nm,
                    CASE
                        WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction' THEN 'Other Facilities'
                        WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%' THEN 'Air MI'
                        WHEN EAU.DEPARTMENT_NM is null
                        and BCM."Location Type" ILIKE 'Stores'
                        and BCM.BUILDING_USE_MAIN ILIKE 'NSO' then 'Retail Inline'
                        WHEN EAU.DEPARTMENT_NM is null
                        and BCM."Location Type" ILIKE 'Stores'
                        and BCM.BUILDING_USE_MAIN in ('NVS', 'FACTORY') then 'Retail Factory'
                        WHEN EAU.DEPARTMENT_NM is null
                        and BCM."Location Type" ILIKE 'Stores' then 'Retail Other'
                        WHEN EAU.DEPARTMENT_NM is null
                        and EAU.location_nm ILIKE '%clearance%' then 'Retail Factory'
                        WHEN EAU.DEPARTMENT_NM is null
                        and EAU.location_nm ILIKE '%store%' then 'Retail Inline'
                        WHEN EAU.DEPARTMENT_NM is NULL THEN BCM."Location Type"
                        ELSE EAU.DEPARTMENT_NM
                    END AS nike_department_type_txt,
                    COALESCE(
                        EAU.whq_campus_nm,
                        EAU.wd_and_c_geo,
                        BCM.LOCATION_REGION,
                        BCM.CAMPUS_NAME_MAIN
                    ) AS property_nm,
                    COALESCE(
                        EAU.whq_campus_nm,
                        EAU.wd_and_c_geo,
                        BCM.LOCATION_REGION,
                        BCM.CAMPUS_NAME_MAIN
                    ) AS BUSINESS_ENTITY_GEO_REGION_CD,
                    BCM.BUILDING_USE_MAIN AS ELECTRICITY_LOCATION_USE_CD,
                    CASE
                        WHEN (EAU.DEPARTMENT_NM IN (
                            'Retail Factory',
                            'Retail Inline',
                            'Retail Other'
                        )
                        or (
                            EAU.DEPARTMENT_NM is null
                            and (
                                BCM."Location Type" ILIKE 'Stores'
                                or EAU.location_nm ILIKE '%store%'
                            )
                        ))
                        AND EAU.BRAND_NM = 'Nike' THEN 'DTC (N)'
                        WHEN (EAU.DEPARTMENT_NM IN (
                            'Retail Factory',
                            'Retail Inline',
                            'Retail Other'
                        )
                        or (
                            EAU.DEPARTMENT_NM is null
                            and (
                                BCM."Location Type" ILIKE 'Stores'
                                or EAU.location_nm ILIKE '%store%'
                            )
                        ))
                        AND EAU.BRAND_NM = 'Converse' THEN 'DTC (C)'
                        WHEN EAU.DEPARTMENT_NM ILIKE '%Air MI%'
                        AND EAU.BRAND_NM = 'Nike' THEN 'Air MI (Nike)'
                        WHEN (
                            EAU.DEPARTMENT_NM ILIKE '%HQ%'
                            OR EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
                        )
                        AND EAU.BRAND_NM = 'Nike' THEN 'WD+C (N)'
                        WHEN EAU.DEPARTMENT_NM = 'Other Offices and Building Construction'
                        AND EAU.BRAND_NM = 'Converse' THEN 'WD+C (C)'
                        ELSE NULL
                    END AS business_function_nm,
                    CASE
                        WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
                        ELSE BCM."NIKE GEO"
                    END AS LOCATION_GEO_REGION_CD,
                    CASE
                        WHEN EAU.location_country_nm IN ('United States', 'Canada') THEN 'North America'
                        ELSE BCM."NIKE GEO"
                    END AS continent_nm,
                    COALESCE(
                        EAU.location_address_1_nm,
                        BCM.BUILDING_ADDRESS_MAIN
                    ) AS ADDRESS_LINE_1_TXT,
                    COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN) AS city_nm,
                    COALESCE(
                        EAU.location_state_or_province_nm,
                        BCM.STATE_CODE_MAIN
                    ) AS STATE_CD,
                    COALESCE(EAU.location_postal_cd, BCM."Zip Code Main") AS POSTAL_CD,
                    CONCAT_WS(
                        '-',
                        COALESCE(EAU.location_postal_cd, BCM."Zip Code Main"),
                        COALESCE(EAU.location_city_nm, BCM.CITY_CODE_MAIN)
                    ) AS geographical_axis_nm,
                    EAU.location_country_nm AS COUNTRY_CD,
                    COALESCE(BCM.BUILDING_USF_MAIN,EAU.location_size_sqft) AS LOCATION_AREA_IN_SQFT,
                    CASE
                        WHEN EAU.location_status_desc = 'Active' THEN 'Open'
                        WHEN EAU.location_status_desc = 'Inactive' THEN 'Close'
                        ELSE EAU.location_status_desc
                    END AS LOCATION_STATUS_CD,
                    BCM.LATITUDE_MAIN AS latitude_deg,
                    BCM.LONGITUDE_MAIN AS longitude_deg,
                    CASE
                        WHEN EAU.EMS_DESC = 'EMS Sites' THEN 'EMS'
                        ELSE EAU.EMS_DESC
                    END AS ADDITIONAL_LOCATION_FEATURE_DESC
                FROM
                    EMISSION_AND_USAGE EAU
                    LEFT JOIN BUILDING_COMBINE BCM ON CONCAT_WS(
                        '-',
                        SUBSTRING(
                            REGEXP_REPLACE(EAU.LOCATION_NBR, '[^\\w]'),
                            -3,
                            3
                        ),
                        REGEXP_REPLACE(EAU.location_postal_cd, '[^\\w]')
                    ) = CONCAT_WS(
                        '-',
                        LPAD(
                            SUBSTRING(
                                COALESCE(
                                    REGEXP_REPLACE(BCM."Tririga POS Store ID", '[^\\w]'),
                                    REGEXP_REPLACE(BCM.BUILDING_CODE_MAIN, '[^\\w]')
                                ),
                                -3,
                                3
                            ),
                            3,
                            '0'
                        ),
                        REGEXP_REPLACE(BCM.TRIRIGA_ZIP_POSTAL_CODE, '[^\\w]')
                    )
                    OR TRIM(EAU.LEASE_NUMBER_DESC) = TRIM(BCM.TRIRIGA_BUILDING_ID)
                    OR TRIM(EAU.location_postal_cd)=TRIM(BCM.TRIRIGA_ZIP_POSTAL_CODE)
                WHERE
                    EAU.DEPARTMENT_NM IS NULL
            )
            SELECT
            
             ROW_NUMBER() OVER(PARTITION BY RETAIL_M.electricity_location_nbr,
                        RETAIL_M.electricity_location_nm
                        ORDER BY
                            RETAIL_M.dept_null_joining_key ASC
                    ) AS dept_null_part,
                RETAIL_M.electricity_location_nbr AS electricity_location_nbr,
                RETAIL_M.electricity_location_nm AS electricity_location_nm,
                RETAIL_M.lease_nbr AS lease_nbr,
                RETAIL_M.building_id AS building_id,
                RETAIL_M.business_group_txt AS business_group_txt,
                RETAIL_M.brand_nm AS brand_nm,
                RETAIL_M.nike_department_type_txt AS nike_department_type_txt,
                RETAIL_M.property_nm AS property_nm,
                RETAIL_M.BUSINESS_ENTITY_GEO_REGION_CD AS BUSINESS_ENTITY_GEO_REGION_CD,
                RETAIL_M.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
                RETAIL_M.business_function_nm AS business_function_nm,
                RETAIL_M.LOCATION_GEO_REGION_CD AS LOCATION_GEO_REGION_CD,
                RETAIL_M.continent_nm AS continent_nm,
                RETAIL_M.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
                RETAIL_M.city_nm AS city_nm,
                RETAIL_M.STATE_CD AS STATE_CD,
                RETAIL_M.POSTAL_CD AS POSTAL_CD,
                RETAIL_M.geographical_axis_nm AS geographical_axis_nm,
                RETAIL_M.COUNTRY_CD AS COUNTRY_CD,
                RETAIL_M.LOCATION_AREA_IN_SQFT AS LOCATION_AREA_IN_SQFT,
                RETAIL_M.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
                RETAIL_M.latitude_deg AS latitude_deg,
                RETAIL_M.longitude_deg AS longitude_deg,
                RETAIL_M.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC
            FROM
                RETAIL_NULL_PART RETAIL_M
            WHERE
                RETAIL_PART = 1
                )
             SELECT
                RETAIL_DEPT_PART.electricity_location_nbr AS electricity_location_nbr,
                RETAIL_DEPT_PART.electricity_location_nm AS electricity_location_nm,
                RETAIL_DEPT_PART.lease_nbr AS lease_nbr,
                RETAIL_DEPT_PART.building_id AS building_id,
                RETAIL_DEPT_PART.business_group_txt AS business_group_txt,
                RETAIL_DEPT_PART.brand_nm AS brand_nm,
                RETAIL_DEPT_PART.nike_department_type_txt AS nike_department_type_txt,
                RETAIL_DEPT_PART.property_nm AS property_nm,
                RETAIL_DEPT_PART.BUSINESS_ENTITY_GEO_REGION_CD AS BUSINESS_ENTITY_GEO_REGION_CD,
                RETAIL_DEPT_PART.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
                RETAIL_DEPT_PART.business_function_nm AS business_function_nm,
                RETAIL_DEPT_PART.LOCATION_GEO_REGION_CD AS LOCATION_GEO_REGION_CD,
                RETAIL_DEPT_PART.continent_nm AS continent_nm,
                RETAIL_DEPT_PART.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
                RETAIL_DEPT_PART.city_nm AS city_nm,
                RETAIL_DEPT_PART.STATE_CD AS STATE_CD,
                RETAIL_DEPT_PART.POSTAL_CD AS POSTAL_CD,
                RETAIL_DEPT_PART.geographical_axis_nm AS geographical_axis_nm,
                RETAIL_DEPT_PART.COUNTRY_CD AS COUNTRY_CD,
                RETAIL_DEPT_PART.LOCATION_AREA_IN_SQFT AS LOCATION_AREA_IN_SQFT,
                RETAIL_DEPT_PART.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
                RETAIL_DEPT_PART.latitude_deg AS latitude_deg,
                RETAIL_DEPT_PART.longitude_deg AS longitude_deg,
                RETAIL_DEPT_PART.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC
            FROM
                RETAIL_DEPT_PART RETAIL_DEPT_PART 
            WHERE dept_null_part = 1
        )
)
SELECT
    uuid_string(
        '8e884ace-bee4-11e4-8dfc-aa07a5b093db',
        md5(
            concat(
                ELECTRIC_SITE.electricity_location_nbr,
                ELECTRIC_SITE.electricity_location_nm
            )
        )
    ) as electricity_consumption_uuid,
    ELECTRIC_SITE.electricity_location_nbr AS electricity_location_nbr,
    ELECTRIC_SITE.electricity_location_nm AS electricity_location_nm,
    ELECTRIC_SITE.lease_nbr AS lease_nbr,
    ELECTRIC_SITE.building_id AS building_id,
    REGEXP_REPLACE(INITCAP(ELECTRIC_SITE.business_group_txt),'-',' ') AS business_group_txt,
    INITCAP(ELECTRIC_SITE.brand_nm) AS brand_nm,
    ELECTRIC_SITE.nike_department_type_txt,
    ELECTRIC_SITE.property_nm AS property_nm,
    CASE WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
        WHEN ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
        ELSE ELECTRIC_SITE.BUSINESS_ENTITY_GEO_REGION_CD
    END AS BUSINESS_ENTITY_GEO_REGION_CD,
    ELECTRIC_SITE.ELECTRICITY_LOCATION_USE_CD AS ELECTRICITY_LOCATION_USE_CD,
    ELECTRIC_SITE.business_function_nm AS business_function_nm,
    CASE
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Inline'
        AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Retail Inline (N)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Other'
        AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Retail Other (N)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Factory'
        AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Retail Factory (N)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Inline'
        AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Retail Inline (C)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Other'
        AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Retail Other (C)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Retail Factory'
        AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Retail Factory (C)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'WHQ'
        AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Headquarters (N)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'WHQ'
        AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Headquarters (C)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Other Facilities'
        AND ELECTRIC_SITE.BRAND_NM = 'Nike' THEN 'Other Facilities (N)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Other Facilities'
        AND ELECTRIC_SITE.BRAND_NM = 'Converse' THEN 'Other Facilities (C)'
        WHEN ELECTRIC_SITE.NIKE_DEPARTMENT_TYPE_TXT = 'Air MI' THEN 'Air MI - Facilities'
        ELSE NULL
    END AS division_nm,
    CASE WHEN ELECTRIC_SITE.LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN ELECTRIC_SITE.LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
        ELSE ELECTRIC_SITE.LOCATION_GEO_REGION_CD
    END AS LOCATION_GEO_REGION_CD,
    CASE
        WHEN ELECTRIC_SITE.continent_nm ILIKE 'EMEA' THEN 'Europe'
        WHEN ELECTRIC_SITE.continent_nm ILIKE 'APLA' THEN 'Asia'
        WHEN ELECTRIC_SITE.continent_nm ILIKE 'North America' THEN 'North America'
        WHEN ELECTRIC_SITE.continent_nm ILIKE 'Greater China' THEN 'Asia'
        ELSE ELECTRIC_SITE.continent_nm
    END AS continent_nm,
    ELECTRIC_SITE.ADDRESS_LINE_1_TXT AS ADDRESS_LINE_1_TXT,
    INITCAP(ELECTRIC_SITE.city_nm) AS city_nm,
    ELECTRIC_SITE.STATE_CD AS STATE_CD,
    ELECTRIC_SITE.POSTAL_CD AS POSTAL_CD,
    ELECTRIC_SITE.geographical_axis_nm AS geographical_axis_nm,
    CASE WHEN ELECTRIC_SITE.COUNTRY_CD ILIKE 'Canada' THEN 'CA'
        WHEN ELECTRIC_SITE.COUNTRY_CD ILIKE 'United States' THEN 'US'
        ELSE ELECTRIC_SITE.COUNTRY_CD
    END AS COUNTRY_CD,
    ELECTRIC_SITE.LOCATION_AREA_IN_SQFT AS LOCATION_AREA_IN_SQFT,
    ELECTRIC_SITE.LOCATION_STATUS_CD AS LOCATION_STATUS_CD,
    ELECTRIC_SITE.latitude_deg AS latitude_deg,
    ELECTRIC_SITE.longitude_deg AS longitude_deg,
    ELECTRIC_SITE.ADDITIONAL_LOCATION_FEATURE_DESC AS ADDITIONAL_LOCATION_FEATURE_DESC,
    'emission_and_usage_metrics' AS data_source_nm
FROM
    SITE_INTEGRATION ELECTRIC_SITE
) ES_SOURCE_T ON CONCAT_WS(
    '_',
    ES_DEST_T.electricity_consumption_uuid,
    ES_DEST_T.electricity_location_nbr,
    ES_DEST_T.electricity_location_nm
) = CONCAT_WS(
    '_',
    ES_SOURCE_T.electricity_consumption_uuid,
    ES_SOURCE_T.electricity_location_nbr,
    ES_SOURCE_T.electricity_location_nm
)
WHEN MATCHED THEN
UPDATE
SET
    ES_DEST_T.lease_nbr = ES_SOURCE_T.lease_nbr,
    ES_DEST_T.building_id = ES_SOURCE_T.building_id,
    ES_DEST_T.business_group_txt = ES_SOURCE_T.business_group_txt,
    ES_DEST_T.brand_nm = ES_SOURCE_T.brand_nm,
    ES_DEST_T.nike_department_type_txt = ES_SOURCE_T.nike_department_type_txt,
    ES_DEST_T.property_nm = ES_SOURCE_T.property_nm,
    ES_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD = ES_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
    ES_DEST_T.ELECTRICITY_LOCATION_USE_CD = ES_SOURCE_T.ELECTRICITY_LOCATION_USE_CD,
    ES_DEST_T.business_function_nm = ES_SOURCE_T.business_function_nm,
    ES_DEST_T.division_nm = ES_SOURCE_T.division_nm,
    ES_DEST_T.LOCATION_GEO_REGION_CD = ES_SOURCE_T.LOCATION_GEO_REGION_CD,
    ES_DEST_T.continent_nm = ES_SOURCE_T.continent_nm,
    ES_DEST_T.ADDRESS_LINE_1_TXT = ES_SOURCE_T.ADDRESS_LINE_1_TXT,
    ES_DEST_T.city_nm = ES_SOURCE_T.city_nm,
    ES_DEST_T.STATE_CD = ES_SOURCE_T.STATE_CD,
    ES_DEST_T.POSTAL_CD = ES_SOURCE_T.POSTAL_CD,
    ES_DEST_T.geographical_axis_nm = ES_SOURCE_T.geographical_axis_nm,
    ES_DEST_T.COUNTRY_CD = ES_SOURCE_T.COUNTRY_CD,
    ES_DEST_T.LOCATION_AREA_IN_SQFT = ES_SOURCE_T.LOCATION_AREA_IN_SQFT,
    ES_DEST_T.LOCATION_STATUS_CD = ES_SOURCE_T.LOCATION_STATUS_CD,
    ES_DEST_T.latitude_deg = ES_SOURCE_T.latitude_deg,
    ES_DEST_T.longitude_deg = ES_SOURCE_T.longitude_deg,
    ES_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC = ES_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
    ES_DEST_T.data_source_nm = ES_SOURCE_T.data_source_nm
    WHEN NOT MATCHED THEN
INSERT
    (
        ES_DEST_T.electricity_consumption_uuid,
        ES_DEST_T.electricity_location_nbr,
        ES_DEST_T.electricity_location_nm,
        ES_DEST_T.lease_nbr,
        ES_DEST_T.building_id,
        ES_DEST_T.business_group_txt,
        ES_DEST_T.brand_nm,
        ES_DEST_T.nike_department_type_txt,
        ES_DEST_T.property_nm,
        ES_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD,
        ES_DEST_T.ELECTRICITY_LOCATION_USE_CD,
        ES_DEST_T.business_function_nm,
        ES_DEST_T.division_nm,
        ES_DEST_T.LOCATION_GEO_REGION_CD,
        ES_DEST_T.continent_nm,
        ES_DEST_T.ADDRESS_LINE_1_TXT,
        ES_DEST_T.city_nm,
        ES_DEST_T.STATE_CD,
        ES_DEST_T.POSTAL_CD,
        ES_DEST_T.geographical_axis_nm,
        ES_DEST_T.COUNTRY_CD,
        ES_DEST_T.LOCATION_AREA_IN_SQFT,
        ES_DEST_T.LOCATION_STATUS_CD,
        ES_DEST_T.latitude_deg,
        ES_DEST_T.longitude_deg,
        ES_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        ES_DEST_T.data_source_nm
    )
VALUES
    (
        ES_SOURCE_T.electricity_consumption_uuid,
        ES_SOURCE_T.electricity_location_nbr,
        ES_SOURCE_T.electricity_location_nm,
        ES_SOURCE_T.lease_nbr,
        ES_SOURCE_T.building_id,
        ES_SOURCE_T.business_group_txt,
        ES_SOURCE_T.brand_nm,
        ES_SOURCE_T.nike_department_type_txt,
        ES_SOURCE_T.property_nm,
        ES_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
        ES_SOURCE_T.ELECTRICITY_LOCATION_USE_CD,
        ES_SOURCE_T.business_function_nm,
        ES_SOURCE_T.division_nm,
        ES_SOURCE_T.LOCATION_GEO_REGION_CD,
        ES_SOURCE_T.continent_nm,
        ES_SOURCE_T.ADDRESS_LINE_1_TXT,
        ES_SOURCE_T.city_nm,
        ES_SOURCE_T.STATE_CD,
        ES_SOURCE_T.POSTAL_CD,
        ES_SOURCE_T.geographical_axis_nm,
        ES_SOURCE_T.COUNTRY_CD,
        ES_SOURCE_T.LOCATION_AREA_IN_SQFT,
        ES_SOURCE_T.LOCATION_STATUS_CD,
        ES_SOURCE_T.latitude_deg,
        ES_SOURCE_T.longitude_deg,
        ES_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        ES_SOURCE_T.data_source_nm
    );