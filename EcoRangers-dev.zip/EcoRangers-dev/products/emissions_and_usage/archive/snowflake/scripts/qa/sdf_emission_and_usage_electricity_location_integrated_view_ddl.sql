-----ELECTRICITY_USAGE_LOCATION_INTEGRATED_V DDL--------
USE ROLE APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE;
CREATE VIEW IF NOT EXISTS global_sustainability_qa.bcl_sustainability_foundation.ELECTRICITY_USAGE_LOCATION_INTEGRATED_V AS
SELECT
    SUBSTR(REGEXP_REPLACE(electricity_consumption_uuid,'[^a-zA-Z0-9]'),1,10) AS electricity_consumption_uuid,
    electricity_location_nbr,
    electricity_location_nm,
    lease_nbr,
    building_id,
    business_group_txt,
    brand_nm,
    nike_department_type_txt,
    property_nm,
    BUSINESS_ENTITY_GEO_REGION_CD,
    ELECTRICITY_LOCATION_USE_CD,
    business_function_nm,
    division_nm,
    LOCATION_GEO_REGION_CD,
    continent_nm,
    ADDRESS_LINE_1_TXT,
    city_nm,
    STATE_CD AS state_cd,
    POSTAL_CD,
    geographical_axis_nm,
    COUNTRY_CD,
    LOCATION_AREA_IN_SQFT,
    LOCATION_STATUS_CD,
    latitude_deg,
    longitude_deg,
    ADDITIONAL_LOCATION_FEATURE_DESC,
    BATCH_LOAD_TIMESTAMP
FROM
    global_sustainability_qa.bcl_sustainability_foundation.ELECTRICITY_USAGE_LOCATION_INTEGRATED_T
    ;