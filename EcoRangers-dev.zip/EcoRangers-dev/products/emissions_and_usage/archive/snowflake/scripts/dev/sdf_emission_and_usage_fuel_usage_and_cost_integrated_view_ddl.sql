-----FUEL_USAGE_CONSUMPTION_INTEGRATED_V DDL--------
USE ROLE APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE;
CREATE VIEW IF NOT EXISTS global_sustainability_dev.bcl_sustainability_foundation.FUEL_USAGE_CONSUMPTION_INTEGRATED_V AS
SELECT
    SUBSTR(REGEXP_REPLACE(fuel_consumption_uuid,'[^a-zA-Z0-9]'),1,10) AS fuel_consumption_uuid,
    fuel_location_nbr,
    fuel_location_nm,
    reporting_period_dt,
    SERVICE_TYPE_CD,
    BILLING_MONTH_START_DT,
    BILLING_MONTH_END_DT,
    BILLING_MONTH_DATE_RANGE_TXT,
    REPORTING_FISCAL_YEAR_NBR,
    REPORTING_CALENDAR_YEAR_NBR,
    REPORTING_MONTH_LONG_NM,
    REPORTING_MONTH_OF_YEAR_NBR,
    REPORTING_QUARTER_NBR,
    REPORTING_WEEK_OF_YEAR_NBR,
    building_id,
    fuel_type_txt,
    saf_pct,
    saf_density_uom AS "SAF_DENSITY_Kg/m3",
    net_heat_of_combustion_uom AS "NET_HEAT_OF_COMBUSTION_MJ/Kg",
    DATA_FREQUENCY_CD,
    SERVICE_USAGE_QTY,
    SERVICE_USAGE_QTY_UOM,
    SERVICE_COST,
    SERVICE_COST_UOM,
    extrapolation_ind,
    scope_nbr,
    BATCH_LOAD_TIMESTAMP
FROM
    global_sustainability_dev.bcl_sustainability_foundation.FUEL_USAGE_CONSUMPTION_INTEGRATED_T
    ;