# Product directory for Engie

This product contains the datasets for emissions and usage metrics provided by Engie Portal for NA region.

Product Details:

| Section          |              Details              |
| ---------------- | :-------------------------------: |
| Vendor Name      |               Engie               |
| Vendor Webpage   | https://platform1.engieimpact.com |
| Report Name      |       Use Cost and Analysis       |
| Data Format      |                CSV                |
| Point of contact |      Felicia.Beier@engie.com      |
