MERGE INTO global_sustainability_qa.bcl_sustainability_foundation.FUEL_SITE_AND_DETAIL_T AS FSD_DEST_T USING (
    SELECT
        entity_nbr,
        reporting_period_dt,
        COALESCE(MAX(usage_type_desc), MIN(usage_type_desc)) AS usage_type_desc,
        BILLING_MONTH_START_DT,
        BILLING_MONTH_END_DT,
        BILLING_MONTH_DATE_RANGE_TXT,
        entity_nm,
        lease_nbr,
        business_group_desc,
        brand_nm,
        entity_type_desc,
        BUSINESS_ENTITY_GEO_REGION_CD,
        entity_use,
        business_function_nm,
        division_nm,
        LOCATION_GEO_REGION_CD,
        continent_nm,
        ADDRESS_LINE_1_TXT,
        city_nm,
        STATE_CD,
        POSTAL_CD,
        geographical_axis_nm,
        COUNTRY_CD,
        LOCATION_AREA_IN_SQFT,
        LOCATION_STATUS_CD,
        latitude_deg,
        longitude_deg,
        ADDITIONAL_LOCATION_FEATURE_DESC,
        fiscal_year_yrs,
        calendar_year_yrs,
        month_nm,
        month_nbr,
        quarter_cd,
        week_wks,
        building_id,
        service_type_desc,
        fuel_type_desc,
        saf_pct,
        saf_density_uom,
        DATA_FREQUENCY_CD,
        COALESCE(MAX(SERVICE_USAGE_QTY), MIN(SERVICE_USAGE_QTY)) AS SERVICE_USAGE_QTY,
        COALESCE(MAX(SERVICE_USAGE_QTY_UOM), MIN(SERVICE_USAGE_QTY_UOM)) AS SERVICE_USAGE_QTY_UOM,
        COALESCE(MAX(cost_type_desc), MIN(cost_type_desc)) AS cost_type_desc,
        COALESCE(MAX(SERVICE_COST), MIN(SERVICE_COST)) AS SERVICE_COST,
        COALESCE(MAX(SERVICE_COST_UOM), MIN(SERVICE_COST_UOM)) AS SERVICE_COST_UOM,
        extrapolation_indicator,
        scope_nbr
    FROM
        (
            SELECT
                logf.LOCATION_KEY AS entity_nbr,
                TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'MM/dd/yyyy'
                ) AS reporting_period_dt,
                CASE
                    WHEN logf.PARENT = 'NATURAL_GAS_SCOPE1' THEN 'Natural Gas Consumption Volume'
                    WHEN logf.PARENT = 'HI_SENE_SCOPE1' THEN 'HI SENE Consumption'
                    WHEN logf.PARENT = 'PURCHASED_GAS_BIO_GAS' THEN 'Bio Gas Consumption'
                    ELSE NULL
                END AS usage_type_desc,
                TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'MM/dd/yyyy'
                ) AS BILLING_MONTH_START_DT,
                TO_VARCHAR(
                    LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')),
                    'MM/dd/yyyy'
                ) AS BILLING_MONTH_END_DT,
                CONCAT(
                    TO_VARCHAR(
                        TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                        'MM/dd/yyyy'
                    ),
                    '-',
                    TO_VARCHAR(
                        LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')),
                        'MM/dd/yyyy'
                    )
                ) AS BILLING_MONTH_DATE_RANGE_TXT,
                logf.LOCATION_NAME AS entity_nm,
                NULL AS lease_nbr,
                NULL AS building_id,
                CASE
                    WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'Non Retail'
                    ELSE 'Retail'
                END AS business_group_desc,
                CASE
                    WHEN logf.SCENARIO_NAME = 'NIKE' THEN 'NIKE'
                    ELSE 'CONVERSE'
                END AS brand_nm,
                CASE
                    WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center' THEN 'Distribution center'
                    ELSE NULL
                END AS entity_type_desc,
                CONCAT(logf.REGION, '-', LOCATION_TYPE) AS BUSINESS_ENTITY_GEO_REGION_CD,
                CASE
                    WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center' THEN 'DISTRIBUTION CENTER'
                    ELSE NULL
                END AS entity_use,
                CASE
                    WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
                    and logf.SCENARIO_NAME = 'NIKE' THEN 'Logistics (N)'
                    WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
                    and logf.SCENARIO_NAME = 'CONVERSE' THEN 'Logistics (C)'
                    ELSE NULL
                END AS business_function_nm,
                CASE
                    WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
                    and logf.SCENARIO_NAME = 'NIKE' THEN 'Distribution center (N)'
                    WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
                    and logf.SCENARIO_NAME = 'CONVERSE' THEN 'Distribution center (C)'
                    ELSE NULL
                END AS division_nm,
                logf.REGION AS LOCATION_GEO_REGION_CD,
                ccg.GEOSHORT_NM AS continent_nm,
                nodef.ADDRESS_LINE_1_TEXT AS ADDRESS_LINE_1_TXT,
                nodef.CITY_NAME AS city_nm,
                nodef.STATE_PROVINCE_CODE AS STATE_CD,
                nodef.POSTAL_CODE AS POSTAL_CD,
                CONCAT(nodef.POSTAL_CODE, '-', nodef.CITY_NAME) AS geographical_axis_nm,
                nodef.ISO_COUNTRY_CODE AS COUNTRY_CD,
                NULL AS LOCATION_AREA_IN_SQFT,
                CASE
                    WHEN logf.IS_ABS = 'true' THEN 'ACTIVE'
                    ELSE NULL
                END AS LOCATION_STATUS_CD,
                nodef.LATITUDE_DECIMAL_DEGREE AS latitude_deg,
                nodef.LONGITUDE_DECIMAL_DEGREE AS longitude_deg,
                NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
                cd.FISCAL_YEAR_NM AS fiscal_year_yrs,
                cd.YEAR_NBR AS calendar_year_yrs,
                cd.MONTH_LONG_NM AS month_nm,
                cd.MONTH_OF_YEAR_NBR AS month_nbr,
                cd.QUARTER_NBR AS quarter_cd,
                cd.WEEK_OF_YEAR_NBR AS week_wks,
                CASE
                    WHEN logf.PARENT IN (
                        'COST_PURCHASED_GAS_BIO_GAS',
                        'PURCHASED_GAS_BIO_GAS'
                    ) THEN 'BIO GAS'
                    WHEN logf.PARENT IN('COST_HI_SENE_SCOPE1', 'HI_SENE_SCOPE1') THEN 'Hi Sene'
                    WHEN logf.PARENT IN('COST_NATURAL_GAS_SCOPE1', 'NATURAL_GAS_SCOPE1') THEN 'Natural Gas'
                    ELSE NULL
                END AS service_type_desc,
                NULL AS fuel_type_desc,
                NULL AS saf_pct,
                NULL AS saf_density_uom,
                12 AS DATA_FREQUENCY_CD,
                CASE
                    WHEN logf.PARENT IN(
                        'PURCHASED_GAS_BIO_GAS',
                        'HI_SENE_SCOPE1',
                        'NATURAL_GAS_SCOPE1'
                    ) THEN logf.VALUE
                    ELSE NULL
                END AS SERVICE_USAGE_QTY,
                CASE
                    WHEN logf.PARENT IN(
                        'PURCHASED_GAS_BIO_GAS',
                        'HI_SENE_SCOPE1',
                        'NATURAL_GAS_SCOPE1'
                    ) THEN logf.UNIT
                    ELSE NULL
                END AS SERVICE_USAGE_QTY_UOM,
                CASE
                    WHEN logf.PARENT = 'COST_PURCHASED_GAS_BIO_GAS' THEN 'BIO GAS Cost'
                    WHEN logf.PARENT = 'COST_HI_SENE_SCOPE1' THEN 'Hi Sene Cost'
                    WHEN logf.PARENT = 'COST_NATURAL_GAS_SCOPE1' THEN 'Natural Gas Cost'
                    ELSE NULL
                END AS cost_type_desc,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_HI_SENE_SCOPE1',
                        'COST_NATURAL_GAS_SCOPE1',
                        'COST_PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.VALUE
                    ELSE NULL
                END AS SERVICE_COST,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_HI_SENE_SCOPE1',
                        'COST_NATURAL_GAS_SCOPE1',
                        'COST_PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.CURRENCY
                    ELSE NULL
                END AS SERVICE_COST_UOM,
                'NO' AS extrapolation_indicator,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_PURCHASED_GAS_BIO_GAS',
                        'PURCHASED_GAS_BIO_GAS',
                        'COST_HI_SENE_SCOPE1',
                        'HI_SENE_SCOPE1',
                        'COST_NATURAL_GAS_SCOPE1',
                        'NATURAL_GAS_SCOPE1'
                    ) THEN 'SCOPE 1'
                    ELSE NULL
                END AS scope_nbr
            FROM
                fulfill_dcanalytics_prod.cons_metapipes.logec_transactional_v_2 logf
                INNER JOIN eda_node_prod.bcl_node_management.node_flat_v1 nodef on SUBSTRING(logf.LOCATION_KEY, 4) = nodef.NODE_CODE
                LEFT JOIN GLOBAL_SUSTAINABILITY_QA.BCL_SUSTAINABILITY_FOUNDATION.COUNTRY_CD_GEO_MAPPING ccg on nodef.ISO_COUNTRY_CODE = ccg.CTRY_CD
                LEFT JOIN CALENDAR_QA.BCL.ENTERPRISECALENDAR_V cd ON TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'yyyy-MM-dd'
                ) = TO_VARCHAR(cd.calendar_dt)
            WHERE
                logf.PARENT IN(
                    'COST_PURCHASED_GAS_BIO_GAS',
                    'PURCHASED_GAS_BIO_GAS',
                    'COST_HI_SENE_SCOPE1',
                    'HI_SENE_SCOPE1',
                    'COST_NATURAL_GAS_SCOPE1',
                    'NATURAL_GAS_SCOPE1'
                )
        )
    GROUP BY
        entity_nbr,
        reporting_period_dt,
        BILLING_MONTH_START_DT,
        BILLING_MONTH_END_DT,
        BILLING_MONTH_DATE_RANGE_TXT,
        entity_nm,
        lease_nbr,
        business_group_desc,
        brand_nm,
        entity_type_desc,
        BUSINESS_ENTITY_GEO_REGION_CD,
        entity_use,
        business_function_nm,
        division_nm,
        LOCATION_GEO_REGION_CD,
        continent_nm,
        ADDRESS_LINE_1_TXT,
        city_nm,
        STATE_CD,
        POSTAL_CD,
        geographical_axis_nm,
        COUNTRY_CD,
        LOCATION_AREA_IN_SQFT,
        LOCATION_STATUS_CD,
        latitude_deg,
        longitude_deg,
        ADDITIONAL_LOCATION_FEATURE_DESC,
        fiscal_year_yrs,
        calendar_year_yrs,
        month_nm,
        month_nbr,
        quarter_cd,
        week_wks,
        building_id,
        service_type_desc,
        fuel_type_desc,
        saf_pct,
        saf_density_uom,
        DATA_FREQUENCY_CD,
        extrapolation_indicator,
        scope_nbr
) AS FSD_SOURCE_T ON FSD_DEST_T.entity_nbr = FSD_SOURCE_T.entity_nbr
and FSD_DEST_T.reporting_period_dt = FSD_SOURCE_T.reporting_period_dt
AND FSD_DEST_T.service_type_desc = FSD_SOURCE_T.service_type_desc
AND COALESCE(FSD_DEST_T.usage_type_desc, '-999999999') = COALESCE(FSD_SOURCE_T.usage_type_desc, '-999999999')
AND COALESCE(FSD_DEST_T.cost_type_desc, '-999999999') = COALESCE(FSD_SOURCE_T.cost_type_desc, '-999999999')
WHEN MATCHED THEN
UPDATE
SET
    FSD_DEST_T.BILLING_MONTH_START_DT = FSD_SOURCE_T.BILLING_MONTH_START_DT,
    FSD_DEST_T.BILLING_MONTH_END_DT = FSD_SOURCE_T.BILLING_MONTH_END_DT,
    FSD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT = FSD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
    FSD_DEST_T.entity_nm = FSD_SOURCE_T.entity_nm,
    FSD_DEST_T.lease_nbr = FSD_SOURCE_T.lease_nbr,
    FSD_DEST_T.business_group_desc = FSD_SOURCE_T.business_group_desc,
    FSD_DEST_T.brand_nm = FSD_SOURCE_T.brand_nm,
    FSD_DEST_T.entity_type_desc = FSD_SOURCE_T.entity_type_desc,
    FSD_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD = FSD_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
    FSD_DEST_T.entity_use = FSD_SOURCE_T.entity_use,
    FSD_DEST_T.business_function_nm = FSD_SOURCE_T.business_function_nm,
    FSD_DEST_T.division_nm = FSD_SOURCE_T.division_nm,
    FSD_DEST_T.LOCATION_GEO_REGION_CD = FSD_SOURCE_T.LOCATION_GEO_REGION_CD,
    FSD_DEST_T.continent_nm = FSD_SOURCE_T.continent_nm,
    FSD_DEST_T.ADDRESS_LINE_1_TXT = FSD_SOURCE_T.ADDRESS_LINE_1_TXT,
    FSD_DEST_T.city_nm = FSD_SOURCE_T.city_nm,
    FSD_DEST_T.STATE_CD = FSD_SOURCE_T.STATE_CD,
    FSD_DEST_T.POSTAL_CD = FSD_SOURCE_T.POSTAL_CD,
    FSD_DEST_T.geographical_axis_nm = FSD_SOURCE_T.geographical_axis_nm,
    FSD_DEST_T.COUNTRY_CD = FSD_SOURCE_T.COUNTRY_CD,
    FSD_DEST_T.LOCATION_AREA_IN_SQFT = FSD_SOURCE_T.LOCATION_AREA_IN_SQFT,
    FSD_DEST_T.LOCATION_STATUS_CD = FSD_SOURCE_T.LOCATION_STATUS_CD,
    FSD_DEST_T.latitude_deg = FSD_SOURCE_T.latitude_deg,
    FSD_DEST_T.longitude_deg = FSD_SOURCE_T.longitude_deg,
    FSD_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC = FSD_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
    FSD_DEST_T.fiscal_year_yrs = FSD_SOURCE_T.fiscal_year_yrs,
    FSD_DEST_T.calendar_year_yrs = FSD_SOURCE_T.calendar_year_yrs,
    FSD_DEST_T.month_nm = FSD_SOURCE_T.month_nm,
    FSD_DEST_T.month_nbr = FSD_SOURCE_T.month_nbr,
    FSD_DEST_T.quarter_cd = FSD_SOURCE_T.quarter_cd,
    FSD_DEST_T.week_wks = FSD_SOURCE_T.week_wks,
    FSD_DEST_T.building_id = FSD_SOURCE_T.building_id,
    FSD_DEST_T.fuel_type_desc = FSD_SOURCE_T.fuel_type_desc,
    FSD_DEST_T.saf_pct = FSD_SOURCE_T.saf_pct,
    FSD_DEST_T.saf_density_uom = FSD_SOURCE_T.saf_density_uom,
    FSD_DEST_T.DATA_FREQUENCY_CD = FSD_SOURCE_T.DATA_FREQUENCY_CD,
    FSD_DEST_T.SERVICE_USAGE_QTY = FSD_SOURCE_T.SERVICE_USAGE_QTY,
    FSD_DEST_T.SERVICE_USAGE_QTY_UOM = FSD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
    FSD_DEST_T.SERVICE_COST = FSD_SOURCE_T.SERVICE_COST,
    FSD_DEST_T.SERVICE_COST_UOM = FSD_SOURCE_T.SERVICE_COST_UOM,
    FSD_DEST_T.extrapolation_indicator = FSD_SOURCE_T.extrapolation_indicator,
    FSD_DEST_T.scope_nbr = FSD_SOURCE_T.scope_nbr
    WHEN NOT MATCHED THEN
INSERT
    (
        FSD_DEST_T.entity_nbr,
        FSD_DEST_T.reporting_period_dt,
        FSD_DEST_T.usage_type_desc,
        FSD_DEST_T.cost_type_desc,
        FSD_DEST_T.BILLING_MONTH_START_DT,
        FSD_DEST_T.BILLING_MONTH_END_DT,
        FSD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT,
        FSD_DEST_T.entity_nm,
        FSD_DEST_T.lease_nbr,
        FSD_DEST_T.business_group_desc,
        FSD_DEST_T.brand_nm,
        FSD_DEST_T.entity_type_desc,
        FSD_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD,
        FSD_DEST_T.entity_use,
        FSD_DEST_T.business_function_nm,
        FSD_DEST_T.division_nm,
        FSD_DEST_T.LOCATION_GEO_REGION_CD,
        FSD_DEST_T.continent_nm,
        FSD_DEST_T.ADDRESS_LINE_1_TXT,
        FSD_DEST_T.city_nm,
        FSD_DEST_T.STATE_CD,
        FSD_DEST_T.POSTAL_CD,
        FSD_DEST_T.geographical_axis_nm,
        FSD_DEST_T.COUNTRY_CD,
        FSD_DEST_T.LOCATION_AREA_IN_SQFT,
        FSD_DEST_T.LOCATION_STATUS_CD,
        FSD_DEST_T.latitude_deg,
        FSD_DEST_T.longitude_deg,
        FSD_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        FSD_DEST_T.fiscal_year_yrs,
        FSD_DEST_T.calendar_year_yrs,
        FSD_DEST_T.month_nm,
        FSD_DEST_T.month_nbr,
        FSD_DEST_T.quarter_cd,
        FSD_DEST_T.week_wks,
        FSD_DEST_T.building_id,
        FSD_DEST_T.service_type_desc,
        FSD_DEST_T.fuel_type_desc,
        FSD_DEST_T.saf_pct,
        FSD_DEST_T.saf_density_uom,
        FSD_DEST_T.DATA_FREQUENCY_CD,
        FSD_DEST_T.SERVICE_USAGE_QTY,
        FSD_DEST_T.SERVICE_USAGE_QTY_UOM,
        FSD_DEST_T.SERVICE_COST,
        FSD_DEST_T.SERVICE_COST_UOM,
        FSD_DEST_T.extrapolation_indicator,
        FSD_DEST_T.scope_nbr
    )
VALUES
    (
        FSD_SOURCE_T.entity_nbr,
        FSD_SOURCE_T.reporting_period_dt,
        FSD_SOURCE_T.usage_type_desc,
        FSD_SOURCE_T.cost_type_desc,
        FSD_SOURCE_T.BILLING_MONTH_START_DT,
        FSD_SOURCE_T.BILLING_MONTH_END_DT,
        FSD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
        FSD_SOURCE_T.entity_nm,
        FSD_SOURCE_T.lease_nbr,
        FSD_SOURCE_T.business_group_desc,
        FSD_SOURCE_T.brand_nm,
        FSD_SOURCE_T.entity_type_desc,
        FSD_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
        FSD_SOURCE_T.entity_use,
        FSD_SOURCE_T.business_function_nm,
        FSD_SOURCE_T.division_nm,
        FSD_SOURCE_T.LOCATION_GEO_REGION_CD,
        FSD_SOURCE_T.continent_nm,
        FSD_SOURCE_T.ADDRESS_LINE_1_TXT,
        FSD_SOURCE_T.city_nm,
        FSD_SOURCE_T.STATE_CD,
        FSD_SOURCE_T.POSTAL_CD,
        FSD_SOURCE_T.geographical_axis_nm,
        FSD_SOURCE_T.COUNTRY_CD,
        FSD_SOURCE_T.LOCATION_AREA_IN_SQFT,
        FSD_SOURCE_T.LOCATION_STATUS_CD,
        FSD_SOURCE_T.latitude_deg,
        FSD_SOURCE_T.longitude_deg,
        FSD_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        FSD_SOURCE_T.fiscal_year_yrs,
        FSD_SOURCE_T.calendar_year_yrs,
        FSD_SOURCE_T.month_nm,
        FSD_SOURCE_T.month_nbr,
        FSD_SOURCE_T.quarter_cd,
        FSD_SOURCE_T.week_wks,
        FSD_SOURCE_T.building_id,
        FSD_SOURCE_T.service_type_desc,
        FSD_SOURCE_T.fuel_type_desc,
        FSD_SOURCE_T.saf_pct,
        FSD_SOURCE_T.saf_density_uom,
        FSD_SOURCE_T.DATA_FREQUENCY_CD,
        FSD_SOURCE_T.SERVICE_USAGE_QTY,
        FSD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
        FSD_SOURCE_T.SERVICE_COST,
        FSD_SOURCE_T.SERVICE_COST_UOM,
        FSD_SOURCE_T.extrapolation_indicator,
        FSD_SOURCE_T.scope_nbr
    );
    