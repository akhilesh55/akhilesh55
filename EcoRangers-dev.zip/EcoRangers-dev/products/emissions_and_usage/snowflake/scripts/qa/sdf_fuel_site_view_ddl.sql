USE ROLE APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE;


CREATE VIEW IF NOT EXISTS FUEL_SITE_V AS
SELECT
    entity_uuid,
    entity_nbr,
    entity_nm,
    lease_nbr,
    building_id,
    business_group_desc,
    brand_nm,
    entity_type_desc,
    BUSINESS_ENTITY_GEO_REGION_CD,
    entity_use,
    business_function_nm,
    division_nm,
    LOCATION_GEO_REGION_CD,
    continent_nm,
    ADDRESS_LINE_1_TXT,
    city_nm,
    STATE_CD,
    POSTAL_CD,
    geographical_axis_nm,
    COUNTRY_CD,
    LOCATION_AREA_IN_SQFT,
    LOCATION_STATUS_CD,
    latitude_deg,
    longitude_deg,
    ADDITIONAL_LOCATION_FEATURE_DESC
FROM
    global_sustainability_qa.bcl_sustainability_foundation.FUEL_SITE_T;