USE ROLE APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE;


CREATE TABLE IF NOT EXISTS global_sustainability_qa.bcl_sustainability_foundation.FUEL_SITE_T (
    entity_uuid STRING DEFAULT UUID_STRING(),
    entity_nbr STRING,
    entity_nm STRING NOT NULL,
    lease_nbr STRING,
    building_id STRING,
    business_group_desc STRING NOT NULL,
    brand_nm STRING NOT NULL,
    entity_type_desc STRING,
    BUSINESS_ENTITY_GEO_REGION_CD STRING,
    entity_use STRING,
    business_function_nm STRING,
    division_nm STRING,
    LOCATION_GEO_REGION_CD STRING NOT NULL,
    continent_nm STRING NOT NULL,
    ADDRESS_LINE_1_TXT STRING,
    city_nm STRING,
    STATE_CD STRING,
    POSTAL_CD STRING,
    geographical_axis_nm STRING NOT NULL,
    COUNTRY_CD STRING NOT NULL,
    LOCATION_AREA_IN_SQFT FLOAT,
    LOCATION_STATUS_CD STRING NOT NULL,
    latitude_deg FLOAT,
    longitude_deg FLOAT,
    ADDITIONAL_LOCATION_FEATURE_DESC STRING,
    parent_desc STRING,
    reporting_period_dt STRING,
    PRIMARY KEY (entity_uuid,entity_nbr,entity_nm)
);