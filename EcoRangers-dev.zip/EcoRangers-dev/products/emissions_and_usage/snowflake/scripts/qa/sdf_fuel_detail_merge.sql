MERGE INTO global_sustainability_qa.bcl_sustainability_foundation.FUEL_DETAIL_T AS FD_DEST_T USING (
    SELECT
        entity_nbr,
        reporting_period_dt,
        COALESCE(MAX(usage_type_desc), MIN(usage_type_desc)) AS usage_type_desc,
        BILLING_MONTH_START_DT,
        BILLING_MONTH_END_DT,
        BILLING_MONTH_DATE_RANGE_TXT,
        entity_nm,
        fiscal_year_yrs,
        calendar_year_yrs,
        month_nm,
        month_nbr,
        quarter_cd,
        week_wks,
        building_id,
        service_type_desc,
        fuel_type_desc,
        saf_pct,
        saf_density_uom,
        DATA_FREQUENCY_CD,
        COALESCE(MAX(SERVICE_USAGE_QTY), MIN(SERVICE_USAGE_QTY)) AS SERVICE_USAGE_QTY,
        COALESCE(MAX(SERVICE_USAGE_QTY_UOM), MIN(SERVICE_USAGE_QTY_UOM)) AS SERVICE_USAGE_QTY_UOM,
        COALESCE(MAX(cost_type_desc), MIN(cost_type_desc)) AS cost_type_desc,
        COALESCE(MAX(SERVICE_COST), MIN(SERVICE_COST)) AS SERVICE_COST,
        COALESCE(MAX(SERVICE_COST_UOM), MIN(SERVICE_COST_UOM)) AS SERVICE_COST_UOM,
        extrapolation_indicator,
        scope_nbr
    FROM
        (
            SELECT
                logf.LOCATION_KEY AS entity_nbr,
                TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'MM/dd/yyyy'
                ) AS reporting_period_dt,
                CASE
                    WHEN logf.PARENT = 'NATURAL_GAS_SCOPE1' THEN 'Natural Gas Consumption Volume'
                    WHEN logf.PARENT = 'HI_SENE_SCOPE1' THEN 'HI SENE Consumption'
                    WHEN logf.PARENT = 'PURCHASED_GAS_BIO_GAS' THEN 'Bio Gas Consumption'
                    ELSE NULL
                END AS usage_type_desc,
                TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'MM/dd/yyyy'
                ) AS BILLING_MONTH_START_DT,
                TO_VARCHAR(
                    LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')),
                    'MM/dd/yyyy'
                ) AS BILLING_MONTH_END_DT,
                CONCAT(
                    TO_VARCHAR(
                        TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                        'MM/dd/yyyy'
                    ),
                    '-',
                    TO_VARCHAR(
                        LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')),
                        'MM/dd/yyyy'
                    )
                ) AS BILLING_MONTH_DATE_RANGE_TXT,
                logf.LOCATION_NAME AS entity_nm,
                cd.FISCAL_YEAR_NM AS fiscal_year_yrs,
                cd.YEAR_NBR AS calendar_year_yrs,
                cd.MONTH_LONG_NM AS month_nm,
                cd.MONTH_OF_YEAR_NBR AS month_nbr,
                cd.QUARTER_NBR AS quarter_cd,
                cd.WEEK_OF_YEAR_NBR AS week_wks,
                NULL AS building_id,
                CASE
                    WHEN logf.PARENT IN (
                        'COST_PURCHASED_GAS_BIO_GAS',
                        'PURCHASED_GAS_BIO_GAS'
                    ) THEN 'BIO GAS'
                    WHEN logf.PARENT IN('COST_HI_SENE_SCOPE1', 'HI_SENE_SCOPE1') THEN 'Hi Sene'
                    WHEN logf.PARENT IN('COST_NATURAL_GAS_SCOPE1', 'NATURAL_GAS_SCOPE1') THEN 'Natural Gas'
                    ELSE NULL
                END AS service_type_desc,
                NULL AS fuel_type_desc,
                CAST(NULL AS DECIMAL) AS saf_pct,
                CAST(NULL AS DECIMAL) AS saf_density_uom,
                CAST(12 AS INTEGER) AS DATA_FREQUENCY_CD,
                CASE
                    WHEN logf.PARENT IN(
                        'PURCHASED_GAS_BIO_GAS',
                        'HI_SENE_SCOPE1',
                        'NATURAL_GAS_SCOPE1'
                    ) THEN logf.VALUE
                    ELSE NULL
                END AS SERVICE_USAGE_QTY,
                CASE
                    WHEN logf.PARENT IN(
                        'PURCHASED_GAS_BIO_GAS',
                        'HI_SENE_SCOPE1',
                        'NATURAL_GAS_SCOPE1'
                    ) THEN logf.UNIT
                    ELSE NULL
                END AS SERVICE_USAGE_QTY_UOM,
                CASE
                    WHEN logf.PARENT = 'COST_PURCHASED_GAS_BIO_GAS' THEN 'BIO GAS Cost'
                    WHEN logf.PARENT = 'COST_HI_SENE_SCOPE1' THEN 'Hi Sene Cost'
                    WHEN logf.PARENT = 'COST_NATURAL_GAS_SCOPE1' THEN 'Natural Gas Cost'
                    ELSE NULL
                END AS cost_type_desc,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_HI_SENE_SCOPE1',
                        'COST_NATURAL_GAS_SCOPE1',
                        'COST_PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.VALUE
                    ELSE NULL
                END AS SERVICE_COST,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_HI_SENE_SCOPE1',
                        'COST_NATURAL_GAS_SCOPE1',
                        'COST_PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.CURRENCY
                    ELSE NULL
                END AS SERVICE_COST_UOM,
                'NO' AS extrapolation_indicator,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_PURCHASED_GAS_BIO_GAS',
                        'PURCHASED_GAS_BIO_GAS',
                        'COST_HI_SENE_SCOPE1',
                        'HI_SENE_SCOPE1',
                        'COST_NATURAL_GAS_SCOPE1',
                        'NATURAL_GAS_SCOPE1'
                    ) THEN 'SCOPE 1'
                    ELSE NULL
                END AS scope_nbr
            FROM
                fulfill_dcanalytics_prod.cons_metapipes.logec_transactional_v_2 logf
                left JOIN CALENDAR_QA.BCL.ENTERPRISECALENDAR_V cd ON TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'yyyy-MM-dd'
                ) = TO_VARCHAR(cd.calendar_dt)
            WHERE
                logf.PARENT IN(
                    'COST_PURCHASED_GAS_BIO_GAS',
                    'PURCHASED_GAS_BIO_GAS',
                    'COST_HI_SENE_SCOPE1',
                    'HI_SENE_SCOPE1',
                    'COST_NATURAL_GAS_SCOPE1',
                    'NATURAL_GAS_SCOPE1'
                )
        )
    GROUP BY
        entity_nbr,
        reporting_period_dt,
        BILLING_MONTH_START_DT,
        BILLING_MONTH_END_DT,
        BILLING_MONTH_DATE_RANGE_TXT,
        entity_nm,
        fiscal_year_yrs,
        calendar_year_yrs,
        month_nm,
        month_nbr,
        quarter_cd,
        week_wks,
        building_id,
        service_type_desc,
        fuel_type_desc,
        saf_pct,
        saf_density_uom,
        DATA_FREQUENCY_CD,
        extrapolation_indicator,
        scope_nbr
) AS FD_SOURCE_T ON FD_DEST_T.entity_nbr = FD_SOURCE_T.entity_nbr
AND FD_DEST_T.reporting_period_dt = FD_SOURCE_T.reporting_period_dt
AND FD_DEST_T.service_type_desc=FD_SOURCE_T.service_type_desc
AND COALESCE(FD_DEST_T.usage_type_desc, '-999999999') = COALESCE(FD_SOURCE_T.usage_type_desc, '-999999999')
AND COALESCE(FD_DEST_T.cost_type_desc, '-999999999') = COALESCE(FD_SOURCE_T.cost_type_desc, '-999999999')
WHEN MATCHED THEN
UPDATE
SET
    FD_DEST_T.BILLING_MONTH_START_DT = FD_SOURCE_T.BILLING_MONTH_START_DT,
    FD_DEST_T.BILLING_MONTH_END_DT = FD_SOURCE_T.BILLING_MONTH_END_DT,
    FD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT = FD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
    FD_DEST_T.entity_nm = FD_SOURCE_T.entity_nm,
    FD_DEST_T.fiscal_year_yrs = FD_SOURCE_T.fiscal_year_yrs,
    FD_DEST_T.calendar_year_yrs = FD_SOURCE_T.calendar_year_yrs,
    FD_DEST_T.month_nm = FD_SOURCE_T.month_nm,
    FD_DEST_T.month_nbr = FD_SOURCE_T.month_nbr,
    FD_DEST_T.quarter_cd = FD_SOURCE_T.quarter_cd,
    FD_DEST_T.week_wks = FD_SOURCE_T.week_wks,
    FD_DEST_T.building_id = FD_SOURCE_T.building_id,
    FD_DEST_T.fuel_type_desc = FD_SOURCE_T.fuel_type_desc,
    FD_DEST_T.saf_pct = FD_SOURCE_T.saf_pct,
    FD_DEST_T.saf_density_uom = FD_SOURCE_T.saf_density_uom,
    FD_DEST_T.DATA_FREQUENCY_CD = FD_SOURCE_T.DATA_FREQUENCY_CD,
    FD_DEST_T.SERVICE_USAGE_QTY = FD_SOURCE_T.SERVICE_USAGE_QTY,
    FD_DEST_T.SERVICE_USAGE_QTY_UOM = FD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
    FD_DEST_T.SERVICE_COST = FD_SOURCE_T.SERVICE_COST,
    FD_DEST_T.SERVICE_COST_UOM = FD_SOURCE_T.SERVICE_COST_UOM,
    FD_DEST_T.extrapolation_indicator = FD_SOURCE_T.extrapolation_indicator,
    FD_DEST_T.scope_nbr = FD_SOURCE_T.scope_nbr
    WHEN NOT MATCHED THEN
INSERT
    (
        FD_DEST_T.entity_nbr,
        FD_DEST_T.reporting_period_dt,
        FD_DEST_T.usage_type_desc,
        FD_DEST_T.BILLING_MONTH_START_DT,
        FD_DEST_T.BILLING_MONTH_END_DT,
        FD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT,
        FD_DEST_T.entity_nm,
        FD_DEST_T.fiscal_year_yrs,
        FD_DEST_T.calendar_year_yrs,
        FD_DEST_T.month_nm,
        FD_DEST_T.month_nbr,
        FD_DEST_T.quarter_cd,
        FD_DEST_T.week_wks,
        FD_DEST_T.building_id,
        FD_DEST_T.service_type_desc,
        FD_DEST_T.fuel_type_desc,
        FD_DEST_T.saf_pct,
        FD_DEST_T.saf_density_uom,
        FD_DEST_T.DATA_FREQUENCY_CD,
        FD_DEST_T.SERVICE_USAGE_QTY,
        FD_DEST_T.SERVICE_USAGE_QTY_UOM,
        FD_DEST_T.cost_type_desc,
        FD_DEST_T.SERVICE_COST,
        FD_DEST_T.SERVICE_COST_UOM,
        FD_DEST_T.extrapolation_indicator,
        FD_DEST_T.scope_nbr
    )
VALUES
    (
        FD_SOURCE_T.entity_nbr,
        FD_SOURCE_T.reporting_period_dt,
        FD_SOURCE_T.usage_type_desc,
        FD_SOURCE_T.BILLING_MONTH_START_DT,
        FD_SOURCE_T.BILLING_MONTH_END_DT,
        FD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
        FD_SOURCE_T.entity_nm,
        FD_SOURCE_T.fiscal_year_yrs,
        FD_SOURCE_T.calendar_year_yrs,
        FD_SOURCE_T.month_nm,
        FD_SOURCE_T.month_nbr,
        FD_SOURCE_T.quarter_cd,
        FD_SOURCE_T.week_wks,
        FD_SOURCE_T.building_id,
        FD_SOURCE_T.service_type_desc,
        FD_SOURCE_T.fuel_type_desc,
        FD_SOURCE_T.saf_pct,
        FD_SOURCE_T.saf_density_uom,
        FD_SOURCE_T.DATA_FREQUENCY_CD,
        FD_SOURCE_T.SERVICE_USAGE_QTY,
        FD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
        FD_SOURCE_T.cost_type_desc,
        FD_SOURCE_T.SERVICE_COST,
        FD_SOURCE_T.SERVICE_COST_UOM,
        FD_SOURCE_T.extrapolation_indicator,
        FD_SOURCE_T.scope_nbr
    );
    