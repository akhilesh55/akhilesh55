MERGE INTO global_sustainability_qa.bcl_sustainability_foundation.FUEL_SITE_T AS FS_DEST_T USING (
    SELECT
        logf.LOCATION_KEY AS entity_nbr,
        logf.LOCATION_NAME AS entity_nm,
        NULL AS lease_nbr,
        NULL AS building_id,
        CASE
            WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'Non Retail'
            ELSE 'Retail'
        END AS business_group_desc,
        CASE
            WHEN logf.SCENARIO_NAME = 'NIKE' THEN 'NIKE'
            ELSE 'CONVERSE'
        END AS brand_nm,
        CASE
            WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center' THEN 'Distribution center'
            ELSE NULL
        END AS entity_type_desc,
        CONCAT(logf.REGION, '-', logf.LOCATION_TYPE) AS BUSINESS_ENTITY_GEO_REGION_CD,
        CASE
            WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center' THEN 'DISTRIBUTION CENTER'
            ELSE NULL
        END AS entity_use,
        CASE
            WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
            and logf.SCENARIO_NAME = 'NIKE' THEN 'Logistics (N)'
            WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
            and logf.SCENARIO_NAME = 'CONVERSE' THEN 'Logistics (C)'
            ELSE NULL
        END AS business_function_nm,
        CASE
            WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
            and logf.SCENARIO_NAME = 'NIKE' THEN 'Distribution center (N)'
            WHEN nodef.NODE_TYPE_DESCRIPTION = 'Distribution center'
            and logf.SCENARIO_NAME = 'CONVERSE' THEN 'Distribution center (C)'
            ELSE NULL
        END AS division_nm,
        logf.REGION AS LOCATION_GEO_REGION_CD,
        ccg.GEOSHORT_NM AS continent_nm,
        nodef.ADDRESS_LINE_1_TEXT AS ADDRESS_LINE_1_TXT,
        nodef.CITY_NAME AS city_nm,
        nodef.STATE_PROVINCE_CODE AS STATE_CD,
        nodef.POSTAL_CODE AS POSTAL_CD,
        CONCAT(nodef.POSTAL_CODE, '-', nodef.CITY_NAME) AS geographical_axis_nm,
        nodef.ISO_COUNTRY_CODE AS COUNTRY_CD,
        NULL AS LOCATION_AREA_IN_SQFT,
        CASE
            WHEN logf.IS_ABS = 'true' THEN 'ACTIVE'
            ELSE NULL
        END AS LOCATION_STATUS_CD,
        nodef.LATITUDE_DECIMAL_DEGREE AS latitude_deg,
        nodef.LONGITUDE_DECIMAL_DEGREE AS longitude_deg,
        NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
        logf.PARENT AS parent_desc,
        TO_VARCHAR(
            TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
            'MM/dd/yyyy'
        ) as reporting_period_dt
    FROM
        fulfill_dcanalytics_prod.cons_metapipes.logec_transactional_v_2 logf
        INNER JOIN eda_node_prod.bcl_node_management.node_flat_v1 nodef on SUBSTRING(logf.LOCATION_KEY, 4) = nodef.NODE_CODE
        LEFT JOIN GLOBAL_SUSTAINABILITY_QA.BCL_SUSTAINABILITY_FOUNDATION.COUNTRY_CD_GEO_MAPPING ccg on nodef.ISO_COUNTRY_CODE = ccg.CTRY_CD
    WHERE
        logf.PARENT IN(
            'COST_PURCHASED_GAS_BIO_GAS',
            'PURCHASED_GAS_BIO_GAS',
            'COST_HI_SENE_SCOPE1',
            'HI_SENE_SCOPE1',
            'COST_NATURAL_GAS_SCOPE1',
            'NATURAL_GAS_SCOPE1'
        )
) AS FS_SOURCE_T ON FS_DEST_T.entity_nbr = FS_SOURCE_T.entity_nbr
and FS_DEST_T.reporting_period_dt = FS_SOURCE_T.reporting_period_dt
and FS_DEST_T.parent_desc = FS_SOURCE_T.parent_desc
WHEN MATCHED THEN
UPDATE
SET
    FS_DEST_T.lease_nbr = FS_SOURCE_T.lease_nbr,
    FS_DEST_T.building_id = FS_SOURCE_T.building_id,
    FS_DEST_T.entity_type_desc = FS_SOURCE_T.entity_type_desc,
    FS_DEST_T.entity_use = FS_SOURCE_T.entity_use,
    FS_DEST_T.business_function_nm = FS_SOURCE_T.business_function_nm,
    FS_DEST_T.division_nm = FS_SOURCE_T.division_nm,
    FS_DEST_T.ADDRESS_LINE_1_TXT = FS_SOURCE_T.ADDRESS_LINE_1_TXT,
    FS_DEST_T.city_nm = FS_SOURCE_T.city_nm,
    FS_DEST_T.STATE_CD = FS_SOURCE_T.STATE_CD,
    FS_DEST_T.POSTAL_CD = FS_SOURCE_T.POSTAL_CD,
    FS_DEST_T.LOCATION_AREA_IN_SQFT = FS_SOURCE_T.LOCATION_AREA_IN_SQFT,
    FS_DEST_T.latitude_deg = FS_SOURCE_T.latitude_deg,
    FS_DEST_T.longitude_deg = FS_SOURCE_T.longitude_deg,
    FS_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC = FS_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
    FS_DEST_T.business_group_desc = FS_SOURCE_T.business_group_desc,
    FS_DEST_T.brand_nm = FS_SOURCE_T.brand_nm,
    FS_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD = FS_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
    FS_DEST_T.LOCATION_GEO_REGION_CD = FS_SOURCE_T.LOCATION_GEO_REGION_CD,
    FS_DEST_T.continent_nm = FS_SOURCE_T.continent_nm,
    FS_DEST_T.geographical_axis_nm = FS_SOURCE_T.geographical_axis_nm,
    FS_DEST_T.COUNTRY_CD = FS_SOURCE_T.COUNTRY_CD,
    FS_DEST_T.LOCATION_STATUS_CD = FS_SOURCE_T.LOCATION_STATUS_CD
    WHEN NOT MATCHED THEN
INSERT
    (
        FS_DEST_T.entity_nbr,
        FS_DEST_T.entity_nm,
        FS_DEST_T.lease_nbr,
        FS_DEST_T.building_id,
        FS_DEST_T.business_group_desc,
        FS_DEST_T.brand_nm,
        FS_DEST_T.entity_type_desc,
        FS_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD,
        FS_DEST_T.entity_use,
        FS_DEST_T.business_function_nm,
        FS_DEST_T.division_nm,
        FS_DEST_T.LOCATION_GEO_REGION_CD,
        FS_DEST_T.continent_nm,
        FS_DEST_T.ADDRESS_LINE_1_TXT,
        FS_DEST_T.city_nm,
        FS_DEST_T.STATE_CD,
        FS_DEST_T.POSTAL_CD,
        FS_DEST_T.geographical_axis_nm,
        FS_DEST_T.COUNTRY_CD,
        FS_DEST_T.LOCATION_AREA_IN_SQFT,
        FS_DEST_T.LOCATION_STATUS_CD,
        FS_DEST_T.latitude_deg,
        FS_DEST_T.longitude_deg,
        FS_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        FS_DEST_T.parent_desc,
        FS_DEST_T.reporting_period_dt
    )
VALUES
    (
        FS_SOURCE_T.entity_nbr,
        FS_SOURCE_T.entity_nm,
        FS_SOURCE_T.lease_nbr,
        FS_SOURCE_T.building_id,
        FS_SOURCE_T.business_group_desc,
        FS_SOURCE_T.brand_nm,
        FS_SOURCE_T.entity_type_desc,
        FS_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
        FS_SOURCE_T.entity_use,
        FS_SOURCE_T.business_function_nm,
        FS_SOURCE_T.division_nm,
        FS_SOURCE_T.LOCATION_GEO_REGION_CD,
        FS_SOURCE_T.continent_nm,
        FS_SOURCE_T.ADDRESS_LINE_1_TXT,
        FS_SOURCE_T.city_nm,
        FS_SOURCE_T.STATE_CD,
        FS_SOURCE_T.POSTAL_CD,
        FS_SOURCE_T.geographical_axis_nm,
        FS_SOURCE_T.COUNTRY_CD,
        FS_SOURCE_T.LOCATION_AREA_IN_SQFT,
        FS_SOURCE_T.LOCATION_STATUS_CD,
        FS_SOURCE_T.latitude_deg,
        FS_SOURCE_T.longitude_deg,
        FS_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        FS_SOURCE_T.parent_desc,
        FS_SOURCE_T.reporting_period_dt
    );
    