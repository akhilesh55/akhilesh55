USE ROLE APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE;


CREATE TABLE IF NOT EXISTS global_sustainability_qa.bcl_sustainability_foundation.FUEL_DETAIL_T(
    entity_uuid STRING DEFAULT UUID_STRING(),
    entity_nbr STRING,
    reporting_period_dt DATE,
    usage_type_desc STRING,
    BILLING_MONTH_START_DT STRING,
    BILLING_MONTH_END_DT STRING,
    BILLING_MONTH_DATE_RANGE_TXT STRING,
    entity_nm STRING NOT NULL,
    fiscal_year_yrs STRING NOT NULL,
    calendar_year_yrs STRING NOT NULL,
    month_nm STRING NOT NULL,
    month_nbr STRING NOT NULL,
    quarter_cd STRING NOT NULL,
    week_wks STRING NOT NULL,
    building_id STRING,
    service_type_desc STRING,
    fuel_type_desc STRING,
    saf_pct FLOAT,
    saf_density_uom FLOAT,
    DATA_FREQUENCY_CD INTEGER,
    SERVICE_USAGE_QTY FLOAT,
    SERVICE_USAGE_QTY_UOM STRING,
    cost_type_desc STRING,
    SERVICE_COST FLOAT,
    SERVICE_COST_UOM STRING,
    extrapolation_indicator STRING NOT NULL,
    scope_nbr STRING NOT NULL,
    PRIMARY KEY(
        entity_uuid,
        entity_nbr,
        entity_nm,
        reporting_period_dt,
        service_type_desc
    )
);