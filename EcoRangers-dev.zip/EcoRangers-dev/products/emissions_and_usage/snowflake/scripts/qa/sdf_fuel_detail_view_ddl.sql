USE ROLE APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE;


CREATE VIEW IF NOT EXISTS FUEL_DETAIL_V AS
SELECT
    entity_uuid,
    entity_nbr,
    reporting_period_dt,
    service_type_desc,
    BILLING_MONTH_START_DT,
    BILLING_MONTH_END_DT,
    BILLING_MONTH_DATE_RANGE_TXT,
    entity_nm,
    fiscal_year_yrs,
    calendar_year_yrs,
    month_nm,
    month_nbr,
    week_wks,
    building_id,
    fuel_type_desc,
    saf_pct,
    saf_density_uom,
    DATA_FREQUENCY_CD,
    SERVICE_USAGE_QTY,
    SERVICE_USAGE_QTY_UOM,
    SERVICE_COST,
    SERVICE_COST_UOM,
    extrapolation_indicator,
    scope_nbr
FROM
    global_sustainability_qa.bcl_sustainability_foundation.FUEL_DETAIL_T;