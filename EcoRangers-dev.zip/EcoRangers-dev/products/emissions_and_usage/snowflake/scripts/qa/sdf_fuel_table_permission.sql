GRANT SELECT on {tableName} to role APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READ; --replace {tableName} with the table name
GRANT ALL on {tableName} to role APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_READWRITE; --replace {tableName} with the table name
GRANT ownership on {tableName} to role APP_SNOWFLAKE_PREPROD_EDAI_ECORANGERS_ADMIN COPY CURRENT GRANTS; --replace {tableName} with the table name
