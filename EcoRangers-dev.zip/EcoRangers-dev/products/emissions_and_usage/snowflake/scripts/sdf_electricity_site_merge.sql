MERGE INTO {target_complete_name} AS ES_DEST_T USING (
with site_size_sqft as (select location_key,year, month, dense_rank() over(partition by location_key order by month,year desc) as max_yr_mn, value 
from {logec_table_name}  where parent = 'LOCATION_SIZE_M2_FC' and VALUE is not NULL and value !=0)
, existing_query as (
    SELECT
        uuid_string(
            '8e884ace-bee4-11e4-8dfc-aa07a5b093db',
            md5(concat(ELECTRICITY_LOCATION_NBR, ELECTRICITY_LOCATION_NM,brand_nm))
        ) as ELECTRICITY_CONSUMPTION_UUID,
        electricity_location_nbr,
        location_key,
        electricity_location_nm,
        lease_nbr,
        building_id,
        REGEXP_REPLACE(INITCAP(business_group_txt),'-',' ') AS business_group_txt,
        INITCAP(brand_nm) AS brand_nm,
        nike_department_type_txt,
        property_nm,
        CASE 
            WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
            WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
            WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
            ELSE BUSINESS_ENTITY_GEO_REGION_CD
        END AS BUSINESS_ENTITY_GEO_REGION_CD,
        ELECTRICITY_LOCATION_USE_CD,
        business_function_nm,
        division_nm,
        CASE 
            WHEN LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
            WHEN LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
            ELSE LOCATION_GEO_REGION_CD
        END AS LOCATION_GEO_REGION_CD,
        CASE 
            WHEN continent_nm ILIKE 'EMEA' THEN 'Europe'
            WHEN continent_nm ILIKE 'APLA' THEN 'Asia'
            WHEN continent_nm ILIKE 'North America' THEN 'North America'
            WHEN continent_nm ILIKE 'Greater China' THEN 'Asia'
            ELSE continent_nm
        END AS continent_nm,
        COALESCE(ADDRESS_LINE_1_TXT, conv_adresss_1) as ADDRESS_LINE_1_TXT,
        COALESCE(INITCAP(city_nm),INITCAP(conv_adresss_2))  AS city_nm,
        COALESCE(STATE_CD,conv_adresss_3) as STATE_CD,
        COALESCE(POSTAL_CD,conv_zip_code) as POSTAL_CD,
        geographical_axis_nm,
        CASE 
            WHEN COUNTRY_CD ILIKE 'Canada' THEN 'CA'
            WHEN COUNTRY_CD ILIKE 'United States' THEN 'US'
            ELSE COUNTRY_CD
        END AS COUNTRY_CD,
        -- LOCATION_AREA_IN_SQFT,
        LOCATION_STATUS_CD,
        latitude_deg,
        longitude_deg,
        ADDITIONAL_LOCATION_FEATURE_DESC,
        data_source_nm
FROM
        (
select distinct 
SUBSTRING(log_tbl.LOCATION_KEY, 4) as ELECTRICITY_LOCATION_NBR,
log_tbl.location_key,
--log_tbl.LOCATION_NAME as ELECTRICITY_LOCATION_NM,
COALESCE(node_tbl.NAME,log_tbl.LOCATION_NAME) AS ELECTRICITY_LOCATION_NM,
conv_dc_mapping.adresss_1 as conv_adresss_1,
conv_dc_mapping.adresss_2 as conv_adresss_2,
conv_dc_mapping.adresss_3 as conv_adresss_3,
conv_dc_mapping.zip_code as conv_zip_code,
NULL as lease_nbr,
NULL as building_id,
CASE WHEN log_tbl.LOCATION_TYPE = 'Warehouse' then 'Non Retail'  
ELSE 'Retail' 
END AS BUSINESS_GROUP_TXT,

CASE WHEN log_tbl.SCENARIO_NAME = 'CONVERSE' then 'CONVERSE'
ELSE 'NIKE'
END AS brand_nm,

CASE WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'Distribution center'
ELSE NULL 
END as NIKE_DEPARTMENT_TYPE_TXT,

COALESCE(node_tbl.NAME,log_tbl.LOCATION_NAME) as property_nm,
log_tbl.REGION AS BUSINESS_ENTITY_GEO_REGION_CD,

CASE WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'DISTRIBUTION CENTER'
ELSE NULL 
END AS ELECTRICITY_LOCATION_USE_CD,

CASE WHEN log_tbl.LOCATION_TYPE = 'Warehouse' and log_tbl.SCENARIO_NAME = 'NIKE' then 'Logistics (N)'
    WHEN log_tbl.LOCATION_TYPE = 'Warehouse' and log_tbl.SCENARIO_NAME = 'CONVERSE' then 'Logistics (C)'
    else null
    END AS business_function_nm,

CASE WHEN log_tbl.LOCATION_TYPE = 'Warehouse' and log_tbl.SCENARIO_NAME = 'NIKE' then 'Distribution Centers (N)'
     WHEN log_tbl.LOCATION_TYPE = 'Warehouse' and log_tbl.SCENARIO_NAME = 'CONVERSE' then 'Distribution Centers (C)'
     ELSE NULL
     END AS division_nm,

log_tbl.REGION as LOCATION_GEO_REGION_CD,
ctry_mapping.GEOSHORT_NM AS continent_nm,

node_tbl.ADDRESS_LINE_1_TEXT as ADDRESS_LINE_1_TXT,
node_tbl.CITY_NAME as city_nm,
node_tbl.STATE_PROVINCE_CODE as STATE_CD,
node_tbl.POSTAL_CODE as POSTAL_CD,
COALESCE(CONCAT(node_tbl.POSTAL_CODE,'-',node_tbl.CITY_NAME),conv_dc_mapping.Country) as geographical_axis_nm,
COALESCE(node_tbl.ISO_COUNTRY_CODE,conv_dc_mapping.Country_cd) as COUNTRY_CD,
-- NULL as LOCATION_AREA_IN_SQFT,

CASE WHEN log_tbl.IS_ABS = 'true' then 'Open'
ELSE 'Close'
END AS LOCATION_STATUS_CD,

node_tbl.LATITUDE_DECIMAL_DEGREE as latitude_deg,
node_tbl.LONGITUDE_DECIMAL_DEGREE as longitude_deg,
NULL as ADDITIONAL_LOCATION_FEATURE_DESC,
'logec' as data_source_nm

from {logec_table_name} log_tbl
left join {node_table_name} node_tbl 
on SUBSTRING(log_tbl.LOCATION_KEY,4) = node_tbl.NODE_CODE 
left join {ctry_mapping_table_name} ctry_mapping 
ON log_tbl.region=ctry_mapping.REGION
left join {conv_dc_mapping_table} conv_dc_mapping
on log_tbl.LOCATION_KEY=conv_dc_mapping.LOCATION_KEY

where log_tbl.PARENT IN ('COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2','COST_GENERATED_ELECTRICITY_WIND_SCOPE2','COST_PURCHASED_ELECTRICITY_SCOPE2',
    'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2','GENERATED_ELECTRICITY_WIND_SCOPE2','OFFSITE_WIND_CONSUMPTION','ONSITE_SOLAR_CONSUMPTION','ONSITE_SOLAR_GENERATION',
    'ONSITE_WIND_CONSUMPTION','ONSITE_WIND_GENERATION','PURCHASED_ELECTRICITY_SCOPE2','REC_AMOUNT_BIOMASS_EMITTED','REC_AMOUNT_GEOTHERMAL','REC_AMOUNT_HYDROPOWER',
    'REC_AMOUNT_SOLAR','REC_AMOUNT_SOLAR_WIND','REC_AMOUNT_WIND','SURPLUS_ONSITE_SOLAR_GENERATION','SURPLUS_ONSITE_WIND_GENERATION')))

select ELECTRICITY_CONSUMPTION_UUID,
        electricity_location_nbr,
        electricity_location_nm,
        lease_nbr,
        building_id,business_group_txt,brand_nm,nike_department_type_txt,
        property_nm,BUSINESS_ENTITY_GEO_REGION_CD,
        ELECTRICITY_LOCATION_USE_CD,
        business_function_nm, LOCATION_GEO_REGION_CD,continent_nm,
        ADDRESS_LINE_1_TXT,
        city_nm,
        STATE_CD,
        POSTAL_CD,
        geographical_axis_nm,COUNTRY_CD,
        round(value*10.76,5) as LOCATION_AREA_IN_SQFT,
        division_nm,
        LOCATION_STATUS_CD,
        latitude_deg,
        longitude_deg,
        ADDITIONAL_LOCATION_FEATURE_DESC,
        data_source_nm from existing_query inner join site_size_sqft on site_size_sqft.location_key = existing_query.location_key where site_size_sqft.max_yr_mn=1
 )AS ES_SOURCE_T ON CONCAT_WS(
    '_',
    ES_DEST_T.electricity_consumption_uuid,
    ES_DEST_T.electricity_location_nbr,
    ES_DEST_T.electricity_location_nm
) = CONCAT_WS(
    '_',
    ES_SOURCE_T.electricity_consumption_uuid,
    ES_SOURCE_T.electricity_location_nbr,
    ES_SOURCE_T.electricity_location_nm
)
   
WHEN MATCHED THEN 
UPDATE SET 
ES_DEST_T.lease_nbr = ES_SOURCE_T.lease_nbr,
ES_DEST_T.building_id = ES_SOURCE_T.building_id,
ES_DEST_T.BUSINESS_GROUP_TXT = ES_SOURCE_T.BUSINESS_GROUP_TXT,
ES_DEST_T.brand_nm  = ES_SOURCE_T.brand_nm ,
ES_DEST_T.NIKE_DEPARTMENT_TYPE_TXT = ES_SOURCE_T.NIKE_DEPARTMENT_TYPE_TXT,
ES_DEST_T.property_nm = ES_SOURCE_T.property_nm,
ES_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD  = ES_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD ,
ES_DEST_T.ELECTRICITY_LOCATION_USE_CD = ES_SOURCE_T.ELECTRICITY_LOCATION_USE_CD,
ES_DEST_T.business_function_nm = ES_SOURCE_T.business_function_nm,
ES_DEST_T.division_nm = ES_SOURCE_T.division_nm,
ES_DEST_T.LOCATION_GEO_REGION_CD  = ES_SOURCE_T.LOCATION_GEO_REGION_CD ,
ES_DEST_T.continent_nm = ES_SOURCE_T.continent_nm,
ES_DEST_T.ADDRESS_LINE_1_TXT = ES_SOURCE_T.ADDRESS_LINE_1_TXT,
ES_DEST_T.city_nm = ES_SOURCE_T.city_nm,
ES_DEST_T.STATE_CD = ES_SOURCE_T.STATE_CD,
ES_DEST_T.POSTAL_CD = ES_SOURCE_T.POSTAL_CD,
ES_DEST_T.geographical_axis_nm = ES_SOURCE_T.geographical_axis_nm,
ES_DEST_T.COUNTRY_CD = ES_SOURCE_T.COUNTRY_CD,
ES_DEST_T.LOCATION_AREA_IN_SQFT = ES_SOURCE_T.LOCATION_AREA_IN_SQFT,
ES_DEST_T.LOCATION_STATUS_CD = ES_SOURCE_T.LOCATION_STATUS_CD,
ES_DEST_T.latitude_deg = ES_SOURCE_T.latitude_deg,
ES_DEST_T.longitude_deg = ES_SOURCE_T.longitude_deg,
ES_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC = ES_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
ES_DEST_T.data_source_nm = ES_SOURCE_T.data_source_nm

WHEN NOT MATCHED THEN 
INSERT (
ES_DEST_T.ELECTRICITY_CONSUMPTION_UUID,
ES_DEST_T.ELECTRICITY_LOCATION_NBR,
ES_DEST_T.ELECTRICITY_LOCATION_NM,
ES_DEST_T.lease_nbr,
ES_DEST_T.building_id,
ES_DEST_T.BUSINESS_GROUP_TXT,
ES_DEST_T.brand_nm,
ES_DEST_T.NIKE_DEPARTMENT_TYPE_TXT,
ES_DEST_T.property_nm,
ES_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD,
ES_DEST_T.ELECTRICITY_LOCATION_USE_CD,
ES_DEST_T.business_function_nm,
ES_DEST_T.division_nm,
ES_DEST_T.LOCATION_GEO_REGION_CD,
ES_DEST_T.continent_nm,
ES_DEST_T.ADDRESS_LINE_1_TXT,
ES_DEST_T.city_nm,
ES_DEST_T.STATE_CD,
ES_DEST_T.POSTAL_CD,
ES_DEST_T.geographical_axis_nm,
ES_DEST_T.COUNTRY_CD,
ES_DEST_T.LOCATION_AREA_IN_SQFT,
ES_DEST_T.LOCATION_STATUS_CD,
ES_DEST_T.latitude_deg,
ES_DEST_T.longitude_deg,
ES_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC,
ES_DEST_T.data_source_nm
)

VALUES (
ES_SOURCE_T.ELECTRICITY_CONSUMPTION_UUID,
ES_SOURCE_T.ELECTRICITY_LOCATION_NBR,
ES_SOURCE_T.ELECTRICITY_LOCATION_NM,
ES_SOURCE_T.lease_nbr,
ES_SOURCE_T.building_id,
ES_SOURCE_T.BUSINESS_GROUP_TXT,
ES_SOURCE_T.brand_nm,
ES_SOURCE_T.NIKE_DEPARTMENT_TYPE_TXT,
ES_SOURCE_T.property_nm,
ES_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
ES_SOURCE_T.ELECTRICITY_LOCATION_USE_CD,
ES_SOURCE_T.business_function_nm,
ES_SOURCE_T.division_nm,
ES_SOURCE_T.LOCATION_GEO_REGION_CD,
ES_SOURCE_T.continent_nm,
ES_SOURCE_T.ADDRESS_LINE_1_TXT,
ES_SOURCE_T.city_nm,
ES_SOURCE_T.STATE_CD,
ES_SOURCE_T.POSTAL_CD,
ES_SOURCE_T.geographical_axis_nm,
ES_SOURCE_T.COUNTRY_CD,
ES_SOURCE_T.LOCATION_AREA_IN_SQFT,
ES_SOURCE_T.LOCATION_STATUS_CD,
ES_SOURCE_T.latitude_deg,
ES_SOURCE_T.longitude_deg,
ES_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
ES_SOURCE_T.data_source_nm);