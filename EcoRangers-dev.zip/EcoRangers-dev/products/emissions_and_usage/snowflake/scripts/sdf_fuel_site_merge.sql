MERGE INTO {target_complete_name} AS FS_DEST_T USING (
with site_size_sqft as (select location_key,year, month, dense_rank() over(partition by location_key order by month,year desc) as max_yr_mn, value from 
{logec_table_name}  where parent = 'LOCATION_SIZE_M2_FC' and VALUE is not NULL and value !=0)
, existing_query as (
SELECT
        uuid_string(
            '8e884ace-bee4-11e4-8dfc-aa07a5b093db',
            md5(concat(FUEL_LOCATION_NBR, FUEL_LOCATION_NM,brand_nm))
        ) as FUEL_CONSUMPTION_UUID,
        fuel_location_nbr,
        fuel_location_nm,
        location_key,
        lease_nbr,
        building_id,
        REGEXP_REPLACE(INITCAP(business_group_txt),'-',' ') AS business_group_txt,
        INITCAP(brand_nm) AS brand_nm,
        nike_department_type_txt,
        CASE
            WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
            WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
            WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
            ELSE BUSINESS_ENTITY_GEO_REGION_CD
        END AS BUSINESS_ENTITY_GEO_REGION_CD,
        FUEL_LOCATION_USE_CD,
        business_function_nm,
        division_nm,
        CASE 
            WHEN LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
            WHEN LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
            ELSE LOCATION_GEO_REGION_CD
        END AS LOCATION_GEO_REGION_CD,
        CASE
            WHEN continent_nm ILIKE 'EMEA' THEN 'Europe'
            WHEN continent_nm ILIKE 'APLA' THEN 'Asia'
            WHEN continent_nm ILIKE 'North America' THEN 'North America'
            WHEN continent_nm ILIKE 'Greater China' THEN 'Asia'
            ELSE continent_nm
        END AS continent_nm,
        COALESCE(ADDRESS_LINE_1_TXT, conv_adresss_1) as ADDRESS_LINE_1_TXT,
        COALESCE(INITCAP(city_nm),INITCAP(conv_adresss_2))  AS city_nm,
        COALESCE(STATE_CD,conv_adresss_3) as STATE_CD,
        COALESCE(POSTAL_CD,conv_zip_code) as POSTAL_CD,
        geographical_axis_nm,
        CASE 
            WHEN COUNTRY_CD ILIKE 'Canada' THEN 'CA'
            WHEN COUNTRY_CD ILIKE 'United States' THEN 'US'
            ELSE COUNTRY_CD
        END AS COUNTRY_CD,
        LOCATION_AREA_IN_SQFT,
        LOCATION_STATUS_CD,
        latitude_deg,
        longitude_deg,
        ADDITIONAL_LOCATION_FEATURE_DESC,
        data_source_nm
    FROM
        (
            SELECT
                DISTINCT SUBSTRING(logf.LOCATION_KEY, 4) AS FUEL_LOCATION_NBR,
                --logf.LOCATION_NAME AS FUEL_LOCATION_NM,
                COALESCE(nodef.NAME,logf.LOCATION_NAME) AS FUEL_LOCATION_NM,
                logf.location_key,
                conv_dc_mapping.adresss_1 as conv_adresss_1,
                conv_dc_mapping.adresss_2 as conv_adresss_2,
                conv_dc_mapping.adresss_3 as conv_adresss_3,
                conv_dc_mapping.zip_code as conv_zip_code,
                NULL AS lease_nbr,
                NULL AS building_id,
                CASE
                    WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'Non Retail'
                    ELSE 'Retail'
                END AS BUSINESS_GROUP_TXT,
                CASE WHEN logf.SCENARIO_NAME = 'CONVERSE' then 'CONVERSE'
                ELSE 'NIKE'
                END AS brand_nm,
                CASE WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'Distribution center'
                ELSE NULL 
                END as NIKE_DEPARTMENT_TYPE_TXT,
                logf.REGION AS BUSINESS_ENTITY_GEO_REGION_CD,
                CASE WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'DISTRIBUTION CENTER'
                ELSE NULL 
                END AS FUEL_LOCATION_USE_CD,
                CASE WHEN logf.LOCATION_TYPE = 'Warehouse' and logf.SCENARIO_NAME = 'NIKE' then 'Logistics (N)'
                WHEN logf.LOCATION_TYPE = 'Warehouse' and logf.SCENARIO_NAME = 'CONVERSE' then 'Logistics (C)'
                ELSE NULL
                END AS business_function_nm,
                CASE
                    WHEN logf.LOCATION_TYPE = 'Warehouse'
                    and logf.SCENARIO_NAME = 'NIKE' THEN 'Distribution Centers (N)'
                    WHEN logf.LOCATION_TYPE = 'Warehouse'
                    and logf.SCENARIO_NAME = 'CONVERSE' THEN 'Distribution Centers (C)'
                    ELSE NULL
                END AS division_nm,
                logf.REGION AS LOCATION_GEO_REGION_CD,
                ccg.GEOSHORT_NM AS continent_nm,
                nodef.ADDRESS_LINE_1_TEXT AS ADDRESS_LINE_1_TXT,
                nodef.CITY_NAME AS city_nm,
                nodef.STATE_PROVINCE_CODE AS STATE_CD,
                nodef.POSTAL_CODE AS POSTAL_CD,
                COALESCE(CONCAT(nodef.POSTAL_CODE, '-', nodef.CITY_NAME),conv_dc_mapping.Country) as geographical_axis_nm,
                COALESCE(nodef.ISO_COUNTRY_CODE,conv_dc_mapping.Country_cd) as COUNTRY_CD,
                NULL AS LOCATION_AREA_IN_SQFT,
                CASE
                    WHEN logf.IS_ABS = 'true' THEN 'Open'
                    ELSE 'Close'
                END AS LOCATION_STATUS_CD,
                nodef.LATITUDE_DECIMAL_DEGREE AS latitude_deg,
                nodef.LONGITUDE_DECIMAL_DEGREE AS longitude_deg,
                NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
                'logec' as data_source_nm
            FROM
                {logec_table_name} logf
                left JOIN {node_table_name}  nodef on SUBSTRING(logf.LOCATION_KEY, 4) = nodef.NODE_CODE
                LEFT JOIN {ctry_mapping_table_name} ccg ON logf.region=ccg.REGION
                left join {conv_dc_mapping_table} conv_dc_mapping ON logf.LOCATION_KEY=conv_dc_mapping.LOCATION_KEY
            WHERE
                logf.PARENT IN (
                    'BIOGAS_CERTIFICATES','COST_HI_SENE_SCOPE1','COST_NATURAL_GAS_SCOPE1','COST_PURCHASED_GAS_BIO_GAS','HI_SENE_SCOPE1','NATURAL_GAS_SCOPE1','PURCHASED_GAS_BIO_GAS'
                )
        )
)
select FUEL_CONSUMPTION_UUID,
        fuel_location_nbr,
        fuel_location_nm,
        lease_nbr,
        building_id,business_group_txt,brand_nm,
        nike_department_type_txt,BUSINESS_ENTITY_GEO_REGION_CD,
        FUEL_LOCATION_USE_CD,
        business_function_nm, division_nm,LOCATION_GEO_REGION_CD, continent_nm, ADDRESS_LINE_1_TXT,city_nm,
        STATE_CD,
        POSTAL_CD,
        geographical_axis_nm,COUNTRY_CD,
        round(value*10.76,5) as LOCATION_AREA_IN_SQFT,
        LOCATION_STATUS_CD,
        latitude_deg,
        longitude_deg,
        ADDITIONAL_LOCATION_FEATURE_DESC,
        data_source_nm from existing_query inner join site_size_sqft on site_size_sqft.location_key = existing_query.location_key where site_size_sqft.max_yr_mn=1
) AS FS_SOURCE_T  ON CONCAT_WS(
    '_',
    FS_DEST_T.fuel_consumption_uuid,
    FS_DEST_T.fuel_location_nbr,
    FS_DEST_T.fuel_location_nm
) = CONCAT_WS(
    '_',
    FS_SOURCE_T.fuel_consumption_uuid,
    FS_SOURCE_T.fuel_location_nbr,
    FS_SOURCE_T.fuel_location_nm
)
WHEN MATCHED THEN
UPDATE
SET
    FS_DEST_T.lease_nbr = FS_SOURCE_T.lease_nbr,
    FS_DEST_T.building_id = FS_SOURCE_T.building_id,
    FS_DEST_T.business_group_txt = FS_SOURCE_T.business_group_txt,
    FS_DEST_T.brand_nm = FS_SOURCE_T.brand_nm,
    FS_DEST_T.nike_department_type_txt = FS_SOURCE_T.nike_department_type_txt,
    FS_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD = FS_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
    FS_DEST_T.FUEL_LOCATION_USE_CD = FS_SOURCE_T.FUEL_LOCATION_USE_CD,
    FS_DEST_T.business_function_nm = FS_SOURCE_T.business_function_nm,
    FS_DEST_T.division_nm = FS_SOURCE_T.division_nm,
    FS_DEST_T.LOCATION_GEO_REGION_CD = FS_SOURCE_T.LOCATION_GEO_REGION_CD,
    FS_DEST_T.continent_nm = FS_SOURCE_T.continent_nm,
    FS_DEST_T.ADDRESS_LINE_1_TXT = FS_SOURCE_T.ADDRESS_LINE_1_TXT,
    FS_DEST_T.city_nm = FS_SOURCE_T.city_nm,
    FS_DEST_T.STATE_CD = FS_SOURCE_T.STATE_CD,
    FS_DEST_T.POSTAL_CD = FS_SOURCE_T.POSTAL_CD,
    FS_DEST_T.geographical_axis_nm = FS_SOURCE_T.geographical_axis_nm,
    FS_DEST_T.COUNTRY_CD = FS_SOURCE_T.COUNTRY_CD,
    FS_DEST_T.LOCATION_AREA_IN_SQFT = FS_SOURCE_T.LOCATION_AREA_IN_SQFT,
    FS_DEST_T.LOCATION_STATUS_CD = FS_SOURCE_T.LOCATION_STATUS_CD,
    FS_DEST_T.latitude_deg = FS_SOURCE_T.latitude_deg,
    FS_DEST_T.longitude_deg = FS_SOURCE_T.longitude_deg,
    FS_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC = FS_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
    FS_DEST_T.data_source_nm = FS_SOURCE_T.data_source_nm
    WHEN NOT MATCHED THEN
INSERT
    (
        FS_DEST_T.fuel_consumption_uuid,
        FS_DEST_T.fuel_location_nbr,
        FS_DEST_T.fuel_location_nm,
        FS_DEST_T.lease_nbr,
        FS_DEST_T.building_id,
        FS_DEST_T.business_group_txt,
        FS_DEST_T.brand_nm,
        FS_DEST_T.nike_department_type_txt,
        FS_DEST_T.BUSINESS_ENTITY_GEO_REGION_CD,
        FS_DEST_T.FUEL_LOCATION_USE_CD,
        FS_DEST_T.business_function_nm,
        FS_DEST_T.division_nm,
        FS_DEST_T.LOCATION_GEO_REGION_CD,
        FS_DEST_T.continent_nm,
        FS_DEST_T.ADDRESS_LINE_1_TXT,
        FS_DEST_T.city_nm,
        FS_DEST_T.STATE_CD,
        FS_DEST_T.POSTAL_CD,
        FS_DEST_T.geographical_axis_nm,
        FS_DEST_T.COUNTRY_CD,
        FS_DEST_T.LOCATION_AREA_IN_SQFT,
        FS_DEST_T.LOCATION_STATUS_CD,
        FS_DEST_T.latitude_deg,
        FS_DEST_T.longitude_deg,
        FS_DEST_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        FS_DEST_T.data_source_nm
    )
VALUES
    (
        FS_SOURCE_T.fuel_consumption_uuid,
        FS_SOURCE_T.fuel_location_nbr,
        FS_SOURCE_T.fuel_location_nm,
        FS_SOURCE_T.lease_nbr,
        FS_SOURCE_T.building_id,
        FS_SOURCE_T.business_group_txt,
        FS_SOURCE_T.brand_nm,
        FS_SOURCE_T.nike_department_type_txt,
        FS_SOURCE_T.BUSINESS_ENTITY_GEO_REGION_CD,
        FS_SOURCE_T.FUEL_LOCATION_USE_CD,
        FS_SOURCE_T.business_function_nm,
        FS_SOURCE_T.division_nm,
        FS_SOURCE_T.LOCATION_GEO_REGION_CD,
        FS_SOURCE_T.continent_nm,
        FS_SOURCE_T.ADDRESS_LINE_1_TXT,
        FS_SOURCE_T.city_nm,
        FS_SOURCE_T.STATE_CD,
        FS_SOURCE_T.POSTAL_CD,
        FS_SOURCE_T.geographical_axis_nm,
        FS_SOURCE_T.COUNTRY_CD,
        FS_SOURCE_T.LOCATION_AREA_IN_SQFT,
        FS_SOURCE_T.LOCATION_STATUS_CD,
        FS_SOURCE_T.latitude_deg,
        FS_SOURCE_T.longitude_deg,
        FS_SOURCE_T.ADDITIONAL_LOCATION_FEATURE_DESC,
        FS_SOURCE_T.data_source_nm
    );