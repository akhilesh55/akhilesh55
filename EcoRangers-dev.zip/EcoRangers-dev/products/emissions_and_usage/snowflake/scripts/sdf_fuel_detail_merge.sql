MERGE INTO {target_complete_name} AS FD_DEST_T USING (with DETAILS_AGG as (
    SELECT
    uuid_string('8e884ace-bee4-11e4-8dfc-aa07a5b093db', md5(concat(FUEL_LOCATION_NBR, FUEL_LOCATION_NM,brand_nm))) as FUEL_CONSUMPTION_UUID,
        FUEL_LOCATION_NBR,
        reporting_period_dt,
        BILLING_MONTH_START_DT,
        BILLING_MONTH_END_DT,
        BILLING_MONTH_DATE_RANGE_TXT,
        FUEL_LOCATION_NM,
        REPORTING_FISCAL_YEAR_NBR,
        REPORTING_CALENDAR_YEAR_NBR,
        REPORTING_MONTH_LONG_NM,
        REPORTING_MONTH_OF_YEAR_NBR,
        REPORTING_QUARTER_NBR,
        REPORTING_WEEK_OF_YEAR_NBR,
        building_id,
        SERVICE_TYPE_CD,
        fuel_type_txt,
        saf_pct,
        saf_density_uom,
        NET_HEAT_OF_COMBUSTION_UOM,
        DATA_FREQUENCY_CD,
        COALESCE(MAX(SERVICE_USAGE_QTY), MIN(SERVICE_USAGE_QTY)) AS SERVICE_USAGE_QTY,
        COALESCE(MAX(SERVICE_USAGE_QTY_UOM), MIN(SERVICE_USAGE_QTY_UOM)) AS SERVICE_USAGE_QTY_UOM,
        COALESCE(MAX(SERVICE_COST), MIN(SERVICE_COST)) AS SERVICE_COST,
        COALESCE(MAX(SERVICE_COST_UOM), MIN(SERVICE_COST_UOM)) AS SERVICE_COST_UOM,
        EXTRAPOLATION_IND,
        scope_nbr,
        data_source_nm
    FROM
        (
            SELECT
                SUBSTRING(logf.LOCATION_KEY, 4) AS FUEL_LOCATION_NBR,
                TO_DATE(TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'MM/dd/yyyy'
                )) AS reporting_period_dt,
                CASE WHEN logf.SCENARIO_NAME = 'CONVERSE' then 'CONVERSE'
                ELSE 'NIKE'
                END AS brand_nm,
                TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'MM/dd/yyyy'
                ) AS BILLING_MONTH_START_DT,
                TO_VARCHAR(
                    LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')),
                    'MM/dd/yyyy'
                ) AS BILLING_MONTH_END_DT,
                CONCAT(
                    TO_VARCHAR(
                        TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                        'MM/dd/yyyy'
                    ),
                    '-',
                    TO_VARCHAR(
                        LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')),
                        'MM/dd/yyyy'
                    )
                ) AS BILLING_MONTH_DATE_RANGE_TXT,
                -- logf.LOCATION_NAME AS FUEL_LOCATION_NM,
                COALESCE(nodef.NAME,logf.LOCATION_NAME) AS FUEL_LOCATION_NM,
                cd.FISCAL_YEAR_NM AS REPORTING_FISCAL_YEAR_NBR,
                cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
                cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
                cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
                cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
                cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
                NULL AS building_id,
                CASE 
                    WHEN logf.PARENT = service_tbl.PARENT THEN service_tbl.SERVICE_TYPE
                    ELSE logf.PARENT
                END AS SERVICE_TYPE_CD,
                CASE 
                    WHEN logf.PARENT = service_tbl.PARENT THEN service_tbl.SERVICE_TYPE
                    ELSE logf.PARENT
                END AS fuel_type_txt,
                CAST(NULL AS DECIMAL) AS saf_pct,
                CAST(NULL AS DECIMAL) AS saf_density_uom,
                CAST(NULL AS DECIMAL) AS net_heat_of_combustion_uom,
                CAST(12 AS INTEGER) AS DATA_FREQUENCY_CD,
                CASE
                    WHEN logf.PARENT IN(
                        'BIOGAS_CERTIFICATES','HI_SENE_SCOPE1','NATURAL_GAS_SCOPE1','PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.VALUE
                    ELSE NULL
                END AS SERVICE_USAGE_QTY,
                CASE
                    WHEN logf.PARENT IN(
                        'BIOGAS_CERTIFICATES','HI_SENE_SCOPE1','NATURAL_GAS_SCOPE1','PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.UNIT
                    ELSE NULL
                END AS SERVICE_USAGE_QTY_UOM,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_HI_SENE_SCOPE1','COST_NATURAL_GAS_SCOPE1','COST_PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.VALUE
                    ELSE NULL
                END AS SERVICE_COST,
                CASE
                    WHEN logf.PARENT IN(
                        'COST_HI_SENE_SCOPE1','COST_NATURAL_GAS_SCOPE1','COST_PURCHASED_GAS_BIO_GAS'
                    ) THEN logf.CURRENCY
                    ELSE NULL
                END AS SERVICE_COST_UOM,
                'NO' AS EXTRAPOLATION_IND,
                CASE
                    WHEN logf.PARENT IN(
                        'BIOGAS_CERTIFICATES','COST_HI_SENE_SCOPE1','COST_NATURAL_GAS_SCOPE1','COST_PURCHASED_GAS_BIO_GAS','HI_SENE_SCOPE1','NATURAL_GAS_SCOPE1','PURCHASED_GAS_BIO_GAS'
                    ) THEN 'SCOPE 1'
                    ELSE NULL
                END AS scope_nbr,

                'logec' as data_source_nm
            FROM
                {logec_table_name} logf
                left JOIN {calendar_table_name} cd ON TO_VARCHAR(
                    TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'),
                    'yyyy-MM-dd'
                ) = TO_VARCHAR(cd.calendar_dt)
                left JOIN {node_table_name}  nodef on SUBSTRING(logf.LOCATION_KEY, 4) = nodef.NODE_CODE
                left join {bcl_service_type} service_tbl on logf.LOCATION_KEY = service_tbl.LOCATION_KEY
AND logf.LOCATION_NAME = service_tbl.LOCATION_NAME
AND logf.PARENT = service_tbl.PARENT
            WHERE
                logf.PARENT IN(
                        'BIOGAS_CERTIFICATES','COST_HI_SENE_SCOPE1','COST_NATURAL_GAS_SCOPE1','COST_PURCHASED_GAS_BIO_GAS','HI_SENE_SCOPE1','NATURAL_GAS_SCOPE1','PURCHASED_GAS_BIO_GAS'
                )
        )
    GROUP BY
    FUEL_CONSUMPTION_UUID,
        FUEL_LOCATION_NBR,
        reporting_period_dt,
        brand_nm,
        BILLING_MONTH_START_DT,
        BILLING_MONTH_END_DT,
        BILLING_MONTH_DATE_RANGE_TXT,
        FUEL_LOCATION_NM,
        REPORTING_FISCAL_YEAR_NBR,
        REPORTING_CALENDAR_YEAR_NBR,
        REPORTING_MONTH_LONG_NM,
        REPORTING_MONTH_OF_YEAR_NBR,
        REPORTING_QUARTER_NBR,
        REPORTING_WEEK_OF_YEAR_NBR,
        building_id,
        SERVICE_TYPE_CD,
        fuel_type_txt,
        saf_pct,
        saf_density_uom,
        net_heat_of_combustion_uom,
        DATA_FREQUENCY_CD,
        EXTRAPOLATION_IND,
        scope_nbr,
        data_source_nm
) 
select 
        FUEL_DETAIL.fuel_consumption_uuid,
        FUEL_DETAIL.fuel_location_nbr,
        FUEL_DETAIL.fuel_location_nm,
        FUEL_DETAIL.reporting_period_dt,
        CASE 
            WHEN FUEL_DETAIL.SERVICE_TYPE_CD ILIKE 'Electric' THEN 'Electricity'
            ELSE FUEL_DETAIL.SERVICE_TYPE_CD
        END AS SERVICE_TYPE_CD,
        FUEL_DETAIL.BILLING_MONTH_START_DT,
        FUEL_DETAIL.BILLING_MONTH_END_DT,
        FUEL_DETAIL.BILLING_MONTH_DATE_RANGE_TXT,
        REGEXP_REPLACE(FUEL_DETAIL.REPORTING_FISCAL_YEAR_NBR, '[^0-9]', '') AS REPORTING_FISCAL_YEAR_NBR,
        FUEL_DETAIL.REPORTING_CALENDAR_YEAR_NBR,
        FUEL_DETAIL.REPORTING_MONTH_LONG_NM,
        FUEL_DETAIL.REPORTING_MONTH_OF_YEAR_NBR,
        FUEL_DETAIL.REPORTING_QUARTER_NBR,
        FUEL_DETAIL.REPORTING_WEEK_OF_YEAR_NBR,
        FUEL_DETAIL.building_id,
        FUEL_DETAIL.fuel_type_txt,
        FUEL_DETAIL.saf_pct,
        FUEL_DETAIL.saf_density_uom,
        FUEL_DETAIL.DATA_FREQUENCY_CD,
        FUEL_DETAIL.SERVICE_USAGE_QTY,
        INITCAP(FUEL_DETAIL.SERVICE_USAGE_QTY_UOM) AS SERVICE_USAGE_QTY_UOM,
        FUEL_DETAIL.SERVICE_COST,
        FUEL_DETAIL.SERVICE_COST_UOM,
        FUEL_DETAIL.extrapolation_ind,
        FUEL_DETAIL.scope_nbr,
        FUEL_DETAIL.data_source_nm
        from DETAILS_AGG FUEL_DETAIL ) AS FD_SOURCE_T ON CONCAT_WS(
    '_',
    FD_DEST_T.fuel_consumption_uuid,
    FD_DEST_T.fuel_location_nbr,
    FD_DEST_T.fuel_location_nm,
    FD_DEST_T.reporting_period_dt,
    FD_DEST_T.SERVICE_TYPE_CD
) = CONCAT_WS(
    '_',
    FD_SOURCE_T.fuel_consumption_uuid,
    FD_SOURCE_T.fuel_location_nbr,
    FD_SOURCE_T.fuel_location_nm,
    FD_SOURCE_T.reporting_period_dt,
    FD_SOURCE_T.SERVICE_TYPE_CD
)
WHEN MATCHED THEN
UPDATE
SET
    FD_DEST_T.BILLING_MONTH_START_DT = FD_SOURCE_T.BILLING_MONTH_START_DT,
    FD_DEST_T.BILLING_MONTH_END_DT = FD_SOURCE_T.BILLING_MONTH_END_DT,
    FD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT = FD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
    FD_DEST_T.REPORTING_FISCAL_YEAR_NBR = FD_SOURCE_T.REPORTING_FISCAL_YEAR_NBR,
    FD_DEST_T.REPORTING_CALENDAR_YEAR_NBR = FD_SOURCE_T.REPORTING_CALENDAR_YEAR_NBR,
    FD_DEST_T.REPORTING_MONTH_LONG_NM = FD_SOURCE_T.REPORTING_MONTH_LONG_NM,
    FD_DEST_T.REPORTING_MONTH_OF_YEAR_NBR = FD_SOURCE_T.REPORTING_MONTH_OF_YEAR_NBR,
    FD_DEST_T.REPORTING_QUARTER_NBR = FD_SOURCE_T.REPORTING_QUARTER_NBR,
    FD_DEST_T.REPORTING_WEEK_OF_YEAR_NBR = FD_SOURCE_T.REPORTING_WEEK_OF_YEAR_NBR,
    FD_DEST_T.building_id = FD_SOURCE_T.building_id,
    FD_DEST_T.fuel_type_txt = FD_SOURCE_T.fuel_type_txt,
    FD_DEST_T.saf_pct = FD_SOURCE_T.saf_pct,
    FD_DEST_T.saf_density_uom = FD_SOURCE_T.saf_density_uom,
    FD_DEST_T.DATA_FREQUENCY_CD = FD_SOURCE_T.DATA_FREQUENCY_CD,
    FD_DEST_T.SERVICE_USAGE_QTY = FD_SOURCE_T.SERVICE_USAGE_QTY,
    FD_DEST_T.SERVICE_USAGE_QTY_UOM = FD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
    FD_DEST_T.SERVICE_COST = FD_SOURCE_T.SERVICE_COST,
    FD_DEST_T.SERVICE_COST_UOM = FD_SOURCE_T.SERVICE_COST_UOM,
    FD_DEST_T.extrapolation_ind = FD_SOURCE_T.extrapolation_ind,
    FD_DEST_T.scope_nbr = FD_SOURCE_T.scope_nbr,
    FD_DEST_T.data_source_nm = FD_SOURCE_T.data_source_nm
    WHEN NOT MATCHED THEN
INSERT
    (
        FD_DEST_T.fuel_consumption_uuid,
        FD_DEST_T.fuel_location_nbr,
        FD_DEST_T.fuel_location_nm,
        FD_DEST_T.reporting_period_dt,
        FD_DEST_T.SERVICE_TYPE_CD,
        FD_DEST_T.BILLING_MONTH_START_DT,
        FD_DEST_T.BILLING_MONTH_END_DT,
        FD_DEST_T.BILLING_MONTH_DATE_RANGE_TXT,
        FD_DEST_T.REPORTING_FISCAL_YEAR_NBR,
        FD_DEST_T.REPORTING_CALENDAR_YEAR_NBR,
        FD_DEST_T.REPORTING_MONTH_LONG_NM,
        FD_DEST_T.REPORTING_MONTH_OF_YEAR_NBR,
        FD_DEST_T.REPORTING_QUARTER_NBR,
        FD_DEST_T.REPORTING_WEEK_OF_YEAR_NBR,
        FD_DEST_T.building_id,
        FD_DEST_T.fuel_type_txt,
        FD_DEST_T.saf_pct,
        FD_DEST_T.saf_density_uom,
        FD_DEST_T.DATA_FREQUENCY_CD,
        FD_DEST_T.SERVICE_USAGE_QTY,
        FD_DEST_T.SERVICE_USAGE_QTY_UOM,
        FD_DEST_T.SERVICE_COST,
        FD_DEST_T.SERVICE_COST_UOM,
        FD_DEST_T.extrapolation_ind,
        FD_DEST_T.scope_nbr,
        FD_DEST_T.data_source_nm
    )
VALUES
    (
        FD_SOURCE_T.fuel_consumption_uuid,
        FD_SOURCE_T.fuel_location_nbr,
        FD_SOURCE_T.fuel_location_nm,
        FD_SOURCE_T.reporting_period_dt,
        FD_SOURCE_T.SERVICE_TYPE_CD,
        FD_SOURCE_T.BILLING_MONTH_START_DT,
        FD_SOURCE_T.BILLING_MONTH_END_DT,
        FD_SOURCE_T.BILLING_MONTH_DATE_RANGE_TXT,
        FD_SOURCE_T.REPORTING_FISCAL_YEAR_NBR,
        FD_SOURCE_T.REPORTING_CALENDAR_YEAR_NBR,
        FD_SOURCE_T.REPORTING_MONTH_LONG_NM,
        FD_SOURCE_T.REPORTING_MONTH_OF_YEAR_NBR,
        FD_SOURCE_T.REPORTING_QUARTER_NBR,
        FD_SOURCE_T.REPORTING_WEEK_OF_YEAR_NBR,
        FD_SOURCE_T.building_id,
        FD_SOURCE_T.fuel_type_txt,
        FD_SOURCE_T.saf_pct,
        FD_SOURCE_T.saf_density_uom,
        FD_SOURCE_T.DATA_FREQUENCY_CD,
        FD_SOURCE_T.SERVICE_USAGE_QTY,
        FD_SOURCE_T.SERVICE_USAGE_QTY_UOM,
        FD_SOURCE_T.SERVICE_COST,
        FD_SOURCE_T.SERVICE_COST_UOM,
        FD_SOURCE_T.extrapolation_ind,
        FD_SOURCE_T.scope_nbr,
        FD_SOURCE_T.data_source_nm
    );