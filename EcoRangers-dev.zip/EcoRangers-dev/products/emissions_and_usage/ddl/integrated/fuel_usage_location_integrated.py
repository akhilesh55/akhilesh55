env = "dev"
catalog = "development" if env.lower() == "dev" else "non_published_domain"
db_name = f"{catalog}.global_sustainability_{env}"
sole_group = "Sole.ServicePrincipal.ecorangers.Developer"
view_catalog = "published_domain" if env.lower() == "prod" else "development"
view_database = f"global_sustainability_{env}"

# table DDL
# spark.sql(f"""drop table if exists {db_name}.fuel_usage_location_integrated""")

spark.sql(
    f"""
CREATE TABLE {db_name}.fuel_usage_location_integrated (
  fuel_location_nbr STRING,
  fuel_location_nm STRING,
  lease_nbr STRING,
  building_id STRING,
  business_group_txt STRING,
  brand_nm STRING,
  nike_department_type_txt STRING,
  BUSINESS_ENTITY_GEO_REGION_CD STRING,
  FUEL_LOCATION_USE_CD STRING,
  business_function_nm STRING,
  division_nm STRING,
  LOCATION_GEO_REGION_CD STRING,
  continent_nm STRING,
  ADDRESS_LINE_1_TXT STRING,
  city_nm STRING,
  STATE_CD STRING,
  POSTAL_CD STRING,
  geographical_axis_nm STRING,
  COUNTRY_CD STRING,
  LOCATION_AREA_IN_SQFT DOUBLE,
  LOCATION_STATUS_CD STRING,
  latitude_deg STRING,
  longitude_deg STRING,
  ADDITIONAL_LOCATION_FEATURE_DESC STRING,
  data_source_nm STRING,
  fuel_consumption_uuid STRING,
  user_nm STRING,
  load_dt DATE,
  load_month_nbr INT,
  load_year_nbr INT,
  created_at_tmst TIMESTAMP,
  batch_load_tmst TIMESTAMP,
  job_nm STRING,
  job_run_id STRING,
  hash_col INT,
  updated_at_tmst TIMESTAMP,
  lease_custom_key STRING)
USING delta
PARTITIONED BY (load_year_nbr, load_month_nbr)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4')
"""
)

if catalog == "development":
    spark.sql(
        f"ALTER TABLE {db_name}.fuel_usage_location_integrated OWNER TO `{sole_group}`"
    )

# view ddl
spark.sql(
    f"""
CREATE VIEW {db_name}.fuel_usage_location_integrated_v 
AS SELECT
    SUBSTR(REGEXP_REPLACE(FUEL_CONSUMPTION_UUID,'[^a-zA-Z0-9]',''),1,10) AS FUEL_CONSUMPTION_UUID,
    FUEL_LOCATION_NBR,
    FUEL_LOCATION_NM,
    LEASE_NBR,
    BUILDING_ID,
    BUSINESS_GROUP_TXT,
    BRAND_NM,
    NIKE_DEPARTMENT_TYPE_TXT,
    BUSINESS_ENTITY_GEO_REGION_CD,
    FUEL_LOCATION_USE_CD,
    BUSINESS_FUNCTION_NM,
    DIVISION_NM,
    LOCATION_GEO_REGION_CD,
    CONTINENT_NM,
    ADDRESS_LINE_1_TXT,
    CITY_NM,
    STATE_CD,
    POSTAL_CD,
    GEOGRAPHICAL_AXIS_NM,
    COUNTRY_CD,
    LOCATION_AREA_IN_SQFT,
    LOCATION_STATUS_CD,
    LATITUDE_DEG,
    LONGITUDE_DEG,
    ADDITIONAL_LOCATION_FEATURE_DESC,
    BATCH_LOAD_TMST AS BATCH_LOAD_TIMESTAMP
FROM
    {db_name}.FUEL_USAGE_LOCATION_INTEGRATED
"""
)
