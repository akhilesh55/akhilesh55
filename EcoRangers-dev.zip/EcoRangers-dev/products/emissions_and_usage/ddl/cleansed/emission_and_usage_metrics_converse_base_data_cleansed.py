env = "dev"
catalog = "development" if env.lower() == "dev" else "non_published_domain"
db_name = f"{catalog}.global_sustainability_{env}"
sole_group = "Sole.ServicePrincipal.ecorangers.Developer"
view_catalog = "published_domain" if env.lower() == "prod" else "development"
view_database = f"global_sustainability_{env}"

# table DDL
# spark.sql(f"""drop table if exists {db_name}.emission_and_usage_metrics_converse_base_data_cleansed""")

spark.sql(
    f"""
CREATE TABLE {db_name}.emission_and_usage_metrics_converse_base_data_cleansed (
  location_nm STRING,
  location_nbr INT,
  location_address_1_nm STRING,
  location_address_2_nm STRING,
  location_city_nm STRING,
  location_state_or_province_nm STRING,
  location_postal_cd STRING,
  location_country_nm STRING,
  location_status_desc STRING,
  location_size_sqft INT,
  misc_information_desc STRING,
  vendor_nm STRING,
  vendor_address_1_nm STRING,
  vendor_address_2_nm STRING,
  vendor_city_nm STRING,
  vendor_state_or_province_nm STRING,
  vendor_postal_cd STRING,
  vendor_country_nm STRING,
  account_nbr STRING,
  summary_account_nbr STRING,
  account_address_1_nm STRING,
  account_address_2_nm STRING,
  account_city_nm STRING,
  account_state_or_province_nm STRING,
  account_postal_cd STRING,
  account_country_nm STRING,
  clean_account_number_desc STRING,
  supplier_only_account_ind STRING,
  audit_only_ind STRING,
  customer_gl_nbr STRING,
  gl_desc STRING,
  gl_allocation_pct INT,
  meter_number_desc STRING,
  service_point_location_nm STRING,
  rate_schedule_desc STRING,
  month_dt DATE,
  begin_dt DATE,
  end_dt DATE,
  service_days INT,
  cost DECIMAL(38,5),
  service_type_nm STRING,
  uom STRING,
  usage_qty DECIMAL(38,5),
  billed_qty DECIMAL(38,5),
  cost_per_unit_uom DECIMAL(38,5),
  cost_per_day DECIMAL(38,5),
  cost_per_sqft DECIMAL(38,5),
  usage_per_day DECIMAL(38,5),
  usage_per_sqft DECIMAL(38,5),
  kbtus_qty DECIMAL(38,5),
  kbtus_per_sqft DECIMAL(38,5),
  max_demand_qty DECIMAL(38,5),
  load_factor_qty DECIMAL(38,5),
  power_factor_qty DECIMAL(38,5),
  cost_per_billed_qty DECIMAL(38,5),
  bill_estimated_ind STRING,
  open_exceptions_ind STRING,
  bill_image_desc STRING,
  department_nm STRING,
  ems_desc STRING,
  in_line_outlet_desc STRING,
  lease_number_desc STRING,
  location_crc_nbr INT,
  location_opened_dt DATE,
  created_at_tmst TIMESTAMP,
  user_nm STRING,
  file_nm STRING,
  load_dt DATE,
  load_year_nbr INT,
  load_month_nbr INT,
  batch_load_tmst TIMESTAMP,
  job_nm STRING,
  job_run_id STRING)
USING delta
PARTITIONED BY (load_year_nbr, load_month_nbr)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4')
"""
)

if catalog == "development":
    spark.sql(
        f"ALTER TABLE {db_name}.emission_and_usage_metrics_converse_base_data_cleansed OWNER TO `{sole_group}`"
    )
