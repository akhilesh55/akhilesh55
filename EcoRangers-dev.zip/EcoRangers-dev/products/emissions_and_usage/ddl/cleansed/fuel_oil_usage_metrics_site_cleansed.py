env = "dev"
catalog = "development" if env.lower() == "dev" else "non_published_domain"
db_name = f"{catalog}.global_sustainability_{env}"
sole_group = "Sole.ServicePrincipal.ecorangers.Developer"
view_catalog = "published_domain" if env.lower() == "prod" else "development"
view_database = f"global_sustainability_{env}"

# table DDL
# spark.sql(f"""drop table if exists {db_name}.fuel_oil_usage_metrics_site_cleansed""")

spark.sql(
    f"""
CREATE TABLE {db_name}.fuel_oil_usage_metrics_site_cleansed (
  location_nm STRING,
  location_nbr INT,
  vendor_nm STRING,
  account_nbr STRING,
  clean_account_number_desc STRING,
  bill_month_dt DATE,
  bill_type DATE,
  fiscal_period INT,
  bill_dt DATE,
  service_begin_dt DATE,
  service_end_dt DATE,
  service_days STRING,
  service_desc STRING,
  service_alias STRING,
  customer_gl_nbr STRING,
  gl_desc STRING,
  gl_allocation_pct INT,
  service_status STRING,
  service_type_nm STRING,
  uom STRING,
  usage_qty DECIMAL(38,5),
  usage_per_day DECIMAL(38,5),
  billed_qty DECIMAL(38,5),
  cost DECIMAL(38,5),
  cost_per_day DECIMAL(38,5),
  location_address_1_nm STRING,
  location_address_2_nm STRING,
  location_city_nm STRING,
  location_state_or_province_nm STRING,
  location_postal_cd STRING,
  location_country_nm STRING,
  location_status_desc STRING,
  misc_information_desc STRING,
  vendor_address_1_nm STRING,
  vendor_address_2_nm STRING,
  vendor_city_nm STRING,
  vendor_state_or_province_nm STRING,
  vendor_postal_cd STRING,
  vendor_cd STRING,
  vendor_invoice_nbr STRING,
  vendor_country_nm STRING,
  summary_account_nbr STRING,
  audit_only_ind STRING,
  account_address_1_nm STRING,
  account_address_2_nm STRING,
  account_city_nm STRING,
  account_state_or_province_nm STRING,
  account_postal_cd STRING,
  account_country_nm STRING,
  account_status STRING,
  account_status_dt DATE,
  account_notes_txt STRING,
  consolidated_dt DATE,
  consolidated_invoice_nbr STRING,
  consolidated_funding_dt STRING,
  due_dt DATE,
  entry_dt DATE,
  payment_initiated_dt DATE,
  payment_clearing_dt DATE,
  check_nbr STRING,
  total_bill_amt STRING,
  engie_insight_bill_id STRING,
  engie_insight_receipt_dt DATE,
  meter_number_desc STRING,
  rate_schedule_desc STRING,
  service_point_location_nm STRING,
  supplier_only_account_ind STRING,
  misc_or_otc_notes STRING,
  max_demand_qty DECIMAL(38,5),
  bill_image_desc STRING,
  department_nm STRING,
  ems_desc STRING,
  ems_install_dt DATE,
  global_sustainability_energy_and_carbon_target_group_desc STRING,
  lease_number_desc STRING,
  location_opened_dt DATE,
  site_cd_siterra_desc STRING,
  total_bldg_sqft INT,
  wd_and_c_geo STRING,
  whq_campus_nm STRING,
  audit_status_dt DATE,
  contract_expiration_dt DATE,
  contract_nm STRING,
  contract_status_desc STRING,
  created_at_tmst TIMESTAMP,
  user_nm STRING,
  file_nm STRING,
  load_dt DATE,
  load_year_nbr INT,
  load_month_nbr INT,
  batch_load_tmst TIMESTAMP,
  job_nm STRING,
  job_run_id STRING)
USING delta
PARTITIONED BY (load_year_nbr, load_month_nbr)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4')
"""
)

if catalog == "development":
    spark.sql(
        f"ALTER TABLE {db_name}.fuel_oil_usage_metrics_site_cleansed OWNER TO `{sole_group}`"
    )
