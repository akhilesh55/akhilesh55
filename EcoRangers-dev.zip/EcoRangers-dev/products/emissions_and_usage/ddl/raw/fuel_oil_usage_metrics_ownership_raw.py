env = "dev"
catalog = "development" if env.lower() == "dev" else "non_published_domain"
db_name = f"{catalog}.global_sustainability_{env}"
sole_group = "Sole.ServicePrincipal.ecorangers.Developer"
view_catalog = "published_domain" if env.lower() == "prod" else "development"
view_database = f"global_sustainability_{env}"

# table DDL
# spark.sql(f"""drop table if exists {db_name}.fuel_oil_usage_metrics_ownership_raw""")

spark.sql(
    f"""
CREATE TABLE {db_name}.fuel_oil_usage_metrics_ownership_raw (
  location_name STRING,
  location_number STRING,
  vendor_name STRING,
  account_number STRING,
  clean_account_number STRING,
  bill_month STRING,
  bill_type STRING,
  fiscal_period STRING,
  bill_date STRING,
  service_begin_date STRING,
  service_end_date STRING,
  service_days STRING,
  service_description STRING,
  service_alias STRING,
  customer_gl_number STRING,
  gl_description STRING,
  gl_percent_allocation STRING,
  service_status STRING,
  service_type STRING,
  uom STRING,
  usage STRING,
  usage_per_day STRING,
  billed_quantity STRING,
  cost STRING,
  cost_per_day STRING,
  location_address_1 STRING,
  location_address_2 STRING,
  location_city STRING,
  location_state_or_province STRING,
  location_postal_code STRING,
  location_country STRING,
  location_status STRING,
  misc_information STRING,
  vendor_address_1 STRING,
  vendor_address_2 STRING,
  vendor_city STRING,
  vendor_state_or_province STRING,
  vendor_postal_code STRING,
  vendor_code STRING,
  vendor_invoice_number STRING,
  vendor_country STRING,
  summary_account_number STRING,
  audit_only STRING,
  account_address_1 STRING,
  account_address_2 STRING,
  account_city STRING,
  account_state_or_province STRING,
  account_postal_code STRING,
  account_country STRING,
  account_status STRING,
  account_status_date STRING,
  account_notes STRING,
  consolidated_date STRING,
  consolidated_invoice_number STRING,
  consolidated_funding_date STRING,
  due_date STRING,
  entry_date STRING,
  payment_initiated_date STRING,
  payment_clearing_date STRING,
  check_number STRING,
  total_bill_amount STRING,
  engie_insight_bill_id STRING,
  engie_insight_receipt_date STRING,
  meter_number STRING,
  rate_schedule STRING,
  service_point_location STRING,
  supplier_only_account STRING,
  misc_or_otc_notes STRING,
  max_demand STRING,
  bill_image STRING,
  file_nm STRING,
  department STRING,
  lease_number STRING,
  leed STRING,
  location_crc STRING,
  new_building_name STRING,
  ownership STRING,
  principle_bldg_activity STRING,
  seated_occupancy STRING,
  sub_concept STRING,
  audit_status_date STRING,
  contract_expiration_date STRING,
  contract_name STRING,
  contract_status STRING,
  user_nm STRING,
  load_dt STRING,
  load_month_nbr STRING,
  load_year_nbr STRING,
  created_at_tmst STRING,
  batch_load_tmst STRING,
  job_nm STRING,
  job_run_id STRING)
USING delta
PARTITIONED BY (load_year_nbr, load_month_nbr)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4')
"""
)

if catalog == "development":
    spark.sql(
        f"ALTER TABLE {db_name}.fuel_oil_usage_metrics_ownership_raw OWNER TO `{sole_group}`"
    )
