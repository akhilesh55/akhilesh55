env = "dev"
catalog = "development" if env.lower() == "dev" else "non_published_domain"
db_name = f"{catalog}.global_sustainability_{env}"
sole_group = "Sole.ServicePrincipal.ecorangers.Developer"
view_catalog = "published_domain" if env.lower() == "prod" else "development"
view_database = f"global_sustainability_{env}"

# table DDL
# spark.sql(f"""drop table if exists {db_name}.Emission_and_usage_metrics_floor_raw""")

spark.sql(
    f"""
CREATE TABLE {db_name}.Emission_and_usage_metrics_floor_raw (
  location_name STRING,
  location_number STRING,
  location_address_1 STRING,
  location_address_2 STRING,
  location_city STRING,
  location_state_or_province STRING,
  location_postal_code STRING,
  location_country STRING,
  location_status STRING,
  location_size_sqft STRING,
  misc_information STRING,
  vendor_name STRING,
  vendor_address_1 STRING,
  vendor_address_2 STRING,
  vendor_city STRING,
  vendor_state_or_province STRING,
  vendor_postal_code STRING,
  vendor_country STRING,
  account_number STRING,
  summary_account_number STRING,
  account_address_1 STRING,
  account_address_2 STRING,
  account_city STRING,
  account_state_or_province STRING,
  account_postal_code STRING,
  account_country STRING,
  clean_account_number STRING,
  supplier_only_account STRING,
  audit_only STRING,
  customer_gl_number STRING,
  gl_description STRING,
  gl_percent_allocation STRING,
  meter_number STRING,
  service_point_location STRING,
  rate_schedule STRING,
  month STRING,
  begin_date STRING,
  end_date STRING,
  service_days STRING,
  cost STRING,
  service_type STRING,
  uom STRING,
  usage STRING,
  billed_quantity STRING,
  cost_per_unit STRING,
  cost_per_day STRING,
  cost_per_sq_ft STRING,
  usage_per_day STRING,
  usage_per_sq_ft STRING,
  kbtus STRING,
  kbtus_per_sq_ft STRING,
  max_demand STRING,
  load_factor STRING,
  power_factor STRING,
  cost_per_billed_qty STRING,
  bill_estimated STRING,
  open_exceptions STRING,
  bill_image STRING,
  file_nm STRING,
  number_floors STRING,
  alternate_name STRING,
  baseline_note STRING,
  better_buildings_challenge STRING,
  department STRING,
  district_inline STRING,
  district_outlet STRING,
  footprint_sq_ft STRING,
  in_line_outlet STRING,
  lease_number STRING,
  audit_status_date STRING,
  contract_expiration_date STRING,
  contract_name STRING,
  contract_status STRING,
  user_nm STRING,
  load_dt STRING,
  load_month_nbr STRING,
  load_year_nbr STRING,
  created_at_tmst STRING,
  batch_load_tmst STRING,
  job_nm STRING,
  job_run_id STRING)
USING delta
PARTITIONED BY (load_year_nbr, load_month_nbr)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '4')
"""
)

if catalog == "development":
    spark.sql(
        f"ALTER TABLE {db_name}.Emission_and_usage_metrics_floor_raw OWNER TO `{sole_group}`"
    )
