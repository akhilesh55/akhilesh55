WITH
  CURATED_TABLE AS (
    SELECT
      location_nm,
      location_nbr,
      lease_number_desc,
      department_nm,
      service_type_nm,
      location_address_1_nm
    FROM
      {curated_table_name}
  ),
  SITE_UNION AS (
    (
      SELECT
        t.location_nm,
        t.location_nbr,
        t.lease_number_desc,
        t.service_type_nm,
        t.department_nm,
        'duplicate site name' AS alert_desc,
        'Duplicate location_nm from vendor, please revisit and update UMD entry for this location.' AS resolution_desc
      FROM
        CURATED_TABLE t
        JOIN CURATED_TABLE t1 ON COALESCE(t.location_nbr, '-999999999') = COALESCE(t1.location_nbr, '-999999999')
        AND COALESCE(t.lease_number_desc, '-999999999') = COALESCE(t1.lease_number_desc, '-999999999')
        AND COALESCE(t.service_type_nm, '-999999999') = COALESCE(t1.service_type_nm, '-999999999')
        AND COALESCE(t.department_nm, '-999999999') = COALESCE(t1.department_nm, '-999999999')
        AND t.location_nm <> t1.location_nm
      ORDER BY
        t.location_nm DESC
    )
    UNION ALL
    (
      SELECT
        t.location_nm,
        t.location_nbr,
        t.lease_number_desc,
        t.service_type_nm,
        t.department_nm,
        'duplicate site number' AS alert_desc,
        'Duplicate location_nbr from vendor, please revisit and update UMD entry for this location.' AS resolution_desc
      FROM
        CURATED_TABLE t
        JOIN CURATED_TABLE t1 ON t.location_nm = t1.location_nm
        AND t.lease_number_desc = t1.lease_number_desc
        AND COALESCE(t.service_type_nm, '-999999999') = COALESCE(t1.service_type_nm, '-999999999')
        AND COALESCE(t.department_nm, '-999999999') = COALESCE(t1.department_nm, '-999999999')
        AND t.location_nbr <> t1.location_nbr
      ORDER BY
        t.location_nm DESC
    )
  )
SELECT DISTINCT
  location_nm,
  location_nbr,
  lease_number_desc,
  service_type_nm,
  department_nm,
  alert_desc,
  resolution_desc,
  'emission_and_usage_metrics' AS cost_usage_data_source_nm
FROM
  SITE_UNION
