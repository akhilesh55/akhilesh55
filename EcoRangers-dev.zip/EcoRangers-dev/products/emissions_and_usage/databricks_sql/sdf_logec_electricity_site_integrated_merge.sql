WITH
  site_size_sqft AS (
    SELECT
      location_key,
      year,
      month,
      DENSE_RANK() OVER (
        PARTITION BY
          location_key
        ORDER BY
          month,
          year DESC
      ) AS max_yr_mn,
      value
    FROM
      logec_table_name
    WHERE
      parent = 'LOCATION_SIZE_M2_FC'
      AND VALUE IS NOT NULL
      AND value != 0
  ),
  existing_query AS (
    SELECT
      -- uuid_string(
      --     '8e884ace-bee4-11e4-8dfc-aa07a5b093db',
      --     md5(concat(ELECTRICITY_LOCATION_NBR, ELECTRICITY_LOCATION_NM,brand_nm))
      -- ) as ELECTRICITY_CONSUMPTION_UUID,
      electricity_location_nbr,
      location_key,
      electricity_location_nm,
      lease_nbr,
      building_id,
      REGEXP_REPLACE(INITCAP(business_group_txt), '-', ' ') AS business_group_txt,
      INITCAP(brand_nm) AS brand_nm,
      nike_department_type_txt,
      property_nm,
      CASE
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
        ELSE BUSINESS_ENTITY_GEO_REGION_CD
      END AS BUSINESS_ENTITY_GEO_REGION_CD,
      ELECTRICITY_LOCATION_USE_CD,
      business_function_nm,
      division_nm,
      CASE
        WHEN LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
        ELSE LOCATION_GEO_REGION_CD
      END AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN continent_nm ILIKE 'EMEA' THEN 'Europe'
        WHEN continent_nm ILIKE 'APLA' THEN 'Asia'
        WHEN continent_nm ILIKE 'North America' THEN 'North America'
        WHEN continent_nm ILIKE 'Greater China' THEN 'Asia'
        ELSE continent_nm
      END AS continent_nm,
      COALESCE(ADDRESS_LINE_1_TXT, conv_adresss_1) AS ADDRESS_LINE_1_TXT,
      COALESCE(INITCAP(city_nm), INITCAP(conv_adresss_2)) AS city_nm,
      COALESCE(STATE_CD, conv_adresss_3) AS STATE_CD,
      COALESCE(POSTAL_CD, conv_zip_code) AS POSTAL_CD,
      geographical_axis_nm,
      CASE
        WHEN COUNTRY_CD ILIKE 'Canada' THEN 'CA'
        WHEN COUNTRY_CD ILIKE 'United States' THEN 'US'
        ELSE COUNTRY_CD
      END AS COUNTRY_CD,
      -- LOCATION_AREA_IN_SQFT,
      LOCATION_STATUS_CD,
      latitude_deg,
      longitude_deg,
      ADDITIONAL_LOCATION_FEATURE_DESC,
      data_source_nm
    FROM
      (
        SELECT DISTINCT
          SUBSTRING(log_tbl.LOCATION_KEY, 4) AS ELECTRICITY_LOCATION_NBR,
          log_tbl.location_key,
          --log_tbl.LOCATION_NAME as ELECTRICITY_LOCATION_NM,
          COALESCE(node_tbl.NAME, log_tbl.LOCATION_NAME) AS ELECTRICITY_LOCATION_NM,
          conv_dc_mapping.adresss_1 AS conv_adresss_1,
          conv_dc_mapping.adresss_2 AS conv_adresss_2,
          conv_dc_mapping.adresss_3 AS conv_adresss_3,
          conv_dc_mapping.zip_code AS conv_zip_code,
          NULL AS lease_nbr,
          NULL AS building_id,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'Non Retail'
            ELSE 'Retail'
          END AS BUSINESS_GROUP_TXT,
          CASE
            WHEN log_tbl.SCENARIO_NAME = 'CONVERSE' THEN 'CONVERSE'
            ELSE 'NIKE'
          END AS brand_nm,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'Distribution center'
            ELSE NULL
          END AS NIKE_DEPARTMENT_TYPE_TXT,
          COALESCE(node_tbl.NAME, log_tbl.LOCATION_NAME) AS property_nm,
          log_tbl.REGION AS BUSINESS_ENTITY_GEO_REGION_CD,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse' THEN 'DISTRIBUTION CENTER'
            ELSE NULL
          END AS ELECTRICITY_LOCATION_USE_CD,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'NIKE' THEN 'Logistics (N)'
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'CONVERSE' THEN 'Logistics (C)'
            ELSE NULL
          END AS business_function_nm,
          CASE
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'NIKE' THEN 'Distribution Centers (N)'
            WHEN log_tbl.LOCATION_TYPE = 'Warehouse'
            AND log_tbl.SCENARIO_NAME = 'CONVERSE' THEN 'Distribution Centers (C)'
            ELSE NULL
          END AS division_nm,
          log_tbl.REGION AS LOCATION_GEO_REGION_CD,
          ctry_mapping.GEOSHORT_NM AS continent_nm,
          node_tbl.ADDRESS_LINE_1_TEXT AS ADDRESS_LINE_1_TXT,
          node_tbl.CITY_NAME AS city_nm,
          node_tbl.STATE_PROVINCE_CODE AS STATE_CD,
          node_tbl.POSTAL_CODE AS POSTAL_CD,
          COALESCE(
            CONCAT(node_tbl.POSTAL_CODE, '-', node_tbl.CITY_NAME),
            conv_dc_mapping.Country
          ) AS geographical_axis_nm,
          COALESCE(
            node_tbl.ISO_COUNTRY_CODE,
            conv_dc_mapping.Country_cd
          ) AS COUNTRY_CD,
          -- NULL as LOCATION_AREA_IN_SQFT,
          CASE
            WHEN log_tbl.IS_ABS = 'true' THEN 'Open'
            ELSE 'Close'
          END AS LOCATION_STATUS_CD,
          node_tbl.LATITUDE_DECIMAL_DEGREE AS latitude_deg,
          node_tbl.LONGITUDE_DECIMAL_DEGREE AS longitude_deg,
          NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
          'logec' AS data_source_nm
        FROM
          logec_table_name log_tbl
          LEFT JOIN {node_table_name} node_tbl ON SUBSTRING(log_tbl.LOCATION_KEY, 4) = node_tbl.NODE_CODE
          LEFT JOIN ctry_mapping_table_name ctry_mapping ON log_tbl.region = ctry_mapping.REGION
          LEFT JOIN conv_dc_mapping_table conv_dc_mapping ON log_tbl.LOCATION_KEY = conv_dc_mapping.LOCATION_KEY
        WHERE
          log_tbl.PARENT IN (
            'COST_GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'COST_GENERATED_ELECTRICITY_WIND_SCOPE2',
            'COST_PURCHASED_ELECTRICITY_SCOPE2',
            'GENERATED_ELECTRICITY_PHOTOVOLTAIC_SCOPE2',
            'GENERATED_ELECTRICITY_WIND_SCOPE2',
            'OFFSITE_WIND_CONSUMPTION',
            'ONSITE_SOLAR_CONSUMPTION',
            'ONSITE_SOLAR_GENERATION',
            'ONSITE_WIND_CONSUMPTION',
            'ONSITE_WIND_GENERATION',
            'PURCHASED_ELECTRICITY_SCOPE2',
            'REC_AMOUNT_BIOMASS_EMITTED',
            'REC_AMOUNT_GEOTHERMAL',
            'REC_AMOUNT_HYDROPOWER',
            'REC_AMOUNT_SOLAR',
            'REC_AMOUNT_SOLAR_WIND',
            'REC_AMOUNT_WIND',
            'SURPLUS_ONSITE_SOLAR_GENERATION',
            'SURPLUS_ONSITE_WIND_GENERATION'
          )
      )
  )
SELECT
  electricity_location_nbr,
  electricity_location_nm,
  lease_nbr,
  building_id,
  business_group_txt,
  brand_nm,
  CASE
    WHEN nike_department_type_txt ILIKE '%air mi%' THEN 'Air MI'
    ELSE nike_department_type_txt
  END AS nike_department_type_txt,
  property_nm,
  BUSINESS_ENTITY_GEO_REGION_CD,
  ELECTRICITY_LOCATION_USE_CD,
  business_function_nm,
  LOCATION_GEO_REGION_CD,
  continent_nm,
  ADDRESS_LINE_1_TXT,
  city_nm,
  STATE_CD,
  POSTAL_CD,
  geographical_axis_nm,
  COUNTRY_CD,
  CAST(ROUND(value * 10.76, 5) AS DECIMAL(31, 0)) AS LOCATION_AREA_IN_SQFT,
  division_nm,
  LOCATION_STATUS_CD,
  latitude_deg,
  longitude_deg,
  ADDITIONAL_LOCATION_FEATURE_DESC,
  data_source_nm
FROM
  existing_query
  INNER JOIN site_size_sqft ON site_size_sqft.location_key = existing_query.location_key
WHERE
  site_size_sqft.max_yr_mn = 1
