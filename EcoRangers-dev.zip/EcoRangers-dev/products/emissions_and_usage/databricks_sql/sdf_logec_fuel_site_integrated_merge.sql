WITH
  site_size_sqft AS (
    SELECT
      location_key,
      year,
      month,
      DENSE_RANK() OVER (
        PARTITION BY
          location_key
        ORDER BY
          month,
          year DESC
      ) AS max_yr_mn,
      value
    FROM
      logec_table_name
    WHERE
      parent = 'LOCATION_SIZE_M2_FC'
      AND VALUE IS NOT NULL
      AND value != 0
  ),
  existing_query AS (
    SELECT
      -- uuid_string(
      --     '8e884ace-bee4-11e4-8dfc-aa07a5b093db',
      --     md5(concat()
      -- ) as FUEL_CONSUMPTION_UUID,
      fuel_location_nbr,
      fuel_location_nm,
      location_key,
      lease_nbr,
      building_id,
      REGEXP_REPLACE(INITCAP(business_group_txt), '-', ' ') AS business_group_txt,
      INITCAP(brand_nm) AS brand_nm,
      nike_department_type_txt,
      CASE
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Asia' THEN 'APLA'
        WHEN BUSINESS_ENTITY_GEO_REGION_CD ILIKE 'Europe' THEN 'EMEA'
        ELSE BUSINESS_ENTITY_GEO_REGION_CD
      END AS BUSINESS_ENTITY_GEO_REGION_CD,
      FUEL_LOCATION_USE_CD,
      business_function_nm,
      division_nm,
      CASE
        WHEN LOCATION_GEO_REGION_CD ILIKE 'North America' THEN 'NA'
        WHEN LOCATION_GEO_REGION_CD ILIKE 'Greater China' THEN 'GC'
        ELSE LOCATION_GEO_REGION_CD
      END AS LOCATION_GEO_REGION_CD,
      CASE
        WHEN continent_nm ILIKE 'EMEA' THEN 'Europe'
        WHEN continent_nm ILIKE 'APLA' THEN 'Asia'
        WHEN continent_nm ILIKE 'North America' THEN 'North America'
        WHEN continent_nm ILIKE 'Greater China' THEN 'Asia'
        ELSE continent_nm
      END AS continent_nm,
      COALESCE(ADDRESS_LINE_1_TXT, conv_adresss_1) AS ADDRESS_LINE_1_TXT,
      COALESCE(INITCAP(city_nm), INITCAP(conv_adresss_2)) AS city_nm,
      COALESCE(STATE_CD, conv_adresss_3) AS STATE_CD,
      COALESCE(POSTAL_CD, conv_zip_code) AS POSTAL_CD,
      geographical_axis_nm,
      CASE
        WHEN COUNTRY_CD ILIKE 'Canada' THEN 'CA'
        WHEN COUNTRY_CD ILIKE 'United States' THEN 'US'
        ELSE COUNTRY_CD
      END AS COUNTRY_CD,
      LOCATION_AREA_IN_SQFT,
      LOCATION_STATUS_CD,
      latitude_deg,
      longitude_deg,
      ADDITIONAL_LOCATION_FEATURE_DESC,
      data_source_nm
    FROM
      (
        SELECT DISTINCT
          SUBSTRING(logf.LOCATION_KEY, 4) AS FUEL_LOCATION_NBR,
          --logf.LOCATION_NAME AS FUEL_LOCATION_NM,
          COALESCE(nodef.NAME, logf.LOCATION_NAME) AS FUEL_LOCATION_NM,
          logf.location_key,
          conv_dc_mapping.adresss_1 AS conv_adresss_1,
          conv_dc_mapping.adresss_2 AS conv_adresss_2,
          conv_dc_mapping.adresss_3 AS conv_adresss_3,
          conv_dc_mapping.zip_code AS conv_zip_code,
          NULL AS lease_nbr,
          NULL AS building_id,
          CASE
            WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'Non Retail'
            ELSE 'Retail'
          END AS BUSINESS_GROUP_TXT,
          CASE
            WHEN logf.SCENARIO_NAME = 'CONVERSE' THEN 'CONVERSE'
            ELSE 'NIKE'
          END AS brand_nm,
          CASE
            WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'Distribution center'
            ELSE NULL
          END AS NIKE_DEPARTMENT_TYPE_TXT,
          logf.REGION AS BUSINESS_ENTITY_GEO_REGION_CD,
          CASE
            WHEN logf.LOCATION_TYPE = 'Warehouse' THEN 'DISTRIBUTION CENTER'
            ELSE NULL
          END AS FUEL_LOCATION_USE_CD,
          CASE
            WHEN logf.LOCATION_TYPE = 'Warehouse'
            AND logf.SCENARIO_NAME = 'NIKE' THEN 'Logistics (N)'
            WHEN logf.LOCATION_TYPE = 'Warehouse'
            AND logf.SCENARIO_NAME = 'CONVERSE' THEN 'Logistics (C)'
            ELSE NULL
          END AS business_function_nm,
          CASE
            WHEN logf.LOCATION_TYPE = 'Warehouse'
            AND logf.SCENARIO_NAME = 'NIKE' THEN 'Distribution Centers (N)'
            WHEN logf.LOCATION_TYPE = 'Warehouse'
            AND logf.SCENARIO_NAME = 'CONVERSE' THEN 'Distribution Centers (C)'
            ELSE NULL
          END AS division_nm,
          logf.REGION AS LOCATION_GEO_REGION_CD,
          ccg.GEOSHORT_NM AS continent_nm,
          nodef.ADDRESS_LINE_1_TEXT AS ADDRESS_LINE_1_TXT,
          nodef.CITY_NAME AS city_nm,
          nodef.STATE_PROVINCE_CODE AS STATE_CD,
          nodef.POSTAL_CODE AS POSTAL_CD,
          COALESCE(
            CONCAT(nodef.POSTAL_CODE, '-', nodef.CITY_NAME),
            conv_dc_mapping.Country
          ) AS geographical_axis_nm,
          COALESCE(
            nodef.ISO_COUNTRY_CODE,
            conv_dc_mapping.Country_cd
          ) AS COUNTRY_CD,
          NULL AS LOCATION_AREA_IN_SQFT,
          CASE
            WHEN logf.IS_ABS = 'true' THEN 'Open'
            ELSE 'Close'
          END AS LOCATION_STATUS_CD,
          nodef.LATITUDE_DECIMAL_DEGREE AS latitude_deg,
          nodef.LONGITUDE_DECIMAL_DEGREE AS longitude_deg,
          NULL AS ADDITIONAL_LOCATION_FEATURE_DESC,
          'logec' AS data_source_nm
        FROM
          logec_table_name logf
          LEFT JOIN {node_table_name} nodef ON SUBSTRING(logf.LOCATION_KEY, 4) = nodef.NODE_CODE
          LEFT JOIN ctry_mapping_table_name ccg ON logf.region = ccg.REGION
          LEFT JOIN conv_dc_mapping_table conv_dc_mapping ON logf.LOCATION_KEY = conv_dc_mapping.LOCATION_KEY
        WHERE
          logf.PARENT IN (
            'BIOGAS_CERTIFICATES',
            'COST_HI_SENE_SCOPE1',
            'COST_NATURAL_GAS_SCOPE1',
            'COST_PURCHASED_GAS_BIO_GAS',
            'HI_SENE_SCOPE1',
            'NATURAL_GAS_SCOPE1',
            'PURCHASED_GAS_BIO_GAS'
          )
      )
  )
SELECT
  -- FUEL_CONSUMPTION_UUID,
  fuel_location_nbr,
  fuel_location_nm,
  brand_nm,
  lease_nbr,
  building_id,
  business_group_txt,
  CASE
    WHEN nike_department_type_txt ILIKE '%air mi%' THEN 'Air MI'
    ELSE nike_department_type_txt
  END AS nike_department_type_txt,
  BUSINESS_ENTITY_GEO_REGION_CD,
  FUEL_LOCATION_USE_CD,
  business_function_nm,
  division_nm,
  LOCATION_GEO_REGION_CD,
  continent_nm,
  ADDRESS_LINE_1_TXT,
  city_nm,
  STATE_CD,
  POSTAL_CD,
  geographical_axis_nm,
  COUNTRY_CD,
  CAST(ROUND(value * 10.76, 5) AS DOUBLE) AS LOCATION_AREA_IN_SQFT,
  LOCATION_STATUS_CD,
  latitude_deg,
  longitude_deg,
  ADDITIONAL_LOCATION_FEATURE_DESC,
  data_source_nm
FROM
  existing_query
  INNER JOIN site_size_sqft ON site_size_sqft.location_key = existing_query.location_key
WHERE
  site_size_sqft.max_yr_mn = 1
