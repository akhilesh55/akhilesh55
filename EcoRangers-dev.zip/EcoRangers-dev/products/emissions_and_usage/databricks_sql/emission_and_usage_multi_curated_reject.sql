SELECT
  *
FROM
  {curated_hist_table}
WHERE
  (
    location_nm,
    location_nbr,
    lease_number_desc,
    department_nm,
    service_type_nm
  ) IN (
    SELECT DISTINCT
      location_nm,
      location_nbr,
      lease_number_desc,
      department_nm,
      service_type_nm
    FROM
      {sdf_multi_site_info_table}
    WHERE
      {engie_filter_condition}
  )
