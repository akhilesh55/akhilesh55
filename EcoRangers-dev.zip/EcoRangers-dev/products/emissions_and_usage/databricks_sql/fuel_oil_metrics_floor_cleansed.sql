--Load data from floor raw table to floor cleanse DF. 
SELECT
  NULLIF(TRIM(REPLACE(location_name, CHAR(160), ' ')), '') AS location_nm,
  NULLIF(
    CAST(
      TRIM(REPLACE(location_number, CHAR(160), ' ')) AS INTEGER
    ),
    ''
  ) AS location_nbr,
  NULLIF(TRIM(REPLACE(vendor_name, CHAR(160), ' ')), '') AS vendor_nm,
  NULLIF(TRIM(REPLACE(account_number, CHAR(160), ' ')), '') AS account_nbr,
  NULLIF(
    TRIM(REPLACE(clean_account_number, CHAR(160), ' ')),
    ''
  ) AS clean_account_number_desc,
  TO_DATE(bill_month, 'M/d/yyyy') AS bill_month_dt,
  TO_DATE(bill_type, 'M/d/yyyy') AS bill_type,
  NULLIF(
    CAST(
      TRIM(REPLACE(fiscal_period, CHAR(160), ' ')) AS INTEGER
    ),
    ''
  ) AS fiscal_period,
  TO_DATE(bill_date, 'M/d/yyyy') AS bill_dt,
  TO_DATE(service_begin_date, 'M/d/yyyy') AS service_begin_dt,
  TO_DATE(service_end_date, 'M/d/yyyy') AS service_end_dt,
  NULLIF(TRIM(REPLACE(service_days, CHAR(160), ' ')), '') AS service_days,
  NULLIF(
    TRIM(REPLACE(service_description, CHAR(160), ' ')),
    ''
  ) AS service_desc,
  NULLIF(TRIM(REPLACE(service_alias, CHAR(160), ' ')), '') AS service_alias,
  NULLIF(
    TRIM(REPLACE(customer_gl_number, CHAR(160), ' ')),
    ''
  ) AS customer_gl_nbr,
  NULLIF(TRIM(REPLACE(gl_description, CHAR(160), ' ')), '') AS gl_desc,
  NULLIF(
    CAST(
      TRIM(REPLACE(gl_percent_allocation, CHAR(160), ' ')) AS INTEGER
    ),
    ''
  ) AS gl_allocation_pct,
  NULLIF(TRIM(REPLACE(service_status, CHAR(160), ' ')), '') AS service_status,
  NULLIF(TRIM(REPLACE(service_type, CHAR(160), ' ')), '') AS service_type_nm,
  NULLIF(TRIM(REPLACE(uom, CHAR(160), ' ')), '') AS uom,
  NULLIF(
    CAST(
      TRIM(REPLACE(usage, CHAR(160), ' ')) AS DECIMAL(38, 5)
    ),
    ''
  ) AS usage_qty,
  NULLIF(
    CAST(
      TRIM(REPLACE(usage_per_day, CHAR(160), ' ')) AS DECIMAL(38, 5)
    ),
    ''
  ) AS usage_per_day,
  NULLIF(
    CAST(
      TRIM(REPLACE(billed_quantity, CHAR(160), ' ')) AS DECIMAL(38, 5)
    ),
    ''
  ) AS billed_qty,
  NULLIF(
    CAST(
      TRIM(REPLACE(COST, CHAR(160), ' ')) AS DECIMAL(38, 5)
    ),
    ''
  ) AS COST,
  NULLIF(
    CAST(
      TRIM(REPLACE(cost_per_day, CHAR(160), ' ')) AS DECIMAL(38, 5)
    ),
    ''
  ) AS cost_per_day,
  NULLIF(
    TRIM(REPLACE(location_address_1, CHAR(160), ' ')),
    ''
  ) AS location_address_1_nm,
  NULLIF(
    TRIM(REPLACE(location_address_2, CHAR(160), ' ')),
    ''
  ) AS location_address_2_nm,
  NULLIF(TRIM(REPLACE(location_city, CHAR(160), ' ')), '') AS location_city_nm,
  NULLIF(
    TRIM(
      REPLACE(location_state_or_province, CHAR(160), ' ')
    ),
    ''
  ) AS location_state_or_province_nm,
  NULLIF(
    TRIM(REPLACE(location_postal_code, CHAR(160), ' ')),
    ''
  ) AS location_postal_cd,
  NULLIF(
    TRIM(REPLACE(location_country, CHAR(160), ' ')),
    ''
  ) AS location_country_nm,
  NULLIF(
    TRIM(REPLACE(location_status, CHAR(160), ' ')),
    ''
  ) AS location_status_desc,
  NULLIF(
    TRIM(REPLACE(misc_information, CHAR(160), ' ')),
    ''
  ) AS misc_information_desc,
  NULLIF(
    TRIM(REPLACE(vendor_address_1, CHAR(160), ' ')),
    ''
  ) AS vendor_address_1_nm,
  NULLIF(
    TRIM(REPLACE(vendor_address_2, CHAR(160), ' ')),
    ''
  ) AS vendor_address_2_nm,
  NULLIF(TRIM(REPLACE(vendor_city, CHAR(160), ' ')), '') AS vendor_city_nm,
  NULLIF(
    TRIM(REPLACE(vendor_state_or_province, CHAR(160), ' ')),
    ''
  ) AS vendor_state_or_province_nm,
  NULLIF(
    TRIM(REPLACE(vendor_postal_code, CHAR(160), ' ')),
    ''
  ) AS vendor_postal_cd,
  NULLIF(TRIM(REPLACE(vendor_code, CHAR(160), ' ')), '') AS vendor_cd,
  NULLIF(
    TRIM(REPLACE(vendor_invoice_number, CHAR(160), ' ')),
    ''
  ) AS vendor_invoice_nbr,
  NULLIF(TRIM(REPLACE(vendor_country, CHAR(160), ' ')), '') AS vendor_country_nm,
  NULLIF(
    TRIM(REPLACE(summary_account_number, CHAR(160), ' ')),
    ''
  ) AS summary_account_nbr,
  CAST(
    CASE
      WHEN TRIM(REPLACE(audit_only, CHAR(160), ' ')) = 'Yes' THEN 'Y'
      WHEN TRIM(REPLACE(audit_only, CHAR(160), ' ')) = 'No' THEN 'N'
      ELSE NULL
    END AS CHAR(1)
  ) AS audit_only_ind,
  NULLIF(
    TRIM(REPLACE(account_address_1, CHAR(160), ' ')),
    ''
  ) AS account_address_1_nm,
  NULLIF(
    TRIM(REPLACE(account_address_2, CHAR(160), ' ')),
    ''
  ) AS account_address_2_nm,
  NULLIF(TRIM(REPLACE(account_city, CHAR(160), ' ')), '') AS account_city_nm,
  NULLIF(
    TRIM(
      REPLACE(account_state_or_province, CHAR(160), ' ')
    ),
    ''
  ) AS account_state_or_province_nm,
  NULLIF(
    TRIM(REPLACE(account_postal_code, CHAR(160), ' ')),
    ''
  ) AS account_postal_cd,
  NULLIF(
    TRIM(REPLACE(account_country, CHAR(160), ' ')),
    ''
  ) AS account_country_nm,
  NULLIF(TRIM(REPLACE(account_status, CHAR(160), ' ')), '') AS account_status,
  TO_DATE(account_status_date, 'M/d/yyyy') AS account_status_dt,
  NULLIF(TRIM(REPLACE(account_notes, CHAR(160), ' ')), '') AS account_notes_txt,
  TO_DATE(consolidated_date, 'M/d/yyyy') AS consolidated_dt,
  NULLIF(
    TRIM(
      REPLACE(consolidated_invoice_number, CHAR(160), ' ')
    ),
    ''
  ) AS consolidated_invoice_nbr,
  NULLIF(
    TRIM(
      REPLACE(consolidated_funding_date, CHAR(160), ' ')
    ),
    ''
  ) AS consolidated_funding_dt,
  TO_DATE(due_date, 'M/d/yyyy') AS due_dt,
  TO_DATE(entry_date, 'M/d/yyyy') AS entry_dt,
  TO_DATE(payment_initiated_date, 'M/d/yyyy') AS payment_initiated_dt,
  TO_DATE(payment_clearing_date, 'M/d/yyyy') AS payment_clearing_dt,
  NULLIF(TRIM(REPLACE(check_number, CHAR(160), ' ')), '') AS check_nbr,
  NULLIF(
    TRIM(REPLACE(total_bill_amount, CHAR(160), ' ')),
    ''
  ) AS total_bill_amt,
  NULLIF(
    TRIM(REPLACE(engie_insight_bill_id, CHAR(160), ' ')),
    ''
  ) AS engie_insight_bill_id,
  TO_DATE(engie_insight_receipt_date, 'M/d/yyyy') AS engie_insight_receipt_dt,
  NULLIF(TRIM(REPLACE(meter_number, CHAR(160), ' ')), '') AS meter_number_desc,
  NULLIF(TRIM(REPLACE(rate_schedule, CHAR(160), ' ')), '') AS rate_schedule_desc,
  NULLIF(
    TRIM(REPLACE(service_point_location, CHAR(160), ' ')),
    ''
  ) AS service_point_location_nm,
  CAST(
    CASE
      WHEN TRIM(REPLACE(supplier_only_account, CHAR(160), ' ')) = 'True' THEN 'Y'
      WHEN TRIM(REPLACE(supplier_only_account, CHAR(160), ' ')) = 'False' THEN 'N'
      ELSE NULL
    END AS CHAR(1)
  ) AS supplier_only_account_ind,
  NULLIF(
    TRIM(REPLACE(misc_or_otc_notes, CHAR(160), ' ')),
    ''
  ) AS misc_or_otc_notes,
  NULLIF(
    CAST(
      TRIM(REPLACE(max_demand, CHAR(160), ' ')) AS DECIMAL(38, 5)
    ),
    ''
  ) AS max_demand_qty,
  NULLIF(TRIM(REPLACE(bill_image, CHAR(160), ' ')), '') AS bill_image_desc,
  NULLIF(TRIM(REPLACE(number_floors, CHAR(160), ' ')), '') AS floor_nbr,
  NULLIF(TRIM(REPLACE(alternate_name, CHAR(160), ' ')), '') AS alternate_nm,
  NULLIF(TRIM(REPLACE(baseline_note, CHAR(160), ' ')), '') AS baseline_note_desc,
  CAST(
    CASE
      WHEN TRIM(
        REPLACE(better_buildings_challenge, CHAR(160), ' ')
      ) = 'Yes' THEN 'Y'
      WHEN TRIM(
        REPLACE(better_buildings_challenge, CHAR(160), ' ')
      ) = 'No' THEN 'N'
      ELSE NULL
    END AS CHAR(1)
  ) AS better_buildings_challenge_ind,
  CASE
    WHEN NULLIF(TRIM(REPLACE(department, CHAR(160), ' ')), '') ILIKE 'air mi' THEN 'Air MI'
    ELSE NULLIF(TRIM(REPLACE(department, CHAR(160), ' ')), '')
  END AS department_nm,
  NULLIF(
    TRIM(REPLACE(district_inline, CHAR(160), ' ')),
    ''
  ) AS district_inline_desc,
  NULLIF(
    TRIM(REPLACE(district_outlet, CHAR(160), ' ')),
    ''
  ) AS district_outlet_desc,
  NULLIF(
    CAST(
      TRIM(REPLACE(footprint_sq_ft, CHAR(160), ' ')) AS INTEGER
    ),
    ''
  ) AS footprint_sqft,
  NULLIF(TRIM(REPLACE(in_line_outlet, CHAR(160), ' ')), '') AS in_line_outlet_desc,
  NULLIF(TRIM(REPLACE(lease_number, CHAR(160), ' ')), '') AS lease_number_desc,
  TO_DATE(audit_status_date, 'M/d/yyyy') AS audit_status_dt,
  TO_DATE(contract_expiration_date, 'M/d/yyyy') AS contract_expiration_dt,
  NULLIF(TRIM(REPLACE(contract_name, CHAR(160), ' ')), '') AS contract_nm,
  NULLIF(
    TRIM(REPLACE(contract_status, CHAR(160), ' ')),
    ''
  ) AS contract_status_desc,
  TO_TIMESTAMP(created_at_tmst) AS created_at_tmst,
  NULLIF(TRIM(REPLACE(user_nm, CHAR(160), ' ')), '') AS user_nm,
  NULLIF(TRIM(REPLACE(file_nm, CHAR(160), ' ')), '') AS file_nm,
  TO_DATE(load_dt, 'yyyy-MM-dd') AS load_dt,
  NULLIF(
    CAST(
      TRIM(REPLACE(load_year_nbr, CHAR(160), ' ')) AS INTEGER
    ),
    ''
  ) AS load_year_nbr,
  NULLIF(
    CAST(
      TRIM(REPLACE(load_month_nbr, CHAR(160), ' ')) AS INTEGER
    ),
    ''
  ) AS load_month_nbr
FROM
  {temp_view_name}
