WITH
  DETAILS_AGG AS (
    SELECT
      FUEL_LOCATION_NBR,
      reporting_period_dt,
      brand_nm,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      BILLING_MONTH_DATE_RANGE_TXT,
      FUEL_LOCATION_NM,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      building_id,
      SERVICE_TYPE_CD,
      fuel_type_txt,
      saf_pct,
      saf_density_uom,
      NET_HEAT_OF_COMBUSTION_UOM,
      DATA_FREQUENCY_CD,
      COALESCE(MAX(SERVICE_USAGE_QTY), MIN(SERVICE_USAGE_QTY)) AS SERVICE_USAGE_QTY,
      COALESCE(
        MAX(SERVICE_USAGE_QTY_UOM),
        MIN(SERVICE_USAGE_QTY_UOM)
      ) AS SERVICE_USAGE_QTY_UOM,
      COALESCE(MAX(SERVICE_COST), MIN(SERVICE_COST)) AS SERVICE_COST,
      COALESCE(MAX(SERVICE_COST_UOM), MIN(SERVICE_COST_UOM)) AS SERVICE_COST_UOM,
      EXTRAPOLATION_IND,
      scope_nbr,
      data_source_nm
    FROM
      (
        SELECT
          SUBSTRING(logf.LOCATION_KEY, 4) AS FUEL_LOCATION_NBR,
          TO_DATE(logf.YEAR_MONTH, 'yyyy-MM') AS reporting_period_dt,
          CASE
            WHEN logf.SCENARIO_NAME = 'CONVERSE' THEN 'CONVERSE'
            ELSE 'NIKE'
          END AS brand_nm,
          TO_DATE(logf.YEAR_MONTH, 'yyyy-MM') AS BILLING_MONTH_START_DT,
          LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')) AS BILLING_MONTH_END_DT,
          CONCAT(
            DATE_FORMAT(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM'), 'MM/dd/yyyy'),
            '-',
            DATE_FORMAT(
              LAST_DAY(TO_DATE(logf.YEAR_MONTH, 'yyyy-MM')),
              'MM/dd/yyyy'
            )
          ) AS BILLING_MONTH_DATE_RANGE_TXT,
          -- logf.LOCATION_NAME AS FUEL_LOCATION_NM,
          COALESCE(nodef.NAME, logf.LOCATION_NAME) AS FUEL_LOCATION_NM,
          cd.FISCAL_YEAR_NM AS REPORTING_FISCAL_YEAR_NBR,
          cd.YEAR_NBR AS REPORTING_CALENDAR_YEAR_NBR,
          cd.MONTH_LONG_NM AS REPORTING_MONTH_LONG_NM,
          cd.MONTH_OF_YEAR_NBR AS REPORTING_MONTH_OF_YEAR_NBR,
          cd.QUARTER_NBR AS REPORTING_QUARTER_NBR,
          cd.WEEK_OF_YEAR_NBR AS REPORTING_WEEK_OF_YEAR_NBR,
          NULL AS building_id,
          CASE
            WHEN logf.PARENT = service_tbl.PARENT THEN service_tbl.SERVICE_TYPE
            ELSE logf.PARENT
          END AS SERVICE_TYPE_CD,
          CASE
            WHEN logf.PARENT = service_tbl.PARENT THEN service_tbl.SERVICE_TYPE
            ELSE logf.PARENT
          END AS fuel_type_txt,
          CAST(NULL AS DECIMAL) AS saf_pct,
          CAST(NULL AS DECIMAL) AS saf_density_uom,
          CAST(NULL AS DECIMAL) AS net_heat_of_combustion_uom,
          CAST(12 AS INTEGER) AS DATA_FREQUENCY_CD,
          CASE
            WHEN logf.PARENT IN (
              'BIOGAS_CERTIFICATES',
              'HI_SENE_SCOPE1',
              'NATURAL_GAS_SCOPE1',
              'PURCHASED_GAS_BIO_GAS'
            ) THEN logf.VALUE
            ELSE NULL
          END AS SERVICE_USAGE_QTY,
          CASE
            WHEN logf.PARENT IN (
              'BIOGAS_CERTIFICATES',
              'HI_SENE_SCOPE1',
              'NATURAL_GAS_SCOPE1',
              'PURCHASED_GAS_BIO_GAS'
            ) THEN logf.UNIT
            ELSE NULL
          END AS SERVICE_USAGE_QTY_UOM,
          CASE
            WHEN logf.PARENT IN (
              'COST_HI_SENE_SCOPE1',
              'COST_NATURAL_GAS_SCOPE1',
              'COST_PURCHASED_GAS_BIO_GAS'
            ) THEN logf.VALUE
            ELSE NULL
          END AS SERVICE_COST,
          CASE
            WHEN logf.PARENT IN (
              'COST_HI_SENE_SCOPE1',
              'COST_NATURAL_GAS_SCOPE1',
              'COST_PURCHASED_GAS_BIO_GAS'
            ) THEN logf.CURRENCY
            ELSE NULL
          END AS SERVICE_COST_UOM,
          'NO' AS EXTRAPOLATION_IND,
          CASE
            WHEN logf.PARENT IN (
              'BIOGAS_CERTIFICATES',
              'COST_HI_SENE_SCOPE1',
              'COST_NATURAL_GAS_SCOPE1',
              'COST_PURCHASED_GAS_BIO_GAS',
              'HI_SENE_SCOPE1',
              'NATURAL_GAS_SCOPE1',
              'PURCHASED_GAS_BIO_GAS'
            ) THEN 'SCOPE 1'
            ELSE NULL
          END AS scope_nbr,
          'logec' AS data_source_nm
        FROM
          logec_table_name logf
          LEFT JOIN {calendar_table_name} cd ON TO_DATE(logf.YEAR_MONTH, 'yyyy-MM') = CAST(cd.calendar_dt AS STRING)
          LEFT JOIN node_table_name nodef ON SUBSTRING(logf.LOCATION_KEY, 4) = nodef.NODE_CODE
          LEFT JOIN bcl_service_type service_tbl ON logf.LOCATION_KEY = service_tbl.LOCATION_KEY
          AND logf.LOCATION_NAME = service_tbl.LOCATION_NAME
          AND logf.PARENT = service_tbl.PARENT
        WHERE
          logf.PARENT IN (
            'BIOGAS_CERTIFICATES',
            'COST_HI_SENE_SCOPE1',
            'COST_NATURAL_GAS_SCOPE1',
            'COST_PURCHASED_GAS_BIO_GAS',
            'HI_SENE_SCOPE1',
            'NATURAL_GAS_SCOPE1',
            'PURCHASED_GAS_BIO_GAS'
          )
      )
    GROUP BY
      FUEL_LOCATION_NBR,
      reporting_period_dt,
      brand_nm,
      BILLING_MONTH_START_DT,
      BILLING_MONTH_END_DT,
      BILLING_MONTH_DATE_RANGE_TXT,
      FUEL_LOCATION_NM,
      REPORTING_FISCAL_YEAR_NBR,
      REPORTING_CALENDAR_YEAR_NBR,
      REPORTING_MONTH_LONG_NM,
      REPORTING_MONTH_OF_YEAR_NBR,
      REPORTING_QUARTER_NBR,
      REPORTING_WEEK_OF_YEAR_NBR,
      building_id,
      SERVICE_TYPE_CD,
      fuel_type_txt,
      saf_pct,
      saf_density_uom,
      net_heat_of_combustion_uom,
      DATA_FREQUENCY_CD,
      EXTRAPOLATION_IND,
      scope_nbr,
      data_source_nm
  )
SELECT
  FUEL_DETAIL.fuel_location_nbr,
  FUEL_DETAIL.fuel_location_nm,
  INITCAP(FUEL_DETAIL.brand_nm) AS brand_nm,
  FUEL_DETAIL.reporting_period_dt,
  CASE
    WHEN FUEL_DETAIL.SERVICE_TYPE_CD ILIKE 'Electric' THEN 'Electricity'
    ELSE FUEL_DETAIL.SERVICE_TYPE_CD
  END AS SERVICE_TYPE_CD,
  FUEL_DETAIL.BILLING_MONTH_START_DT,
  FUEL_DETAIL.BILLING_MONTH_END_DT,
  FUEL_DETAIL.BILLING_MONTH_DATE_RANGE_TXT,
  REGEXP_REPLACE(
    FUEL_DETAIL.REPORTING_FISCAL_YEAR_NBR,
    '[^0-9]',
    ''
  ) AS REPORTING_FISCAL_YEAR_NBR,
  FUEL_DETAIL.REPORTING_CALENDAR_YEAR_NBR,
  FUEL_DETAIL.REPORTING_MONTH_LONG_NM,
  FUEL_DETAIL.REPORTING_MONTH_OF_YEAR_NBR,
  FUEL_DETAIL.REPORTING_QUARTER_NBR,
  FUEL_DETAIL.REPORTING_WEEK_OF_YEAR_NBR,
  FUEL_DETAIL.building_id,
  FUEL_DETAIL.fuel_type_txt,
  CAST(FUEL_DETAIL.saf_pct AS STRING),
  CAST(FUEL_DETAIL.saf_density_uom AS STRING),
  FUEL_DETAIL.DATA_FREQUENCY_CD,
  CAST(FUEL_DETAIL.SERVICE_USAGE_QTY AS DOUBLE),
  INITCAP(FUEL_DETAIL.SERVICE_USAGE_QTY_UOM) AS SERVICE_USAGE_QTY_UOM,
  FUEL_DETAIL.SERVICE_COST,
  FUEL_DETAIL.SERVICE_COST_UOM,
  FUEL_DETAIL.extrapolation_ind,
  FUEL_DETAIL.scope_nbr,
  FUEL_DETAIL.data_source_nm
FROM
  DETAILS_AGG FUEL_DETAIL
