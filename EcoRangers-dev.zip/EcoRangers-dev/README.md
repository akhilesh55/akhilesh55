# Repo for SDF / SEAM ITC Team (Ecorangers)

This repository inherits the SEC/Databricks Sole referential architecture for storing the code/artifacts.

Team Details:

| Section               |                  Details                  |
| --------------------- | :---------------------------------------: |
| Engineering Director  |          Bharath Hegde (BHegd2)           |
| SDF Product Owner     |          Sonali Patnaik (Spatn)           |
| SEAM Product Owner    |            Hina Goyal (HGoyal)            |
| SDF Engineering Lead  |          Prasad Nadiger (Pnadig)          |
| SEAM Engineering Lead |           Subhasis Deb (SDeb1)            |
| SDF Team DL           | <Lst-Technology.EDAI.Ecorangers@nike.com> |
| SEAM Team DL          |    <Lst-Technology.EDAI.SEAM@nike.com>    |
